import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon
import os , sys , time , xbmcvfs , glob , shutil , datetime , zipfile , ntpath
import subprocess , threading
import yt , downloader , checkPath
import binascii
import hashlib
import speedtest
import extract
try :
 from sqlite3 import dbapi2 as database
 if 64 - 64: i11iIiiIii
except :
 from pysqlite2 import dbapi2 as database
 if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
from addon . common . addon import Addon
from addon . common . net import Net
if 73 - 73: II111iiii
######################################################
IiII1IiiIiI1 = 'plugin.program.totalinstaller'
iIiiiI1IiI1I1 = 'The Community Portal'
if 87 - 87: OoOoOO00
I11i = xbmcaddon . Addon ( id = IiII1IiiIiI1 )
zip = I11i . getSetting ( 'zip' )
O0O = I11i . getSetting ( 'localcopy' )
Oo = I11i . getSetting ( 'private' )
I1ii11iIi11i = I11i . getSetting ( 'reseller' )
I1IiI = I11i . getSetting ( 'openelec' )
o0OOO = I11i . getSetting ( 'favourites' )
iIiiiI = I11i . getSetting ( 'sources' )
Iii1ii1II11i = I11i . getSetting ( 'repositories' )
iI111iI = I11i . getSetting ( 'enablekeyword' )
IiII = I11i . getSetting ( 'keywordpath' )
iI1Ii11111iIi = I11i . getSetting ( 'keywordname' )
i1i1II = I11i . getSetting ( 'mastercopy' )
O0oo0OO0 = I11i . getSetting ( 'username' ) . replace ( ' ' , '%20' )
I1i1iiI1 = I11i . getSetting ( 'password' )
iiIIIII1i1iI = I11i . getSetting ( 'versionoverride' )
o0oO0 = I11i . getSetting ( 'login' )
oo00 = I11i . getSetting ( 'addonportal' )
o00 = I11i . getSetting ( 'maintenance' )
Oo0oO0ooo = I11i . getSetting ( 'hardwareportal' )
o0oOoO00o = I11i . getSetting ( 'maintenance' )
i1 = I11i . getSetting ( 'latestnews' )
oOOoo00O0O = I11i . getSetting ( 'tutorialportal' )
i1111 = I11i . getSetting ( 'startupvideo' )
i11 = I11i . getSetting ( 'startupvideopath' )
I11 = I11i . getSetting ( 'wizard' )
Oo0o0000o0o0 = I11i . getSetting ( 'wizardurl1' )
oOo0oooo00o = I11i . getSetting ( 'wizardname1' )
oO0o0o0ooO0oO = I11i . getSetting ( 'wizardurl2' )
oo0o0O00 = I11i . getSetting ( 'wizardname2' )
oO = I11i . getSetting ( 'wizardurl3' )
i1iiIIiiI111 = I11i . getSetting ( 'wizardname3' )
oooOOOOO = I11i . getSetting ( 'wizardurl4' )
i1iiIII111ii = I11i . getSetting ( 'wizardname4' )
i1iIIi1 = I11i . getSetting ( 'wizardurl5' )
ii11iIi1I = I11i . getSetting ( 'wizardname5' )
iI111I11I1I1 = I11i . getSetting ( 'trcheck' )
OOooO0OOoo = xbmcgui . Dialog ( )
iIii1 = xbmcgui . DialogProgress ( )
oOOoO0 = xbmc . translatePath ( 'special://home/' )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'addon_data' ) )
II = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'Database' ) )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'Thumbnails' ) )
OooO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( OooO0 , IiII1IiiIiI1 , 'default.py' ) )
OO0o = xbmc . translatePath ( os . path . join ( OooO0 , IiII1IiiIiI1 , 'fanart.jpg' ) )
Ooo = xbmc . translatePath ( os . path . join ( OooO0 , IiII1IiiIiI1 , 'resources' , 'addonxml' ) )
O0o0Oo = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'guisettings.xml' ) )
Oo00OOOOO = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'guifix.xml' ) )
O0OO00o0OO = 'http://www.noobsandnerds.com/TI/artwork/'
I11i1 = xbmc . translatePath ( os . path . join ( OooO0 , IiII1IiiIiI1 , 'icon_menu.png' ) )
iIi1ii1I1 = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'favourites.xml' ) )
o0 = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'sources.xml' ) )
I11II1i = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'advancedsettings.xml' ) )
IIIII = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'profiles.xml' ) )
ooooooO0oo = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'RssFeeds.xml' ) )
IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'keymaps' , 'keyboard.xml' ) )
I1IIIii = xbmc . translatePath ( os . path . join ( zip ) )
oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , '' ) )
OOOO = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'startup.xml' ) )
OOO00 = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'temp.xml' ) )
iiiiiIIii = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'id.xml' ) )
O000OO0 = xbmc . translatePath ( os . path . join ( OooO0 , 'repository.totalinstaller' ) )
I11iii1Ii = xbmc . translatePath ( os . path . join ( OooO0 , 'repository.totalrevolution' ) )
I1IIiiIiii = xbmc . translatePath ( os . path . join ( OooO0 , 'plugin.program.totalrevolution' ) )
O000oo0O = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'idtemp.xml' ) )
OOOOi11i1 = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'temp' ) )
IIIii1II1II = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'ascii_results' ) )
i1I1iI = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'ascii_results1' ) )
oo0OooOOo0 = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'ascii_results2' ) )
o0O = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'guizip' ) )
O00oO = xbmc . translatePath ( os . path . join ( OooO0 , IiII1IiiIiI1 , 'resources/' ) )
I11i1I1I = xbmc . translatePath ( os . path . join ( OooO0 , IiII1IiiIiI1 , 'default.py' ) )
oO0Oo = xbmc . getSkinDir ( )
oOOoo0Oo = xbmc . translatePath ( 'special://logpath/' )
o00OO00OoO = '/storage/backup'
OOOO0OOoO0O0 = '/storage/.restore/'
O0Oo000ooO00 = Net ( )
oO0 = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 ) )
Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( oO0 , 'guinew.xml' ) )
ooOooo000oOO = xbmc . translatePath ( os . path . join ( oO0 , 'guitemp' , '' ) )
Oo0oOOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Database' ) )
Oo0OoO00oOO0o = os . path . join ( OooO0 , 'packages' )
OOO00O = os . path . join ( O0OoO000O0OO , 'addontemp' )
OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , '.cbcfg' ) )
O0o0O00Oo0o0 = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' ]
O00O0oOO00O00 = 0.0
i1Oo00 = 0.0
i1i = '0'
iiI111I1iIiI = [ '/storage/.kodi' , '/storage/.cache' , '/storage/.config' , '/storage/.ssh' ]
IIIi1I1IIii1II = '1889903'
if 65 - 65: oOo . iii1i1iiiiIi % ooo0O . oOoO0o00OO0
if 7 - 7: oooOooOOo0OO + II11iIiIIIiI - o0o
if 84 - 84: IIIIiiII111
class OOoOoo ( xbmcgui . WindowXMLDialog ) :
 if 85 - 85: O00OOo00oo0o % IIiIi1iI + i1IiiiI1iI
 def __init__ ( self , * args , ** kwargs ) :
  self . shut = kwargs [ 'close_time' ]
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
  if 49 - 49: oo0O0oO / iiii - i11iIiiIii
 def onFocus ( self , controlID ) :
  pass
  if 75 - 75: IIIIiiII111 + oOoO0o00OO0
 def onClick ( self , controlID ) :
  if controlID == 12 :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 84 - 84: i1IiiiI1iI . i11iIiiIii . i1IiiiI1iI * oooOooOOo0OO - IIIIiiII111
 def onAction ( self , action ) :
  if action in [ 5 , 6 , 7 , 9 , 10 , 92 , 117 ] or action . getButtonCode ( ) in [ 275 , 257 , 261 ] :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 42 - 42: i11iIiiIii
 def _close_dialog ( self ) :
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  time . sleep ( .4 )
  self . close ( )
  if 33 - 33: IIiIi1iI - O0 * i1IIi * oOoO0o00OO0 - oOo
  if 32 - 32: OoooooooOO / iIii1I11I1II1 - oOoO0o00OO0
def o00oooO0Oo ( name , url , mode , iconimage , fanart , video , description , skins , guisettingslink , artpack ) :
 o0O0OOO0Ooo = sys . argv [ 0 ]
 o0O0OOO0Ooo += "?url=" + urllib . quote_plus ( url )
 o0O0OOO0Ooo += "&mode=" + str ( mode )
 o0O0OOO0Ooo += "&name=" + urllib . quote_plus ( name )
 o0O0OOO0Ooo += "&iconimage=" + urllib . quote_plus ( iconimage )
 o0O0OOO0Ooo += "&fanart=" + urllib . quote_plus ( fanart )
 o0O0OOO0Ooo += "&video=" + urllib . quote_plus ( video )
 o0O0OOO0Ooo += "&description=" + urllib . quote_plus ( description )
 o0O0OOO0Ooo += "&skins=" + urllib . quote_plus ( skins )
 o0O0OOO0Ooo += "&guisettingslink=" + urllib . quote_plus ( guisettingslink )
 o0O0OOO0Ooo += "&artpack=" + urllib . quote_plus ( artpack )
 if 45 - 45: O0 / oOoO0o00OO0
 i1IIIII11I1IiI = True
 i1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 72 - 72: i1IIi / iii1i1iiiiIi + OoooooooOO - oOo
 i1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I . setProperty ( "Fanart_Image" , fanart )
 i1I . setProperty ( "Build.Video" , video )
 if 29 - 29: oooOooOOo0OO + II11iIiIIIiI % O0
 if ( mode == None ) or ( mode == 'restore_option' ) or ( mode == 'backup_option' ) or ( mode == 'cb_root_menu' ) or ( mode == 'genres' ) or ( mode == 'grab_builds' ) or ( mode == 'community_menu' ) or ( mode == 'instructions' ) or ( mode == 'countries' ) or ( mode == 'update_build' ) or ( url == None ) or ( len ( url ) < 1 ) :
  if 10 - 10: IIIIiiII111 / oo0O0oO - OoOoOO00 * iIii1I11I1II1 - OoOoOO00
  i1IIIII11I1IiI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0O0OOO0Ooo , listitem = i1I , isFolder = True )
  if 97 - 97: oooOooOOo0OO + OoOoOO00 * O00OOo00oo0o + o0o % IIiIi1iI
 else :
  i1IIIII11I1IiI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0O0OOO0Ooo , listitem = i1I , isFolder = False )
  if 74 - 74: II11iIiIIIiI - oOo + OoooooooOO + oo0O0oO / ooo0O
 return i1IIIII11I1IiI
 if 23 - 23: O0
 if 85 - 85: O00OOo00oo0o
def OO ( handle , url , listitem , isFolder ) :
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 77 - 77: oOo
 if 17 - 17: IIiIi1iI % iii1i1iiiiIi . o0o + iii1i1iiiiIi / II111iiii
def oo0O0O00 ( name , url , mode , iconimage , fanart , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 if 47 - 47: oOoO0o00OO0 + iiii
 iconimage = I11i1
 if 82 - 82: II111iiii . i1IiiiI1iI - iIii1I11I1II1 - i1IiiiI1iI * II111iiii
 o0O0OOO0Ooo = sys . argv [ 0 ]
 o0O0OOO0Ooo += "?url=" + urllib . quote_plus ( url )
 o0O0OOO0Ooo += "&mode=" + str ( mode )
 o0O0OOO0Ooo += "&name=" + urllib . quote_plus ( name )
 o0O0OOO0Ooo += "&iconimage=" + urllib . quote_plus ( iconimage )
 o0O0OOO0Ooo += "&fanart=" + urllib . quote_plus ( fanart )
 o0O0OOO0Ooo += "&author=" + urllib . quote_plus ( author )
 o0O0OOO0Ooo += "&description=" + urllib . quote_plus ( description )
 o0O0OOO0Ooo += "&version=" + urllib . quote_plus ( version )
 o0O0OOO0Ooo += "&buildname=" + urllib . quote_plus ( buildname )
 o0O0OOO0Ooo += "&updated=" + urllib . quote_plus ( updated )
 o0O0OOO0Ooo += "&skins=" + urllib . quote_plus ( skins )
 o0O0OOO0Ooo += "&videoaddons=" + urllib . quote_plus ( videoaddons )
 o0O0OOO0Ooo += "&audioaddons=" + urllib . quote_plus ( audioaddons )
 o0O0OOO0Ooo += "&buildname=" + urllib . quote_plus ( buildname )
 o0O0OOO0Ooo += "&programaddons=" + urllib . quote_plus ( programaddons )
 o0O0OOO0Ooo += "&pictureaddons=" + urllib . quote_plus ( pictureaddons )
 o0O0OOO0Ooo += "&sources=" + urllib . quote_plus ( sources )
 o0O0OOO0Ooo += "&adult=" + urllib . quote_plus ( adult )
 if 77 - 77: iIii1I11I1II1 * iii1i1iiiiIi
 i1IIIII11I1IiI = True
 i1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 95 - 95: OoOoOO00 + i11iIiiIii
 i1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I . setProperty ( "Fanart_Image" , fanart )
 i1I . setProperty ( "Build.Video" , I1Ii )
 if 94 - 94: O00OOo00oo0o - II111iiii . o0o % IIIIiiII111 . i11iIiiIii + O0
 i1IIIII11I1IiI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0O0OOO0Ooo , listitem = i1I , isFolder = False )
 if 26 - 26: IIIIiiII111 - iIii1I11I1II1 - OoOoOO00 / iii1i1iiiiIi . ooo0O % iIii1I11I1II1
 return i1IIIII11I1IiI
 if 91 - 91: oOoO0o00OO0 . iIii1I11I1II1 / II11iIiIIIiI + i1IIi
def I1i ( title , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' , zip_link = '' , repo_link = '' , repo_id = '' , addon_id = '' , provider_name = '' , forum = '' , data_path = '' ) :
 if len ( iconimage ) > 0 :
  if 53 - 53: oooOooOOo0OO * ooo0O + iiii - II111iiii
  iconimage = I11i1
 else :
  iconimage = 'DefaultFolder.png'
  if 2 - 2: IIIIiiII111 + O00OOo00oo0o - OoOoOO00 % oOoO0o00OO0 . IIiIi1iI
 if fanart == '' :
  fanart = OO0o
  if 18 - 18: o0o + IIiIi1iI - O00OOo00oo0o . II111iiii + i11iIiiIii
 o0O0OOO0Ooo = sys . argv [ 0 ]
 o0O0OOO0Ooo += "?url=" + urllib . quote_plus ( url )
 o0O0OOO0Ooo += "&zip_link=" + urllib . quote_plus ( zip_link )
 o0O0OOO0Ooo += "&repo_link=" + urllib . quote_plus ( repo_link )
 o0O0OOO0Ooo += "&data_path=" + urllib . quote_plus ( data_path )
 o0O0OOO0Ooo += "&provider_name=" + str ( provider_name )
 o0O0OOO0Ooo += "&forum=" + str ( forum )
 o0O0OOO0Ooo += "&repo_id=" + str ( repo_id )
 o0O0OOO0Ooo += "&addon_id=" + str ( addon_id )
 o0O0OOO0Ooo += "&mode=" + str ( mode )
 o0O0OOO0Ooo += "&name=" + urllib . quote_plus ( name )
 o0O0OOO0Ooo += "&fanart=" + urllib . quote_plus ( fanart )
 o0O0OOO0Ooo += "&video=" + urllib . quote_plus ( video )
 o0O0OOO0Ooo += "&description=" + urllib . quote_plus ( description )
 if 20 - 20: oo0O0oO
 i1IIIII11I1IiI = True
 i1I = xbmcgui . ListItem ( title , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 52 - 52: II111iiii - OoooooooOO % O00OOo00oo0o + OoOoOO00 * oOo . i1IiiiI1iI
 i1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I . setProperty ( "Fanart_Image" , fanart )
 i1I . setProperty ( "Build.Video" , video )
 if 75 - 75: iiii + ooo0O + oOoO0o00OO0 * IIIIiiII111 % II11iIiIIIiI . IIiIi1iI
 OO ( handle = int ( sys . argv [ 1 ] ) , url = o0O0OOO0Ooo , listitem = i1I , isFolder = False )
 if 55 - 55: o0o . OoOoOO00
 if 61 - 61: oOo % i1IiiiI1iI . oOo
def o0oOO000oO0oo ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if type != 'addon' :
  if 78 - 78: oooOooOOo0OO + o0o - oo0O0oO
  if len ( iconimage ) > 0 :
   iconimage = O0OO00o0OO + iconimage
   if 38 - 38: oOoO0o00OO0 - II11iIiIIIiI + iIii1I11I1II1 / ooo0O % oOo
  else :
   iconimage = I11i1
   if 57 - 57: iii1i1iiiiIi / iiii
 if type == 'addon' :
  if 29 - 29: iIii1I11I1II1 + ooo0O * iii1i1iiiiIi * o0o . OoOoOO00 * OoOoOO00
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'DefaultFolder.png'
   if 7 - 7: i1IiiiI1iI * oo0O0oO % O00OOo00oo0o - oOoO0o00OO0
   if 13 - 13: O00OOo00oo0o . i11iIiiIii
   if 56 - 56: oooOooOOo0OO % O0 - OoOoOO00
 if fanart == '' :
  fanart = OO0o
  if 100 - 100: O00OOo00oo0o - O0 % II11iIiIIIiI * o0o + OoOoOO00
 o0O0OOO0Ooo = sys . argv [ 0 ]
 o0O0OOO0Ooo += "?url=" + urllib . quote_plus ( url )
 o0O0OOO0Ooo += "&mode=" + str ( mode )
 o0O0OOO0Ooo += "&name=" + urllib . quote_plus ( name )
 o0O0OOO0Ooo += "&iconimage=" + urllib . quote_plus ( iconimage )
 o0O0OOO0Ooo += "&fanart=" + urllib . quote_plus ( fanart )
 o0O0OOO0Ooo += "&video=" + urllib . quote_plus ( video )
 o0O0OOO0Ooo += "&description=" + urllib . quote_plus ( description )
 if 88 - 88: OoooooooOO - iii1i1iiiiIi * O0 * OoooooooOO . OoooooooOO
 i1IIIII11I1IiI = True
 i1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 33 - 33: oo0O0oO + IIiIi1iI * II11iIiIIIiI / iIii1I11I1II1 - OoOoOO00
 i1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1I . setProperty ( "Fanart_Image" , fanart )
 i1I . setProperty ( "Build.Video" , video )
 if 54 - 54: oo0O0oO / o0o . II11iIiIIIiI % IIiIi1iI
 if ( type == 'folder' ) or ( type == 'folder2' ) or ( type == 'tutorial_folder' ) or ( type == 'news_folder' ) :
  i1IIIII11I1IiI = OO ( handle = int ( sys . argv [ 1 ] ) , url = o0O0OOO0Ooo , listitem = i1I , isFolder = True )
  if 57 - 57: i11iIiiIii . oooOooOOo0OO - O00OOo00oo0o - II11iIiIIIiI + ooo0O
 else :
  i1IIIII11I1IiI = OO ( handle = int ( sys . argv [ 1 ] ) , url = o0O0OOO0Ooo , listitem = i1I , isFolder = False )
  if 63 - 63: ooo0O * IIiIi1iI
 return i1IIIII11I1IiI
 if 69 - 69: O0 . iii1i1iiiiIi
 if 49 - 49: OoOoOO00 - IIIIiiII111
def OoOOoOooooOOo ( url ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Audio' , url + '&typex=audio' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Image (Picture)' , url + '&typex=image' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Program' , url + '&typex=program' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Video' , url + '&typex=video' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Movies (Used for library scanning)' , url + '&typex=movie%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] TV Shows (Used for library scanning)' , url + '&typex=tv%20show%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Artists (Used for library scanning)' , url + '&typex=artist%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Videos (Used for library scanning)' , url + '&typex=music%20video%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] All Services' , url + '&typex=service' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] Weather Service' , url + '&typex=weather' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Repositories' , url + '&typex=repository' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Scripts (Program Add-ons)' , url + '&typex=executable' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Screensavers' , url + '&typex=screensaver' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Script Modules' , url + '&typex=script%20module' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Skins' , url + '&typex=skin' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Subtitles' , url + '&typex=subtitles' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Web Interface' , url + '&typex=web%20interface' , 'grab_addons' , '' , '' , '' , '' )
 if 87 - 87: OoOoOO00
 if 58 - 58: ooo0O % oOoO0o00OO0
def i1OOoO ( ) :
 OO0O000 ( )
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://outdated/",return)' )
 if 37 - 37: OoooooooOO - O0 - oOoO0o00OO0
 if 77 - 77: o0o * iIii1I11I1II1
def oO00oOOoooO ( url ) :
 o0oOO000oO0oo ( 'folder' , 'African' , url + '&genre=african' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Arabic' , url + '&genre=arabic' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Asian' , url + '&genre=asian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Australian' , url + '&genre=australian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Austrian' , url + '&genre=austrian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Belgian' , url + '&genre=belgian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Brazilian' , url + '&genre=brazilian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Canadian' , url + '&genre=canadian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Chinese' , url + '&genre=chinese' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Colombian' , url + '&genre=columbian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Croatian' , url + '&genre=croatian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Czech' , url + '&genre=czech' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Danish' , url + '&genre=danish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Dominican' , url + '&genre=dominican' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Dutch' , url + '&genre=dutch' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Egyptian' , url + '&genre=egyptian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Filipino' , url + '&genre=filipino' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Finnish' , url + '&genre=finnish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'French' , url + '&genre=french' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'German' , url + '&genre=german' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Greek' , url + '&genre=greek' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Hebrew' , url + '&genre=hebrew' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Hungarian' , url + '&genre=hungarian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Icelandic' , url + '&genre=icelandic' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Indian' , url + '&genre=indian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Irish' , url + '&genre=irish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Italian' , url + '&genre=italian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Japanese' , url + '&genre=japanese' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Korean' , url + '&genre=korean' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Lebanese' , url + '&genre=lebanese' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Mongolian' , url + '&genre=mongolian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Moroccan' , url + '&genre=moroccan' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Nepali' , url + '&genre=nepali' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'New Zealand' , url + '&genre=newzealand' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Norwegian' , url + '&genre=norwegian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Pakistani' , url + '&genre=pakistani' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Polish' , url + '&genre=polish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Portuguese' , url + '&genre=portuguese' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Romanian' , url + '&genre=romanian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Russian' , url + '&genre=russian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Singapore' , url + '&genre=singapore' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Spanish' , url + '&genre=spanish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Swedish' , url + '&genre=swedish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Swiss' , url + '&genre=swiss' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Syrian' , url + '&genre=syrian' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Tamil' , url + '&genre=tamil' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Thai' , url + '&genre=thai' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Turkish' , url + '&genre=turkish' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'UK' , url + '&genre=uk' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'USA' , url + '&genre=usa' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Vietnamese' , url + '&genre=vietnamese' , 'grab_addons' , '' , '' , '' , '' )
 if 46 - 46: OoOoOO00 - OoooooooOO - IIIIiiII111 * II111iiii
 if 34 - 34: IIIIiiII111 - IIiIi1iI / o0o + oooOooOOo0OO * O00OOo00oo0o
def OOOO0OoOO0o0o ( url ) :
 oo = 'http://noobsandnerds.com/TI/AddonPortal/addondetails.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 92 - 92: O00OOo00oo0o + II11iIiIIIiI % o0o
 oOo0 = re . compile ( 'addon_types="(.+?)"' ) . findall ( I1111i )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 Oo0O0 = re . compile ( 'UID="(.+?)"' ) . findall ( I1111i )
 Ooo0OOoOoO0 = re . compile ( 'id="(.+?)"' ) . findall ( I1111i )
 oOo0OOoO0 = re . compile ( 'provider_name="(.+?)"' ) . findall ( I1111i )
 IIo0Oo0oO0oOO00 = re . compile ( 'version="(.+?)"' ) . findall ( I1111i )
 oo00OO0000oO = re . compile ( 'created="(.+?)"' ) . findall ( I1111i )
 I1II1 = re . compile ( 'addon_types="(.+?)"' ) . findall ( I1111i )
 oooO = re . compile ( 'updated="(.+?)"' ) . findall ( I1111i )
 i1I1i111Ii = re . compile ( 'downloads="(.+?)"' ) . findall ( I1111i )
 if 67 - 67: OoOoOO00 . i1IIi
 i1i1iI1iiiI = re . compile ( 'description="(.+?)"' ) . findall ( I1111i )
 Ooo0oOooo0 = re . compile ( 'devbroke="(.+?)"' ) . findall ( I1111i )
 oOOOoo00 = re . compile ( 'broken="(.+?)"' ) . findall ( I1111i )
 iiIiIIIiiI = re . compile ( 'deleted="(.+?)"' ) . findall ( I1111i )
 iiI1IIIi = re . compile ( 'mainbranch_notes="(.+?)"' ) . findall ( I1111i )
 if 47 - 47: oOo % IIIIiiII111 % i11iIiiIii - O0 + iiii
 ooO000OO0O00O = re . compile ( 'repo_url="(.+?)"' ) . findall ( I1111i )
 OOOoOO0o = re . compile ( 'data_url="(.+?)"' ) . findall ( I1111i )
 i1II1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( I1111i )
 i11i1 = re . compile ( 'genres="(.+?)"' ) . findall ( I1111i )
 IiiiiI1i1Iii = re . compile ( 'forum="(.+?)"' ) . findall ( I1111i )
 oo00oO0o = re . compile ( 'repo_id="(.+?)"' ) . findall ( I1111i )
 iiii111II = re . compile ( 'license="(.+?)"' ) . findall ( I1111i )
 I11iIiI1I1i11 = re . compile ( 'platform="(.+?)"' ) . findall ( I1111i )
 OOoooO00o0oo0 = re . compile ( 'visible="(.+?)"' ) . findall ( I1111i )
 O00O = re . compile ( 'script="(.+?)"' ) . findall ( I1111i )
 I1i11 = re . compile ( 'program_plugin="(.+?)"' ) . findall ( I1111i )
 IiIi1I1 = re . compile ( 'script_module="(.+?)"' ) . findall ( I1111i )
 IiIIi1 = re . compile ( 'video_plugin="(.+?)"' ) . findall ( I1111i )
 IIIIiii1IIii = re . compile ( 'audio_plugin="(.+?)"' ) . findall ( I1111i )
 II1i11I = re . compile ( 'image_plugin="(.+?)"' ) . findall ( I1111i )
 ii1I1IIii11 = re . compile ( 'repository="(.+?)"' ) . findall ( I1111i )
 O0o0oO = re . compile ( 'weather_service="(.+?)"' ) . findall ( I1111i )
 IIIIiIiIi1 = re . compile ( 'skin="(.+?)"' ) . findall ( I1111i )
 I11iiiiI1i = re . compile ( 'service="(.+?)"' ) . findall ( I1111i )
 iI1i11 = re . compile ( 'warning="(.+?)"' ) . findall ( I1111i )
 OoOOoooOO0O = re . compile ( 'web_interface="(.+?)"' ) . findall ( I1111i )
 ooo00Ooo = re . compile ( 'movie_scraper="(.+?)"' ) . findall ( I1111i )
 Oo0o0O00 = re . compile ( 'tv_scraper="(.+?)"' ) . findall ( I1111i )
 ii1 = re . compile ( 'artist_scraper="(.+?)"' ) . findall ( I1111i )
 I1i11OO = re . compile ( 'music_video_scraper="(.+?)"' ) . findall ( I1111i )
 o0O0oo0OO0O = re . compile ( 'subtitles="(.+?)"' ) . findall ( I1111i )
 OO0 = re . compile ( 'requires="(.+?)"' ) . findall ( I1111i )
 o0Oooo = re . compile ( 'modules="(.+?)"' ) . findall ( I1111i )
 iiI = re . compile ( 'icon="(.+?)"' ) . findall ( I1111i )
 oOIIiIi = re . compile ( 'video_preview="(.+?)"' ) . findall ( I1111i )
 OOoOooOoOOOoo = re . compile ( 'video_guide="(.+?)"' ) . findall ( I1111i )
 Iiii1iI1i = re . compile ( 'video_guide1="(.+?)"' ) . findall ( I1111i )
 I1ii1ii11i1I = re . compile ( 'video_guide2="(.+?)"' ) . findall ( I1111i )
 o0OoOO = re . compile ( 'video_guide3="(.+?)"' ) . findall ( I1111i )
 O0O0Oo00 = re . compile ( 'video_guide4="(.+?)"' ) . findall ( I1111i )
 oOoO00o = re . compile ( 'video_guide5="(.+?)"' ) . findall ( I1111i )
 oO00O0 = re . compile ( 'video_guide6="(.+?)"' ) . findall ( I1111i )
 IIi1IIIi = re . compile ( 'video_guide7="(.+?)"' ) . findall ( I1111i )
 O00Ooo = re . compile ( 'video_guide8="(.+?)"' ) . findall ( I1111i )
 OOOO0OOO = re . compile ( 'video_guide9="(.+?)"' ) . findall ( I1111i )
 i1i1ii = re . compile ( 'video_guide10="(.+?)"' ) . findall ( I1111i )
 iII1ii1 = re . compile ( 'video_label1="(.+?)"' ) . findall ( I1111i )
 I1i1iiiI1 = re . compile ( 'video_label2="(.+?)"' ) . findall ( I1111i )
 iIIi = re . compile ( 'video_label3="(.+?)"' ) . findall ( I1111i )
 oO0o00oo0 = re . compile ( 'video_label4="(.+?)"' ) . findall ( I1111i )
 ii1IIII = re . compile ( 'video_label5="(.+?)"' ) . findall ( I1111i )
 oO00oOooooo0 = re . compile ( 'video_label6="(.+?)"' ) . findall ( I1111i )
 oOoO0OOooOoO = re . compile ( 'video_label7="(.+?)"' ) . findall ( I1111i )
 i1II1I1Iii1 = re . compile ( 'video_label8="(.+?)"' ) . findall ( I1111i )
 iiI11Iii = re . compile ( 'video_label9="(.+?)"' ) . findall ( I1111i )
 O0o0O0 = re . compile ( 'video_label10="(.+?)"' ) . findall ( I1111i )
 if 11 - 11: II111iiii % iii1i1iiiiIi * IIiIi1iI + iiii + O00OOo00oo0o
 if 24 - 24: oOo - II11iIiIIIiI % iIii1I11I1II1 . i1IIi / O0
 if 36 - 36: OoOoOO00 - IIIIiiII111
 i11i11111i1i = oOo0 [ 0 ] if ( len ( oOo0 ) > 0 ) else ''
 O0OOoOOO0oO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 I1ii11 = Oo0O0 [ 0 ] if ( len ( Oo0O0 ) > 0 ) else ''
 oOoOoOoo0 = Ooo0OOoOoO0 [ 0 ] if ( len ( Ooo0OOoOoO0 ) > 0 ) else ''
 III1ii1I = oOo0OOoO0 [ 0 ] if ( len ( oOo0OOoO0 ) > 0 ) else ''
 Ii1i1iI = IIo0Oo0oO0oOO00 [ 0 ] if ( len ( IIo0Oo0oO0oOO00 ) > 0 ) else ''
 IIiI1 = oo00OO0000oO [ 0 ] if ( len ( oo00OO0000oO ) > 0 ) else ''
 i1iI1 = I1II1 [ 0 ] if ( len ( I1II1 ) > 0 ) else ''
 ii1I1IiiI1ii1i = oooO [ 0 ] if ( len ( oooO ) > 0 ) else ''
 O0o = i1I1i111Ii [ 0 ] if ( len ( i1I1i111Ii ) > 0 ) else ''
 if 54 - 54: o0o
 IiI11ii1I = '[CR][CR][COLOR=dodgerblue]Description: [/COLOR]' + i1i1iI1iiiI [ 0 ] if ( len ( i1i1iI1iiiI ) > 0 ) else ''
 IiiiI = Ooo0oOooo0 [ 0 ] if ( len ( Ooo0oOooo0 ) > 0 ) else ''
 O00OoOO0oo0 = oOOOoo00 [ 0 ] if ( len ( oOOOoo00 ) > 0 ) else ''
 oOO = '[CR]' + iiIiIIIiiI [ 0 ] if ( len ( iiIiIIIiiI ) > 0 ) else ''
 O0o0OO0000ooo = '[CR][CR][COLOR=dodgerblue]User Notes: [/COLOR]' + iiI1IIIi [ 0 ] if ( len ( iiI1IIIi ) > 0 ) else ''
 if 4 - 4: O00OOo00oo0o
 OO0oOOoo = ooO000OO0O00O [ 0 ] if ( len ( ooO000OO0O00O ) > 0 ) else ''
 oOOO00o000o = OOOoOO0o [ 0 ] if ( len ( OOOoOO0o ) > 0 ) else ''
 iIi11i1 = i1II1 [ 0 ] if ( len ( i1II1 ) > 0 ) else ''
 oO00oo0o00o0o = i11i1 [ 0 ] if ( len ( i11i1 ) > 0 ) else ''
 IiIIIIIi = '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]' + IiiiiI1i1Iii [ 0 ] if ( len ( IiiiiI1i1Iii ) > 0 ) else '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]No forum details given by developer'
 IiIi1iIIi1 = IiiiiI1i1Iii [ 0 ] if ( len ( IiiiiI1i1Iii ) > 0 ) else 'None'
 O0OoO0ooOO0o = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 license = iiii111II [ 0 ] if ( len ( iiii111II ) > 0 ) else ''
 OoOo0oOooOoOO = '[COLOR=orange]     Platform: [/COLOR]' + I11iIiI1I1i11 [ 0 ] if ( len ( I11iIiI1I1i11 ) > 0 ) else ''
 oo00ooOoO00 = OOoooO00o0oo0 [ 0 ] if ( len ( OOoooO00o0oo0 ) > 0 ) else ''
 o00oOoOo0 = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
 o0O0O0ooo0oOO = I1i11 [ 0 ] if ( len ( I1i11 ) > 0 ) else ''
 oo000 = IiIi1I1 [ 0 ] if ( len ( IiIi1I1 ) > 0 ) else ''
 ii = IiIIi1 [ 0 ] if ( len ( IiIIi1 ) > 0 ) else ''
 OoO = IIIIiii1IIii [ 0 ] if ( len ( IIIIiii1IIii ) > 0 ) else ''
 Iiiiii111i1ii = II1i11I [ 0 ] if ( len ( II1i11I ) > 0 ) else ''
 i1i1iII1 = ii1I1IIii11 [ 0 ] if ( len ( ii1I1IIii11 ) > 0 ) else ''
 iii11i1IIII = I11iiiiI1i [ 0 ] if ( len ( I11iiiiI1i ) > 0 ) else ''
 oO0Oo = IIIIiIiIi1 [ 0 ] if ( len ( IIIIiIiIi1 ) > 0 ) else ''
 Ii = iI1i11 [ 0 ] if ( len ( iI1i11 ) > 0 ) else ''
 o00iiI1Ii1 = OoOOoooOO0O [ 0 ] if ( len ( OoOOoooOO0O ) > 0 ) else ''
 ii1i = O0o0oO [ 0 ] if ( len ( O0o0oO ) > 0 ) else ''
 oOOoo = ooo00Ooo [ 0 ] if ( len ( ooo00Ooo ) > 0 ) else ''
 iII1111III1I = Oo0o0O00 [ 0 ] if ( len ( Oo0o0O00 ) > 0 ) else ''
 ii11i = ii1 [ 0 ] if ( len ( ii1 ) > 0 ) else ''
 O00oOo00o0o = I1i11OO [ 0 ] if ( len ( I1i11OO ) > 0 ) else ''
 O00oO0 = o0O0oo0OO0O [ 0 ] if ( len ( o0O0oo0OO0O ) > 0 ) else ''
 O0Oo00OoOo = OO0 [ 0 ] if ( len ( OO0 ) > 0 ) else ''
 ii1ii111 = o0Oooo [ 0 ] if ( len ( o0Oooo ) > 0 ) else ''
 i11111I1I = iiI [ 0 ] if ( len ( iiI ) > 0 ) else ''
 ii1Oo0000oOo = oOIIiIi [ 0 ] if ( len ( oOIIiIi ) > 0 ) else 'None'
 I11o0oO00oO0o0o0 = OOoOooOoOOOoo [ 0 ] if ( len ( OOoOooOoOOOoo ) > 0 ) else 'None'
 I1I = Iiii1iI1i [ 0 ] if ( len ( Iiii1iI1i ) > 0 ) else 'None'
 ooooo = I1ii1ii11i1I [ 0 ] if ( len ( I1ii1ii11i1I ) > 0 ) else 'None'
 i11IIIiI1I = o0OoOO [ 0 ] if ( len ( o0OoOO ) > 0 ) else 'None'
 o0iiiI1I1iIIIi1 = O0O0Oo00 [ 0 ] if ( len ( O0O0Oo00 ) > 0 ) else 'None'
 Iii = oOoO00o [ 0 ] if ( len ( oOoO00o ) > 0 ) else 'None'
 I1iiiiI1iI = oO00O0 [ 0 ] if ( len ( oO00O0 ) > 0 ) else 'None'
 iIiiiii1i = IIi1IIIi [ 0 ] if ( len ( IIi1IIIi ) > 0 ) else 'None'
 iiIi1IIiI = O00Ooo [ 0 ] if ( len ( O00Ooo ) > 0 ) else 'None'
 i1oO0OO0 = OOOO0OOO [ 0 ] if ( len ( OOOO0OOO ) > 0 ) else 'None'
 o0O0Oo00 = i1i1ii [ 0 ] if ( len ( i1i1ii ) > 0 ) else 'None'
 O0Oo0o000oO = iII1ii1 [ 0 ] if ( len ( iII1ii1 ) > 0 ) else 'None'
 oO0o00oOOooO0 = I1i1iiiI1 [ 0 ] if ( len ( I1i1iiiI1 ) > 0 ) else 'None'
 OOOoO000 = iIIi [ 0 ] if ( len ( iIIi ) > 0 ) else 'None'
 oOOOO = oO0o00oo0 [ 0 ] if ( len ( oO0o00oo0 ) > 0 ) else 'None'
 IiIi1ii111i1 = ii1IIII [ 0 ] if ( len ( ii1IIII ) > 0 ) else 'None'
 i1i1i1I = oO00oOooooo0 [ 0 ] if ( len ( oO00oOooooo0 ) > 0 ) else 'None'
 oOoo000 = oOoO0OOooOoO [ 0 ] if ( len ( oOoO0OOooOoO ) > 0 ) else 'None'
 OooOo00o = i1II1I1Iii1 [ 0 ] if ( len ( i1II1I1Iii1 ) > 0 ) else 'None'
 IiI11i1IIiiI = iiI11Iii [ 0 ] if ( len ( iiI11Iii ) > 0 ) else 'None'
 oOOo000oOoO0 = O0o0O0 [ 0 ] if ( len ( O0o0O0 ) > 0 ) else 'None'
 if 86 - 86: II111iiii % i11iIiiIii + O00OOo00oo0o % i11iIiiIii
 print "### Addon Details: " + O0OOoOOO0oO
 if 92 - 92: i11iIiiIii - IIiIi1iI / iiii / II11iIiIIIiI
 if oOO != '' :
  iiI11I = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=red]This add-on is depreciated, it\'s no longer available.[/COLOR]'
  if 11 - 11: IIiIi1iI - II11iIiIIIiI + II111iiii - iIii1I11I1II1
 elif O00OoOO0oo0 == '' and IiiiI == '' and Ii == '' :
  iiI11I = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=lime]No reported problems[/COLOR]'
  if 7 - 7: i1IiiiI1iI - IIIIiiII111 / II111iiii * O00OOo00oo0o . IIiIi1iI * IIiIi1iI
 elif O00OoOO0oo0 == '' and IiiiI == '' and Ii != '' and oOO == '' :
  iiI11I = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=orange]Although there have been no reported problems there may be issues with this add-on, see below.[/COLOR]'
  if 61 - 61: IIIIiiII111 % iiii - iii1i1iiiiIi / oOo
 elif O00OoOO0oo0 == '' and IiiiI != '' :
  iiI11I = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by the add-on developer.[CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + IiiiI
  if 4 - 4: OoooooooOO - i1IIi % O00OOo00oo0o - o0o * oOoO0o00OO0
 elif O00OoOO0oo0 != '' and IiiiI == '' :
  iiI11I = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]User Comments: [/COLOR]' + O00OoOO0oo0
  if 85 - 85: OoooooooOO * iIii1I11I1II1 . IIiIi1iI / OoooooooOO % OoOoOO00 % O0
 elif O00OoOO0oo0 != '' and IiiiI != '' :
  iiI11I = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by both the add-on developer and a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + IiiiI + '[CR][COLOR=dodgerblue]User Comments: [/COLOR]' + O00OoOO0oo0
  if 36 - 36: O00OOo00oo0o / II111iiii / i1IiiiI1iI / i1IiiiI1iI + oooOooOOo0OO
  if 95 - 95: i1IiiiI1iI
 Ooo0oo = str ( '[COLOR=orange]Name: [/COLOR]' + O0OOoOOO0oO + '[COLOR=orange]     Author(s): [/COLOR]' + III1ii1I + '[COLOR=orange][CR][CR]Version: [/COLOR]' + Ii1i1iI + '[COLOR=orange]     Created: [/COLOR]' + IIiI1 + '[COLOR=orange]     Updated: [/COLOR]' + ii1I1IiiI1ii1i + '[COLOR=orange][CR][CR]Repository: [/COLOR]' + O0OoO0ooOO0o + OoOo0oOooOoOO + '[COLOR=orange]     Add-on Type(s): [/COLOR]' + i1iI1 + O0Oo00OoOo + iiI11I + oOO + Ii + IiIIIIIi + IiI11ii1I + O0o0OO0000ooo )
 if 41 - 41: ooo0O * IIIIiiII111 / ooo0O % II11iIiIIIiI
 if 18 - 18: II111iiii . OoooooooOO % ooo0O % O00OOo00oo0o
 if os . path . exists ( os . path . join ( OooO0 , oOoOoOoo0 ) ) :
  if 'script.module' in oOoOoOoo0 or 'repo' in oOoOoOoo0 :
   o0oOO000oO0oo ( '' , '[COLOR=orange]Already installed[/COLOR]' , '' , '' , i11111I1I , '' , '' , '' )
  else :
   o0oOO000oO0oo ( '' , '[COLOR=orange]Already installed -[/COLOR] Click here to run the add-on' , oOoOoOoo0 , 'run_addon' , i11111I1I , '' , '' , '' )
   if 9 - 9: iii1i1iiiiIi - oOo * OoooooooOO . oOo
   if 2 - 2: OoooooooOO % o0o
 if O0OOoOOO0oO == '' :
  o0oOO000oO0oo ( '' , '[COLOR=yellow]Sorry request failed due to high traffic on server, please try again[/COLOR]' , '' , '' , i11111I1I , '' , '' , '' )
  if 63 - 63: OoOoOO00 % iIii1I11I1II1
  if 39 - 39: IIiIi1iI / II111iiii / oooOooOOo0OO % OoOoOO00
 elif O0OOoOOO0oO != '' :
  if 89 - 89: oo0O0oO + OoooooooOO + oo0O0oO * i1IIi + iIii1I11I1II1 % IIIIiiII111
  if ( O00OoOO0oo0 == '' ) and ( IiiiI == '' ) and ( oOO == '' ) and ( Ii == '' ) :
   o0oOO000oO0oo ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR] No problems reported' , Ooo0oo , 'text_guide' , i11111I1I , '' , '' , Ooo0oo )
   if 59 - 59: o0o + i11iIiiIii
  if ( O00OoOO0oo0 != '' and oOO == '' ) or ( IiiiI != '' and oOO == '' ) or ( Ii != '' and oOO == '' ) :
   o0oOO000oO0oo ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=orange] Possbile problems reported[/COLOR]' , Ooo0oo , 'text_guide' , i11111I1I , '' , '' , Ooo0oo )
   if 88 - 88: i11iIiiIii - iiii
  if oOO != '' :
   o0oOO000oO0oo ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=red] Add-on now depreciated[/COLOR]' , Ooo0oo , 'text_guide' , i11111I1I , '' , '' , Ooo0oo )
   if 67 - 67: o0o . oOo + ooo0O - OoooooooOO
   if 70 - 70: o0o / II111iiii - iIii1I11I1II1 - IIiIi1iI
  if oOO == '' :
   if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - IIIIiiII111
   if O0OoO0ooOO0o != '' and 'superrepo' not in O0OoO0ooOO0o :
    I1i ( '[COLOR=lime][INSTALL - Recommended] [/COLOR]' + O0OOoOOO0oO , O0OOoOOO0oO , '' , 'addon_install_zero' , '' , '' , '' , IiI11ii1I , i11i11111i1i , OO0oOOoo , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIi1iIIi1 , oOOO00o000o )
    I1i ( '[COLOR=lime][INSTALL - Backup Option] [/COLOR]' + O0OOoOOO0oO , O0OOoOOO0oO , '' , 'addon_install' , '' , '' , '' , IiI11ii1I , iIi11i1 , OO0oOOoo , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIi1iIIi1 , oOOO00o000o )
    if 30 - 30: ooo0O
   if O0OoO0ooOO0o == '' or 'superrepo' in O0OoO0ooOO0o :
    I1i ( '[COLOR=lime][INSTALL] [/COLOR]' + O0OOoOOO0oO + ' - THIS IS NOT IN A SELF UPDATING REPO' , O0OOoOOO0oO , '' , 'addon_install' , '' , '' , '' , IiI11ii1I , iIi11i1 , OO0oOOoo , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIi1iIIi1 , oOOO00o000o )
    if 21 - 21: i11iIiiIii / oo0O0oO % o0o * O0 . IIIIiiII111 - iIii1I11I1II1
    if 26 - 26: II111iiii * ooo0O
  if ii1Oo0000oOo != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  Preview' , I1I , 'play_video' , '' , '' , '' , '' )
   if 10 - 10: II111iiii . IIiIi1iI
  if I1I != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + O0Oo0o000oO , I1I , 'play_video' , '' , '' , '' , '' )
   if 32 - 32: O00OOo00oo0o . i1IiiiI1iI . OoooooooOO - iii1i1iiiiIi + II11iIiIIIiI
  if ooooo != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oO0o00oOOooO0 , ooooo , 'play_video' , '' , '' , '' , '' )
   if 88 - 88: IIiIi1iI
  if i11IIIiI1I != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + OOOoO000 , i11IIIiI1I , 'play_video' , '' , '' , '' , '' )
   if 19 - 19: II111iiii * i1IiiiI1iI + O00OOo00oo0o
  if o0iiiI1I1iIIIi1 != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOOOO , o0iiiI1I1iIIIi1 , 'play_video' , '' , '' , '' , '' )
   if 65 - 65: o0o . oo0O0oO . iii1i1iiiiIi . IIiIi1iI - o0o
  if Iii != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IiIi1ii111i1 , Iii , 'play_video' , '' , '' , '' , '' )
   if 19 - 19: i11iIiiIii + IIiIi1iI % iiii
  if I1iiiiI1iI != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i1i1i1I , I1iiiiI1iI , 'play_video' , '' , '' , '' , '' )
   if 14 - 14: iii1i1iiiiIi . II111iiii . IIIIiiII111 / O00OOo00oo0o % oooOooOOo0OO - iiii
  if iIiiiii1i != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOoo000 , iIiiiii1i , 'play_video' , '' , '' , '' , '' )
   if 67 - 67: IIIIiiII111 - o0o . i1IIi
  if iiIi1IIiI != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + OooOo00o , iiIi1IIiI , 'play_video' , '' , '' , '' , '' )
   if 35 - 35: IIiIi1iI + iiii - II11iIiIIIiI . IIiIi1iI . i1IiiiI1iI
  if i1oO0OO0 != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IiI11i1IIiiI , i1oO0OO0 , 'play_video' , '' , '' , '' , '' )
   if 87 - 87: ooo0O
  if o0O0Oo00 != 'None' :
   o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOOo000oOoO0 , o0O0Oo00 , 'play_video' , '' , '' , '' , '' )
   if 25 - 25: i1IIi . iii1i1iiiiIi - ooo0O / iii1i1iiiiIi % iii1i1iiiiIi * iIii1I11I1II1
   if 50 - 50: iii1i1iiiiIi . i11iIiiIii - II11iIiIIIiI . II11iIiIIIiI
def I11I ( url ) :
 o0oOO000oO0oo ( 'folder' , 'Anime' , url + '&genre=anime' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Audiobooks' , url + '&genre=audiobooks' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Comedy' , url + '&genre=comedy' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Comics' , url + '&genre=comics' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Documentary' , url + '&genre=documentary' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Downloads' , url + '&genre=downloads' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Food' , url + '&genre=food' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Gaming' , url + '&genre=gaming' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Health' , url + '&genre=health' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'How To...' , url + '&genre=howto' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Kids' , url + '&genre=kids' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Live TV' , url + '&genre=livetv' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Movies' , url + '&genre=movies' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Music' , url + '&genre=music' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'News' , url + '&genre=news' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Photos' , url + '&genre=photos' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Podcasts' , url + '&genre=podcasts' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Radio' , url + '&genre=radio' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Religion' , url + '&genre=religion' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Space' , url + '&genre=space' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Sports' , url + '&genre=sports' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Technology' , url + '&genre=tech' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Trailers' , url + '&genre=trailers' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'TV Shows' , url + '&genre=tv' , 'grab_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Misc.' , url + '&genre=other' , 'grab_addons' , '' , '' , '' , '' )
 if 6 - 6: oooOooOOo0OO + II11iIiIIIiI
 if I11i . getSetting ( 'adult' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , 'XXX' , url + '&genre=adult' , 'grab_addons' , '' , '' , '' , '' )
  if 48 - 48: iIii1I11I1II1 % i1IIi % IIiIi1iI + iiii
  if 30 - 30: i11iIiiIii % iIii1I11I1II1 . IIIIiiII111 % iIii1I11I1II1
def oOO00oO00O0OO ( name , zip_link , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 forum = str ( forum )
 repo_id = str ( repo_id )
 oOo00OO = 1
 o0oOO0OO = 1
 Oo00OoO00o0 = 1
 OOoOoO00O0O0o = xbmc . translatePath ( os . path . join ( OooO0 , addon_id ) )
 if 12 - 12: oooOooOOo0OO + iii1i1iiiiIi % IIIIiiII111
 if os . path . exists ( OOoOoO00O0O0o ) :
  o0Ooo0o0ooo0 = 1
  if 70 - 70: i11iIiiIii % IIiIi1iI
 else :
  o0Ooo0o0ooo0 = 0
  if 11 - 11: i1IiiiI1iI % oooOooOOo0OO % O00OOo00oo0o / II111iiii % oo0O0oO - oOo
 OOooO = xbmc . translatePath ( os . path . join ( Oo0OoO00oOO0o , name + '.zip' ) )
 O00O0OO00oo = xbmc . translatePath ( os . path . join ( OooO0 , addon_id ) )
 if 69 - 69: oOoO0o00OO0 / oOo
 iIii1 . create ( "Installing Addon" , "Please wait whilst your addon is installed" , '' , '' )
 if 43 - 43: oooOooOOo0OO . OoOoOO00 / OoooooooOO % OoooooooOO
 try :
  downloader . download ( repo_link , OOooO , iIii1 )
  extract . all ( OOooO , OooO0 , iIii1 )
  if 33 - 33: oo0O0oO
 except :
  if 62 - 62: oooOooOOo0OO + O00OOo00oo0o + i1IIi / OoooooooOO
  try :
   downloader . download ( zip_link , OOooO , iIii1 )
   extract . all ( OOooO , OooO0 , iIii1 )
   if 7 - 7: oOoO0o00OO0 + i1IIi . OoOoOO00 / oOo
  except :
   if 22 - 22: iiii - iiii % o0o . oo0O0oO + II11iIiIIIiI
   try :
    if not os . path . exists ( O00O0OO00oo ) :
     os . makedirs ( O00O0OO00oo )
     if 63 - 63: OoOoOO00 % oo0O0oO * oOoO0o00OO0 + oo0O0oO / oOo % IIiIi1iI
    I1111i = iIIii ( data_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    iiI1i1Iii111 = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( I1111i )
    if 43 - 43: oOoO0o00OO0
    for OO00oOooo0O in iiI1i1Iii111 :
     oOOOo = xbmc . translatePath ( os . path . join ( O00O0OO00oo , OO00oOooo0O ) )
     if 68 - 68: II11iIiIIIiI - oooOooOOo0OO % O0 % oo0O0oO
     if addon_id not in OO00oOooo0O and '/' not in OO00oOooo0O :
      if 11 - 11: O0 / iii1i1iiiiIi % o0o + oOoO0o00OO0 + iIii1I11I1II1
      try :
       iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + OO00oOooo0O + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( data_path + OO00oOooo0O , oOOOo , iIii1 )
       if 40 - 40: iiii - o0o . O00OOo00oo0o * oOo % oo0O0oO
      except :
       print "failed to install" + OO00oOooo0O
       if 56 - 56: i11iIiiIii . oOoO0o00OO0 - OoOoOO00 * IIIIiiII111
     if '/' in OO00oOooo0O and '..' not in OO00oOooo0O and 'http' not in OO00oOooo0O :
      oOOoo0 = data_path + OO00oOooo0O
      i1111IIiii1 ( oOOOo , oOOoo0 )
      if 49 - 49: o0o . iIii1I11I1II1
   except :
    OOooO0OOoo . ok ( "Error downloading add-on" , 'There was an error downloading [COLOR=yellow]' + name , '[/COLOR]Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    oOo00OO = 0
    if 62 - 62: ooo0O / OoOoOO00 - oooOooOOo0OO - OoOoOO00 + i11iIiiIii + i1IIi
 if oOo00OO == 1 :
  time . sleep ( 1 )
  iIii1 . update ( 0 , "[COLOR=yellow]" + name + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing repository' )
  time . sleep ( 1 )
  I1i11II = xbmc . translatePath ( os . path . join ( OooO0 , repo_id ) )
  if 31 - 31: II11iIiIIIiI / i1IiiiI1iI * oOoO0o00OO0 . II111iiii
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( I1i11II ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   oooOO0OO0O ( repo_id )
   if 78 - 78: O00OOo00oo0o / II111iiii % ooo0O
  xbmc . sleep ( 2000 )
  if 52 - 52: o0o - IIiIi1iI * II11iIiIIIiI
  if os . path . exists ( OOoOoO00O0O0o ) and o0Ooo0o0ooo0 == 0 :
   Ii1I11I = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    iIIii ( Ii1I11I )
   except :
    pass
    if 36 - 36: O0 + oOo
  iIIIi1i1I11i ( name , addon_id )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 55 - 55: oOo - o0o
  if o0oOO0OO == 0 :
   OOooO0OOoo . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing the repository.' , 'This will mean the add-on fails to update' )
   if 84 - 84: oo0O0oO + oOo - ooo0O * ooo0O
  if Oo00OoO00o0 == 0 :
   OOooO0OOoo . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing modules.' , 'This could result in errors with the add-on.' )
   if 61 - 61: OoooooooOO . II11iIiIIIiI . OoooooooOO / oOo
  if Oo00OoO00o0 != 0 and o0oOO0OO != 0 and forum != 'None' :
   OOooO0OOoo . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]Support for this add-on can be found at [COLOR=yellow]' + forum , '[/COLOR][CR]Visit [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR] for all your Kodi needs.' )
   if 72 - 72: i1IIi
  if Oo00OoO00o0 != 0 and o0oOO0OO != 0 and forum == 'None' :
   OOooO0OOoo . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]No details of forum support have been given.' )
   if 82 - 82: ooo0O + OoooooooOO / i11iIiiIii * oooOooOOo0OO . OoooooooOO
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 63 - 63: oooOooOOo0OO
 if 6 - 6: iiii / oooOooOOo0OO
def oOooO00o0O ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 OOoOoO00O0O0o = xbmc . translatePath ( os . path . join ( OooO0 , addon_id ) )
 forum = str ( forum )
 if 80 - 80: o0o / IIIIiiII111 / ooo0O + i1IIi - oOo
 if not os . path . exists ( OOoOoO00O0O0o ) :
  iIIiiIIi1IiI = 1
  if 14 - 14: i1IiiiI1iI % II11iIiIIIiI % oOo - i11iIiiIii
 else :
  iIIiiIIi1IiI = 0
  if 53 - 53: O00OOo00oo0o % oOo
 repo_id = str ( repo_id )
 I1i11II = xbmc . translatePath ( os . path . join ( OooO0 , repo_id ) )
 if 59 - 59: o0o % iIii1I11I1II1 . i1IIi + II111iiii * i1IiiiI1iI
 if os . path . exists ( OOoOoO00O0O0o ) :
  o0Ooo0o0ooo0 = 1
  i1IiiI1iIi = OOooO0OOoo . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 66 - 66: iii1i1iiiiIi * oOo
  if i1IiiI1iIi == 1 :
   II1IIIiiI11 ( OOoOoO00O0O0o )
   iIIiiIIi1IiI = 1
 else :
  o0Ooo0o0ooo0 = 0
  if 86 - 86: iii1i1iiiiIi % OoooooooOO % iii1i1iiiiIi / OoOoOO00
 if iIIiiIIi1IiI == 1 :
  if 56 - 56: OoooooooOO % i11iIiiIii * iIii1I11I1II1 . iii1i1iiiiIi * O0
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( I1i11II ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   oooOO0OO0O ( repo_id )
   if 23 - 23: i11iIiiIii
  if not os . path . exists ( OOoOoO00O0O0o ) :
   os . makedirs ( OOoOoO00O0O0o )
   if 39 - 39: oOoO0o00OO0 - oooOooOOo0OO % IIiIi1iI * iii1i1iiiiIi - o0o / IIiIi1iI
  iIiiiiii1 = os . path . join ( OooO0 , addon_id , 'addon.xml' )
  oOO0oo = os . path . join ( OooO0 , addon_id , 'default.py' )
  if 29 - 29: OoOoOO00 * II111iiii * OoooooooOO - oooOooOOo0OO * II111iiii
  shutil . copyfile ( Ooo , iIiiiiii1 )
  if 41 - 41: O0
  I111I11I111 = open ( os . path . join ( iIiiiiii1 ) , mode = 'r' )
  iiiiI11ii = I111I11I111 . read ( )
  I111I11I111 . close ( )
  if 96 - 96: IIiIi1iI . O0 / IIiIi1iI % O0
  if 94 - 94: i1IiiiI1iI + oo0O0oO / o0o
  o00o = re . compile ( 'testid[\s\S]*?' ) . findall ( iiiiI11ii )
  Ooo0OOoOoO0 = o00o [ 0 ] if ( len ( o00o ) > 0 ) else 'None'
  iii11II1I = re . compile ( 'testname[\s\S]*?' ) . findall ( iiiiI11ii )
  i1iI = iii11II1I [ 0 ] if ( len ( iii11II1I ) > 0 ) else 'None'
  iI111I11i = re . compile ( 'testprovider[\s\S]*?' ) . findall ( iiiiI11ii )
  I1 = iI111I11i [ 0 ] if ( len ( iI111I11i ) > 0 ) else 'None'
  II1i11I1 = re . compile ( 'testprovides[\s\S]*?' ) . findall ( iiiiI11ii )
  iiIiIiII = II1i11I1 [ 0 ] if ( len ( II1i11I1 ) > 0 ) else 'None'
  i1I1 = iiiiI11ii . replace ( Ooo0OOoOoO0 , addon_id ) . replace ( i1iI , name ) . replace ( I1 , provider_name ) . replace ( iiIiIiII , contenttypes )
  if 28 - 28: oooOooOOo0OO . i1IIi
  iIIiooO00O00oOO = open ( iIiiiiii1 , mode = 'w+' )
  iIIiooO00O00oOO . write ( str ( i1I1 ) )
  iIIiooO00O00oOO . close ( )
  if 40 - 40: IIiIi1iI . II11iIiIIIiI + OoOoOO00 + oooOooOOo0OO + oo0O0oO
  i11Ii1I1I11I = open ( oOO0oo , mode = 'w' )
  i11Ii1I1I11I . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + addon_id + '"\nAddonName="' + name + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating. We recommend waiting but if you\'ve already tried that and it\'s not updating you can try re-installing via the CP backup method.",yeslabel="Install Option 2", nolabel="Wait...")\nif choice == 1: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.totalinstaller/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
  i11Ii1I1I11I . close ( )
  if 29 - 29: OoooooooOO . OoOoOO00 % oooOooOOo0OO - IIiIi1iI
  xbmc . sleep ( 1000 )
  if 8 - 8: i1IIi
  if os . path . exists ( OOoOoO00O0O0o ) and o0Ooo0o0ooo0 == 0 :
   Ii1I11I = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    iIIii ( Ii1I11I )
   except :
    pass
    if 32 - 32: II11iIiIIIiI / II111iiii
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  OOooO0OOoo . ok ( name + " Install Complete" , '[COLOR=dodgerblue]' + name + '[/COLOR] has now been installed, please allow a few moments for Kodi to update the add-on and it\'s dependencies.' )
  if 45 - 45: oooOooOOo0OO + iii1i1iiiiIi * i11iIiiIii / o0o % IIIIiiII111 * O0
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 17 - 17: O0
 if 88 - 88: oOo . O0 % OoooooooOO / o0o
def ooOo ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 I1i11II = xbmc . translatePath ( os . path . join ( OooO0 , repo_id ) )
 OOoOoO00O0O0o = xbmc . translatePath ( os . path . join ( OooO0 , addon_id ) )
 if 84 - 84: o0o
 if os . path . exists ( OOoOoO00O0O0o ) :
  if 87 - 87: iiii + oOoO0o00OO0
  i1IiiI1iIi = OOooO0OOoo . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 28 - 28: o0o * oooOooOOo0OO / II11iIiIIIiI
  if i1IiiI1iIi == 1 :
   II1IIIiiI11 ( OOoOoO00O0O0o )
   if 64 - 64: II11iIiIIIiI - OoOoOO00 / IIiIi1iI - iii1i1iiiiIi
 if os . path . exists ( I1i11II ) :
  if 37 - 37: i11iIiiIii / IIiIi1iI
  if os . path . exists ( OOoOoO00O0O0o ) :
   o0Ooo0o0ooo0 = 1
   if 85 - 85: i11iIiiIii + oo0O0oO * ooo0O
  else :
   o0Ooo0o0ooo0 = 0
   if 1 - 1: i1IIi / oOo . iii1i1iiiiIi
  i1IiiI1iIi = OOooO0OOoo . yesno ( 'WARNING!' , '[COLOR=orange]This Add-on may be unlawful in your region.[/COLOR][CR]The repository required for installation of this add-on has been detected on your system. Would you like to continue to the Kodi addon browser to install?' )
  if 57 - 57: IIIIiiII111 . oOo + II111iiii
  if i1IiiI1iIi == 1 :
   if 43 - 43: oo0O0oO % IIiIi1iI
   if 'video' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.video/?",return)' )
    if 69 - 69: IIiIi1iI % iii1i1iiiiIi
   elif 'executable' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.executable/?",return)' )
    if 86 - 86: II11iIiIIIiI / II11iIiIIIiI
   elif 'audio' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.audio/?",return)' )
    if 28 - 28: i11iIiiIii / oOoO0o00OO0 . iIii1I11I1II1 / II111iiii
  xbmc . sleep ( 2000 )
  if 72 - 72: OoooooooOO / OoOoOO00 + O00OOo00oo0o / ooo0O * O00OOo00oo0o
  if os . path . exists ( OOoOoO00O0O0o ) and o0Ooo0o0ooo0 == 0 :
   Ii1I11I = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    iIIii ( Ii1I11I )
   except :
    pass
    if 34 - 34: O0 * O0 % OoooooooOO + IIiIi1iI * iIii1I11I1II1 % O00OOo00oo0o
 else :
  OOooO0OOoo . ok ( 'WARNING!' , '[COLOR=orange]This add-on may possibly be unlawful in your region.[/COLOR][CR]If you\'ve investigated the legality of it and are happy to install then you must have the following repository installed: [COLOR=dodgerblue]' + repo_id + '[/COLOR]' )
  if 25 - 25: IIIIiiII111 + ooo0O . oOoO0o00OO0 % ooo0O * o0o
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 32 - 32: i11iIiiIii - oo0O0oO
 if 53 - 53: OoooooooOO - i1IiiiI1iI
def oOoi1i ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 OOooO0OOoo . ok ( 'Add-on Not Approved' , 'Sorry there are no repository details for this add-on and it\'s been marked as potentially giving access to unlawful content. The most likely cause for this is the add-on has only been released via social media groups.' )
 if 5 - 5: oooOooOOo0OO + O0 + O0 . oo0O0oO - iiii
 if 63 - 63: II11iIiIIIiI
def Oo0 ( sign ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search By Name' , 'name=' , 'search_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search By Author' , 'author=' , 'search_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search In Description' , 'desc=' , 'search_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search By Add-on ID' , 'addonid=' , 'search_addons' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Genres' , 'p' , 'addon_genres' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Countries' , 'p' , 'addon_countries' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Kodi Categories' , 'p' , 'addon_categories' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Install From Zip' , '' , 'install_from_zip' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Browse My Repositories' , '' , 'browse_repos' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Check For Add-on Updates' , '' , 'check_updates' , '' , '' , '' , '' )
 if 79 - 79: iii1i1iiiiIi % o0o / iIii1I11I1II1 + ooo0O * iii1i1iiiiIi
 if 30 - 30: OoooooooOO / IIIIiiII111 + IIiIi1iI / oooOooOOo0OO * O0
def iIiII ( ) :
 for file in glob . glob ( os . path . join ( OooO0 , '*' ) ) :
  O0OOoOOO0oO = str ( file ) . replace ( OooO0 , '[COLOR=red]REMOVE [/COLOR]' ) . replace ( 'plugin.' , '[COLOR=dodgerblue](PLUGIN) [/COLOR]' ) . replace ( 'audio.' , '' ) . replace ( 'video.' , '' ) . replace ( 'skin.' , '[COLOR=yellow](SKIN) [/COLOR]' ) . replace ( 'repository.' , '[COLOR=orange](REPOSITORY) [/COLOR]' ) . replace ( 'script.' , '[COLOR=cyan](SCRIPT) [/COLOR]' ) . replace ( 'metadata.' , '[COLOR=orange](METADATA) [/COLOR]' ) . replace ( 'service.' , '[COLOR=pink](SERVICE) [/COLOR]' ) . replace ( 'weather.' , '[COLOR=green](WEATHER) [/COLOR]' ) . replace ( 'module.' , '[COLOR=orange](MODULE) [/COLOR]' )
  i1i1IIIIIIIi = ( os . path . join ( file , 'icon.png' ) )
  oo0o0oOo = ( os . path . join ( file , 'fanart.jpg' ) )
  o0oOO000oO0oo ( '' , O0OOoOOO0oO , file , 'remove_addons' , i1i1IIIIIIIi , oo0o0oOo , '' , '' )
  if 58 - 58: oOoO0o00OO0 - II111iiii % II11iIiIIIiI + oo0O0oO . ooo0O / i1IiiiI1iI
  if 8 - 8: oooOooOOo0OO . iii1i1iiiiIi * IIIIiiII111 + II111iiii % i11iIiiIii
def i1i1IiIiIi1Ii ( ) :
 I11i . openSettings ( sys . argv [ 0 ] )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 64 - 64: o0o + OoooooooOO * OoooooooOO
 if 41 - 41: iiii . oOo + OoOoOO00
def o0O0OO ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 Ii1II11II1iii = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 o0oOO0ooOoO = len ( sourcefile )
 ooO0000o00O = [ ]
 O0Ooo = [ ]
 if 78 - 78: iii1i1iiiiIi % i1IiiiI1iI * i1IIi
 iIii1 . create ( message_header , message1 , message2 , message3 )
 if 66 - 66: O00OOo00oo0o . OoOoOO00 + oOoO0o00OO0 . iIii1I11I1II1
 for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( sourcefile ) :
  if 93 - 93: o0o
  for file in Oo0o :
   O0Ooo . append ( file )
   if 43 - 43: oooOooOOo0OO / OoOoOO00 . iiii
 Ooo0oO0 = len ( O0Ooo )
 if 86 - 86: O0
 for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( sourcefile ) :
  if 95 - 95: IIiIi1iI * o0o . ooo0O . i1IIi . i1IIi - oOoO0o00OO0
  i1iiIIIi [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in i1iiIIIi if ii1iIIiii1 not in exclude_dirs ]
  Oo0o [ : ] = [ ooOo0O0o0 for ooOo0O0o0 in Oo0o if ooOo0O0o0 not in exclude_files and not 'crashlog' in ooOo0O0o0 and not 'stacktrace' in ooOo0O0o0 ]
  if 65 - 65: iiii + O0
  for file in Oo0o :
   if 32 - 32: OoooooooOO - ooo0O - i11iIiiIii * oOoO0o00OO0 / oOo + OoooooooOO
   try :
    ooO0000o00O . append ( file )
    ii1I1I111 = len ( ooO0000o00O ) / float ( Ooo0oO0 ) * 100
    iIii1 . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % ii1iIIiii1 , 'Please Wait' )
    Ii1Ii = os . path . join ( o0iIiiIiiIi , file )
    if 39 - 39: II11iIiIIIiI - i1IIi / iiii . OoOoOO00 * i1IIi - iIii1I11I1II1
   except :
    print "Unable to backup file: " + file
    if 55 - 55: OoOoOO00 * oOoO0o00OO0 % iiii . iIii1I11I1II1 * oo0O0oO
   if not 'temp' in i1iiIIIi :
    if 92 - 92: oo0O0oO - iIii1I11I1II1
    if not IiII1IiiIiI1 in i1iiIIIi :
     if 32 - 32: O00OOo00oo0o % iii1i1iiiiIi * iii1i1iiiiIi + i1IiiiI1iI * II111iiii * O00OOo00oo0o
     try :
      iIiIii1I1II = '01/01/1980'
      O0Oooo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ii1Ii ) ) )
      if 77 - 77: II111iiii
      if O0Oooo > iIiIii1I1II :
       Ii1II11II1iii . write ( Ii1Ii , Ii1Ii [ o0oOO0ooOoO : ] )
       if 42 - 42: O00OOo00oo0o * oo0O0oO . i1IiiiI1iI * OoOoOO00 + ooo0O
     except :
      print "Unable to backup file: " + file
      if 25 - 25: IIIIiiII111 . OoOoOO00 + II11iIiIIIiI
 Ii1II11II1iii . close ( )
 iIii1 . close ( )
 if 75 - 75: i1IiiiI1iI - oOoO0o00OO0 % IIiIi1iI + i11iIiiIii
 if 100 - 100: IIIIiiII111 + oOoO0o00OO0 - i11iIiiIii - II111iiii
def iIIIiIi1I1i ( sourcefile , destfile ) :
 Ii1II11II1iii = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 o0oOO0ooOoO = len ( sourcefile )
 ooO0000o00O = [ ]
 O0Ooo = [ ]
 if 78 - 78: iIii1I11I1II1 % ooo0O + oooOooOOo0OO / i1IIi % II111iiii + o0o
 iIii1 . create ( "Backing Up Files" , "Archiving..." , '' , 'Please Wait' )
 if 91 - 91: iIii1I11I1II1 % iii1i1iiiiIi . oOoO0o00OO0 + O00OOo00oo0o + oOoO0o00OO0
 for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( sourcefile ) :
  if 95 - 95: O00OOo00oo0o + oooOooOOo0OO * o0o
  for file in Oo0o :
   O0Ooo . append ( file )
   if 16 - 16: IIIIiiII111 / OoOoOO00 + iii1i1iiiiIi % iIii1I11I1II1 - i1IIi . II11iIiIIIiI
 Ooo0oO0 = len ( O0Ooo )
 if 26 - 26: oOoO0o00OO0 * i1IiiiI1iI . i1IIi
 for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( sourcefile ) :
  if 59 - 59: O0 + i1IIi - oOoO0o00OO0
  for file in Oo0o :
   ooO0000o00O . append ( file )
   ii1I1I111 = len ( ooO0000o00O ) / float ( Ooo0oO0 ) * 100
   iIii1 . update ( int ( ii1I1I111 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
   Ii1Ii = os . path . join ( o0iIiiIiiIi , file )
   if 62 - 62: i11iIiiIii % o0o . i1IiiiI1iI . o0o
   if not 'temp' in i1iiIIIi :
    if 84 - 84: i11iIiiIii * iii1i1iiiiIi
    if not IiII1IiiIiI1 in i1iiIIIi :
     if 18 - 18: o0o - O00OOo00oo0o - ooo0O / oo0O0oO - O0
     import time
     iIiIii1I1II = '01/01/1980'
     O0Oooo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ii1Ii ) ) )
     if 30 - 30: O0 + oooOooOOo0OO + II111iiii
     if O0Oooo > iIiIii1I1II :
      Ii1II11II1iii . write ( Ii1Ii , Ii1Ii [ o0oOO0ooOoO : ] )
 Ii1II11II1iii . close ( )
 iIii1 . close ( )
 if 14 - 14: oOoO0o00OO0 / o0o - iIii1I11I1II1 - II11iIiIIIiI % iiii
 if 49 - 49: iiii * II11iIiIIIiI / oOoO0o00OO0 / oOo * iIii1I11I1II1
def OOoO00ooO ( ) :
 I1IIIIiii1i = OOooO0OOoo . browse ( 3 , 'Select the folder you want to scan' , 'files' , '' , False , False )
 o0oOO0ooOoO = len ( I1IIIIiii1i )
 ooO0000o00O = [ ]
 O0Ooo = [ ]
 if 51 - 51: o0o . OoOoOO00
 iIii1 . create ( 'Checking File Structure' , '' , 'Please wait...' , '' )
 if 73 - 73: OoooooooOO . OoOoOO00 / oo0O0oO % O00OOo00oo0o
 i1IiiI1iIi = OOooO0OOoo . yesno ( 'Delete or Scan?' , 'Do you want to delete all filenames with special characters or would you rather just scan and view the results in the log?' , yeslabel = 'Delete' , nolabel = 'Scan' )
 if 65 - 65: i1IiiiI1iI - OoOoOO00 - O00OOo00oo0o
 Ii1iIi111I1i = open ( i1I1iI , mode = 'w+' )
 I1III111i = open ( oo0OooOOo0 , mode = 'w+' )
 if 4 - 4: i1IIi + iiii + i1IIi
 for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( I1IIIIiii1i ) :
  if 31 - 31: O00OOo00oo0o
  for file in Oo0o :
   O0Ooo . append ( file )
   if 78 - 78: i11iIiiIii + oOoO0o00OO0 + oo0O0oO / oOoO0o00OO0 % iIii1I11I1II1 % i1IiiiI1iI
 Ooo0oO0 = len ( O0Ooo )
 if 83 - 83: iIii1I11I1II1 % ooo0O % oOoO0o00OO0 % oo0O0oO . oooOooOOo0OO % O0
 for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( I1IIIIiii1i ) :
  if 47 - 47: oOoO0o00OO0
  i1iiIIIi [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in i1iiIIIi ]
  Oo0o [ : ] = [ ooOo0O0o0 for ooOo0O0o0 in Oo0o ]
  if 66 - 66: OoOoOO00 - i1IiiiI1iI
  for file in Oo0o :
   if 33 - 33: OoOoOO00 / iii1i1iiiiIi
   ooO0000o00O . append ( file )
   ii1I1I111 = len ( ooO0000o00O ) / float ( Ooo0oO0 ) * 100
   iIii1 . update ( 0 , "Checking for non ASCII files" , '[COLOR yellow]%s[/COLOR]' % ii1iIIiii1 , 'Please Wait' )
   if 12 - 12: II111iiii
   try :
    file . encode ( 'ascii' )
    if 2 - 2: i1IIi - OoOoOO00 + IIIIiiII111 . II111iiii
   except UnicodeDecodeError :
    iIIiI1iiI = ( str ( o0iIiiIiiIi ) + '/' + str ( file ) ) . replace ( '\\' , '/' ) . replace ( ':/' , ':\\' )
    if 18 - 18: IIiIi1iI - II11iIiIIIiI % IIiIi1iI / IIIIiiII111
    print " non-ASCII file status logged successfully: " + iIIiI1iiI
    if i1IiiI1iIi != 1 :
     Ii1iIi111I1i . write ( '[COLOR=dodgerblue]Non-ASCII File:[/COLOR]\n' )
     for O0Oo00OO00Ooo in OO0O00OoOOOo ( iIIiI1iiI , 75 ) :
      Ii1iIi111I1i . write ( O0Oo00OO00Ooo + '[CR]' )
     Ii1iIi111I1i . write ( '\n' )
    if i1IiiI1iIi == 1 :
     try :
      os . remove ( iIIiI1iiI )
      print "### SUCCESS - deleted " + iIIiI1iiI
      Ii1iIi111I1i . write ( '[COLOR=dodgerblue]SUCCESSFULLY DELETED:[/COLOR]\n' )
      for O0Oo00OO00Ooo in OO0O00OoOOOo ( iIIiI1iiI , 75 ) :
       Ii1iIi111I1i . write ( O0Oo00OO00Ooo + '[CR]' )
      Ii1iIi111I1i . write ( '\n' )
      if 77 - 77: iIii1I11I1II1 . O00OOo00oo0o % II11iIiIIIiI / O00OOo00oo0o
     except :
      print "######## FAILED TO REMOVE: " + iIIiI1iiI
      print "######## Make sure you manually remove this file ##########"
      I1III111i . write ( '[COLOR=red]FAILED TO DELETE:[/COLOR]\n' )
      for O0Oo00OO00Ooo in OO0O00OoOOOo ( iIIiI1iiI , 75 ) :
       I1III111i . write ( O0Oo00OO00Ooo + '[CR]' )
      I1III111i . write ( '\n' )
      if 54 - 54: II11iIiIIIiI + iiii - oOo
 I1III111i . close ( )
 Ii1iIi111I1i . close ( )
 if 35 - 35: O00OOo00oo0o - O00OOo00oo0o + i1IIi - O0 - oo0O0oO
 if 58 - 58: ooo0O - IIiIi1iI - OoooooooOO
 Ii1iIi111I1i = open ( i1I1iI , mode = 'r' )
 o00ii111Iiii = Ii1iIi111I1i . read ( )
 Ii1iIi111I1i . close ( )
 I1III111i = open ( oo0OooOOo0 , mode = 'r' )
 oo0oO0o0 = I1III111i . read ( )
 I1III111i . close ( )
 if o00ii111Iiii == '' and oo0oO0o0 == '' :
  OOooO0OOoo . ok ( 'No Special Characters Found' , 'Great news, all filenames in the path you scanned are ASCII based - no special characters found.' )
 else :
  Iii1Ii = open ( IIIii1II1II , mode = 'w+' )
  Iii1Ii . write ( o00ii111Iiii + '\n\n' + oo0oO0o0 )
  Iii1Ii . close ( )
  ii11I11i = open ( IIIii1II1II , mode = 'r' )
  oOOOOi11i11 = ii11I11i . read ( )
  ii11I11i . close ( )
  i1iiIII1IIiIIII ( 'Final Results' , oOOOOi11i11 )
  os . remove ( IIIii1II1II )
 os . remove ( i1I1iI )
 os . remove ( oo0OooOOo0 )
 if 19 - 19: IIiIi1iI - oOoO0o00OO0 / oOoO0o00OO0 + oOo
 if 98 - 98: iIii1I11I1II1 % o0o + IIIIiiII111 . iiii
def Oo0oO00 ( ) :
 o0oOO000oO0oo ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] How to create and share my build' , '' , 'instructions_1' , '' , '' , '' , 'Back Up Your Full System' )
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Create [/COLOR][COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] [COLOR=dodgerblue]Community Build[/COLOR] (for sharing on CP)' , 'url' , 'community_backup' , '' , '' , '' , 'Back Up Your Full System' )
 if IiiI1III1I1 ( ) :
  o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Create OpenELEC Backup[/COLOR] (full backup can only be used on OpenELEC)' , 'none' , 'openelec_backup' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Create Universal Build[/COLOR] (For copying to other devices)' , 'none' , 'community_backup_2' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Create Full Backup[/COLOR] (will only work on THIS device)' , 'local' , 'local_backup' , '' , '' , '' , 'Back Up Your Full System' )
 o0oOO000oO0oo ( '' , 'Backup Addons Only' , 'addons' , 'restore_zip' , '' , '' , '' , 'Back Up Your Addons' )
 o0oOO000oO0oo ( '' , 'Backup Addon Data Only' , 'addon_data' , 'restore_zip' , '' , '' , '' , 'Back Up Your Addon Userdata' )
 o0oOO000oO0oo ( '' , 'Backup Guisettings.xml' , O0o0Oo , 'restore_backup' , '' , '' , '' , 'Back Up Your guisettings.xml' )
 if 80 - 80: oo0O0oO . IIIIiiII111
 if os . path . exists ( iIi1ii1I1 ) :
  o0oOO000oO0oo ( '' , 'Backup Favourites.xml' , iIi1ii1I1 , 'restore_backup' , '' , '' , '' , 'Back Up Your favourites.xml' )
  if 73 - 73: ooo0O . O0 / IIiIi1iI * II11iIiIIIiI
 if os . path . exists ( o0 ) :
  o0oOO000oO0oo ( '' , 'Backup Source.xml' , o0 , 'restore_backup' , '' , '' , '' , 'Back Up Your sources.xml' )
  if 29 - 29: oOoO0o00OO0
 if os . path . exists ( I11II1i ) :
  o0oOO000oO0oo ( '' , 'Backup Advancedsettings.xml' , I11II1i , 'restore_backup' , '' , '' , '' , 'Back Up Your advancedsettings.xml' )
  if 86 - 86: II111iiii . i1IiiiI1iI
 if os . path . exists ( IIiiiiiiIi1I1 ) :
  o0oOO000oO0oo ( '' , 'Backup Advancedsettings.xml' , IIiiiiiiIi1I1 , 'restore_backup' , '' , '' , '' , 'Back Up Your keyboard.xml' )
  if 2 - 2: OoooooooOO
 if os . path . exists ( ooooooO0oo ) :
  o0oOO000oO0oo ( '' , 'Backup RssFeeds.xml' , ooooooO0oo , 'restore_backup' , '' , '' , '' , 'Back Up Your RssFeeds.xml' )
  if 60 - 60: iii1i1iiiiIi
  if 81 - 81: ooo0O % O00OOo00oo0o
def oo0 ( ) :
 o0oOO000oO0oo ( 'folder' , 'Backup My Content' , 'none' , 'backup_option' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Restore My Content' , 'none' , 'restore_option' , '' , '' , '' , '' )
 if 16 - 16: O00OOo00oo0o * iii1i1iiiiIi / II11iIiIIIiI
 if 22 - 22: II11iIiIIIiI + iIii1I11I1II1 % oOo / IIIIiiII111 / O00OOo00oo0o
def oOo0o0O000 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://repos/",return)' )
 if 5 - 5: iiii - oo0O0oO + OoOoOO00 * O0 / oOo - O00OOo00oo0o
 if 75 - 75: OoooooooOO - o0o + oOoO0o00OO0 / IIiIi1iI % i11iIiiIii
def iiiiii1 ( localbuildcheck , localversioncheck , id , welcometext ) :
 OO0o0oO0O000o = I1iI11iii ( )
 if OO0o0oO0O000o != 'none' :
  try :
   exec OO0o0oO0O000o
   o0oOO000oO0oo ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  except :
   pass
 if ( O0oo0OO0 . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) :
  o0oOO000oO0oo ( '' , welcometext , 'show' , 'user_info' , '' , '' , '' , '' )
  if 78 - 78: O0 / II111iiii * iii1i1iiiiIi
  if id != 'None' :
   if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % oo0O0oO - iIii1I11I1II1 % O0
   if id != 'Local' :
    o0oO0Oo = OO0OO000 ( localbuildcheck , localversioncheck , id )
    if 55 - 55: iiii
    if o0oO0Oo == True :
     if 82 - 82: oo0O0oO - o0o + iii1i1iiiiIi
     if not 'Partially installed' in localbuildcheck :
      o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]' + localbuildcheck + ':[/COLOR] [COLOR=lime]NEW VERSION AVAILABLE[/COLOR]' , id , 'showinfo' , '' , '' , '' , '' )
      if 64 - 64: oOoO0o00OO0 . O0 * O00OOo00oo0o + OoooooooOO - oOo . OoooooooOO
     if '(Partially installed)' in localbuildcheck :
      o0oOO000oO0oo ( 'folder' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo2' , '' , '' , '' , '' )
    else :
     o0oOO000oO0oo ( 'folder' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo' , '' , '' , '' , '' )
     if 70 - 70: oOo - II11iIiIIIiI . iIii1I11I1II1 % IIIIiiII111 / ooo0O - O0
   else :
    if 55 - 55: IIiIi1iI - iii1i1iiiiIi
    if localbuildcheck == 'Incomplete' :
     o0oOO000oO0oo ( '' , '[COLOR=lime]Your last restore is not yet completed[/COLOR]' , 'url' , o0i1I11iI1iiI ( ) , '' , '' , '' , '' )
     if 48 - 48: IIIIiiII111 . OoooooooOO . OoOoOO00 . ooo0O % oooOooOOo0OO / IIiIi1iI
    else :
     o0oOO000oO0oo ( '' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]Local Build (' + localbuildcheck + ')[/COLOR]' , '' , '' , '' , '' , '' , '' )
  o0oOO000oO0oo ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 11 - 11: i1IIi % iii1i1iiiiIi % IIiIi1iI
 if O0oo0OO0 != '' and I1i1iiI1 != '' and not 'elc' in welcometext :
  o0oOO000oO0oo ( '' , '[COLOR=lime]Unable to login, please check your details[/COLOR]' , 'None' , 'addon_settings' , '' , '' , '' , '' )
  if 99 - 99: iiii / iIii1I11I1II1 - O00OOo00oo0o * oooOooOOo0OO % OoOoOO00
 if not 'elc' in welcometext :
  o0oOO000oO0oo ( '' , welcometext , 'None' , 'register' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=yellow]Settings[/COLOR]' , 'settings' , 'addon_settings' , '' , '' , '' , '' )
 if 13 - 13: iii1i1iiiiIi
 o0oOO000oO0oo ( 'folder' , 'Install Content' , welcometext , 'install_content' , '' , '' , '' , '' )
 if 70 - 70: oo0O0oO + O0 . II11iIiIIIiI * O00OOo00oo0o
 if Oo0oO0ooo == 'true' :
  o0oOO000oO0oo ( 'folder' , 'Hardware Reviews' , 'none' , 'hardware_root_menu' , '' , '' , '' , '' )
  if 2 - 2: OoooooooOO . o0o . i1IiiiI1iI
 if i1 == 'true' :
  o0oOO000oO0oo ( 'folder' , 'Latest News' , 'none' , 'news_root_menu' , '' , '' , '' , '' )
  if 42 - 42: o0o % II11iIiIIIiI / iii1i1iiiiIi - II11iIiIIIiI * i11iIiiIii
 if oOOoo00O0O == 'true' :
  o0oOO000oO0oo ( 'folder' , 'Tutorials' , '' , 'tutorial_root_menu' , '' , '' , '' , '' )
  if 19 - 19: II11iIiIIIiI * OoOoOO00 % i11iIiiIii
 if o0oOoO00o == 'true' :
  o0oOO000oO0oo ( 'folder' , 'Maintenance' , 'none' , 'tools' , '' , '' , '' , '' )
  if 24 - 24: oOoO0o00OO0
  if 10 - 10: oOoO0o00OO0 % O00OOo00oo0o / o0o
def i11Ii1iIiII ( ) :
 O0oOo00Ooo0o0 = 'defaultskindependecycheck'
 if os . path . exists ( OOO00O ) :
  shutil . rmtree ( OOO00O )
  if 33 - 33: IIIIiiII111
 if not os . path . exists ( OOO00O ) :
  os . makedirs ( OOO00O )
  if 87 - 87: ooo0O / i1IiiiI1iI + iIii1I11I1II1
  if 93 - 93: iIii1I11I1II1 + II11iIiIIIiI % iiii
  if 21 - 21: o0o
 if oO0Oo != 'skin.confluence' :
  iIiI1I1IIi11 = os . path . join ( OooO0 , oO0Oo , 'addon.xml' )
  I1I1i11 = open ( iIiI1I1IIi11 , mode = 'r' )
  i1IiIi1i = I1I1i11 . read ( )
  I1I1i11 . close ( )
  if 48 - 48: oOoO0o00OO0 . O00OOo00oo0o + ooo0O % oooOooOOo0OO / i11iIiiIii
  OoOi111i = re . compile ( '<requires[\s\S]*?\/requires' ) . findall ( i1IiIi1i )
  O0oOo00Ooo0o0 = OoOi111i [ 0 ] if ( len ( OoOi111i ) > 0 ) else 'None'
  if 46 - 46: iii1i1iiiiIi * oOo % II11iIiIIIiI + O0 * i1IiiiI1iI
 ii1I11i = iIIii ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' )
 if 89 - 89: oo0O0oO . i1IiiiI1iI % oOo . oOo - OoooooooOO
 iIii1 . create ( 'Backing Up Add-ons' , '' , 'Please Wait...' )
 if 56 - 56: IIIIiiII111
 for O0OOoOOO0oO in os . listdir ( OooO0 ) :
  if 21 - 21: iIii1I11I1II1 / oo0O0oO + iiii - IIIIiiII111 / oOo / II111iiii
  if 69 - 69: OoOoOO00 . ooo0O
  if not 'totalinstaller' in O0OOoOOO0oO and not 'plugin.program.tbs' in O0OOoOOO0oO and not 'packages' in O0OOoOOO0oO and os . path . isdir ( os . path . join ( OooO0 , O0OOoOOO0oO ) ) :
   if 53 - 53: IIIIiiII111
   if 68 - 68: II11iIiIIIiI / oo0O0oO % oo0O0oO % O0
   if O0OOoOOO0oO in ii1I11i and not O0OOoOOO0oO in O0oOo00Ooo0o0 and not 'script.' in O0OOoOOO0oO and not 'repo.' in O0OOoOOO0oO and not 'repository.' in O0OOoOOO0oO and os . path . isdir ( os . path . join ( OooO0 , O0OOoOOO0oO ) ) :
    if 90 - 90: i1IiiiI1iI . iiii / iIii1I11I1II1
    if 28 - 28: i1IiiiI1iI + II11iIiIIIiI - iiii / iIii1I11I1II1 - OoOoOO00
    if not 'service.xbmc.versioncheck' in O0OOoOOO0oO and not 'packages' in O0OOoOOO0oO and os . path . isdir ( os . path . join ( OooO0 , O0OOoOOO0oO ) ) :
     if 45 - 45: O0 / i1IIi * II11iIiIIIiI * iii1i1iiiiIi
     try :
      iIii1 . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % O0OOoOOO0oO , 'Please Wait...' )
      os . makedirs ( os . path . join ( OOO00O , O0OOoOOO0oO ) )
      if 35 - 35: oooOooOOo0OO / IIiIi1iI % OoOoOO00 + iIii1I11I1II1
      iIiiiiii1 = os . path . join ( OOO00O , O0OOoOOO0oO , 'addon.xml' )
      oOO0oo = os . path . join ( OOO00O , O0OOoOOO0oO , 'default.py' )
      I111I11I111 = open ( os . path . join ( OooO0 , O0OOoOOO0oO , 'addon.xml' ) , mode = 'r' )
      iiiiI11ii = I111I11I111 . read ( )
      I111I11I111 . close ( )
      if 79 - 79: ooo0O / iiii
      iii11II1I = re . compile ( ' name="(.+?)"' ) . findall ( iiiiI11ii )
      iI111I11i = re . compile ( 'provider-name="(.+?)"' ) . findall ( iiiiI11ii )
      oOo00o = re . compile ( '<addon[\s\S]*?">' ) . findall ( iiiiI11ii )
      OOoooooooO = re . compile ( '<description[\s\S]*?<\/description>' ) . findall ( iiiiI11ii )
      i1iI = iii11II1I [ 0 ] if ( len ( iii11II1I ) > 0 ) else 'None'
      oOo0OOoO0 = iI111I11i [ 0 ] if ( len ( iI111I11i ) > 0 ) else 'Anonymous'
      iIIii1 = oOo00o [ 0 ] if ( len ( oOo00o ) > 0 ) else 'None'
      i1i1iI1iiiI = OOoooooooO [ 0 ] if ( len ( OOoooooooO ) > 0 ) else 'None'
      if 41 - 41: ooo0O . i11iIiiIii / IIIIiiII111
      oOo00OoO0O = '<addon id="' + O0OOoOOO0oO + '" name="' + i1iI + '" version="0" provider-name="' + oOo0OOoO0 + '">'
      Ooo0oo = '<description>If you\'re seeing this message it means the add-on is still updating, please wait for the update process to complete.</description>'
      if 69 - 69: iIii1I11I1II1 * OoOoOO00 - IIiIi1iI + O0 + O0
      if iIIii1 != 'None' :
       i1I1 = iiiiI11ii . replace ( i1i1iI1iiiI , Ooo0oo ) . replace ( iIIii1 , oOo00OoO0O )
       if 65 - 65: oo0O0oO / i11iIiiIii / iii1i1iiiiIi - o0o
      else :
       i1I1 = iiiiI11ii . replace ( i1i1iI1iiiI , Ooo0oo )
       if 9 - 9: OoOoOO00 / oo0O0oO - oOo * iIii1I11I1II1
      iIIiooO00O00oOO = open ( iIiiiiii1 , mode = 'w+' )
      iIIiooO00O00oOO . write ( str ( i1I1 ) )
      iIIiooO00O00oOO . close ( )
      i11Ii1I1I11I = open ( oOO0oo , mode = 'w+' )
      i11Ii1I1I11I . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + O0OOoOOO0oO + '"\nAddonName="' + i1iI + '"\ndialog=xbmcgui.Dialog()\ndialog.ok(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating so we recommend waiting a few minutes to see if it updates naturally. If it hasn\'t updated after 5mins please try reinstalling via the Community Portal add-on")\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
      i11Ii1I1I11I . close ( )
      if 86 - 86: II111iiii + iiii + i1IiiiI1iI
     except :
      print "### Failed to backup: " + O0OOoOOO0oO
      if 9 - 9: iiii + II111iiii % iiii % i1IiiiI1iI + iIii1I11I1II1
      if 59 - 59: i1IIi
   else :
    shutil . copytree ( os . path . join ( OooO0 , O0OOoOOO0oO ) , os . path . join ( OOO00O , O0OOoOOO0oO ) )
    if 48 - 48: O0 * O00OOo00oo0o * iii1i1iiiiIi . iii1i1iiiiIi * IIIIiiII111 - O00OOo00oo0o
 iIii1 . close ( )
 if 14 - 14: oooOooOOo0OO + i11iIiiIii
 OOOoo = "Creating Backup"
 III1II1iii1i = "Archiving..."
 O0OO0oOO = ""
 ooooO = "Please Wait"
 if 92 - 92: oOoO0o00OO0 / oOoO0o00OO0 * O00OOo00oo0o
 o0O0OO ( OOO00O , OOoOO0oo0ooO , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , '' , '' )
 if 19 - 19: O00OOo00oo0o
 try :
  shutil . rmtree ( OOO00O )
  if 55 - 55: o0o % o0o / O0 % IIiIi1iI - oOoO0o00OO0 . oOo
 except :
  print "### COMMUNITY BUILDS: Failed to remove temp addons folder - manual delete required ###"
  if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
  if 90 - 90: oOoO0o00OO0 % oooOooOOo0OO - iIii1I11I1II1 % ooo0O
def IIiI11I1I1i1i ( url ) :
 iIii1 . create ( 'Cleaning Temp Paths' , '' , 'Please wait...' )
 if os . path . exists ( OOO00O ) :
  shutil . rmtree ( OOO00O )
  if 86 - 86: i1IIi
 if not os . path . exists ( OOO00O ) :
  os . makedirs ( OOO00O )
  if 13 - 13: O0
 extract . all ( OOoOO0oo0ooO , OOO00O )
 if 70 - 70: O00OOo00oo0o . i11iIiiIii % O00OOo00oo0o . O0 - iIii1I11I1II1
 for O0OOoOOO0oO in os . listdir ( OOO00O ) :
  if 26 - 26: o0o
  if not 'totalinstaller' in O0OOoOOO0oO and not 'plugin.program.tbs' in O0OOoOOO0oO :
   if not os . path . exists ( os . path . join ( OooO0 , O0OOoOOO0oO ) ) :
    os . rename ( os . path . join ( OOO00O , O0OOoOOO0oO ) , os . path . join ( OooO0 , O0OOoOOO0oO ) )
    iIii1 . update ( 0 , "Installing: [COLOR=yellow]" + O0OOoOOO0oO + '[/COLOR]' , '' , 'Please wait...' )
    print "### Successfully installed: " + O0OOoOOO0oO
    if 76 - 76: i1IIi * OoooooooOO * O0 + oo0O0oO * oo0O0oO
   else :
    print "### " + O0OOoOOO0oO + " Already exists on system"
    if 35 - 35: oOoO0o00OO0
    if 73 - 73: O0 - oooOooOOo0OO
def ii1I ( welcometext ) :
 oO0O ( 'disclaimer.xml' )
 if iI111I11I1I1 == 'true' :
  o0oOO000oO0oo ( 'folder' , 'I have read and understand the disclaimer.' , welcometext , 'CB_Menu' , '' , '' , '' , '' )
 else :
  o0oOO000oO0oo ( 'folder' , 'I have read and understand the disclaimer.' , 'welcome' , 'CB_Menu' , '' , '' , '' , '' )
  if 59 - 59: OoooooooOO * oOo + i1IIi
  if 23 - 23: iiii
def i11oooOo ( welcometext ) :
 oo0oo0O0 = xbmc . getInfoLabel ( "System.BuildVersion" )
 IiIIiiI = float ( oo0oo0O0 [ : 2 ] )
 Ii1i1iI = int ( IiIIiiI )
 print "#### Welcome: " + welcometext
 if 60 - 60: oo0O0oO
 if 98 - 98: iiii
 if 34 - 34: iIii1I11I1II1 * IIIIiiII111 * IIIIiiII111 / oooOooOOo0OO
 if 28 - 28: iii1i1iiiiIi - II11iIiIIIiI + ooo0O + O00OOo00oo0o / iIii1I11I1II1
 if 26 - 26: iIii1I11I1II1 - O0 . O0
 if 68 - 68: o0o + II11iIiIIIiI . O0 . O00OOo00oo0o % i1IIi % o0o
 if 50 - 50: i1IiiiI1iI + oOoO0o00OO0
 if 96 - 96: iii1i1iiiiIi
 if not 'elc' in welcometext :
  o0oOO000oO0oo ( '' , '[COLOR=orange]To access community builds you must be logged in[/COLOR]' , 'settings' , 'addon_settings' , '' , '' , '' , 'Register at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
  if 92 - 92: oOo / i11iIiiIii + oooOooOOo0OO
 if Oo == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Show My Private List[/COLOR]' , '&visibility=private' , 'grab_builds' , '' , '' , '' , '' )
  if 87 - 87: ooo0O % iIii1I11I1II1
 if ( ( O0oo0OO0 . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) ) :
  if 72 - 72: o0o . o0o - oooOooOOo0OO
  if ( Ii1i1iI < 14 ) or ( iiIIIII1i1iI == 'true' ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Show All Gotham Compatible Builds[/COLOR]' , '&xbmc=gotham&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 48 - 48: oOo - iiii + oOo - OoOoOO00 * i11iIiiIii . IIiIi1iI
  if ( Ii1i1iI == 14 ) or ( iiIIIII1i1iI == 'true' ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Show All Helix Compatible Builds[/COLOR]' , '&xbmc=helix&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 35 - 35: i1IiiiI1iI . O0 + oOo + o0o + i1IIi
  if ( Ii1i1iI == 15 ) or ( iiIIIII1i1iI == 'true' ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Show All Isengard Compatible Builds[/COLOR]' , '&xbmc=isengard&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
  if ( Ii1i1iI == 16 ) or ( iiIIIII1i1iI == 'true' ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Show All Jarvis Compatible Builds[/COLOR]' , '&xbmc=jarvis&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 65 - 65: O0 * OoOoOO00 / OoOoOO00 . ooo0O
  if I11 == 'false' :
   o0oOO000oO0oo ( '' , '[COLOR=gold]How to fix builds broken on other wizards![/COLOR]' , '' , 'instructions_5' , '' , '' , '' , '' )
  if Oo0o0000o0o0 != '' and I11 == 'true' :
   o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan]Show ' + oOo0oooo00o + ' Builds[/COLOR]' , '&id=1' , 'grab_builds' , '' , '' , '' , '' )
  if oO0o0o0ooO0oO != '' and I11 == 'true' :
   o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan]Show ' + oo0o0O00 + ' Builds[/COLOR]' , '&id=2' , 'grab_builds' , '' , '' , '' , '' )
  if oO != '' and I11 == 'true' :
   o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan]Show ' + i1iiIIiiI111 + ' Builds[/COLOR]' , '&id=3' , 'grab_builds' , '' , '' , '' , '' )
  if oooOOOOO != '' and I11 == 'true' :
   o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan]Show ' + i1iiIII111ii + ' Builds[/COLOR]' , '&id=4' , 'grab_builds' , '' , '' , '' , '' )
  if i1iIIi1 != '' and I11 == 'true' :
   o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan]Show ' + ii11iIi1I + ' Builds[/COLOR]' , '&id=5' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Create My Own Community Build' , 'url' , 'backup_option' , '' , '' , '' , 'Back Up Your Full System' )
 if 87 - 87: II111iiii * oooOooOOo0OO % oOo * oOo
 if 58 - 58: o0o . oOoO0o00OO0 + OoOoOO00 % oOo - iii1i1iiiiIi
def I1Iii1Ii1i1 ( skin ) :
 i1iIi1IIiIII1 = '<onleft>%s</onleft>'
 i1Ii11I1II = '<onright>%s</onright>'
 oOOOoo0o = '<onup>%s</onup>'
 iiiI1IiIIii = '<ondown>%s</ondown>'
 IIIIiii = '<control type="button" id="%s">'
 if 26 - 26: OoooooooOO - iiii * i11iIiiIii + O0 * II11iIiIIIiI
 if 87 - 87: oOo + O0 - IIIIiiII111 * iIii1I11I1II1 . oo0O0oO % oOoO0o00OO0
 Oo0oo0oOO0oOo = [
 ( '65' , '140' ) ,
 ( '66' , '164' ) ,
 ( '67' , '162' ) ,
 ( '68' , '142' ) ,
 ( '69' , '122' ) ,
 ( '70' , '143' ) ,
 ( '71' , '144' ) ,
 ( '72' , '145' ) ,
 ( '73' , '127' ) ,
 ( '74' , '146' ) ,
 ( '75' , '147' ) ,
 ( '76' , '148' ) ,
 ( '77' , '166' ) ,
 ( '78' , '165' ) ,
 ( '79' , '128' ) ,
 ( '80' , '129' ) ,
 ( '81' , '120' ) ,
 ( '82' , '123' ) ,
 ( '83' , '141' ) ,
 ( '84' , '124' ) ,
 ( '85' , '126' ) ,
 ( '86' , '163' ) ,
 ( '87' , '121' ) ,
 ( '88' , '161' ) ,
 ( '89' , '125' ) ,
 ( '90' , '160' ) ]
 if 18 - 18: II111iiii + ooo0O - oo0O0oO + iii1i1iiiiIi / iiii % i1IiiiI1iI
 for o0o0O0O000 , I1I1i in Oo0oo0oOO0oOo :
  O0O0oo = open ( skin ) . read ( )
  o00O = O0O0oo . replace ( IIIIiii % o0o0O0O000 , IIIIiii % I1I1i ) . replace ( i1iIi1IIiIII1 % o0o0O0O000 , i1iIi1IIiIII1 % I1I1i ) . replace ( i1Ii11I1II % o0o0O0O000 , i1Ii11I1II % I1I1i ) . replace ( oOOOoo0o % o0o0O0O000 , oOOOoo0o % I1I1i ) . replace ( iiiI1IiIIii % o0o0O0O000 , iiiI1IiIIii % I1I1i )
  ooOo0O0o0 = open ( skin , mode = 'w' )
  ooOo0O0o0 . write ( o00O )
  ooOo0O0o0 . close ( )
  if 88 - 88: i11iIiiIii + IIiIi1iI * ooo0O * IIiIi1iI + IIIIiiII111
def O0OOO00OooO ( u , skin ) :
 i1iIi1IIiIII1 = '<onleft>%s</onleft>'
 i1Ii11I1II = '<onright>%s</onright>'
 oOOOoo0o = '<onup>%s</onup>'
 iiiI1IiIIii = '<ondown>%s</ondown>'
 IIIIiii = '<control type="button" id="%s">'
 if 64 - 64: iii1i1iiiiIi . OoOoOO00 - OoooooooOO . iiii - IIiIi1iI
 if u < 49 :
  O0oO0o000o = u + 61
  if 42 - 42: oo0O0oO * i1IiiiI1iI
 else :
  O0oO0o000o = u + 51
  if 23 - 23: II11iIiIIIiI * oo0O0oO - OoooooooOO * OoooooooOO % iii1i1iiiiIi + II111iiii
 O0O0oo = open ( skin ) . read ( )
 o00O = O0O0oo . replace ( i1iIi1IIiIII1 % u , i1iIi1IIiIII1 % O0oO0o000o ) . replace ( i1Ii11I1II % u , i1Ii11I1II % O0oO0o000o ) . replace ( oOOOoo0o % u , oOOOoo0o % O0oO0o000o ) . replace ( iiiI1IiIIii % u , iiiI1IiIIii % O0oO0o000o ) . replace ( IIIIiii % u , IIIIiii % O0oO0o000o )
 ooOo0O0o0 = open ( skin , mode = 'w' )
 ooOo0O0o0 . write ( o00O )
 ooOo0O0o0 . close ( )
 if 9 - 9: iIii1I11I1II1 * iii1i1iiiiIi % oo0O0oO
 if 46 - 46: IIIIiiII111 . i1IiiiI1iI / II111iiii % iIii1I11I1II1 + i1IiiiI1iI
def O0OOo ( ) :
 i1I1Iiii1 = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 69 - 69: IIIIiiII111 % O0 / OoOoOO00 . oo0O0oO / iiii
 if not os . path . exists ( zip ) :
  OOooO0OOoo . ok ( 'Download/Storage Path Check' , 'The download location you have stored does not exist .\nPlease update the addon settings and try again.' )
  I11i . openSettings ( sys . argv [ 0 ] )
  if 94 - 94: IIIIiiII111 - II111iiii . OoOoOO00 - oOo + oooOooOOo0OO * oooOooOOo0OO
  if 27 - 27: i1IiiiI1iI * OoOoOO00 . iIii1I11I1II1 - iIii1I11I1II1
def I1iI11iii ( ) :
 oo = 'http://noobsandnerds.com/TI/menu_check'
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i111i1I1ii1i = re . compile ( 'd="(.+?)"' ) . findall ( I1111i )
 O0OoooI11iI1I = i111i1I1ii1i [ 0 ] if ( len ( i111i1I1ii1i ) > 0 ) else ''
 if O0OoooI11iI1I != '' :
  return O0OoooI11iI1I
 else :
  return "none"
  if 50 - 50: iIii1I11I1II1 * i1IiiiI1iI . OoooooooOO / II111iiii - oooOooOOo0OO * oooOooOOo0OO
  if 98 - 98: iii1i1iiiiIi - O00OOo00oo0o . i1IiiiI1iI % i11iIiiIii
def OO0OO000 ( localbuildcheck , localversioncheck , id ) :
 oo = 'http://noobsandnerds.com/TI/Community_Builds/buildupdate.php?id=%s' % ( id )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 69 - 69: oooOooOOo0OO + IIiIi1iI * O0 . o0o % ooo0O
 if id != 'None' :
  O0O000O = re . compile ( 'version="(.+?)"' ) . findall ( I1111i )
  iiii1IIi1 = O0O000O [ 0 ] if ( len ( O0O000O ) > 0 ) else ''
  if 87 - 87: i1IiiiI1iI
  if localversioncheck < iiii1IIi1 :
   return True
   if 17 - 17: O00OOo00oo0o / iIii1I11I1II1 - iii1i1iiiiIi + OoOoOO00 % o0o
 else :
  return False
  if 14 - 14: oOoO0o00OO0 % i1IiiiI1iI + oooOooOOo0OO + iii1i1iiiiIi
  if 76 - 76: iii1i1iiiiIi - i11iIiiIii + ooo0O + o0o / OoooooooOO
def o0i1I11iI1iiI ( ) :
 IiI1Iii1 = open ( iiiiiIIii , mode = 'r' )
 iiiiI11ii = IiI1Iii1 . read ( )
 IiI1Iii1 . close ( )
 if 85 - 85: i11iIiiIii / i11iIiiIii . iii1i1iiiiIi . O0
 OooOo = re . compile ( 'name="(.+?)"' ) . findall ( iiiiI11ii )
 oOo0I1Ii11i = OooOo [ 0 ] if ( len ( OooOo ) > 0 ) else ''
 if 19 - 19: i1IiiiI1iI - oOoO0o00OO0 . iIii1I11I1II1 . ooo0O / o0o
 if oOo0I1Ii11i == "Incomplete" :
  i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( "Finish Restore Process" , 'If you\'re certain the correct skin has now been set click OK' , 'to finish the install process, once complete XBMC/Kodi will' , ' then close. Do you want to finish the install process?' , yeslabel = 'Yes' , nolabel = 'No' )
  if 87 - 87: ooo0O - iiii - o0o + oOo % iIii1I11I1II1 / i11iIiiIii
  if i1IiiI1iIi == 1 :
   i1iIIII1iiIIi ( )
   if 17 - 17: IIIIiiII111
  elif i1IiiI1iIi == 0 :
   return
   if 97 - 97: oooOooOOo0OO * oooOooOOo0OO / IIiIi1iI
def i1111IIiI ( ) :
 i1I1Iiii1 = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 49 - 49: o0o - ooo0O % oOoO0o00OO0 % iii1i1iiiiIi
 try :
  os . makedirs ( i1I1Iiii1 )
  os . removedirs ( i1I1Iiii1 )
  OOooO0OOoo . ok ( '[COLOR=lime]SUCCESS[/COLOR]' , 'Great news, the path you chose is writeable.' , 'Some of these builds are rather big, we recommend a minimum of 1GB storage space.' )
  if 32 - 32: i1IiiiI1iI
 except :
  OOooO0OOoo . ok ( '[COLOR=red]CANNOT WRITE TO PATH[/COLOR]' , 'Kodi cannot write to the path you\'ve chosen. Please click OK in the settings menu to save the path then try again. Some devices give false results, we recommend using a USB stick as the backup path.' )
  if 42 - 42: oo0O0oO + o0o + i11iIiiIii
  if 29 - 29: i1IIi + i1IIi
def OO0O00OoOOOo ( s , n ) :
 for o0Ooo0000 in range ( 0 , len ( s ) , n ) :
  yield s [ o0Ooo0000 : o0Ooo0000 + n ]
  if 74 - 74: IIiIi1iI % II111iiii - o0o % OoooooooOO . II11iIiIIIiI
  if 11 - 11: OoOoOO00 * i11iIiiIii / i11iIiiIii
def o00iIiiiII ( data ) :
 data = data . replace ( '</p><p>' , '[CR][CR]' ) . replace ( '&ndash;' , '-' ) . replace ( '&mdash;' , '-' ) . replace ( "\n" , " " ) . replace ( "\r" , " " ) . replace ( "&rsquo;" , "'" ) . replace ( "&rdquo;" , '"' ) . replace ( "</a>" , " " ) . replace ( "&hellip;" , '...' ) . replace ( "&lsquo;" , "'" ) . replace ( "&ldquo;" , '"' )
 data = " " . join ( data . split ( ) )
 Ii1I1 = re . compile ( r'< script[^<>]*?>.*?< / script >' )
 data = Ii1I1 . sub ( '' , data )
 Ii1I1 = re . compile ( r'< style[^<>]*?>.*?< / style >' )
 data = Ii1I1 . sub ( '' , data )
 Ii1I1 = re . compile ( r'' )
 data = Ii1I1 . sub ( '' , data )
 Ii1I1 = re . compile ( r'<[^<]*?>' )
 data = Ii1I1 . sub ( '' , data )
 data = data . replace ( '&nbsp;' , ' ' )
 return data
 if 71 - 71: ooo0O + iIii1I11I1II1 * II11iIiIIIiI . oo0O0oO % i11iIiiIii % iIii1I11I1II1
 if 63 - 63: OoooooooOO * iii1i1iiiiIi / IIIIiiII111 - II11iIiIIIiI . iIii1I11I1II1 + IIiIi1iI
def ii1IIiI1IIi ( ) :
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Clear All Known Cache?' , 'This will clear all known cache files and can help if you\'re encountering kick-outs during playback as well as other random issues. There is no harm in using this.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 76 - 76: IIiIi1iI / iii1i1iiiiIi + ooo0O
 if i1IiiI1iIi == 1 :
  Oooo00 ( )
  iii1II1iI1IIi ( )
  if 41 - 41: OoOoOO00 - oo0O0oO % II111iiii . oo0O0oO - IIIIiiII111
  if 45 - 45: O00OOo00oo0o - o0o
def OOoooO00o0o ( url ) :
 o0oOO000oO0oo ( 'folder' , 'African' , str ( url ) + '&genre=african' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Arabic' , str ( url ) + '&genre=arabic' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Asian' , str ( url ) + '&genre=asian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Australian' , str ( url ) + '&genre=australian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Austrian' , str ( url ) + '&genre=austrian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Belgian' , str ( url ) + '&genre=belgian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Brazilian' , str ( url ) + '&genre=brazilian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Canadian' , str ( url ) + '&genre=canadian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Columbian' , str ( url ) + '&genre=columbian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Czech' , str ( url ) + '&genre=czech' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Danish' , str ( url ) + '&genre=danish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Dominican' , str ( url ) + '&genre=dominican' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Dutch' , str ( url ) + '&genre=dutch' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Egyptian' , str ( url ) + '&genre=egyptian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Filipino' , str ( url ) + '&genre=filipino' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Finnish' , str ( url ) + '&genre=finnish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'French' , str ( url ) + '&genre=french' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'German' , str ( url ) + '&genre=german' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Greek' , str ( url ) + '&genre=greek' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Hebrew' , str ( url ) + '&genre=hebrew' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Hungarian' , str ( url ) + '&genre=hungarian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Icelandic' , str ( url ) + '&genre=icelandic' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Indian' , str ( url ) + '&genre=indian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Irish' , str ( url ) + '&genre=irish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Italian' , str ( url ) + '&genre=italian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Japanese' , str ( url ) + '&genre=japanese' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Korean' , str ( url ) + '&genre=korean' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Lebanese' , str ( url ) + '&genre=lebanese' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Mongolian' , str ( url ) + '&genre=mongolian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Nepali' , str ( url ) + '&genre=nepali' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'New Zealand' , str ( url ) + '&genre=newzealand' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Norwegian' , str ( url ) + '&genre=norwegian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Pakistani' , str ( url ) + '&genre=pakistani' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Polish' , str ( url ) + '&genre=polish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Portuguese' , str ( url ) + '&genre=portuguese' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Romanian' , str ( url ) + '&genre=romanian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Russian' , str ( url ) + '&genre=russian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Singapore' , str ( url ) + '&genre=singapore' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Spanish' , str ( url ) + '&genre=spanish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Swedish' , str ( url ) + '&genre=swedish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Swiss' , str ( url ) + '&genre=swiss' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Syrian' , str ( url ) + '&genre=syrian' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Tamil' , str ( url ) + '&genre=tamil' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Thai' , str ( url ) + '&genre=thai' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Turkish' , str ( url ) + '&genre=turkish' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'UK' , str ( url ) + '&genre=uk' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'USA' , str ( url ) + '&genre=usa' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Vietnamese' , str ( url ) + '&genre=vietnamese' , 'grab_builds' , '' , '' , '' , '' )
 if 10 - 10: O00OOo00oo0o - i11iIiiIii . oooOooOOo0OO % i1IIi
 if 78 - 78: iIii1I11I1II1 * oOo . oOo - o0o . iIii1I11I1II1
def I111I1I ( ) :
 if os . path . exists ( OOO00O ) :
  shutil . rmtree ( OOO00O )
 Oo0000 = 1
 O0OOo ( )
 oO0OoOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , '' ) )
 oOOOOOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
 i1I11ii = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 72 - 72: IIIIiiII111
 if not os . path . exists ( oO0OoOo ) :
  os . makedirs ( oO0OoOo )
  if 87 - 87: i1IIi
 II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this backup" )
 if ( not II1IIiIiiI1iI ) :
  return False , 0
  if 88 - 88: oooOooOOo0OO - O00OOo00oo0o * ooo0O
 OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
 I11I11I11IiIi = xbmc . translatePath ( os . path . join ( oO0OoOo , OOOOO0o0OOo + '.zip' ) )
 OOii1ii1i11I1I = [ IiII1IiiIiI1 ]
 iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 iiIiii = [ IiII1IiiIiI1 , 'cache' , 'system' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' ]
 iiI1ii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
 OOOoo = "Creating full backup of existing build"
 O0OooOO = "Creating Community Build"
 III1II1iii1i = "Archiving..."
 O0OO0oOO = ""
 ooooO = "Please Wait"
 if 49 - 49: i1IiiiI1iI / iiii / o0o
 if i1i1II == 'true' :
  o0O0OO ( oOOoO0 , oOOOOOo , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
  if 25 - 25: OoOoOO00 % O0 + i1IIi - iiii
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
 if 38 - 38: oOoO0o00OO0 % oo0O0oO + i11iIiiIii + IIiIi1iI + iiii / i11iIiiIii
 if i1IiiI1iIi == 0 :
  iiIiii = [ IiII1IiiIiI1 , 'cache' , 'system' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
  if 94 - 94: IIiIi1iI - oOo + II11iIiIIIiI
 elif i1IiiI1iIi == 1 :
  pass
  if 59 - 59: IIIIiiII111 . OoOoOO00 - iIii1I11I1II1 + iIii1I11I1II1
 oO0o0Oo ( oOOoO0 )
 o0O0OO ( oOOoO0 , I11I11I11IiIi , O0OooOO , III1II1iii1i , O0OO0oOO , ooooO , iiIiii , iiI1ii )
 time . sleep ( 1 )
 if 76 - 76: iiii / ooo0O + oooOooOOo0OO
 IiI11I111 = xbmc . translatePath ( os . path . join ( oO0OoOo , OOOOO0o0OOo + '_guisettings.zip' ) )
 Ooo000O00 = zipfile . ZipFile ( IiI11I111 , mode = 'w' )
 if 36 - 36: o0o % i11iIiiIii
 try :
  Ooo000O00 . write ( O0o0Oo , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
 except :
  Oo0000 = 0
  if 47 - 47: i1IIi + II111iiii . oOo * II11iIiIIIiI . IIIIiiII111 / i1IIi
 try :
  Ooo000O00 . write ( xbmc . translatePath ( os . path . join ( oOOoO0 , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
 except :
  pass
  if 50 - 50: oo0O0oO / i1IIi % OoooooooOO
 Ooo000O00 . close ( )
 if 83 - 83: oooOooOOo0OO * oooOooOOo0OO + o0o
 if i1i1II == 'true' :
  OooooOoO = zipfile . ZipFile ( i1I11ii , mode = 'w' )
  try :
   OooooOoO . write ( O0o0Oo , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
  except :
   Oo0000 = 0
   if 79 - 79: iiii % o0o
  try :
   OooooOoO . write ( xbmc . translatePath ( os . path . join ( oOOoO0 , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
  except :
   pass
  OooooOoO . close ( )
  if 54 - 54: ooo0O - oo0O0oO
  if Oo0000 == 0 :
   OOooO0OOoo . ok ( "FAILED!" , 'The guisettings.xml file could not be found on your system, please reboot and try again.' , '' , '' )
   if 65 - 65: oo0O0oO . iiii + o0o / oOo + i1IiiiI1iI % i1IIi
  else :
   OOooO0OOoo . ok ( "SUCCESS!" , 'You Are Now Backed Up and can share this build with the community.' )
   if 28 - 28: i11iIiiIii + O0 / oooOooOOo0OO
   if i1i1II == 'true' :
    OOooO0OOoo . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + oOOOOOo , '[/COLOR]Universal Backup: [COLOR=dodgerblue]' + I11I11I11IiIi + '[/COLOR]' )
    if 3 - 3: iii1i1iiiiIi * i1IIi . OoOoOO00 . O0 - ooo0O
   else :
    OOooO0OOoo . ok ( "Build Location" , 'Universal Backup:[CR][COLOR=dodgerblue]' + I11I11I11IiIi + '[/COLOR]' )
    if 81 - 81: OoOoOO00 - iIii1I11I1II1 / OoOoOO00 / O0
    if 34 - 34: O00OOo00oo0o * O00OOo00oo0o - oooOooOOo0OO - O0 . i11iIiiIii
def IioOo0O ( ) :
 O0OOo ( )
 if 30 - 30: O00OOo00oo0o . oooOooOOo0OO / o0o
 if os . path . exists ( OOO00O ) :
  shutil . rmtree ( OOO00O )
  if 2 - 2: i1IiiiI1iI % OoOoOO00 - oo0O0oO
 i1IiiI1iIi = OOooO0OOoo . yesno ( 'Create noobsandnerds Build' , 'This backup will only work if you share your build on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal with the rest of the community. It will not work with any other installer/wizard, do you wish to continue?' )
 if 79 - 79: OoooooooOO / oooOooOOo0OO . O0
 if i1IiiI1iIi == 1 :
  iIii1 . create ( 'Checking File Structure' , '' , 'Please wait' , '' )
  if not os . path . exists ( o0O ) :
   os . makedirs ( o0O )
   if 79 - 79: II11iIiIIIiI - II111iiii
  Oo0000 = 1
  oO0OoOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , '' ) )
  oOOOOOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
  i1I11ii = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
  if 43 - 43: i1IIi + O0 % iii1i1iiiiIi / O00OOo00oo0o * OoOoOO00
  if not os . path . exists ( oO0OoOo ) :
   os . makedirs ( oO0OoOo )
   if 89 - 89: OoOoOO00 . oOo + oooOooOOo0OO . O0 % oOoO0o00OO0
  II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this backup" )
  if 84 - 84: OoooooooOO + oo0O0oO / OoOoOO00 % o0o % oooOooOOo0OO * OoOoOO00
  if ( not II1IIiIiiI1iI ) :
   return False , 0
   if 58 - 58: iii1i1iiiiIi - ooo0O . i11iIiiIii % i11iIiiIii / i1IIi / II11iIiIIIiI
  OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
  I11I11I11IiIi = xbmc . translatePath ( os . path . join ( oO0OoOo , OOOOO0o0OOo + '.zip' ) )
  if 24 - 24: OoOoOO00 * i1IIi % iiii / O0 + i11iIiiIii
  if 12 - 12: oooOooOOo0OO / O00OOo00oo0o
  OOii1ii1i11I1I = [ IiII1IiiIiI1 ]
  iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
  iiIiii = [ IiII1IiiIiI1 , 'cache' , 'system' , 'addons' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' , 'script.module.metahandler' , 'script.artistslideshow' , 'ArtistSlideshow' ]
  iiI1ii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
  OOOoo = "Creating full backup of existing build"
  O0OooOO = "Creating Community Build"
  III1II1iii1i = "Archiving..."
  O0OO0oOO = ""
  ooooO = "Please Wait"
  if 5 - 5: OoooooooOO
  if 18 - 18: OoOoOO00 % OoooooooOO - IIiIi1iI . i11iIiiIii * oOo % O00OOo00oo0o
  if i1i1II == 'true' :
   o0O0OO ( oOOoO0 , oOOOOOo , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
   if 12 - 12: i1IIi / o0o % iiii * i1IiiiI1iI * O0 * iIii1I11I1II1
  i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
  if 93 - 93: oOo / oooOooOOo0OO + i1IIi * II11iIiIIIiI . OoooooooOO
  if 54 - 54: O0 / i1IiiiI1iI % iiii * i1IIi * O0
  if i1IiiI1iIi == 0 :
   iiIiii = [ IiII1IiiIiI1 , 'cache' , 'system' , 'addons' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
   if 48 - 48: oOoO0o00OO0 . II11iIiIIIiI % ooo0O - ooo0O
  elif i1IiiI1iIi == 1 :
   pass
   if 33 - 33: IIIIiiII111 % II111iiii + iii1i1iiiiIi
   if 93 - 93: i1IIi . i1IiiiI1iI / OoOoOO00 + i1IiiiI1iI
  i11Ii1iIiII ( )
  oO0o0Oo ( oOOoO0 )
  o0O0OO ( oOOoO0 , I11I11I11IiIi , O0OooOO , III1II1iii1i , O0OO0oOO , ooooO , iiIiii , iiI1ii )
  if 58 - 58: oooOooOOo0OO + O0 . oOo + ooo0O - iii1i1iiiiIi - ooo0O
  if 41 - 41: oOo / i1IIi / oOo - IIiIi1iI . oOoO0o00OO0
  try :
   os . remove ( OOoOO0oo0ooO )
  except :
   pass
   if 65 - 65: O0 * i11iIiiIii . OoooooooOO / OoOoOO00 / IIiIi1iI
  try :
   os . remove ( OOO00O )
  except :
   pass
   if 69 - 69: iiii % iiii
  time . sleep ( 1 )
  if 76 - 76: i11iIiiIii * IIiIi1iI / iii1i1iiiiIi % oooOooOOo0OO + o0o
  if 48 - 48: iIii1I11I1II1 % i1IIi + ooo0O % oOoO0o00OO0
  IiI11I111 = xbmc . translatePath ( os . path . join ( oO0OoOo , OOOOO0o0OOo + '_guisettings.zip' ) )
  if 79 - 79: ooo0O % OoOoOO00 % O00OOo00oo0o / i1IIi % iii1i1iiiiIi
  if 56 - 56: iIii1I11I1II1 - i11iIiiIii * IIiIi1iI
  try :
   shutil . copyfile ( O0o0Oo , os . path . join ( o0O , 'guisettings.xml' ) )
   print "### Successfully copied guisettings to : " + os . path . join ( o0O , 'guisettings.xml' )
   if 84 - 84: o0o + O00OOo00oo0o + oOoO0o00OO0
  except :
   print "### FAILED TO copy guisettings to : " + os . path . join ( o0O , 'guisettings.xml' )
   Oo0000 = 0
   if 33 - 33: O00OOo00oo0o
  try :
   shutil . copyfile ( xbmc . translatePath ( os . path . join ( oOOoO0 , 'userdata' , 'profiles.xml' ) ) , xbmc . translatePath ( os . path . join ( o0O , 'profiles.xml' ) ) )
   print "### Successfully copied profiles to : " + os . path . join ( o0O , 'profiles.xml' )
   if 93 - 93: iiii
  except :
   pass
   if 34 - 34: II11iIiIIIiI - iiii * oOo / oOoO0o00OO0
  iI1iiIi1 = os . path . join ( iiI1IiI , 'script.skinshortcuts' )
  if os . path . exists ( iI1iiIi1 ) :
   try :
    shutil . copytree ( os . path . join ( iiI1IiI , 'script.skinshortcuts' ) , os . path . join ( o0O , 'script.skinshortcuts' ) )
    print "### Successfully copied skinshortcuts to : " + os . path . join ( o0O , 'script.skinshortcuts' )
    if 49 - 49: iiii . II111iiii
   except :
    OOooO0OOoo . ok ( 'Failed to copy Skin Shortcuts' , 'There was an error trying to backup your script.skinshortcuts, please try again and if you continue to receive this message upload a log and send details to the noobsandnerds forum.' )
    print "### FAILED to copy skinshortcuts to: " + os . path . join ( o0O , 'script.skinshortcuts' )
    if 24 - 24: O0 . OoooooooOO - iii1i1iiiiIi * OoooooooOO
  iIIIiIi1I1i ( o0O , IiI11I111 )
  if 12 - 12: O0 + i1IiiiI1iI * i1IIi . iii1i1iiiiIi
  if 71 - 71: oo0O0oO - oOoO0o00OO0 - o0o
  if 28 - 28: iIii1I11I1II1
  if 7 - 7: oOoO0o00OO0 % i1IiiiI1iI * ooo0O
  if i1i1II == 'true' :
   iIIIiIi1I1i ( o0O , i1I11ii )
   if 58 - 58: i1IiiiI1iI / IIIIiiII111 + II111iiii % IIiIi1iI - OoooooooOO
   if 25 - 25: ooo0O % OoooooooOO * oOo - i1IIi * II111iiii * II11iIiIIIiI
  if os . path . exists ( o0O ) :
   shutil . rmtree ( o0O )
   if 30 - 30: IIIIiiII111 % ooo0O / oooOooOOo0OO * O0 * O00OOo00oo0o . OoOoOO00
  if Oo0000 == 0 :
   OOooO0OOoo . ok ( 'ERROR' , 'There was an error backing up your guisettings.xml, you cannot share a build without one so please try again. If this keeps happening please upload a log and contact the noobsandnerds forum with details.' )
   if 46 - 46: ooo0O - O0
  else :
   OOooO0OOoo . ok ( "SUCCESS!" , 'You Are Now Backed Up and can share this build with the community.' )
   if 70 - 70: IIIIiiII111 + oOo * iIii1I11I1II1 . OoOoOO00 * IIIIiiII111
   if i1i1II == 'true' :
    OOooO0OOoo . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + oOOOOOo , '[/COLOR]Universal Backup (this will ONLY work for sharing on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal):[CR][COLOR=dodgerblue]' + I11I11I11IiIi + '[/COLOR]' )
    if 49 - 49: oOoO0o00OO0
   else :
    OOooO0OOoo . ok ( "Build Location" , 'Universal Backup (this will ONLY work for sharing on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal):[CR][COLOR=dodgerblue]' + I11I11I11IiIi + '[/COLOR]' )
    if 25 - 25: IIiIi1iI . OoooooooOO * iIii1I11I1II1 . oOoO0o00OO0 / O0 + O00OOo00oo0o
    if 68 - 68: oOo
def ii111I11Ii ( url , video ) :
 oo = 'http://noobsandnerds.com/TI/Community_Builds/community_builds_premium.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i11IiiI1Ii1 = re . compile ( 'path="(.+?)"' ) . findall ( I1111i )
 I1iiIiiIiiI = re . compile ( 'myart="(.+?)"' ) . findall ( I1111i )
 oOoO = re . compile ( 'artpack="(.+?)"' ) . findall ( I1111i )
 oOIIiIi = re . compile ( 'videopreview="(.+?)"' ) . findall ( I1111i )
 ii1IIii = re . compile ( 'videoguide1="(.+?)"' ) . findall ( I1111i )
 IiI11i1I11111 = re . compile ( 'videoguide2="(.+?)"' ) . findall ( I1111i )
 Ii1IIIIIIiI1 = re . compile ( 'videoguide3="(.+?)"' ) . findall ( I1111i )
 Ii11IiIiiii1 = re . compile ( 'videoguide4="(.+?)"' ) . findall ( I1111i )
 OooO0O0Ooo = re . compile ( 'videoguide5="(.+?)"' ) . findall ( I1111i )
 oO0OIIIiIi1iiI = re . compile ( 'videolabel1="(.+?)"' ) . findall ( I1111i )
 iI1 = re . compile ( 'videolabel2="(.+?)"' ) . findall ( I1111i )
 o0Iiii = re . compile ( 'videolabel3="(.+?)"' ) . findall ( I1111i )
 I1i1I = re . compile ( 'videolabel4="(.+?)"' ) . findall ( I1111i )
 i1111iI1 = re . compile ( 'videolabel5="(.+?)"' ) . findall ( I1111i )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 Oo0oOOOOo = re . compile ( 'author="(.+?)"' ) . findall ( I1111i )
 IIo0Oo0oO0oOO00 = re . compile ( 'version="(.+?)"' ) . findall ( I1111i )
 OOoooooooO = re . compile ( 'description="(.+?)"' ) . findall ( I1111i )
 iii = re . compile ( 'DownloadURL="(.+?)"' ) . findall ( I1111i )
 O000OOO = re . compile ( 'UpdateURL="(.+?)"' ) . findall ( I1111i )
 o0IIi1 = re . compile ( 'UpdateDate="(.+?)"' ) . findall ( I1111i )
 O00O00o = re . compile ( 'UpdateDesc="(.+?)"' ) . findall ( I1111i )
 oooO = re . compile ( 'updated="(.+?)"' ) . findall ( I1111i )
 I11IiI1iI = re . compile ( 'defaultskin="(.+?)"' ) . findall ( I1111i )
 O0OO0OoO = re . compile ( 'skins="(.+?)"' ) . findall ( I1111i )
 o0OOo = re . compile ( 'videoaddons="(.+?)"' ) . findall ( I1111i )
 IiI1Ii11Ii = re . compile ( 'audioaddons="(.+?)"' ) . findall ( I1111i )
 OoO0oO0oo0O = re . compile ( 'programaddons="(.+?)"' ) . findall ( I1111i )
 oooOOO0ooOoOOO = re . compile ( 'pictureaddons="(.+?)"' ) . findall ( I1111i )
 o0IiIiI111IIII1 = re . compile ( 'sources="(.+?)"' ) . findall ( I1111i )
 OOOoOooO000oO = re . compile ( 'adult="(.+?)"' ) . findall ( I1111i )
 o0OOOOOo00 = re . compile ( 'guisettings="(.+?)"' ) . findall ( I1111i )
 oo0oOO = re . compile ( 'thumb="(.+?)"' ) . findall ( I1111i )
 IIO000oooOO0Oo0 = re . compile ( 'fanart="(.+?)"' ) . findall ( I1111i )
 I1iIiIii = re . compile ( 'openelec="(.+?)"' ) . findall ( I1111i )
 if 76 - 76: iii1i1iiiiIi . OoooooooOO % oo0O0oO * O00OOo00oo0o
 i1iiI1i = I1iiIiiIiiI [ 0 ] if ( len ( I1iiIiiIiiI ) > 0 ) else ''
 O0OOO00OOO00o = oOoO [ 0 ] if ( len ( oOoO ) > 0 ) else ''
 i1I1Iiii1 = i11IiiI1Ii1 [ 0 ] if ( len ( i11IiiI1Ii1 ) > 0 ) else ''
 O0OOoOOO0oO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 i11o00Ooo = Oo0oOOOOo [ 0 ] if ( len ( Oo0oOOOOo ) > 0 ) else ''
 Ii1i1iI = IIo0Oo0oO0oOO00 [ 0 ] if ( len ( IIo0Oo0oO0oOO00 ) > 0 ) else ''
 Ooo0oo = OOoooooooO [ 0 ] if ( len ( OOoooooooO ) > 0 ) else 'No information available'
 ii1I1IiiI1ii1i = oooO [ 0 ] if ( len ( oooO ) > 0 ) else ''
 OoO00OOoOOOo0 = I11IiI1iI [ 0 ] if ( len ( I11IiI1iI ) > 0 ) else ''
 oOoO00O = O0OO0OoO [ 0 ] if ( len ( O0OO0OoO ) > 0 ) else ''
 I11I1I1i1i = o0OOo [ 0 ] if ( len ( o0OOo ) > 0 ) else ''
 Oo0oOO0O00 = IiI1Ii11Ii [ 0 ] if ( len ( IiI1Ii11Ii ) > 0 ) else ''
 o00OOo0o0O = OoO0oO0oo0O [ 0 ] if ( len ( OoO0oO0oo0O ) > 0 ) else ''
 I111Iii1 = oooOOO0ooOoOOO [ 0 ] if ( len ( oooOOO0ooOoOOO ) > 0 ) else ''
 i11i = o0IiIiI111IIII1 [ 0 ] if ( len ( o0IiIiI111IIII1 ) > 0 ) else ''
 O0o0O00o0o = OOOoOooO000oO [ 0 ] if ( len ( OOOoOooO000oO ) > 0 ) else ''
 II1IIiiI1 = o0OOOOOo00 [ 0 ] if ( len ( o0OOOOOo00 ) > 0 ) else 'None'
 O00O00 = iii [ 0 ] if ( len ( iii ) > 0 ) else 'None'
 oOooO0OoO = O000OOO [ 0 ] if ( len ( O000OOO ) > 0 ) else 'None'
 o0oOOOOoo0 = o0IIi1 [ 0 ] if ( len ( o0IIi1 ) > 0 ) else 'None'
 ooOO0OOO00o = O00O00o [ 0 ] if ( len ( O00O00o ) > 0 ) else 'None'
 ii1Oo0000oOo = oOIIiIi [ 0 ] if ( len ( oOIIiIi ) > 0 ) else 'None'
 I1I = ii1IIii [ 0 ] if ( len ( ii1IIii ) > 0 ) else 'None'
 ooooo = IiI11i1I11111 [ 0 ] if ( len ( IiI11i1I11111 ) > 0 ) else 'None'
 i11IIIiI1I = Ii1IIIIIIiI1 [ 0 ] if ( len ( Ii1IIIIIIiI1 ) > 0 ) else 'None'
 o0iiiI1I1iIIIi1 = Ii11IiIiiii1 [ 0 ] if ( len ( Ii11IiIiiii1 ) > 0 ) else 'None'
 Iii = OooO0O0Ooo [ 0 ] if ( len ( OooO0O0Ooo ) > 0 ) else 'None'
 O0Oo0o000oO = oO0OIIIiIi1iiI [ 0 ] if ( len ( oO0OIIIiIi1iiI ) > 0 ) else 'None'
 oO0o00oOOooO0 = iI1 [ 0 ] if ( len ( iI1 ) > 0 ) else 'None'
 OOOoO000 = o0Iiii [ 0 ] if ( len ( o0Iiii ) > 0 ) else 'None'
 oOOOO = I1i1I [ 0 ] if ( len ( I1i1I ) > 0 ) else 'None'
 IiIi1ii111i1 = i1111iI1 [ 0 ] if ( len ( i1111iI1 ) > 0 ) else 'None'
 i1i1IIIIIIIi = oo0oOO [ 0 ] if ( len ( oo0oOO ) > 0 ) else 'None'
 oo0o0oOo = IIO000oooOO0Oo0 [ 0 ] if ( len ( IIO000oooOO0Oo0 ) > 0 ) else 'None'
 OoOoO0ooooO0 = I1iIiIii [ 0 ] if ( len ( I1iIiIii ) > 0 ) else 'None'
 if 4 - 4: oOo - iii1i1iiiiIi - i11iIiiIii * oo0O0oO / O00OOo00oo0o - o0o
 IiI1Iii1 = open ( OOO00 , mode = 'w+' )
 IiI1Iii1 . write ( 'id="' + str ( video ) + '"\nname="' + O0OOoOOO0oO + '"\nversion="' + Ii1i1iI + '"' )
 IiI1Iii1 . close ( )
 if 45 - 45: oOoO0o00OO0 % oOo * i1IIi - O0
 oo00ooOooO = open ( iiiiiIIii , mode = 'r' )
 ooIi111iII = oo00ooOooO . read ( )
 oo00ooOooO . close ( )
 if 83 - 83: OoooooooOO + iii1i1iiiiIi * II11iIiIIIiI . O0
 o00o = re . compile ( 'id="(.+?)"' ) . findall ( ooIi111iII )
 iiIIIi1i = o00o [ 0 ] if ( len ( o00o ) > 0 ) else 'None'
 iIi1i1i1II11I = re . compile ( 'version="(.+?)"' ) . findall ( ooIi111iII )
 i1i = iIi1i1i1II11I [ 0 ] if ( len ( iIi1i1i1II11I ) > 0 ) else 'None'
 O0OO , OO0OooOo , ii111iI1i1 = url . partition ( '&' )
 print "### Community Build Details:"
 print "### Name: " + O0OOoOOO0oO
 print "### URL: " + O00O00
 o0oOO000oO0oo ( '' , '[COLOR=yellow]IMPORTANT:[/COLOR] Install Instructions' , '' , 'instructions_2' , '' , '' , '' , '' )
 oo0O0O00 ( '[COLOR=yellow]Description:[/COLOR] This contains important info from the build author' , 'None' , 'description' , '' , oo0o0oOo , O0OOoOOO0oO , i11o00Ooo , Ii1i1iI , Ooo0oo , ii1I1IiiI1ii1i , oOoO00O , I11I1I1i1i , Oo0oOO0O00 , o00OOo0o0O , I111Iii1 , i11i , O0o0O00o0o )
 if 80 - 80: iii1i1iiiiIi / i1IiiiI1iI * OoOoOO00 % i1IiiiI1iI
 if iiIIIi1i == O0OO and i1i != Ii1i1iI :
  o0oOO000oO0oo ( '' , '[COLOR=orange]----------------- UPDATE AVAILABLE ------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  o00oooO0Oo ( '[COLOR=dodgerblue]1. Update:[/COLOR] Overwrite My Current Setup & Install New Build' , O00O00 , 'restore_community' , i1i1IIIIIIIi , '' , 'update' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  o00oooO0Oo ( '[COLOR=dodgerblue]2. Update:[/COLOR] Keep My Library & Profiles' , O00O00 , 'restore_community' , i1i1IIIIIIIi , '' , 'updatelibprofile' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  o00oooO0Oo ( '[COLOR=dodgerblue]3. Update:[/COLOR] Keep My Library Only' , O00O00 , 'restore_community' , i1i1IIIIIIIi , '' , 'updatelibrary' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  o00oooO0Oo ( '[COLOR=dodgerblue]4. Update:[/COLOR] Keep My Profiles Only' , O00O00 , 'restore_community' , i1i1IIIIIIIi , '' , 'updateprofiles' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  if 95 - 95: O0 / IIIIiiII111 . oo0O0oO
 if ii1Oo0000oOo != 'None' or I1I != 'None' or ooooo != 'None' or i11IIIiI1I != 'None' or o0iiiI1I1iIIIi1 != 'None' or Iii != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]------------------ VIDEO GUIDES -----------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 17 - 17: IIIIiiII111
 if ii1Oo0000oOo != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] Preview[/COLOR]' , ii1Oo0000oOo , 'play_video' , '' , oo0o0oOo , '' , '' )
  if 56 - 56: iiii * oOoO0o00OO0 + IIIIiiII111
 if I1I != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + O0Oo0o000oO + '[/COLOR]' , I1I , 'play_video' , '' , oo0o0oOo , '' , '' )
  if 48 - 48: i1IiiiI1iI * iii1i1iiiiIi % oo0O0oO - IIIIiiII111
 if ooooo != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + oO0o00oOOooO0 + '[/COLOR]' , ooooo , 'play_video' , '' , oo0o0oOo , '' , '' )
  if 72 - 72: i1IIi % iiii % i1IiiiI1iI % II11iIiIIIiI - II11iIiIIIiI
 if i11IIIiI1I != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + OOOoO000 + '[/COLOR]' , i11IIIiI1I , 'play_video' , '' , oo0o0oOo , '' , '' )
  if 97 - 97: oOoO0o00OO0 * O0 / oOoO0o00OO0 * iii1i1iiiiIi * oOo
 if o0iiiI1I1iIIIi1 != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + oOOOO + '[/COLOR]' , o0iiiI1I1iIIIi1 , 'play_video' , '' , oo0o0oOo , '' , '' )
  if 38 - 38: oo0O0oO
 if Iii != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + IiIi1ii111i1 + '[/COLOR]' , Iii , 'play_video' , '' , oo0o0oOo , '' , '' )
  if 25 - 25: iIii1I11I1II1 % II111iiii / IIIIiiII111 / oooOooOOo0OO
 if iiIIIi1i != O0OO :
  o0oOO000oO0oo ( '' , '[COLOR=orange]------------------ INSTALL OPTIONS ------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 22 - 22: II11iIiIIIiI * IIiIi1iI
 if O00O00 == 'None' :
  o00oooO0Oo ( '[COLOR=orange]Sorry this build is currently unavailable[/COLOR]' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 4 - 4: ooo0O - II11iIiIIIiI + OoOoOO00
 if iiIIIi1i != O0OO :
  if IiiI1III1I1 ( ) and OoOoO0ooooO0 != 'None' :
   if 36 - 36: i1IiiiI1iI
   o00oooO0Oo ( '[COLOR=darkcyan]OpenELEC FRESH INSTALL[/COLOR]' , OoOoO0ooooO0 , 'restore_openelec' , i1i1IIIIIIIi , oo0o0oOo , II1IIiiI1 , O0OOoOOO0oO , '' , '' , '' )
   if 19 - 19: ooo0O . oOoO0o00OO0 . OoooooooOO
   if 13 - 13: o0o . oOo / II111iiii
  o00oooO0Oo ( '[COLOR=dodgerblue]1. Install:[/COLOR] Overwrite My Current Setup & Install New Build' , O00O00 , 'restore_community' , i1i1IIIIIIIi , oo0o0oOo , 'merge' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  o00oooO0Oo ( '[COLOR=dodgerblue]2. Install:[/COLOR] Keep My Library & Profiles' , O00O00 , 'restore_community' , i1i1IIIIIIIi , oo0o0oOo , 'libprofile' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  o00oooO0Oo ( '[COLOR=dodgerblue]3. Install:[/COLOR] Keep My Library Only' , O00O00 , 'restore_community' , i1i1IIIIIIIi , oo0o0oOo , 'library' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  o00oooO0Oo ( '[COLOR=dodgerblue]4. Install:[/COLOR] Keep My Profiles Only' , O00O00 , 'restore_community' , i1i1IIIIIIIi , oo0o0oOo , 'profiles' , O0OOoOOO0oO , OoO00OOoOOOo0 , II1IIiiI1 , O0OOO00OOO00o )
  if 43 - 43: iIii1I11I1II1 % iii1i1iiiiIi
 if II1IIiiI1 != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]---------- (OPTIONAL) Guisettings Fix ----------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  o0oOO000oO0oo ( '' , '[COLOR=orange]Install Step 2:[/COLOR] Apply guisettings.xml fix' , II1IIiiI1 , 'guisettingsfix' , '' , oo0o0oOo , '' , '' )
  if 84 - 84: oOo
  if 44 - 44: OoooooooOO * i11iIiiIii / oOo
def OoOoO00o00 ( ) :
 OOooooO0o0O0 = xbmcgui . Dialog ( ) . browse ( 3 , 'Select the folder you want to store this file in' , 'files' , '' , False , False )
 II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this keyword" )
 if 74 - 74: ooo0O / i1IIi % OoooooooOO
 if ( not II1IIiIiiI1iI ) :
  return False , 0
  if 52 - 52: i1IiiiI1iI % iiii
 OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
 iIii1 . create ( 'Backing Up Addons & Repositories' , '' , 'Please Wait...' )
 if 25 - 25: IIIIiiII111 / IIIIiiII111 % OoooooooOO - oooOooOOo0OO * II11iIiIIIiI
 if not os . path . exists ( OOO00O ) :
  os . makedirs ( OOO00O )
  if 23 - 23: i11iIiiIii
 ii1I11i = iIIii ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' )
 if 100 - 100: II11iIiIIIiI + O0 . OoOoOO00 + i1IIi - ooo0O + oOoO0o00OO0
 if 65 - 65: II111iiii / oOo
 for O0OOoOOO0oO in os . listdir ( OooO0 ) :
  if not 'metadata' in O0OOoOOO0oO and not 'module' in O0OOoOOO0oO and not 'script.common' in O0OOoOOO0oO and not 'packages' in O0OOoOOO0oO and not 'service.xbmc.versioncheck' in O0OOoOOO0oO and os . path . isdir ( os . path . join ( OooO0 , O0OOoOOO0oO ) ) :
   try :
    iIii1 . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % O0OOoOOO0oO , 'Please Wait...' )
    if 42 - 42: i11iIiiIii . O0
    if 75 - 75: oo0O0oO + iIii1I11I1II1
    if O0OOoOOO0oO in ii1I11i :
     if 19 - 19: OoOoOO00 + i11iIiiIii . i1IiiiI1iI - IIIIiiII111 / O00OOo00oo0o + oOoO0o00OO0
     if not os . path . exists ( os . path . join ( OOO00O , 'addons' , O0OOoOOO0oO ) ) :
      os . makedirs ( os . path . join ( OOO00O , 'addons' , O0OOoOOO0oO ) )
     shutil . copyfile ( os . path . join ( OooO0 , O0OOoOOO0oO , 'addon.xml' ) , os . path . join ( OOO00O , 'addons' , O0OOoOOO0oO , 'addon.xml' ) )
    if not O0OOoOOO0oO in ii1I11i :
     shutil . copytree ( os . path . join ( OooO0 , O0OOoOOO0oO ) , os . path . join ( OOO00O , 'addons' , O0OOoOOO0oO ) )
     if 38 - 38: oOo / iIii1I11I1II1 * iIii1I11I1II1 % oooOooOOo0OO
    O00o = os . path . join ( OOO00O , 'addons' , O0OOoOOO0oO , 'addon.xml' )
    if 55 - 55: iiii % IIIIiiII111 / i11iIiiIii
    if 20 - 20: i1IiiiI1iI / oo0O0oO * i1IiiiI1iI * iii1i1iiiiIi
    if 72 - 72: iii1i1iiiiIi . oOoO0o00OO0 * oooOooOOo0OO . iIii1I11I1II1 % oooOooOOo0OO . O00OOo00oo0o
    O000o0 = open ( O00o , mode = 'r' )
    iiiiI11ii = O000o0 . read ( )
    O000o0 . close ( )
    if 39 - 39: II111iiii + OoooooooOO / o0o / O00OOo00oo0o * ooo0O
    if 71 - 71: i1IIi / oooOooOOo0OO % i11iIiiIii / i1IIi
    oOo00o = re . compile ( '<addon[\s\S]*?">' ) . findall ( iiiiI11ii )
    iIIii1 = oOo00o [ 0 ] if ( len ( oOo00o ) > 0 ) else 'None'
    i1i1Ii1IiIII = re . compile ( 'version="[\s\S]*?"' ) . findall ( iIIii1 )
    I1IIii11 = i1i1Ii1IiIII [ 0 ] if ( len ( i1i1Ii1IiIII ) > 0 ) else '0'
    if 22 - 22: iiii / iiii - O00OOo00oo0o % IIIIiiII111 . o0o + i1IiiiI1iI
    if 64 - 64: i1IIi % oooOooOOo0OO / O00OOo00oo0o % OoooooooOO
    I1iii1 = str ( iIIii1 ) . replace ( I1IIii11 , 'version="0.0.0.1"' )
    i1I1 = iiiiI11ii . replace ( iIIii1 , I1iii1 )
    if 19 - 19: II11iIiIIIiI % OoooooooOO . OoooooooOO
    i11Ii1I1I11I = open ( O00o , mode = 'w' )
    i11Ii1I1I11I . write ( str ( i1I1 ) )
    i11Ii1I1I11I . close ( )
    if 40 - 40: O0 . oo0O0oO / iIii1I11I1II1 * oOoO0o00OO0
   except :
    print "### Failed to create: " + O0OOoOOO0oO + ' ###'
    if 73 - 73: oOo - IIiIi1iI . II11iIiIIIiI % i1IIi . O0
 iiIiii = [ '.svn' , '.git' ]
 iiI1ii = [ '.DS_Store' , 'Thumbs.db' , '.gitignore' ]
 I1oO0oOOOooo = os . path . join ( OOooooO0o0O0 , OOOOO0o0OOo + '.zip' )
 o0O0OO ( OOO00O , I1oO0oOOOooo , 'Creating Keyword' , '' , '' , '' , iiIiii , iiI1ii )
 try :
  shutil . rmtree ( OOO00O )
 except :
  pass
 OOooO0OOoo . ok ( 'New Keyword Created' , 'Please read the instructions on how to share this keyword with the community. Your zip file can be found at:' , '[COLOR=dodgerblue]' + I1oO0oOOOooo + '[/COLOR]' )
 if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % oOoO0o00OO0 / iIii1I11I1II1 * oo0O0oO
 if 3 - 3: o0o . i1IiiiI1iI / oOo
def OooIIi111 ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 oO0o0o0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 11 - 11: oo0O0oO - IIIIiiII111 % i11iIiiIii . iIii1I11I1II1 * OoOoOO00 - oOo
 for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( oO0o0o0O ) :
  iI1I1 = 0
  iI1I1 += len ( Oo0o )
  if 34 - 34: i1IIi - ooo0O + oOoO0o00OO0 - oOo % oooOooOOo0OO
  if iI1I1 >= 0 :
   if 43 - 43: IIIIiiII111 % i1IIi % iiii . i11iIiiIii
   for ooOo0O0o0 in Oo0o :
    os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    if 56 - 56: O0 * IIiIi1iI + IIiIi1iI * iIii1I11I1II1 / iiii * oo0O0oO
   for ii1iIIiii1 in i1iiIIIi :
    shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
    if 25 - 25: iIii1I11I1II1 . IIIIiiII111 * i11iIiiIii + oOo * IIIIiiII111
    if 67 - 67: IIiIi1iI
def oooO0o ( ) :
 for I1iII11ii1 in glob . glob ( os . path . join ( oOOoo0Oo , 'xbmc_crashlog*.*' ) ) :
  Ii111I11 = I1iII11ii1
  os . remove ( I1iII11ii1 )
  OOooO0OOoo = xbmcgui . Dialog ( )
  OOooO0OOoo . ok ( "Crash Logs Deleted" , "Your old crash logs have now been deleted." )
  if 51 - 51: OoooooooOO + oOoO0o00OO0 * iIii1I11I1II1 * II11iIiIIIiI / i1IIi
  if 19 - 19: IIiIi1iI - ooo0O % II11iIiIIIiI / OoooooooOO % IIiIi1iI
def ooO ( ) :
 print '############################################################       DELETING PACKAGES             ###############################################################'
 oOoO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 if 31 - 31: i11iIiiIii - iiii / oooOooOOo0OO - O00OOo00oo0o
 for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( oOoO0 ) :
  iI1I1 = 0
  iI1I1 += len ( Oo0o )
  if 5 - 5: i11iIiiIii * oOo
  if iI1I1 > 0 :
   if 29 - 29: O00OOo00oo0o / iiii % IIIIiiII111
   for ooOo0O0o0 in Oo0o :
    os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    if 10 - 10: iIii1I11I1II1 % OoooooooOO % oooOooOOo0OO
   for ii1iIIiii1 in i1iiIIIi :
    shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
    if 39 - 39: II111iiii * ooo0O . O0 * IIIIiiII111
    if 89 - 89: O00OOo00oo0o - iiii . IIIIiiII111 - oo0O0oO - OoOoOO00
def o0O00O ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 oO0o0o0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 21 - 21: OoooooooOO . ooo0O - iIii1I11I1II1 % i1IiiiI1iI
 for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( oO0o0o0O ) :
  iI1I1 = 0
  iI1I1 += len ( Oo0o )
  if 55 - 55: O0 % OoOoOO00 . OoooooooOO * oOo / OoooooooOO . O00OOo00oo0o
  if iI1I1 >= 0 :
   if 26 - 26: i1IiiiI1iI / iIii1I11I1II1 - iIii1I11I1II1
   for ooOo0O0o0 in Oo0o :
    os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    if 57 - 57: i1IiiiI1iI
   for ii1iIIiii1 in i1iiIIIi :
    shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
    if 41 - 41: iIii1I11I1II1 * IIiIi1iI + oOo * oOoO0o00OO0 % i1IiiiI1iI / o0o
    if 63 - 63: i1IIi % i11iIiiIii % II111iiii * OoooooooOO
def iIIIi1i1I11i ( name , addon_id ) :
 Oo00OoO00o0 = 1
 oOo00OO = 1
 iIiII1 = xbmc . translatePath ( os . path . join ( OooO0 , addon_id , 'addon.xml' ) )
 i111iii1I1 = open ( iIiII1 , mode = 'r' )
 iiIiII1 = i111iii1I1 . read ( )
 i111iii1I1 . close ( )
 ii111iI = re . compile ( 'import addon="(.+?)"' ) . findall ( iiIiII1 )
 if 9 - 9: iii1i1iiiiIi
 for O0Oo00OoOo in ii111iI :
  if 30 - 30: oOoO0o00OO0 * II111iiii % O0 % OoOoOO00 * O00OOo00oo0o
  if not 'xbmc.python' in O0Oo00OoOo :
   print 'Script Requires --- ' + O0Oo00OoOo
   iI1i1I1 = xbmc . translatePath ( os . path . join ( OooO0 , O0Oo00OoOo ) )
   if 39 - 39: O00OOo00oo0o
   if not os . path . exists ( iI1i1I1 ) :
    oo = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( O0Oo00OoOo )
    I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
    IIo0Oo0oO0oOO00 = re . compile ( 'version="(.+?)"' ) . findall ( I1111i )
    ooO000OO0O00O = re . compile ( 'repo_url="(.+?)"' ) . findall ( I1111i )
    OOOoOO0o = re . compile ( 'data_url="(.+?)"' ) . findall ( I1111i )
    i1II1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( I1111i )
    oo00oO0o = re . compile ( 'repo_id="(.+?)"' ) . findall ( I1111i )
    oOo0000ooO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
    Ii1i1iI = IIo0Oo0oO0oOO00 [ 0 ] if ( len ( IIo0Oo0oO0oOO00 ) > 0 ) else ''
    I1Io0oO0oo = ooO000OO0O00O [ 0 ] if ( len ( ooO000OO0O00O ) > 0 ) else ''
    ooOO00Oo = OOOoOO0o [ 0 ] if ( len ( OOOoOO0o ) > 0 ) else ''
    oO00OOOOOO0o = i1II1 [ 0 ] if ( len ( i1II1 ) > 0 ) else ''
    iIII = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
    OoO0000 = xbmc . translatePath ( os . path . join ( Oo0OoO00oOO0o , oOo0000ooO + '.zip' ) )
    if 11 - 11: iii1i1iiiiIi - O00OOo00oo0o + O0 * iii1i1iiiiIi
    try :
     downloader . download ( I1Io0oO0oo , OoO0000 , iIii1 )
     extract . all ( OoO0000 , OooO0 , iIii1 )
     if 59 - 59: II111iiii
    except :
     if 43 - 43: oOo + OoooooooOO
     try :
      downloader . download ( oO00OOOOOO0o , OoO0000 , iIii1 )
      extract . all ( OoO0000 , OooO0 , iIii1 )
      if 47 - 47: iiii
     except :
      if 92 - 92: IIIIiiII111 % i11iIiiIii % oOo
      try :
       if 23 - 23: II111iiii * IIiIi1iI
       if not os . path . exists ( iI1i1I1 ) :
        os . makedirs ( iI1i1I1 )
        if 80 - 80: oo0O0oO / i11iIiiIii + OoooooooOO
       I1111i = iIIii ( ooOO00Oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
       iiI1i1Iii111 = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( I1111i )
       if 38 - 38: oooOooOOo0OO % iiii + i1IIi * OoooooooOO * II11iIiIIIiI
       for OO00oOooo0O in iiI1i1Iii111 :
        oOOOo = xbmc . translatePath ( os . path . join ( iI1i1I1 , OO00oOooo0O ) )
        if 83 - 83: iIii1I11I1II1 - iiii - oo0O0oO / iii1i1iiiiIi - O0
        if addon_id not in OO00oOooo0O and '/' not in OO00oOooo0O :
         if 81 - 81: O00OOo00oo0o - II11iIiIIIiI * oooOooOOo0OO / oo0O0oO
         try :
          iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + OO00oOooo0O + '[/COLOR]' , '' , 'Please wait...' )
          downloader . download ( ooOO00Oo + OO00oOooo0O , oOOOo , iIii1 )
          if 21 - 21: iii1i1iiiiIi
         except :
          print "failed to install" + OO00oOooo0O
          if 63 - 63: IIIIiiII111 . O0 * IIIIiiII111 + iIii1I11I1II1
        if '/' in OO00oOooo0O and '..' not in OO00oOooo0O and 'http' not in OO00oOooo0O :
         oOOoo0 = ooOO00Oo + OO00oOooo0O
         i1111IIiii1 ( oOOOo , oOOoo0 )
         if 46 - 46: i1IIi + II111iiii * i1IIi - O00OOo00oo0o
      except :
       OOooO0OOoo . ok ( "Error downloading dependency" , 'There was an error downloading [COLOR=dodgerblue]' + oOo0000ooO + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
       oOo00OO = 0
       Oo00OoO00o0 = 0
       if 79 - 79: II111iiii - II11iIiIIIiI * oooOooOOo0OO - ooo0O . oooOooOOo0OO
    if oOo00OO == 1 :
     time . sleep ( 1 )
     iIii1 . update ( 0 , "[COLOR=yellow]" + oOo0000ooO + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Please wait...' )
     time . sleep ( 1 )
     Ii1I11I = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( O0Oo00OoOo )
     try :
      iIIii ( Ii1I11I )
     except :
      pass
 iIii1 . close ( )
 time . sleep ( 1 )
 if 11 - 11: O0 * ooo0O
 if 37 - 37: ooo0O + O0 . O0 * oOo % oo0O0oO / IIiIi1iI
def iIIiOOOo00o ( name , url , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 i1iiIII1IIiIIII ( buildname + '     v.' + version , '[COLOR=yellow][B]Author:   [/B][/COLOR]' + author + '[COLOR=yellow][B]               Last Updated:   [/B][/COLOR]' + updated + '[COLOR=yellow][B]               Adult Content:   [/B][/COLOR]' + adult + '[CR][CR][COLOR=yellow][B]Description:[CR][/B][/COLOR]' + description +
 '[CR][CR][COLOR=blue][B]Skins:   [/B][/COLOR]' + skins + '[CR][CR][COLOR=blue][B]Video Addons:   [/B][/COLOR]' + videoaddons + '[CR][CR][COLOR=blue][B]Audio Addons:   [/B][/COLOR]' + audioaddons +
 '[CR][CR][COLOR=blue][B]Program Addons:   [/B][/COLOR]' + programaddons + '[CR][CR][COLOR=blue][B]Picture Addons:   [/B][/COLOR]' + pictureaddons + '[CR][CR][COLOR=blue][B]Sources:   [/B][/COLOR]' + sources +
 '[CR][CR][COLOR=orange]Disclaimer: [/COLOR]These are community builds and they may overwrite some of your existing settings, '
 'It\'s purely the responsibility of the user to choose whether or not they wish to install these builds, the individual who uploads the build should state what\'s included and then it\'s the users decision to decide whether or not that content is suitable for them.' )
 if 3 - 3: oOoO0o00OO0
 if 16 - 16: i1IIi . i1IIi / oo0O0oO % ooo0O / OoOoOO00 * oooOooOOo0OO
def IIIii11 ( path ) :
 iIii1 . create ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "Wiping..." , '' , 'Please Wait' )
 shutil . rmtree ( path , ignore_errors = True )
 if 29 - 29: O00OOo00oo0o - O00OOo00oo0o / iiii
def i1iIIII1iiIIi ( ) :
 os . remove ( iiiiiIIii )
 os . rename ( O000oo0O , iiiiiIIii )
 xbmc . executebuiltin ( 'UnloadSkin' )
 xbmc . executebuiltin ( "ReloadSkin" )
 OOooO0OOoo . ok ( "Local Restore Complete" , 'XBMC/Kodi will now close.' , '' , '' )
 xbmc . executebuiltin ( "Quit" )
 if 49 - 49: IIIIiiII111 + II11iIiIIIiI % iii1i1iiiiIi - oOo - O0 - OoooooooOO
 if 4 - 4: II111iiii - II11iIiIIIiI % oOo * i11iIiiIii
def oO0o0Oo ( url ) :
 iIii1 . create ( "Changing Physical Paths To Special" , "Renaming paths..." , '' , 'Please Wait' )
 if 18 - 18: oOo % O0
 for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( url ) :
  if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OoOoOO00
  for file in Oo0o :
   if 47 - 47: oooOooOOo0OO * II11iIiIIIiI + iIii1I11I1II1 - II11iIiIIIiI / i1IiiiI1iI
   if file . endswith ( ".xml" ) :
    iIii1 . update ( 0 , "Fixing" , file , 'Please Wait' )
    O0O0oo = open ( ( os . path . join ( OoO0oo0 , file ) ) ) . read ( )
    oO0ooo0O0Ooo = O0O0oo . replace ( oOOoO0 , 'special://home/' )
    ooOo0O0o0 = open ( ( os . path . join ( OoO0oo0 , file ) ) , mode = 'w' )
    ooOo0O0o0 . write ( str ( oO0ooo0O0Ooo ) )
    ooOo0O0o0 . close ( )
    if 33 - 33: II111iiii - i1IiiiI1iI - iiii
    if 92 - 92: iii1i1iiiiIi * i1IiiiI1iI
def ooo00o0OO ( ) :
 if os . path . exists ( OOO00O ) :
  shutil . rmtree ( OOO00O )
 OOii1ii1i11I1I = [ ]
 iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
 OOOoo = "Creating full backup of existing build"
 O0OooOO = "Creating Community Build"
 III1II1iii1i = "Archiving..."
 O0OO0oOO = ""
 ooooO = "Please Wait"
 if 32 - 32: o0o + IIiIi1iI + iIii1I11I1II1 * oOo
 o0O0OO ( oOOoO0 , myfullbackup , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
 if 62 - 62: i11iIiiIii
def i1Iii ( ) :
 o000o0o0ooO0 = 0
 iIi = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
 O0OOoOOO0o0o = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
 iI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 Ooo0ooo0oo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 I11iIiI1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 i1I1iiii1Ii11 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 IiIIIIi = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 OoIIiIIIII1I = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 ooiiI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 o00iIiI1iI1Ii1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 iioO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
 ii11I = os . path . join ( oOOoO0 , 'temp' )
 iIii1 . create ( 'Calculating Used Space' , '' , 'Please wait' , '' )
 if os . path . exists ( iIi ) :
  o000o0o0ooO0 = Ooo0O00 ( iIi , o000o0o0ooO0 )
 if os . path . exists ( O0OOoOOO0o0o ) :
  o000o0o0ooO0 = Ooo0O00 ( O0OOoOOO0o0o , o000o0o0ooO0 )
 if os . path . exists ( iI ) :
  o000o0o0ooO0 = Ooo0O00 ( iI , o000o0o0ooO0 )
 if os . path . exists ( Ooo0ooo0oo ) :
  o000o0o0ooO0 = Ooo0O00 ( Ooo0ooo0oo , o000o0o0ooO0 )
 if os . path . exists ( I11iIiI1 ) :
  o000o0o0ooO0 = Ooo0O00 ( I11iIiI1 , o000o0o0ooO0 )
 if os . path . exists ( i1I1iiii1Ii11 ) :
  o000o0o0ooO0 = Ooo0O00 ( i1I1iiii1Ii11 , o000o0o0ooO0 )
 if os . path . exists ( IiIIIIi ) :
  o000o0o0ooO0 = Ooo0O00 ( IiIIIIi , o000o0o0ooO0 )
 if os . path . exists ( OoIIiIIIII1I ) :
  o000o0o0ooO0 = Ooo0O00 ( OoIIiIIIII1I , o000o0o0ooO0 )
 if os . path . exists ( ooiiI ) :
  o000o0o0ooO0 = Ooo0O00 ( ooiiI , o000o0o0ooO0 )
 if os . path . exists ( o00iIiI1iI1Ii1 ) :
  o000o0o0ooO0 = Ooo0O00 ( o00iIiI1iI1Ii1 , o000o0o0ooO0 )
 if os . path . exists ( iioO ) :
  o000o0o0ooO0 = Ooo0O00 ( iioO , o000o0o0ooO0 )
 if os . path . exists ( ii11I ) :
  o000o0o0ooO0 = Ooo0O00 ( ii11I , o000o0o0ooO0 )
 o000o0o0ooO0 = Ooo0O00 ( ooOoOoo0O , o000o0o0ooO0 )
 o000o0o0ooO0 = Ooo0O00 ( Oo0OoO00oOO0o , o000o0o0ooO0 ) / 1000000
 i1IiiI1iIi = OOooO0OOoo . yesno ( 'Results' , 'You can free up [COLOR=dodgerblue]' + str ( o000o0o0ooO0 ) + 'MB[/COLOR] of space if you run this cleanup program. Would you like to run the cleanup procedure?' )
 if i1IiiI1iIi == 1 :
  Oooo00 ( )
  try :
   shutil . rmtree ( Oo0OoO00oOO0o )
  except :
   pass
  ooo ( )
  IIIii11 ( ooOoOoo0O )
  if 74 - 74: iiii % ooo0O / oOo
  i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Quit Kodi Now?' , 'Cache has been successfully deleted.' , 'You must now restart Kodi, would you like to quit now?' , '' , nolabel = 'I\'ll restart later' , yeslabel = 'Yes, quit' )
  if 2 - 2: i1IiiiI1iI % i1IiiiI1iI % oo0O0oO
  if i1IiiI1iIi == 1 :
   try :
    xbmc . executebuiltin ( "RestartApp" )
    if 60 - 60: o0o
   except :
    o0OoOo00O0o0O ( )
    if 97 - 97: i1IiiiI1iI % iiii + II111iiii - i1IiiiI1iI % iii1i1iiiiIi + iiii
    if 31 - 31: oOoO0o00OO0
def II11i1I ( url ) :
 o0oOO000oO0oo ( 'folder' , 'Anime' , str ( url ) + '&genre=anime' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Audiobooks' , str ( url ) + '&genre=audiobooks' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Comedy' , str ( url ) + '&genre=comedy' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Comics' , str ( url ) + '&genre=comics' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Documentary' , str ( url ) + '&genre=documentary' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Downloads' , str ( url ) + '&genre=downloads' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Food' , str ( url ) + '&genre=food' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Gaming' , str ( url ) + '&genre=gaming' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Health' , str ( url ) + '&genre=health' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'How To...' , str ( url ) + '&genre=howto' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Kids' , str ( url ) + '&genre=kids' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Live TV' , str ( url ) + '&genre=livetv' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Movies' , str ( url ) + '&genre=movies' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Music' , str ( url ) + '&genre=music' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'News' , str ( url ) + '&genre=news' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Photos' , str ( url ) + '&genre=photos' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Podcasts' , str ( url ) + '&genre=podcasts' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Radio' , str ( url ) + '&genre=radio' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Religion' , str ( url ) + '&genre=religion' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Space' , str ( url ) + '&genre=space' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Sports' , str ( url ) + '&genre=sports' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Technology' , str ( url ) + '&genre=tech' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Trailers' , str ( url ) + '&genre=trailers' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'TV Shows' , str ( url ) + '&genre=tv' , 'grab_builds' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Misc.' , str ( url ) + '&genre=other' , 'grab_builds' , '' , '' , '' , '' )
 if 69 - 69: iiii . o0o - OoOoOO00
 if I11i . getSetting ( 'adult' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , 'XXX' , str ( url ) + '&genre=adult' , 'grab_builds' , '' , '' , '' , '' )
  if 29 - 29: i11iIiiIii . oooOooOOo0OO / OoOoOO00 . o0o + i11iIiiIii
def Ooo0O00 ( path , size ) :
 for i1I1i , iiIiiII1II1ii , i1iI1iiI in os . walk ( path ) :
  for ooOo0O0o0 in i1iI1iiI :
   iIii1 . update ( 0 , "Calulating..." , '[COLOR=dodgerblue]' + ooOo0O0o0 + '[/COLOR]' , 'Please Wait' )
   iIII1IiI = os . path . join ( i1I1i , ooOo0O0o0 )
   size += os . path . getsize ( iIII1IiI )
 return size
 if 32 - 32: ooo0O % iii1i1iiiiIi + i11iIiiIii + iiii - O00OOo00oo0o + II11iIiIIIiI
def oo00o0OoO ( default = "" , heading = "" , hidden = False ) :
 iiIIi1II = xbmc . Keyboard ( default , heading , hidden )
 if 1 - 1: ooo0O * O0 . II11iIiIIIiI % O0 + II111iiii
 iiIIi1II . doModal ( )
 if ( iiIIi1II . isConfirmed ( ) ) :
  return unicode ( iiIIi1II . getText ( ) , "utf-8" )
 return default
 if 49 - 49: IIIIiiII111 . o0o
 if 74 - 74: i1IIi
def Ii11ii1 ( ) :
 iiiIiiiI1I = [ ]
 i111I1 = sys . argv [ 2 ]
 if len ( i111I1 ) >= 2 :
  OOOo0Oo0O = sys . argv [ 2 ]
  i1I1I1iIIi = OOOo0Oo0O . replace ( '?' , '' )
  if ( OOOo0Oo0O [ len ( OOOo0Oo0O ) - 1 ] == '/' ) :
   OOOo0Oo0O = OOOo0Oo0O [ 0 : len ( OOOo0Oo0O ) - 2 ]
  IiOo00O0o0O = i1I1I1iIIi . split ( '&' )
  iiiIiiiI1I = { }
  for O0OoOO in range ( len ( IiOo00O0o0O ) ) :
   o0o0oO0OOO = { }
   o0o0oO0OOO = IiOo00O0o0O [ O0OoOO ] . split ( '=' )
   if ( len ( o0o0oO0OOO ) ) == 2 :
    iiiIiiiI1I [ o0o0oO0OOO [ 0 ] ] = o0o0oO0OOO [ 1 ]
    if 66 - 66: O00OOo00oo0o * iIii1I11I1II1 - iiii / OoOoOO00
 return iiiIiiiI1I
 if 62 - 62: i1IiiiI1iI . O0 . iIii1I11I1II1
def o000o0o00Oo ( ) :
 i1I1Iiii1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 iIii1 = xbmcgui . DialogProgress ( )
 iIii1 . create ( "Gotham Addon Fix" , "Please wait whilst your addons" , '' , 'are being made Gotham compatible.' )
 if 62 - 62: IIiIi1iI
 for I1iII11ii1 in glob . glob ( os . path . join ( i1I1Iiii1 , '*.*' ) ) :
  if 8 - 8: IIiIi1iI - OoOoOO00 * oOo % oooOooOOo0OO * OoooooooOO
  for file in glob . glob ( os . path . join ( I1iII11ii1 , '*.*' ) ) :
   if 26 - 26: i1IIi / IIiIi1iI . IIiIi1iI
   if 'addon.xml' in file :
    iIii1 . update ( 0 , "Fixing" , file , 'Please Wait' )
    O0O0oo = open ( file ) . read ( )
    oO0ooo0O0Ooo = O0O0oo . replace ( 'addon="xbmc.python" version="1.0"' , 'addon="xbmc.python" version="2.1.0"' ) . replace ( 'addon="xbmc.python" version="2.0"' , 'addon="xbmc.python" version="2.1.0"' )
    ooOo0O0o0 = open ( file , mode = 'w' )
    ooOo0O0o0 . write ( str ( oO0ooo0O0Ooo ) )
    ooOo0O0o0 . close ( )
    if 20 - 20: o0o - IIiIi1iI / oOo * iii1i1iiiiIi
 OOooO0OOoo = xbmcgui . Dialog ( )
 OOooO0OOoo . ok ( "Your addons have now been made compatible" , "If you still find you have addons that aren't working please run the addon so it throws up a script error, upload a log and post details on the relevant support forum." )
 if 55 - 55: OoooooooOO
 if 73 - 73: ooo0O - oooOooOOo0OO % oOo + oooOooOOo0OO - O0 . iii1i1iiiiIi
def i1iIii ( ) :
 OOooO0OOoo = xbmcgui . Dialog ( )
 O0o00 = xbmcgui . Dialog ( ) . yesno ( 'Convert Addons To Gotham' , 'This will edit your addon.xml files so they show as Gotham compatible. It\'s doubtful this will have any effect on whether or not they work but it will get rid of the annoying incompatible pop-up message. Do you wish to continue?' )
 if 8 - 8: oo0O0oO * oOo - o0o . iIii1I11I1II1
 if O0o00 == 1 :
  o000o0o00Oo ( )
  if 48 - 48: i11iIiiIii / II111iiii + O00OOo00oo0o + oOoO0o00OO0 . oo0O0oO % o0o
  if 88 - 88: oo0O0oO . oo0O0oO
def O0OoO0oooOO ( url ) :
 global IIIi1I1IIii1II
 if 44 - 44: iiii * i11iIiiIii
 if I11i . getSetting ( 'adult' ) == 'true' :
  O0o0O00o0o = 'yes'
  if 6 - 6: oOoO0o00OO0 % o0o * oooOooOOo0OO % O00OOo00oo0o . o0o
 else :
  O0o0O00o0o = 'no'
  if 43 - 43: iii1i1iiiiIi . iiii * oOo
 iio00O0o00oo = 'http://noobsandnerds.com/TI/AddonPortal/sortby_new.php?sortx=name&user=%s&adult=%s&%s' % ( O0oo0OO0 , O0o0O00o0o , url )
 I1111i = iIIii ( iio00O0o00oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 19 - 19: OoOoOO00
 iiI1i1Iii111 = re . compile ( 'name="(.+?)"  <br> downloads="(.+?)"  <br> icon="(.+?)"  <br> broken="(.+?)"  <br> UID="(.+?)"  <br>' , re . DOTALL ) . findall ( I1111i )
 if iiI1i1Iii111 == [ ] :
  if 66 - 66: II11iIiIIIiI / ooo0O
  iiI1i1Iii111 = re . compile ( 'name="(.+?)" <br> downloads="(.+?)" <br> icon="(.+?)" <br> broken="(.+?)" <br> UID="(.+?)" <br>' , re . DOTALL ) . findall ( I1111i )
 print iiI1i1Iii111
 if 13 - 13: II111iiii
 if iiI1i1Iii111 != [ ] :
  oO0o000oOO ( iio00O0o00oo , 'addons' )
  if 27 - 27: O0 - IIIIiiII111 * II111iiii - iIii1I11I1II1 / iiii
  for O0OOoOOO0oO , O0o , i11111I1I , O00OoOO0oo0 , II1i in iiI1i1Iii111 :
   if 98 - 98: ooo0O - ooo0O . II111iiii . IIiIi1iI + O0
   if O00OoOO0oo0 == '0' :
    o0oOO000oO0oo ( 'folder2' , O0OOoOOO0oO + '[COLOR=lime] [' + O0o + ' downloads][/COLOR]' , II1i , 'addon_final_menu' , i11111I1I , '' , '' )
    if 28 - 28: i1IiiiI1iI + i11iIiiIii + OoooooooOO / iii1i1iiiiIi
   if O00OoOO0oo0 == '1' :
    o0oOO000oO0oo ( 'folder2' , '[COLOR=red]' + O0OOoOOO0oO + ' [REPORTED AS BROKEN][/COLOR]' , II1i , 'addon_final_menu' , i11111I1I , '' , '' )
    if 6 - 6: OoOoOO00 - i11iIiiIii
 elif '&redirect' in url :
  i1IiiI1iIi = OOooO0OOoo . yesno ( 'No Content Found' , 'This add-on cannot be found on the Add-on Portal.' , '' , 'Would you like to remove this item from your setup?' )
  if 61 - 61: oo0O0oO * oooOooOOo0OO % OoOoOO00 % iii1i1iiiiIi % IIIIiiII111 + IIIIiiII111
  if i1IiiI1iIi == 1 : print "remove"
  if 6 - 6: oOo
 else :
  OOooO0OOoo . ok ( 'No Content Found' , 'Sorry no content can be found that matches' , 'your search criteria.' , '' )
  if 73 - 73: oo0O0oO * oooOooOOo0OO + oOoO0o00OO0 - oOo . IIIIiiII111
  if 93 - 93: i11iIiiIii
def OoOiII11IiIi ( url ) :
 if zip == '' :
  OOooO0OOoo . ok ( 'Storage/Download Folder Not Set' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' , '' , '' )
  I11i . openSettings ( sys . argv [ 0 ] )
  if 27 - 27: iii1i1iiiiIi + ooo0O
 if I11i . getSetting ( 'adult' ) == 'true' :
  O0o0O00o0o = ''
  if 97 - 97: i1IIi * oo0O0oO . II111iiii
 else :
  O0o0O00o0o = 'no'
  if 62 - 62: OoooooooOO . O00OOo00oo0o
 if not 'id=' in url :
  iio00O0o00oo = 'http://noobsandnerds.com/TI/Community_Builds/sortby.php?sortx=name&orderx=ASC&adult=%s&%s' % ( O0o0O00o0o , url )
  I1111i = iIIii ( iio00O0o00oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  if 28 - 28: II11iIiIIIiI . II11iIiIIIiI . iIii1I11I1II1 . o0o . oooOooOOo0OO * i11iIiiIii
  iiI1i1Iii111 = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> Thumbnail="(.+?)"  <br> Fanart="(.+?)"  <br> downloads="(.+?)"  <br> <br>' , re . DOTALL ) . findall ( I1111i )
  if iiI1i1Iii111 == [ ] :
   if 72 - 72: IIIIiiII111
   iiI1i1Iii111 = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> Thumbnail="(.+?)" <br> Fanart="(.+?)" <br> downloads="(.+?)" <br> <br>' , re . DOTALL ) . findall ( I1111i )
  oO0o000oOO ( url , 'communitybuilds' )
  if 26 - 26: i1IiiiI1iI % oOo
  for O0OOoOOO0oO , id , OoOOoo , II1ii1 , O0o in iiI1i1Iii111 :
   o00oooO0Oo ( O0OOoOOO0oO + '[COLOR=lime] (' + O0o + ' downloads)[/COLOR]' , id + url , 'community_menu' , OoOOoo , II1ii1 , id , '' , '' , '' , '' )
   if 34 - 34: ooo0O - II11iIiIIIiI * OoooooooOO
 if 'id=1' in url : iio00O0o00oo = Oo0o0000o0o0
 if 'id=2' in url : iio00O0o00oo = oO0o0o0ooO0oO
 if 'id=3' in url : iio00O0o00oo = oO
 if 'id=4' in url : iio00O0o00oo = oooOOOOO
 if 'id=5' in url : iio00O0o00oo = i1iIIi1
 if 5 - 5: i11iIiiIii * IIiIi1iI - O00OOo00oo0o - oooOooOOo0OO - i1IIi + IIiIi1iI
 I1111i = iIIii ( iio00O0o00oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iiI1i1Iii111 = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( I1111i )
 if 4 - 4: iiii + O0 . i1IIi * oooOooOOo0OO - oOoO0o00OO0
 for O0OOoOOO0oO , url , i1i1IIIIIIIi , oo0o0oOo , Ooo0oo in iiI1i1Iii111 :
  if not 'viewport' in O0OOoOOO0oO :
   o0oOO000oO0oo ( 'addon' , O0OOoOOO0oO , url , 'restore_local_CB' , i1i1IIIIIIIi , oo0o0oOo , Ooo0oo , '' )
   if 42 - 42: oOoO0o00OO0 * ooo0O . iii1i1iiiiIi - IIiIi1iI / II111iiii
   if 25 - 25: oOo % ooo0O
def o00OIIIIII1iI1II ( url ) :
 iio00O0o00oo = 'http://noobsandnerds.com/TI/HardwarePortal/sortby.php?sortx=Added&orderx=DESC&%s' % ( url )
 I1111i = iIIii ( iio00O0o00oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 14 - 14: OoOoOO00 / O0
 iiI1i1Iii111 = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> thumb="(.+?)"  <br><br>' , re . DOTALL ) . findall ( I1111i )
 if iiI1i1Iii111 == [ ] :
  if 43 - 43: II11iIiIIIiI - i1IiiiI1iI % i11iIiiIii * II111iiii . oo0O0oO - IIIIiiII111
  iiI1i1Iii111 = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> thumb="(.+?)" <br><br>' , re . DOTALL ) . findall ( I1111i )
 oO0o000oOO ( iio00O0o00oo , 'hardware' )
 if 13 - 13: iii1i1iiiiIi
 for O0OOoOOO0oO , id , O00 in iiI1i1Iii111 :
  o0oOO000oO0oo ( 'folder2' , O0OOoOOO0oO , id , 'hardware_final_menu' , O00 , '' , '' )
  if 91 - 91: oooOooOOo0OO + iIii1I11I1II1 % i1IiiiI1iI
  if 90 - 90: iiii - IIIIiiII111 . iii1i1iiiiIi + iii1i1iiiiIi
def IIii1 ( url ) :
 iio00O0o00oo = 'http://noobsandnerds.com/TI/LatestNews/sortby.php?sortx=item_date&orderx=DESC&%s' % ( url )
 I1111i = iIIii ( iio00O0o00oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 92 - 92: i1IiiiI1iI . oOo - oOo - oOoO0o00OO0 + oo0O0oO - O0
 iiI1i1Iii111 = re . compile ( 'name="(.+?)"  <br> date="(.+?)"  <br> source="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( I1111i )
 if iiI1i1Iii111 == [ ] :
  if 30 - 30: i1IiiiI1iI - IIiIi1iI - iii1i1iiiiIi
  iiI1i1Iii111 = re . compile ( 'name="(.+?)" <br> date="(.+?)" <br> source="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( I1111i )
 for O0OOoOOO0oO , ii11 , oOOooooO , id in iiI1i1Iii111 :
  if 89 - 89: iiii * O00OOo00oo0o
  if "OpenELEC" in oOOooooO :
   o0oOO000oO0oo ( '' , O0OOoOOO0oO + '  (' + ii11 + ')' , id , 'news_menu' , '' , '' , '' )
   if 93 - 93: i1IIi . O00OOo00oo0o * oo0O0oO . iiii
  if "Official" in oOOooooO :
   o0oOO000oO0oo ( '' , O0OOoOOO0oO + '  (' + ii11 + ')' , id , 'news_menu' , '' , '' , '' )
   if 54 - 54: IIiIi1iI . i1IIi . oooOooOOo0OO * oOoO0o00OO0 % IIiIi1iI
  if "Raspbmc" in oOOooooO :
   o0oOO000oO0oo ( '' , O0OOoOOO0oO + '  (' + ii11 + ')' , id , 'news_menu' , '' , '' , '' )
   if 30 - 30: IIIIiiII111
  if "XBMC4Xbox" in oOOooooO :
   o0oOO000oO0oo ( '' , O0OOoOOO0oO + '  (' + ii11 + ')' , id , 'news_menu' , '' , '' , '' )
   if 85 - 85: II111iiii + iiii * IIIIiiII111
  if "noobsandnerds" in oOOooooO :
   o0oOO000oO0oo ( '' , O0OOoOOO0oO + '  (' + ii11 + ')' , id , 'news_menu' , '' , '' , '' )
   if 12 - 12: O00OOo00oo0o . OoOoOO00 % oOoO0o00OO0
   if 28 - 28: O00OOo00oo0o - OoOoOO00 % iii1i1iiiiIi * oo0O0oO
def oO0oOooO00oo ( url ) :
 iio00O0o00oo = 'http://noobsandnerds.com/TI/TutorialPortal/sortby.php?sortx=Name&orderx=ASC&%s' % ( url )
 I1111i = iIIii ( iio00O0o00oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 82 - 82: OoooooooOO / iiii * IIIIiiII111 * O0 . oooOooOOo0OO
 iiI1i1Iii111 = re . compile ( 'name="(.+?)"  <br> about="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( I1111i )
 if iiI1i1Iii111 == [ ] :
  if 21 - 21: II111iiii + oOo
  iiI1i1Iii111 = re . compile ( 'name="(.+?)" <br> about="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( I1111i )
 oO0o000oOO ( iio00O0o00oo , 'tutorials' )
 if 59 - 59: o0o + OoOoOO00 / II111iiii / ooo0O
 for O0OOoOOO0oO , oOoo00 , id in iiI1i1Iii111 :
  o0oOO000oO0oo ( 'folder' , O0OOoOOO0oO , id , 'tutorial_final_menu' , '' , '' , oOoo00 )
  if 29 - 29: o0o / ooo0O . iIii1I11I1II1 / IIIIiiII111 % ooo0O % IIiIi1iI
  if 49 - 49: II111iiii / i1IiiiI1iI - O00OOo00oo0o
def IiIII ( url , local ) :
 O0OOo ( )
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( O0OOoOOO0oO , 'This will over-write your existing guisettings.xml.' , 'Are you sure this is the build you have installed?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 92 - 92: OoOoOO00 % IIiIi1iI
 if i1IiiI1iIi == 1 :
  iiiI1IiI ( url , local )
  if 2 - 2: O0 % oo0O0oO % oooOooOOo0OO % oOoO0o00OO0 - oOo
  if 20 - 20: oOoO0o00OO0
def iiiI1IiI ( url , local ) :
 o0oo00oo0oO = False
 ii1ii = 0
 Ii1iii11I = 1
 if 2 - 2: OoooooooOO - O00OOo00oo0o % II11iIiIIIiI / OoOoOO00 / oOoO0o00OO0
 if os . path . exists ( Ii1iIiII1ii1 ) :
  os . remove ( Ii1iIiII1ii1 )
  if 3 - 3: II111iiii / o0o
 if os . path . exists ( Oo00OOOOO ) :
  os . remove ( Oo00OOOOO )
  if 48 - 48: iiii . oooOooOOo0OO
 if os . path . exists ( IIIII ) :
  os . remove ( IIIII )
  if 49 - 49: i1IIi - ooo0O . oOo + iIii1I11I1II1 - iiii / oOo
 if not os . path . exists ( ooOooo000oOO ) :
  os . makedirs ( ooOooo000oOO )
  if 24 - 24: II11iIiIIIiI - IIiIi1iI / iiii
  if 10 - 10: ooo0O * i1IIi
 try :
  shutil . copyfile ( O0o0Oo , Ii1iIiII1ii1 )
  if 15 - 15: IIIIiiII111 + i1IIi - II111iiii % OoOoOO00
 except :
  print "No guisettings found, most likely due to a previously failed attempt at install"
  if 34 - 34: OoOoOO00
 if local != 1 :
  o0OoOo0O00 = os . path . join ( I1IIIii , 'guifix.zip' )
  if 9 - 9: o0o
 else :
  o0OoOo0O00 = xbmc . translatePath ( url )
  if 38 - 38: IIIIiiII111 . iii1i1iiiiIi . i11iIiiIii * OoooooooOO + IIiIi1iI
  if 49 - 49: oOo - iii1i1iiiiIi / oo0O0oO / oOoO0o00OO0 % II11iIiIIIiI
 IIi = str ( os . path . getsize ( o0OoOo0O00 ) )
 iIii1 . create ( "Installing Skin Fix" , "Checking " , '' , 'Please Wait' )
 iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
 extract . all ( o0OoOo0O00 , ooOooo000oOO , iIii1 )
 if 62 - 62: II111iiii - oo0O0oO + IIIIiiII111 * iIii1I11I1II1 * oOoO0o00OO0
 if os . path . exists ( os . path . join ( ooOooo000oOO , 'script.skinshortcuts' ) ) :
  try :
   shutil . rmtree ( os . path . join ( iiI1IiI , 'script.skinshortcuts' ) )
  except :
   pass
  os . rename ( os . path . join ( ooOooo000oOO , 'script.skinshortcuts' ) , os . path . join ( iiI1IiI , 'script.skinshortcuts' ) )
  if 83 - 83: iii1i1iiiiIi
 if local != 'library' or local != 'updatelibrary' or local != 'fresh' :
  if 16 - 16: iiii
  try :
   O000o0 = open ( ooOooo000oOO + 'profiles.xml' , mode = 'r' )
   iIiiIiIIiI = O000o0 . read ( )
   O000o0 . close ( )
   if 93 - 93: i1IiiiI1iI % oooOooOOo0OO
   if os . path . exists ( ooOooo000oOO + 'profiles.xml' ) :
    if 31 - 31: II111iiii + o0o - OoooooooOO . IIIIiiII111
    if local == None :
     i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( "PROFILES DETECTED" , 'This build has profiles included, would you like to overwrite your existing profiles or keep the ones you have?' , '' , '' , nolabel = 'Keep my profiles' , yeslabel = 'Use new profiles' )
     if 28 - 28: O00OOo00oo0o . oooOooOOo0OO
    if local != None :
     i1IiiI1iIi = 1
     if 77 - 77: oooOooOOo0OO % II111iiii
    if i1IiiI1iIi == 1 :
     iIIiooO00O00oOO = open ( IIIII , mode = 'w' )
     time . sleep ( 1 )
     iIIiooO00O00oOO . write ( iIiiIiIIiI )
     time . sleep ( 1 )
     iIIiooO00O00oOO . close ( )
     Ii1iii11I = 0
     if 81 - 81: ooo0O % O00OOo00oo0o / O0 * iIii1I11I1II1 % i1IiiiI1iI . OoOoOO00
  except :
   print "no profiles.xml file"
   if 90 - 90: oOoO0o00OO0
   if 44 - 44: oOoO0o00OO0 / oooOooOOo0OO . oOo + ooo0O
 os . rename ( ooOooo000oOO + 'guisettings.xml' , Oo00OOOOO )
 if 32 - 32: i1IiiiI1iI - iiii * IIiIi1iI * IIIIiiII111
 if local != 'fresh' :
  O00OOOo = OOooO0OOoo . yesno ( "Do You Want To Keep Your Kodi Settings?" , 'Would you like to keep your existing settings or would you rather erase them and install the ones associated with this latest build?' , nolabel = 'Keep my settings' , yeslabel = 'Replace my settings' )
  if 37 - 37: IIIIiiII111 % oooOooOOo0OO / iiii
 if local == 'fresh' :
  O00OOOo = 1
  if 94 - 94: IIIIiiII111 / iii1i1iiiiIi . oOoO0o00OO0
 if O00OOOo == 1 :
  if 1 - 1: oOo . II111iiii
  if os . path . exists ( O0o0Oo ) :
   if 93 - 93: II111iiii . i11iIiiIii + II111iiii % II11iIiIIIiI
   try :
    print "Attempting to remove guisettings"
    os . remove ( O0o0Oo )
    o0oo00oo0oO = True
    if 98 - 98: oo0O0oO * II11iIiIIIiI * ooo0O + O00OOo00oo0o * IIiIi1iI
   except :
    print "Problem removing guisettings"
    o0oo00oo0oO = False
    if 4 - 4: i1IiiiI1iI
   try :
    print "Attempting to replace guisettings with new"
    os . rename ( Oo00OOOOO , O0o0Oo )
    o0oo00oo0oO = True
    if 16 - 16: iIii1I11I1II1 * IIiIi1iI + II11iIiIIIiI . O0 . oOoO0o00OO0
   except :
    print "Failed to replace guisettings with new"
    o0oo00oo0oO = False
    if 99 - 99: i11iIiiIii - IIiIi1iI
    if 85 - 85: oo0O0oO % oooOooOOo0OO
 if O00OOOo == 0 :
  IiI1Iii1 = open ( Ii1iIiII1ii1 , mode = 'r' )
  iiiiI11ii = IiI1Iii1 . read ( )
  IiI1Iii1 . close ( )
  if 95 - 95: iii1i1iiiiIi * o0o * IIiIi1iI . oOoO0o00OO0
  oooOo00 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( iiiiI11ii )
  iII1II = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( iiiiI11ii )
  iiI111iIi1 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( iiiiI11ii )
  I1i1ii1ii = oooOo00 [ 0 ] if ( len ( oooOo00 ) > 0 ) else ''
  i1ii = iII1II [ 0 ] if ( len ( iII1II ) > 0 ) else ''
  oOOOOO0 = iiI111iIi1 [ 0 ] if ( len ( iiI111iIi1 ) > 0 ) else ''
  if 4 - 4: oOoO0o00OO0 + IIIIiiII111 / IIiIi1iI + i1IIi % oOoO0o00OO0 % IIiIi1iI
  if 80 - 80: O00OOo00oo0o
  oo00ooOooO = open ( Oo00OOOOO , mode = 'r' )
  ooIi111iII = oo00ooOooO . read ( )
  oo00ooOooO . close ( )
  if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
  oOo0O0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooIi111iII )
  iIi1iI = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooIi111iII )
  iIIII1iII1i = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooIi111iII )
  O0OO00OoO00 = oOo0O0 [ 0 ] if ( len ( oOo0O0 ) > 0 ) else ''
  O00oIi11Iiii1iiii = iIi1iI [ 0 ] if ( len ( iIi1iI ) > 0 ) else ''
  i1IIII1111 = iIIII1iII1i [ 0 ] if ( len ( iIIII1iII1i ) > 0 ) else ''
  i1I1 = iiiiI11ii . replace ( I1i1ii1ii , O0OO00OoO00 ) . replace ( oOOOOO0 , i1IIII1111 ) . replace ( i1ii , O00oIi11Iiii1iiii )
  if 84 - 84: O0 % O00OOo00oo0o . O00OOo00oo0o . IIiIi1iI * IIIIiiII111
  iIIiooO00O00oOO = open ( Ii1iIiII1ii1 , mode = 'w+' )
  iIIiooO00O00oOO . write ( str ( i1I1 ) )
  iIIiooO00O00oOO . close ( )
  if 43 - 43: ooo0O . oooOooOOo0OO % i1IIi
  if 61 - 61: OoOoOO00 + II11iIiIIIiI % oo0O0oO % iIii1I11I1II1 - OoooooooOO
  if os . path . exists ( O0o0Oo ) :
   if 22 - 22: o0o + II111iiii + oOo
   try :
    os . remove ( O0o0Oo )
    o0oo00oo0oO = True
    if 83 - 83: iiii
   except :
    o0oo00oo0oO = False
    if 43 - 43: o0o
  try :
   os . rename ( Ii1iIiII1ii1 , O0o0Oo )
   os . remove ( Oo00OOOOO )
   o0oo00oo0oO = True
   if 84 - 84: o0o . i1IiiiI1iI . IIiIi1iI
  except :
   o0oo00oo0oO = False
   if 2 - 2: oOo - ooo0O
   if 49 - 49: O00OOo00oo0o + II111iiii / II11iIiIIIiI - ooo0O % ooo0O + OoOoOO00
 if o0oo00oo0oO == True or local == None :
  if 54 - 54: iiii % oOo - o0o
  try :
   IiI1Iii1 = open ( OOO00 , mode = 'r' )
   iiiiI11ii = IiI1Iii1 . read ( )
   IiI1Iii1 . close ( )
   if 16 - 16: oooOooOOo0OO * IIiIi1iI / IIIIiiII111
   iiII1 = re . compile ( 'id="(.+?)"' ) . findall ( iiiiI11ii )
   oo0OoO = re . compile ( 'name="(.+?)"' ) . findall ( iiiiI11ii )
   iIIi1iii1 = re . compile ( 'version="(.+?)"' ) . findall ( iiiiI11ii )
   o00o0 = iiII1 [ 0 ] if ( len ( iiII1 ) > 0 ) else ''
   OOoOo0O0 = oo0OoO [ 0 ] if ( len ( oo0OoO ) > 0 ) else ''
   iiii1IIi1 = iIIi1iii1 [ 0 ] if ( len ( iIIi1iii1 ) > 0 ) else ''
   if 39 - 39: oo0O0oO . iii1i1iiiiIi % iiii . o0o / IIiIi1iI * iii1i1iiiiIi
   iIIiooO00O00oOO = open ( iiiiiIIii , mode = 'w+' )
   iIIiooO00O00oOO . write ( 'id="' + str ( o00o0 ) + '"\nname="' + OOoOo0O0 + '"\nversion="' + iiii1IIi1 + '"\ngui="' + IIi + '"' )
   iIIiooO00O00oOO . close ( )
   if 12 - 12: OoOoOO00 / oOoO0o00OO0
   IiI1Iii1 = open ( OOOO , mode = 'r' )
   iiiiI11ii = IiI1Iii1 . read ( )
   IiI1Iii1 . close ( )
   if 86 - 86: oOo % ooo0O
   I1IIii11 = re . compile ( 'version="(.+?)"' ) . findall ( iiiiI11ii )
   i1i = I1IIii11 [ 0 ] if ( len ( I1IIii11 ) > 0 ) else ''
   i1I1 = iiiiI11ii . replace ( i1i , iiii1IIi1 )
   if 77 - 77: O00OOo00oo0o % o0o / II11iIiIIIiI
   iIIiooO00O00oOO = open ( OOOO , mode = 'w' )
   iIIiooO00O00oOO . write ( str ( i1I1 ) )
   iIIiooO00O00oOO . close ( )
   os . remove ( OOO00 )
   if 91 - 91: iii1i1iiiiIi / iii1i1iiiiIi . II111iiii . iiii - OoOoOO00
  except :
   iIIiooO00O00oOO = open ( iiiiiIIii , mode = 'w+' )
   iIIiooO00O00oOO . write ( 'id="None"\nname="Unknown"\nversion="Unknown"\ngui="' + IIi + '"' )
   iIIiooO00O00oOO . close ( )
   if 23 - 23: OoOoOO00
   if 7 - 7: IIiIi1iI % oooOooOOo0OO
 if os . path . exists ( ooOooo000oOO + 'profiles.xml' ) :
  os . remove ( ooOooo000oOO + 'profiles.xml' )
  time . sleep ( 1 )
  if 64 - 64: oo0O0oO + i11iIiiIii
 if os . path . exists ( ooOooo000oOO ) :
  os . removedirs ( ooOooo000oOO )
  if 35 - 35: ooo0O + i1IIi % o0o
 o0OOo0Ooo0 = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'notification.txt' ) )
 if 3 - 3: oOo / iiii + iiii . oooOooOOo0OO
 if os . path . exists ( o0OOo0Ooo0 ) :
  os . remove ( o0OOo0Ooo0 )
  if 50 - 50: iIii1I11I1II1 * II11iIiIIIiI
 if o0oo00oo0oO == True :
  ooo ( )
  o0OoOo00O0o0O ( )
  if 85 - 85: i1IIi
  if 100 - 100: OoooooooOO / IIIIiiII111 % iii1i1iiiiIi + O00OOo00oo0o
def IIi11 ( url ) :
 oo = 'http://noobsandnerds.com/TI/HardwarePortal/hardwaredetails.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 oO0OO0O0 = re . compile ( 'manufacturer="(.+?)"' ) . findall ( I1111i )
 ii1IIii = re . compile ( 'video_guide1="(.+?)"' ) . findall ( I1111i )
 IiI11i1I11111 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( I1111i )
 Ii1IIIIIIiI1 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( I1111i )
 Ii11IiIiiii1 = re . compile ( 'video_guide4="(.+?)"' ) . findall ( I1111i )
 OooO0O0Ooo = re . compile ( 'video_guide5="(.+?)"' ) . findall ( I1111i )
 oO0OIIIiIi1iiI = re . compile ( 'video_label1="(.+?)"' ) . findall ( I1111i )
 iI1 = re . compile ( 'video_label2="(.+?)"' ) . findall ( I1111i )
 o0Iiii = re . compile ( 'video_label3="(.+?)"' ) . findall ( I1111i )
 I1i1I = re . compile ( 'video_label4="(.+?)"' ) . findall ( I1111i )
 i1111iI1 = re . compile ( 'video_label5="(.+?)"' ) . findall ( I1111i )
 iIIi1II1 = re . compile ( 'shops="(.+?)"' ) . findall ( I1111i )
 OOoooooooO = re . compile ( 'description="(.+?)"' ) . findall ( I1111i )
 IiI1I11ii = re . compile ( 'screenshot1="(.+?)"' ) . findall ( I1111i )
 oO0O00oO0o0 = re . compile ( 'screenshot2="(.+?)"' ) . findall ( I1111i )
 o0oOo = re . compile ( 'screenshot3="(.+?)"' ) . findall ( I1111i )
 O0OoOo0oO0o = re . compile ( 'screenshot4="(.+?)"' ) . findall ( I1111i )
 I11iIi1i1IIi = re . compile ( 'screenshot5="(.+?)"' ) . findall ( I1111i )
 II11I = re . compile ( 'screenshot6="(.+?)"' ) . findall ( I1111i )
 OOooo00oo = re . compile ( 'screenshot7="(.+?)"' ) . findall ( I1111i )
 i1iiIi1IiiiI = re . compile ( 'screenshot8="(.+?)"' ) . findall ( I1111i )
 OO0oooOO = re . compile ( 'screenshot9="(.+?)"' ) . findall ( I1111i )
 III = re . compile ( 'screenshot10="(.+?)"' ) . findall ( I1111i )
 i1iiIIiiiI = re . compile ( 'screenshot11="(.+?)"' ) . findall ( I1111i )
 I1IIiIi1iI = re . compile ( 'screenshot12="(.+?)"' ) . findall ( I1111i )
 oOo0Iiii11 = re . compile ( 'screenshot13="(.+?)"' ) . findall ( I1111i )
 o00000O = re . compile ( 'screenshot14="(.+?)"' ) . findall ( I1111i )
 iIiiiII11 = re . compile ( 'added="(.+?)"' ) . findall ( I1111i )
 I11iIiI1I1i11 = re . compile ( 'platform="(.+?)"' ) . findall ( I1111i )
 ooo00Oo0 = re . compile ( 'chipset="(.+?)"' ) . findall ( I1111i )
 iIii1i1Ii = re . compile ( 'official_guide="(.+?)"' ) . findall ( I1111i )
 III1iIii = re . compile ( 'official_preview="(.+?)"' ) . findall ( I1111i )
 oo0oOO = re . compile ( 'thumbnail="(.+?)"' ) . findall ( I1111i )
 iiIII1i1 = re . compile ( 'stock_rom="(.+?)"' ) . findall ( I1111i )
 oOOo0OOoOO0 = re . compile ( 'CPU="(.+?)"' ) . findall ( I1111i )
 IiIi = re . compile ( 'GPU="(.+?)"' ) . findall ( I1111i )
 IIi1IiiIi1III = re . compile ( 'RAM="(.+?)"' ) . findall ( I1111i )
 IiIiIiiIIii = re . compile ( 'flash="(.+?)"' ) . findall ( I1111i )
 OOo00O00o0O0 = re . compile ( 'wifi="(.+?)"' ) . findall ( I1111i )
 iI1III = re . compile ( 'bluetooth="(.+?)"' ) . findall ( I1111i )
 I1I111 = re . compile ( 'LAN="(.+?)"' ) . findall ( I1111i )
 I1iI = re . compile ( 'xbmc_version="(.+?)"' ) . findall ( I1111i )
 IIiiI = re . compile ( 'pros="(.+?)"' ) . findall ( I1111i )
 ooO0 = re . compile ( 'cons="(.+?)"' ) . findall ( I1111i )
 IIOoOOoOo = re . compile ( 'library_scan="(.+?)"' ) . findall ( I1111i )
 Ii1 = re . compile ( '4k="(.+?)"' ) . findall ( I1111i )
 Iiiiii = re . compile ( '1080="(.+?)"' ) . findall ( I1111i )
 IiIii1i11i1 = re . compile ( '720="(.+?)"' ) . findall ( I1111i )
 ooOOo00o0ooO = re . compile ( '3D="(.+?)"' ) . findall ( I1111i )
 iIOO = re . compile ( 'DTS="(.+?)"' ) . findall ( I1111i )
 I1III1I11I1 = re . compile ( 'BootTime="(.+?)"' ) . findall ( I1111i )
 oO000OoO00OoO = re . compile ( 'CopyFiles="(.+?)"' ) . findall ( I1111i )
 I1IiIi1iiI = re . compile ( 'CopyVideo="(.+?)"' ) . findall ( I1111i )
 iiII1II11i = re . compile ( 'EthernetTest="(.+?)"' ) . findall ( I1111i )
 ooO0OoooooOo0oOo0 = re . compile ( 'Slideshow="(.+?)"' ) . findall ( I1111i )
 II11II = re . compile ( 'total_review="(.+?)"' ) . findall ( I1111i )
 i1ii11 = re . compile ( 'whufclee_review="(.+?)"' ) . findall ( I1111i )
 IIIo00O = re . compile ( 'CB_Premium="(.+?)"' ) . findall ( I1111i )
 if 26 - 26: ooo0O
 O0OOoOOO0oO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 I1I11I = oO0OO0O0 [ 0 ] if ( len ( oO0OO0O0 ) > 0 ) else ''
 I1I = ii1IIii [ 0 ] if ( len ( ii1IIii ) > 0 ) else 'None'
 ooooo = IiI11i1I11111 [ 0 ] if ( len ( IiI11i1I11111 ) > 0 ) else 'None'
 i11IIIiI1I = Ii1IIIIIIiI1 [ 0 ] if ( len ( Ii1IIIIIIiI1 ) > 0 ) else 'None'
 o0iiiI1I1iIIIi1 = Ii11IiIiiii1 [ 0 ] if ( len ( Ii11IiIiiii1 ) > 0 ) else 'None'
 Iii = OooO0O0Ooo [ 0 ] if ( len ( OooO0O0Ooo ) > 0 ) else 'None'
 O0Oo0o000oO = oO0OIIIiIi1iiI [ 0 ] if ( len ( oO0OIIIiIi1iiI ) > 0 ) else 'None'
 oO0o00oOOooO0 = iI1 [ 0 ] if ( len ( iI1 ) > 0 ) else 'None'
 OOOoO000 = o0Iiii [ 0 ] if ( len ( o0Iiii ) > 0 ) else 'None'
 oOOOO = I1i1I [ 0 ] if ( len ( I1i1I ) > 0 ) else 'None'
 IiIi1ii111i1 = i1111iI1 [ 0 ] if ( len ( i1111iI1 ) > 0 ) else 'None'
 ooOOO0oOoooOo = iIIi1II1 [ 0 ] if ( len ( iIIi1II1 ) > 0 ) else ''
 Ooo0oo = OOoooooooO [ 0 ] if ( len ( OOoooooooO ) > 0 ) else ''
 Ii11IIIii11 = IiI1I11ii [ 0 ] if ( len ( IiI1I11ii ) > 0 ) else ''
 O0oo = oO0O00oO0o0 [ 0 ] if ( len ( oO0O00oO0o0 ) > 0 ) else ''
 i1ii1i1i1 = o0oOo [ 0 ] if ( len ( o0oOo ) > 0 ) else ''
 oOOoo0II1 = O0OoOo0oO0o [ 0 ] if ( len ( O0OoOo0oO0o ) > 0 ) else ''
 OOO = I11iIi1i1IIi [ 0 ] if ( len ( I11iIi1i1IIi ) > 0 ) else ''
 iiIII1I11iii = II11I [ 0 ] if ( len ( II11I ) > 0 ) else ''
 ooIii = OOooo00oo [ 0 ] if ( len ( OOooo00oo ) > 0 ) else ''
 o0OO00oOOO0o0 = i1iiIi1IiiiI [ 0 ] if ( len ( i1iiIi1IiiiI ) > 0 ) else ''
 iiiioOOOO = OO0oooOO [ 0 ] if ( len ( OO0oooOO ) > 0 ) else ''
 OoOOoo0 = III [ 0 ] if ( len ( III ) > 0 ) else ''
 oo0OOO0OOoOO = i1iiIIiiiI [ 0 ] if ( len ( i1iiIIiiiI ) > 0 ) else ''
 oOoOII1i1 = I1IIiIi1iI [ 0 ] if ( len ( I1IIiIi1iI ) > 0 ) else ''
 o0o0oo0OOo0O0 = oOo0Iiii11 [ 0 ] if ( len ( oOo0Iiii11 ) > 0 ) else ''
 iIIiiII11i1I1 = o00000O [ 0 ] if ( len ( o00000O ) > 0 ) else ''
 Ii111Ii1iiIi1 = iIiiiII11 [ 0 ] if ( len ( iIiiiII11 ) > 0 ) else ''
 OoOo0oOooOoOO = I11iIiI1I1i11 [ 0 ] if ( len ( I11iIiI1I1i11 ) > 0 ) else ''
 OOI11i1IIi1i1 = ooo00Oo0 [ 0 ] if ( len ( ooo00Oo0 ) > 0 ) else ''
 I11i1iiiiIIIi = iIii1i1Ii [ 0 ] if ( len ( iIii1i1Ii ) > 0 ) else 'None'
 Ii11Ii1 = III1iIii [ 0 ] if ( len ( III1iIii ) > 0 ) else 'None'
 O00 = oo0oOO [ 0 ] if ( len ( oo0oOO ) > 0 ) else ''
 IIIO0oo0OOO0O0 = iiIII1i1 [ 0 ] if ( len ( iiIII1i1 ) > 0 ) else ''
 o0o0ooOO0 = oOOo0OOoOO0 [ 0 ] if ( len ( oOOo0OOoOO0 ) > 0 ) else ''
 o0oIi11I1II1 = IiIi [ 0 ] if ( len ( IiIi ) > 0 ) else ''
 I11Ii1I11 = IIi1IiiIi1III [ 0 ] if ( len ( IIi1IiiIi1III ) > 0 ) else ''
 iI11II11I1 = IiIiIiiIIii [ 0 ] if ( len ( IiIiIiiIIii ) > 0 ) else ''
 oo0o0000 = OOo00O00o0O0 [ 0 ] if ( len ( OOo00O00o0O0 ) > 0 ) else ''
 I1iIiI = iI1III [ 0 ] if ( len ( iI1III ) > 0 ) else ''
 oo0OoOO000O = I1I111 [ 0 ] if ( len ( I1I111 ) > 0 ) else ''
 oo0oo0O0 = I1iI [ 0 ] if ( len ( I1iI ) > 0 ) else ''
 Oo0o0OoOoOo0 = IIiiI [ 0 ] if ( len ( IIiiI ) > 0 ) else ''
 I11iiI11I1II = ooO0 [ 0 ] if ( len ( ooO0 ) > 0 ) else ''
 oO0iII1i111iI = IIOoOOoOo [ 0 ] if ( len ( IIOoOOoOo ) > 0 ) else ''
 IiI1iI1 = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else ''
 oOoo = Iiiiii [ 0 ] if ( len ( Iiiiii ) > 0 ) else ''
 i1IIII1II = IiIii1i11i1 [ 0 ] if ( len ( IiIii1i11i1 ) > 0 ) else ''
 O000oO00oO = ooOOo00o0ooO [ 0 ] if ( len ( ooOOo00o0ooO ) > 0 ) else ''
 o0oOo00OOo0O = iIOO [ 0 ] if ( len ( iIOO ) > 0 ) else ''
 OO0OOoOOO = I1III1I11I1 [ 0 ] if ( len ( I1III1I11I1 ) > 0 ) else ''
 oOoO0o0o = oO000OoO00OoO [ 0 ] if ( len ( oO000OoO00OoO ) > 0 ) else ''
 O00O000oOO0oO = I1IiIi1iiI [ 0 ] if ( len ( I1IiIi1iiI ) > 0 ) else ''
 OO0i1Ii1II11 = iiII1II11i [ 0 ] if ( len ( iiII1II11i ) > 0 ) else ''
 IiiIIii1I1I = ooO0OoooooOo0oOo0 [ 0 ] if ( len ( ooO0OoooooOo0oOo0 ) > 0 ) else ''
 IIiIIiIi1II1IiI = II11II [ 0 ] if ( len ( II11II ) > 0 ) else ''
 oo0OoOI11iIiiI = i1ii11 [ 0 ] if ( len ( i1ii11 ) > 0 ) else 'None'
 OO000oo0o = IIIo00O [ 0 ] if ( len ( IIIo00O ) > 0 ) else ''
 I11iiIiI1II11 = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + Ii111Ii1iiIi1 + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + I1I11I + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + OoOo0oOooOoOO + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + OOI11i1IIi1i1 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + o0o0ooOO0 + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + o0oIi11I1II1 + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + I11Ii1I11 + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + iI11II11I1 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + oo0o0000 + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + I1iIiI + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + oo0OoOO000O + '[CR][CR][COLOR=yellow]About: [/COLOR]' + Ooo0oo + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + Oo0o0OoOoOo0 + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + I11iiI11I1II + '[CR][CR][COLOR=yellow]Benchmark Results:[/COLOR][CR][CR][COLOR=dodgerblue]Boot Time:[/COLOR][CR]' + OO0OOoOOO + '[CR][CR][COLOR=dodgerblue]Time taken to scan 1,000 movies (local NFO files):[/COLOR][CR]' + oO0iII1i111iI + '[CR][CR][COLOR=dodgerblue]Copy 4,000 files (660.8MB) locally:[/COLOR][CR]' + oOoO0o0o + '[CR][CR][COLOR=dodgerblue]Copy a MP4 file (339.4MB) locally:[/COLOR][CR]' + O00O000oOO0oO + '[CR][CR][COLOR=dodgerblue]Ethernet Speed - Copy MP4 (339.4MB) from SMB share to device:[/COLOR][CR]' + OO0i1Ii1II11 + '[CR][CR][COLOR=dodgerblue]4k Playback:[/COLOR][CR]' + IiI1iI1 + '[CR][CR][COLOR=dodgerblue]1080p Playback:[/COLOR][CR]' + oOoo + '[CR][CR][COLOR=dodgerblue]720p Playback:[/COLOR][CR]' + i1IIII1II + '[CR][CR][COLOR=dodgerblue]Audio Playback:[/COLOR][CR]' + o0oOo00OOo0O + '[CR][CR][COLOR=dodgerblue]Image Slideshow:[/COLOR][CR]' + IiiIIii1I1I )
 OOOoOOOo = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + Ii111Ii1iiIi1 + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + I1I11I + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + OoOo0oOooOoOO + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + OOI11i1IIi1i1 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + o0o0ooOO0 + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + o0oIi11I1II1 + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + I11Ii1I11 + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + iI11II11I1 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + oo0o0000 + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + I1iIiI + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + oo0OoOO000O + '[CR][CR][COLOR=yellow]About: [/COLOR]' + Ooo0oo + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + Oo0o0OoOoOo0 + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + I11iiI11I1II + '[CR][CR][COLOR=orange]4k Playback:[/COLOR]  ' + IiI1iI1 + '[CR][CR][COLOR=orange]1080p Playback:[/COLOR]  ' + oOoo + '[CR][CR][COLOR=orange]720p Playback:[/COLOR]  ' + i1IIII1II + '[CR][CR][COLOR=orange]DTS Compatibility:[/COLOR]  ' + o0oOo00OOo0O + '[CR][CR][COLOR=orange]Time taken to scan 100 movies:[/COLOR]  ' + oO0iII1i111iI )
 if 82 - 82: oOo + oo0O0oO
 if Ooo0oo != '' and ooOOO0oOoooOo != '' :
  o0oOO000oO0oo ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , I11iiIiI1II11 , 'text_guide' , '' , OO0o , '' , '' )
 if Ooo0oo != '' and ooOOO0oOoooOo == '' :
  o0oOO000oO0oo ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , OOOoOOOo , 'text_guide' , '' , OO0o , '' , '' )
 if oo0OoOI11iIiiI != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]   Benchmark Review' , oo0OoOI11iIiiI , 'play_video' , '' , OO0o , '' , '' )
 if Ii11Ii1 != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Preview' , Ii11Ii1 , 'play_video' , '' , OO0o , '' , '' )
 if I11i1iiiiIIIi != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Guide' , I11i1iiiiIIIi , 'play_video' , '' , OO0o , '' , '' )
 if I1I != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + O0Oo0o000oO , I1I , 'play_video' , '' , OO0o , '' , '' )
 if ooooo != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oO0o00oOOooO0 , ooooo , 'play_video' , '' , OO0o , '' , '' )
 if i11IIIiI1I != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + OOOoO000 , i11IIIiI1I , 'play_video' , '' , OO0o , '' , '' )
 if o0iiiI1I1iIIIi1 != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oOOOO , o0iiiI1I1iIIIi1 , 'play_video' , '' , OO0o , '' , '' )
 if Iii != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + IiIi1ii111i1 , Iii , 'play_video' , '' , OO0o , '' , '' )
  if 93 - 93: IIIIiiII111 * O0 * o0o - oOoO0o00OO0 / oooOooOOo0OO
  if 54 - 54: i1IIi - iii1i1iiiiIi / OoooooooOO
def ooooOOo ( ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'hardware' , 'manual_search' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime]All Devices[/COLOR]' , '' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Game Consoles' , 'device=Console' , '' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Hardware][/COLOR] HTPC' , 'device=HTPC' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Phones' , 'device=Phone' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Set Top Boxes' , 'device=STB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Tablets' , 'device=Tablet' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Remotes/Keyboards' , 'device=Remote' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Gaming Controllers' , 'device=Controller' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Dongles' , 'device=Dongle' , 'grab_hardware' , '' , '' , '' , '' )
 if 100 - 100: o0o % i11iIiiIii - OoOoOO00 * oo0O0oO - oOoO0o00OO0
 if 65 - 65: i11iIiiIii - OoooooooOO / O0 * i1IiiiI1iI % IIIIiiII111
def o00o00 ( url ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Allwinner Devices' , str ( url ) + '&chip=Allwinner' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][CPU][/COLOR] AMLogic Devices' , str ( url ) + '&chip=AMLogic' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Intel Devices' , str ( url ) + '&chip=Intel' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Rockchip Devices' , str ( url ) + '&chip=Rockchip' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] Android' , str ( url ) + '&platform=Android' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] iOS' , str ( url ) + '&platform=iOS' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] Linux' , str ( url ) + '&platform=Linux' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] OpenELEC' , str ( url ) + '&platform=OpenELEC' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] OSX' , str ( url ) + '&platform=OSX' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] Pure Linux' , str ( url ) + '&platform=Custom_Linux' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][Platform][/COLOR] Windows' , str ( url ) + '&platform=Windows' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 4GB' , str ( url ) + '&flash=4GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 8GB' , str ( url ) + '&flash=8GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 16GB' , str ( url ) + '&flash=16GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 32GB' , str ( url ) + '&flash=32GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 64GB' , str ( url ) + '&flash=64GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 1GB' , str ( url ) + '&ram=1GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 2GB' , str ( url ) + '&ram=2GB' , 'grab_hardware' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 4GB' , str ( url ) + '&ram=4GB' , 'grab_hardware' , '' , '' , '' , '' )
 if 72 - 72: i1IIi
 if 21 - 21: oo0O0oO . o0o / i11iIiiIii * i1IIi
 if 82 - 82: iiii * oOo % i11iIiiIii * i1IIi . o0o
def o0Oo00o0 ( ) :
 oO0Oo = xbmc . getSkinDir ( )
 i1I1Iiii1 = xbmc . translatePath ( os . path . join ( OooO0 , oO0Oo ) )
 if 42 - 42: oo0O0oO / ooo0O % II11iIiIIIiI
 for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( i1I1Iiii1 ) :
  if 63 - 63: iii1i1iiiiIi % i1IIi - II11iIiIIIiI
  for ooOo0O0o0 in Oo0o :
   if 12 - 12: OoooooooOO + oo0O0oO / o0o / oOo * II111iiii - oooOooOOo0OO
   if 'DialogKeyboard.xml' in ooOo0O0o0 :
    oO0Oo = os . path . join ( OoO0oo0 , ooOo0O0o0 )
    O0O0oo = open ( oO0Oo ) . read ( )
    o00O = O0O0oo . replace ( '<control type="label" id="310"' , '<control type="edit" id="312"' )
    ooOo0O0o0 = open ( oO0Oo , mode = 'w' )
    ooOo0O0o0 . write ( o00O )
    ooOo0O0o0 . close ( )
    I1Iii1Ii1i1 ( oO0Oo )
    if 11 - 11: IIiIi1iI
    for O0OoOO in range ( 48 , 58 ) :
     O0OOO00OooO ( O0OoOO , oO0Oo )
     if 89 - 89: ooo0O - iiii . iIii1I11I1II1 + IIiIi1iI / O00OOo00oo0o / IIiIi1iI
 OOooO0OOoo = xbmcgui . Dialog ( )
 OOooO0OOoo . ok ( "Skin Changes Successful" , 'A BIG thank you to Mikey1234 for this fix. The code used for this function was ported from the Xunity Maintenance add-on' )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 25 - 25: iIii1I11I1II1 + i11iIiiIii - O00OOo00oo0o * OoooooooOO
def i1I11IiI ( ) :
 OOooO0OOoo = xbmcgui . Dialog ( )
 O0o00 = xbmcgui . Dialog ( ) . yesno ( 'Convert This Skin To Kodi (Helix)?' , 'This will fix the problem with a blank on-screen keyboard showing in skins designed for Gotham (being run on Kodi). This will only affect the currently running skin.' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 40 - 40: II111iiii
 if O0o00 == 1 :
  o0Oo00o0 ( )
  if 7 - 7: o0o / iii1i1iiiiIi
  if 88 - 88: i1IIi
def O0ooOo0Oooo ( ) :
 if OOooO0OOoo . yesno ( "Hide Passwords" , "This will hide all your passwords in your" , "add-on settings, are you sure you wish to continue?" ) :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( OooO0 ) :
   for ooOo0O0o0 in Oo0o :
    if ooOo0O0o0 == 'settings.xml' :
     I1iiIIiI11I = open ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) ) . read ( )
     iiI1i1Iii111 = re . compile ( '<setting id=(.+?)>' ) . findall ( I1iiIIiI11I )
     for I11II1I in iiI1i1Iii111 :
      if 'pass' in I11II1I :
       if not 'option="hidden"' in I11II1I :
        try :
         oOoOo000 = I11II1I . replace ( '/' , ' option="hidden"/' )
         ooOo0O0o0 = open ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) , mode = 'w' )
         ooOo0O0o0 . write ( str ( I1iiIIiI11I ) . replace ( I11II1I , oOoOo000 ) )
         ooOo0O0o0 . close ( )
        except :
         pass
  OOooO0OOoo . ok ( "Passwords Hidden" , "Your passwords will now show as stars (hidden), if you want to undo this please use the option to unhide passwords." )
  if 37 - 37: IIiIi1iI
  if 15 - 15: oOoO0o00OO0 % iii1i1iiiiIi / IIiIi1iI
def II1IIIi ( url ) :
 oo = 'http://noobsandnerds.com/IT/Community_Builds/guisettings.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0OOOOOo00 = re . compile ( 'guisettings="(.+?)"' ) . findall ( I1111i )
 II1IIiiI1 = o0OOOOOo00 [ 0 ] if ( len ( o0OOOOOo00 ) > 0 ) else 'None'
 if 40 - 40: i1IIi / OoooooooOO / o0o * oo0O0oO - oOoO0o00OO0
 iiiI1IiI ( II1IIiiI1 , ooooOo00O )
 if 6 - 6: OoooooooOO - oOo
 if 52 - 52: o0o + oOo
def oOoO0oOO0o ( path ) :
 oO0000oo0o0o0 = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , 'background_art' , '' ) )
 if 21 - 21: i1IIi
 if os . path . exists ( oO0000oo0o0o0 ) :
  IIIii11 ( oO0000oo0o0o0 )
  if 85 - 85: oooOooOOo0OO * ooo0O % IIIIiiII111
 time . sleep ( 1 )
 if 29 - 29: oooOooOOo0OO
 if not os . path . exists ( oO0000oo0o0o0 ) :
  os . makedirs ( oO0000oo0o0o0 )
  if 91 - 91: iii1i1iiiiIi
 try :
  iIii1 . create ( "Installing Artwork" , "Downloading artwork pack" , '' , 'Please Wait' )
  O0OOO00OOO00o = os . path . join ( I1IIIii , I1IiiI + '_artpack.zip' )
  downloader . download ( path , O0OOO00OOO00o , iIii1 )
  time . sleep ( 1 )
  iIii1 . create ( "Installing Artwork" , "Checking " , '' , 'Please Wait' )
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( O0OOO00OOO00o , oO0000oo0o0o0 , iIii1 )
  if 54 - 54: oooOooOOo0OO . iiii + oo0O0oO % iiii
 except :
  pass
  if 67 - 67: iii1i1iiiiIi
  if 76 - 76: oOo
def i1Oo000O000 ( url ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keywords' , '' , 'nan_menu' , '' , '' , '' , '' )
 if 7 - 7: OoOoOO00
 if iI111iI == 'true' and IiII != '' and iI1Ii11111iIi != '' :
  o0oOO000oO0oo ( '' , 'Install ' + iI1Ii11111iIi + ' keyword' , IiII , 'keywords' , '' , '' , '' , '' )
  if 40 - 40: iiii
 if oo00 == 'true' :
  o0oOO000oO0oo ( 'folder' , 'Install Add-ons' , IIIi1I1IIii1II , 'addonmenu' , '' , '' , '' , '' )
  if 80 - 80: OoOoOO00 * oo0O0oO % II11iIiIIIiI . i11iIiiIii % i1IiiiI1iI
 if o00 == 'true' :
  o0oOO000oO0oo ( 'folder' , 'Community Builds' , url , 'community' , '' , '' , '' , '' )
  if 42 - 42: OoooooooOO * II111iiii
  if 53 - 53: oo0O0oO + i1IIi . iii1i1iiiiIi / i11iIiiIii + O00OOo00oo0o % ooo0O
def I1Io0Oo00 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://install/",return)' )
 if 34 - 34: O00OOo00oo0o * OoOoOO00 + IIIIiiII111 * ooo0O - II111iiii
 if 92 - 92: o0o . oOoO0o00OO0 / IIiIi1iI . iIii1I11I1II1 % oOo . OoooooooOO
def oooOO0OO0O ( repo_id ) :
 o0oOO0OO = 1
 oo = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( repo_id )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 IIo0Oo0oO0oOO00 = re . compile ( 'version="(.+?)"' ) . findall ( I1111i )
 ooO000OO0O00O = re . compile ( 'repo_url="(.+?)"' ) . findall ( I1111i )
 OOOoOO0o = re . compile ( 'data_url="(.+?)"' ) . findall ( I1111i )
 i1II1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( I1111i )
 oo00oO0o = re . compile ( 'repo_id="(.+?)"' ) . findall ( I1111i )
 Ooo00OoO0O00 = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 Ii1i1iI = IIo0Oo0oO0oOO00 [ 0 ] if ( len ( IIo0Oo0oO0oOO00 ) > 0 ) else ''
 I1Io0oO0oo = ooO000OO0O00O [ 0 ] if ( len ( ooO000OO0O00O ) > 0 ) else ''
 ooOO00Oo = OOOoOO0o [ 0 ] if ( len ( OOOoOO0o ) > 0 ) else ''
 oO00OOOOOO0o = i1II1 [ 0 ] if ( len ( i1II1 ) > 0 ) else ''
 iIII = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 ii1ii1i1ii = xbmc . translatePath ( os . path . join ( Oo0OoO00oOO0o , iIII + '.zip' ) )
 iIi1Iii1 = xbmc . translatePath ( os . path . join ( OooO0 , iIII ) )
 if 87 - 87: OoooooooOO
 iIii1 . create ( 'Installing Repository' , 'Please wait...' , '' )
 if 1 - 1: iIii1I11I1II1 / oOoO0o00OO0
 try :
  downloader . download ( I1Io0oO0oo , ii1ii1i1ii , iIii1 )
  extract . all ( ii1ii1i1ii , OooO0 , iIii1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 98 - 98: O0 % OoOoOO00 / OoooooooOO * oooOooOOo0OO - II11iIiIIIiI
 except :
  if 51 - 51: IIiIi1iI + IIIIiiII111
  try :
   downloader . download ( oO00OOOOOO0o , ii1ii1i1ii , iIii1 )
   extract . all ( ii1ii1i1ii , OooO0 , iIii1 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if 54 - 54: II111iiii * O0 % OoOoOO00 . IIIIiiII111
  except :
   if 62 - 62: O00OOo00oo0o . i11iIiiIii % O0 % oo0O0oO - oOo
   try :
    if 69 - 69: II111iiii . ooo0O * ooo0O % O00OOo00oo0o + OoOoOO00
    if not os . path . exists ( iIi1Iii1 ) :
     os . makedirs ( iIi1Iii1 )
     if 100 - 100: i11iIiiIii - oOo
    I1111i = iIIii ( ooOO00Oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    iiI1i1Iii111 = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( I1111i )
    if 47 - 47: IIiIi1iI * ooo0O * i1IiiiI1iI
    for OO00oOooo0O in iiI1i1Iii111 :
     oOOOo = xbmc . translatePath ( os . path . join ( iIi1Iii1 , OO00oOooo0O ) )
     if 46 - 46: O00OOo00oo0o
     if oOoOoOoo0 not in OO00oOooo0O and '/' not in OO00oOooo0O :
      if 42 - 42: iIii1I11I1II1
      try :
       iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + OO00oOooo0O + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( ooOO00Oo + OO00oOooo0O , oOOOo , iIii1 )
       if 32 - 32: oOo - O00OOo00oo0o . OoooooooOO - OoooooooOO - oOo . iIii1I11I1II1
      except :
       print "failed to install" + OO00oOooo0O
       if 34 - 34: oOo
     if '/' in OO00oOooo0O and '..' not in OO00oOooo0O and 'http' not in OO00oOooo0O :
      oOOoo0 = ooOO00Oo + OO00oOooo0O
      i1111IIiii1 ( oOOOo , oOOoo0 )
      if 31 - 31: i1IIi - IIIIiiII111 + oo0O0oO + iiii . iiii . O0
   except :
    OOooO0OOoo . ok ( "Error downloading repository" , 'There was an error downloading[CR][COLOR=dodgerblue]' + Ooo00OoO0O00 + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    o0oOO0OO = 0
    if 33 - 33: i1IIi / IIiIi1iI * iii1i1iiiiIi
    if 2 - 2: II11iIiIIIiI . o0o
 if o0oOO0OO == 1 :
  time . sleep ( 1 )
  iIii1 . update ( 0 , "[COLOR=yellow]" + Ooo00OoO0O00 + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing dependencies' )
  time . sleep ( 1 )
  Ii1I11I = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( repo_id )
  try :
   iIIii ( Ii1I11I )
  except :
   pass
   if 43 - 43: iIii1I11I1II1
   if 29 - 29: i1IiiiI1iI % iiii + iii1i1iiiiIi . i1IIi + OoOoOO00
def I111I ( ) :
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  What is Community Builds?' , 'url' , 'instructions_3' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Creating a Community Build' , 'url' , 'instructions_1' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Installing a Community Build' , 'url' , 'instructions_2' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Add Your Own Guides @ [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' , 'K0XIxEodUhc' , 'play_video' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Community Builds FULL GUIDE' , "ewuxVfKZ3Fs" , 'play_video' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  IMPORTANT initial settings' , "1vXniHsEMEg" , 'play_video' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Install a Community Build' , "kLsVOapuM1A" , 'play_video' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Fixing a half installed build (guisettings.xml fix)' , "X8QYLziFzQU" , 'play_video' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 1)' , "3rMScZF2h_U" , 'play_video' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 2)' , "C2IPhn0OSSw" , 'play_video' , '' , '' , '' , '' )
 if 58 - 58: iIii1I11I1II1 / OoOoOO00
 if 64 - 64: oooOooOOo0OO / IIiIi1iI / ooo0O + oOoO0o00OO0 . O00OOo00oo0o . II11iIiIIIiI
def i11iI11ii ( ) :
 i1iiIII1IIiIIII ( 'Creating A Backup To Share' ,
 '[COLOR=gold]THE OPTIONS:[/COLOR][CR]There are 3 options when choosing to create a backup, we shall explain here the differences between them:[CR][CR]'
 '[COLOR=dodgerblue]1. noobsandnerds Community Build[/COLOR] - This is by far the best way to create a build that you want to share with others, it will create a zip file for you to share that can only be used on with this add-on. The size of the zip will be incredibly small compared to other backup options out there and it will also do lots of other clever stuff too such as error checking against the Addon Portal and the addons will always be updated via the relevant developer repositories. Added to this when it comes to updating it\'s a breeze, only the new addons not already on the system will be installed and for the majority of builds Kodi won\'t even have to restart after installing![CR][CR]'
 '[COLOR=dodgerblue]2. Universal Build[/COLOR] - This was the original method created by TotalXBMC, we would really only recommend this if for some strange reason you want your build available on other inferior wizards. The zip size is much larger and every time someone wants to update their build they have to download and install the whole thing again which can be very frustrating and time consuming. The whole build is backed up in full with the exception of the packages and thumbnails folder. Just like the option above all physical paths (so long as they exist somewhere in the Kodi environment) will be changed to special paths so they work on all devices.[CR][CR]'
 '[COLOR=dodgerblue]3. Full Backup[/COLOR] - It\'s highly unlikely you will ever want to use this option and it\'s more for the geeks out there. It will create a complete backup of your setup and not do any extra clever stuff. Things like packages will remain intact as will temp cache files, be warned the size could be VERY large![CR][CR]'
 '[CR][COLOR=gold]CREATING A COMMUNITY BUILD:[/COLOR][CR][CR][COLOR=blue][B]Step 1:[/COLOR] Remove any sensitive data[/B][CR]Make sure you\'ve removed any sensitive data such as passwords and usernames in your addon_data folder.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Backup your system[/B][CR]Choose the backup option you want from the list on the previous page, if you\'re sharing this via the CP Addon then please use the noobsandnerds backup option, this will create two zip files that you need to upload to a server.'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip files to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - archive.org and copy.com are two good examples. Do not use Dropbox unless you have a paid account, they have a fair useage policy and the chances are you\'ll find within 24 hours your download has been blocked and nobody can download it. [COLOR=lime]Top Tip: [/COLOR]The vast majority of problems occur when the wrong download URL has been entered in the online form, a good download URL normally ends in "=1" or "zip=true". Please double check when you copy the URL into a web browser it immediately starts downloading without the need to press any other button.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4:[/COLOR] Submit the build[/B]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR].[CR]Full details can be found on there of the template you should use when posting, once you\'ve created your support thread (NOT BEFORE) you can request to become a member of the Community Builder group and you\'ll then be able to add your build via the web form. As soon as you\'ve successfully added the details your build will be live, if you can\'t find it in the CP addon make sure you have XXX enabled (if you marked it as having adult content) and also make sure you\'re running the same version of Kodi that you said it was compatible with. If you\'re running another version then you can select the option to "show all community builds" in the addon settings and that will show even the builds that aren\'t marked as compatible with your version of Kodi.'
 '[CR][CR][COLOR=gold]PRIVATE BUILDS[/COLOR][CR]If you aren\'t interested in sharing your build with the community you can still use our system for private builds. Just follow the instructions above but you will not need to create a support thread and you WILL require a minimum of 5 useful (not spam) posts on the forum. The 5 post rule only applies to users that wish to use the private builds option. Once you have 5 posts you\'ll be able to access the web form and in there you can enter up to 3 IP addresses that you want to be able to view your build(s). Anybody caught disobeying the forum rules will be banned so please make sure you understand the forum rules before posting, we welcome everyone but there is strictly no spamming or nonsense posts just saying something like "Thanks" in order to bump up your post count. The site rules even have examples of how you can get to 5 posts without receiving a ban.' )
 if 85 - 85: i1IIi
 if 64 - 64: ooo0O % iIii1I11I1II1
def iII1I1Ii11i1i ( ) :
 i1iiIII1IIiIIII ( 'Installing a build' , '[COLOR=dodgerblue][B]Step 1 (Optional):[/COLOR] Backup your system[/B][CR]When selecting an install option you\'ll be asked if you want to create a backup - we strongly recommend creating a backup of your system in case you don\'t like the build and want to revert back. Remember your backup may be quite large so if you\'re using a device with a very small amount of storage we recommend using a USB stick or SD card as the storage location otherwise you may run out of space and the install may fail.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Choose an install method:[/B][CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]1. Overwrite my current setup & install new build:[/COLOR] This copy over the whole build[CR]As the title suggests this will overwrite your existing setup with the one created by the community builder. We recommend using the wipe option in the maintenance section before running this, that will completely wipe your existing settings and will ensure you don\'t have any conflicting data left on the device. Once you\'ve wiped please restart Kodi and install the build, you can of course use this install option 1 without wiping but you may encounter problems. If you choose to do this DO NOT bombard the community builder with questions on how to fix certain things, they will expect you to have installed over a clean setup and if you\'ve installed over another build the responsibility for bug tracking lies solely with you!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]2. Install:[/COLOR] Keep my library & profiles[CR]This will install a build over the top of your existing setup so you won\'t lose anything already installed in Kodi. Your library and any profiles you may have setup will also remain unchanged.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]3. Install:[/COLOR] Keep my library only[CR]This will do exactly the same as number 2 (above) but it will delete any profiles you may have and replace them with the ones the build author has created.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]4. Install:[/COLOR] Keep my profiles only[CR]Again, the same as number 2 but your library will be replaced with the one created by the build author. If you\'ve spent a long time setting up your library and have it just how you want it then use this with caution and make sure you do a backup!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Replace or keep settings?[/B][CR]When completing the install process you\'ll be asked if you want to keep your existing Kodi settings or replace with the ones in the build. If you choose to keep your settings then only the important skin related settings are copied over from the build. All your other Kodi settings such as screen calibration, region, audio output, resolution etc. will remain intact. Choosing to replace your settings could possibly cause a few issues, unless the build author has specifically recommended you replace the settings with theirs we would always recommend keeping your own.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4: [/COLOR][COLOR=red]VERY IMPORTANT[/COLOR][/B][CR]For the install to complete properly Kodi MUST force close, this means forcing it to close via your operating system rather than elegantly via the Kodi menu. By default this add-on will attempt to make your operating system force close Kodi but there are systems that will not allow this (devices that do not allow Kodi to have root permissions).'
 ' Once the final step of the install process has been completed you\'ll see a dialog explaining Kodi is attempting a force close, please be patient and give it a minute. If after a minute Kodi hasn\'t closed or restarted you will need to manually force close. The recommended solution for force closing is to go into your operating system menu and make it force close the Kodi app but if you dont\'t know how to do that you can just pull the power from the unit.'
 ' Pulling the power is fairly safe these days, on most set top boxes it\'s the only way to switch them off - they rarely have a power switch. Even though it\'s considered fairly safe nowadays you do this at your own risk and we would always recommend force closing via the operating system menu.' )
 if 80 - 80: i11iIiiIii % iIii1I11I1II1 / i11iIiiIii
 if 66 - 66: ooo0O . iIii1I11I1II1 * oooOooOOo0OO - O00OOo00oo0o - iIii1I11I1II1
def iIii1i1IIi ( ) :
 i1iiIII1IIiIIII ( 'What is a noobsandnerds keyword?' , '[COLOR=gold]WHAT IS A KEYWORD?[/COLOR][CR]The noobsandnerds keywords are based on the ingenious TLBB keyword system that was introduced years ago. It\'s nothing new and unlike certain other people out there we\'re not going to claim it as our idea. If you\'re already familiar with TLBB Keywords or even some of the copies out there like Cloudwords you will already know how this works but for those of you that don\'t have one of those devices we\'ll just go through the details...'
 '[CR][CR]Anyone in the community can make their own keywords and share them with others, it\'s a simple word you type in and then the content you uploaded to the web is downloaded and installed. Previously keywords have mostly been used for addon packs, this is a great way to get whole packs of addons in one go without the need to install a whole new build. We are taking this to the next level and will be introducing artwork packs and also addon fixes. More details will be available in the Community Portal section of the forum on www.noobsandnerds.com'
 '[CR][CR][CR][COLOR=gold]HOW DO I FIND A KEYWORD?[/COLOR][CR]The full list of noobsandnerds keywords can be found on the forum, in the Community Portal section you\'ll see a section for the keywords at the top of the page. Just find the pack you would like to install then using this addon type the keyword in when prompted (after clicking "Install a noobsandnerds keyword"). Your content will now be installed, if installing addon packs please be patient while each addon updates to the latest version directly from the developers repo.'
 '[CR][CR][CR][COLOR=gold]CAN I USE OTHER KEYWORDS?[/COLOR] (Cloudwords, TLBB etc.)[CR]Yes you can, just go to the addon settings and enter the url shortener that particular company use. Again you will find full details of supported keywords on the forum.' )
 if 73 - 73: II11iIiIIIiI - OoOoOO00 + i11iIiiIii * II111iiii
 if 57 - 57: O0 * iIii1I11I1II1 % O0 . OoooooooOO
def O00OIIIIIi1 ( ) :
 i1iiIII1IIiIIII ( 'How to create a keyword?' , '[COLOR=gold]NaN MAKE IT EASY![/COLOR][CR]The keywords can now be made very simply by anyone. We\'ve not locked this down to just our addon and others can use this on similar systems for creating keywords if they want...'
 '[CR][CR][COLOR=dodgerblue][B]Step 1:[/COLOR] Use a vanilla Kodi setup[/B][CR]You will require a complete fresh install of Kodi with absolutely nothing else installed and running the default skin. Decide what kind of pack you want to create, lets say we want to create a kids pack... Add all the kid related addons you want and make sure you also have the relevant repository installed too. In the unlikely event you\'ve found an addon that doesn\'t belong in a repository that\'s fine the system will create a full backup of that addon too (just means it won\'t auto update with future updates to the addon).'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Create the backup[/B][CR]Using this addon create your backup, currently only addon packs are supported but soon more packs will be added. When you create the keyword you\'ll be asked for a location to store the zip file that will be created and a name, this can be anywhwere you like and can be called whatever you want - you do not need to add the zip extension, that will automatically be added for you so in our example here we would call it "kids".'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip file to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - archive.org and copy.com are two good examples. Do not use Dropbox unless you have a paid account, they have a fair useage policy and the chances are you\'ll find within 24 hours your download has been blocked and nobody can download it.[CR][CR][COLOR=lime]Top Tip: [/COLOR]The vast majority of problems occur when the wrong download URL has been entered in the online form, a good download URL normally ends in "=1" or "zip=true". Please double check when you copy the URL into a web browser it immediately starts downloading without the need to press any other button.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4:[/COLOR] Create the keyword[/B][CR]Copy the download URL to your clipboard and then go to www.urlshortbot.com. In here you need to enter the URL in the "Long URL" field and then in the "Custom Keyword" field you need to enter "noobs" (without the quotation marks) followed by your keyword. We recommend always using a random test keyword for testing because once you have a keyword you can\'t change it, also when uploading make sure it\'s a link you can edit and still keep the same URL - that way it\'s easy to keep up to date and you can still use the same keyword. In our example of kids we would set the custom keyword as "noobskids". The noobs bit is ignored and is only for helping the addon know what to look for, the user would just type in "kids" for the kids pack to be installed.' )
 if 82 - 82: oo0O0oO . i1IIi / II11iIiIIIiI
 if 56 - 56: IIiIi1iI
def iii1 ( ) :
 i1iiIII1IIiIIII ( 'Adding Third Party Wizards' , '[COLOR=gold]ONE WIZARD TO RULE THEM ALL![/COLOR][CR]Did you know the vast majority of wizards out there (every single one we\'ve tested) has just been a copy/paste of very old code created by the team here? We\'ve noticed a lot of the users installing builds via these third party wizards have run into many different problems so we thought we\'d take it upon ourselves to help out...'
 '[CR][CR][CR][COLOR=gold]WHAT BENEFITS DOES THIS HAVE?[/COLOR][CR]We\'ve added extra code that checks for common errors, unfortunately there are some people out there using inferior programs to create their backups and that is causing problems in their wizards. If such a problem exists when trying to use another wizard you can try adding the details to this addon and it automatically fixes any corrupt files it finds. Of course there are other benefits... installing code from an unknown source can give the author access to your system so make sure you always trust the author(s). Why take the risk of installing wizards created by anonymous usernames on social media sites when you can install from a trusted source like noobsandnerds and you\'ll also be safe in the knowledge that any new updates and improvements will be made here first - we do not copy/paste code, we are actively creating new exciting solutions!'
 '[CR][CR][CR][COLOR=gold]ADDING 3RD PARTY WIZARDS TO THIS ADDON[/COLOR][CR][CR][COLOR=dodgerblue][B]Step 1:[/COLOR] Enabling 3rd Party Wizards[/B][CR]In the addon settings under the Community Builds section you have the option to enable third party community builds, if you click on this you will be able to enter details of up to 5 different wizards.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Enter the URL[/B][CR]As virtually all wizards use exactly the same structure all you need to do is find out what URL they are looking up in the code, you can open the default.py file of the wizard in a text editor and search for "http" and you will more than likely find the URL straight away. Try entering it in a web address, it should show the details for all the builds in that wizard in a text based page. If the page is blank don\'t worry it may just be locked from web browsers and can only be opened in Kodi, try it out and see if it works.'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Enter the name[/B][CR]Give the wizard a name, now when you go into the Community Builds section you\'ll have the official noobsandnerds builds as an option and also any new ones you\'ve added.' )
 if 51 - 51: o0o % i11iIiiIii
 if 77 - 77: o0o % i11iIiiIii - oooOooOOo0OO
def I1oooO00oOOooO ( url = 'http://www.iplocation.net/' , inc = 1 ) :
 iiI1i1Iii111 = re . compile ( "<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>" ) . findall ( O0Oo000ooO00 . http_GET ( url ) . content )
 for iiiiI , Ooo000 , I1111IiII1 , IiiII in iiI1i1Iii111 :
  if inc < 2 : OOooO0OOoo = xbmcgui . Dialog ( ) ; OOooO0OOoo . ok ( 'Check My IP' , "[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % iiiiI , '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % I1111IiII1 , '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % IiiII )
  inc = inc + 1
  if 72 - 72: oOo + oo0O0oO % oooOooOOo0OO + o0o % oo0O0oO
  if 8 - 8: i11iIiiIii
def iii1iII11IiI ( url ) :
 if not os . path . exists ( Oo0OoO00oOO0o ) :
  os . makedirs ( Oo0OoO00oOO0o )
  if 30 - 30: iIii1I11I1II1
 i11iI1111ii1I = ''
 OOOOO0o0OOo = 'Enter Keyword'
 OoOo0 = iiIIii ( OOOOO0o0OOo )
 i11iI1111ii1I = url + OoOo0
 o0OoOo0O00 = os . path . join ( Oo0OoO00oOO0o , OoOo0 + '.zip' )
 if 90 - 90: i1IiiiI1iI * IIIIiiII111 % II111iiii / o0o
 if OoOo0 != '' :
  o00oO0O000 = OOooO0OOoo . yesno ( 'Backup existing setup' , 'Installing certain keywords can result in some existing settings or add-ons to be replaced. Would you like to create a backup before proceeding?' )
  if 75 - 75: oOo . IIiIi1iI
  if o00oO0O000 == 1 :
   o0OoOOOO00o0 ( )
   if 89 - 89: iiii + II111iiii . oo0O0oO . ooo0O - oOoO0o00OO0
  try :
   print "Attempting download " + i11iI1111ii1I + " to " + o0OoOo0O00
   iIii1 . create ( "Web Installer" , "Downloading " , '' , 'Please Wait' )
   downloader . download ( i11iI1111ii1I , o0OoOo0O00 )
   print "### Keyword " + OoOo0 + " Successfully downloaded"
   iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
   if 69 - 69: oo0O0oO + iIii1I11I1II1 * II11iIiIIIiI + i1IiiiI1iI % iiii - O00OOo00oo0o
   if zipfile . is_zipfile ( o0OoOo0O00 ) :
    if 83 - 83: i1IiiiI1iI % oOoO0o00OO0 * oOoO0o00OO0
    try :
     extract . all ( o0OoOo0O00 , oOOoO0 , iIii1 )
     xbmc . executebuiltin ( 'UpdateLocalAddons' )
     xbmc . executebuiltin ( 'UpdateAddonRepos' )
     OOooO0OOoo . ok ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "" , "Content now installed" , "" )
     iIii1 . close ( )
     if 58 - 58: oo0O0oO - IIIIiiII111
    except :
     OOooO0OOoo . ok ( "Error with zip" , 'There was an error trying to install this file. It may possibly be corrupt, either try again or contact the author of this keyword.' )
     print "### Unable to install keyword (passed zip check): " + OoOo0
   else :
    OOooO0OOoo . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
    if 69 - 69: OoOoOO00 + oOo * oOoO0o00OO0 * i1IIi % oOo
  except :
   OOooO0OOoo . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
   print "### Unable to install keyword (unknown error, most likely a typo in keyword entry): " + OoOo0
   if 41 - 41: II11iIiIIIiI . IIiIi1iI + OoooooooOO * O00OOo00oo0o . oOoO0o00OO0
 if os . path . exists ( o0OoOo0O00 ) :
  os . remove ( o0OoOo0O00 )
  if 11 - 11: O0
  if 96 - 96: IIiIi1iI + oOoO0o00OO0
def o0OoOo00O0o0O ( ) :
 if 10 - 10: i11iIiiIii . OoooooooOO . O0 % iiii / iii1i1iiiiIi
 if xbmc . getCondVisibility ( 'system.platform.windows' ) :
  print "############   try windows force close  #################"
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im Kodi.exe /f' )
  except :
   pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill Kodi.exe' )
  except :
   pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill XBMC.exe' )
  except :
   pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im XBMC.exe /f' )
  except :
   pass
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  print "############   try osx force close  #################"
  try :
   os . system ( 'killall -9 XBMC' )
  except :
   pass
  try :
   os . system ( 'killall -9 Kodi' )
  except :
   pass
 else :
  if 36 - 36: OoOoOO00 % i1IIi + iii1i1iiiiIi
  print "############   try linux force close  #################"
  try :
   os . system ( 'killall XBMC' )
  except :
   pass
  try :
   os . system ( 'killall Kodi' )
  except :
   pass
  try :
   os . system ( 'killall -9 xbmc.bin' )
  except :
   pass
  try :
   os . system ( 'killall -9 kodi.bin' )
  except :
   pass
   if 59 - 59: i11iIiiIii - i11iIiiIii + OoOoOO00
  print "############   try atv force close  #################"
  try :
   os . system ( 'killall AppleTV' )
  except :
   pass
  print "############   try raspbmc force close  #################"
  try :
   os . system ( 'sudo initctl stop kodi' )
  except :
   pass
  try :
   os . system ( 'sudo initctl stop xbmc' )
  except :
   pass
   if 4 - 4: oOo * O0 - II11iIiIIIiI % iiii + ooo0O
  print "############   try android force close  #################"
  try :
   os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc,kodi());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.kodi());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc.xbmc());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc());' )
  except :
   pass
  OOooO0OOoo . ok ( 'Attempting to use advanced task killer apk' , 'If you have the advanced task killer apk installed please click the big button at the top which says "KILL selected apps". Click "OK" then "Kill selected apps. Please be patient while your system updates the necessary files and your skin will automatically switch once fully updated.' )
  try :
   xbmc . executebuiltin ( 'StartAndroidActivity(com.rechild.advancedtaskkiller)' )
  except :
   pass
   if 3 - 3: ooo0O
   if 91 - 91: O0 - IIIIiiII111 % oo0O0oO
def I1ii ( ) :
 xbmc . executebuiltin ( 'ReplaceWindow(settings)' )
 if 78 - 78: iii1i1iiiiIi / iIii1I11I1II1 . O00OOo00oo0o * iii1i1iiiiIi * ooo0O - o0o
 if 39 - 39: i11iIiiIii - o0o - oo0O0oO + OoooooooOO / OoOoOO00 / iIii1I11I1II1
 if 16 - 16: ooo0O / O00OOo00oo0o . oo0O0oO % i11iIiiIii % OoOoOO00 / o0o
 if 85 - 85: IIIIiiII111 + oo0O0oO
def o0OoOOOO00o0 ( ) :
 O0OOo ( )
 if 11 - 11: IIIIiiII111
 oO0OoOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , '' ) )
 oOOOOOo = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
 i1I11ii = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 95 - 95: oOo + i11iIiiIii % o0o - II11iIiIIIiI
 if not os . path . exists ( oO0OoOo ) :
  os . makedirs ( oO0OoOo )
  if 11 - 11: oooOooOOo0OO / O0 + II111iiii
 II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this backup" )
 if 95 - 95: oo0O0oO + i1IiiiI1iI * iIii1I11I1II1
 if ( not II1IIiIiiI1iI ) :
  return False , 0
  if 17 - 17: iii1i1iiiiIi - oOo * O0 / O00OOo00oo0o
 OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
 I11I11I11IiIi = xbmc . translatePath ( os . path . join ( oO0OoOo , OOOOO0o0OOo + '.zip' ) )
 OOii1ii1i11I1I = [ IiII1IiiIiI1 ]
 iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 OOOoo = "Creating full backup of existing build"
 O0OooOO = "Creating Community Build"
 III1II1iii1i = "Archiving..."
 O0OO0oOO = ""
 ooooO = "Please Wait"
 if 19 - 19: i1IIi - iIii1I11I1II1 . IIIIiiII111
 o0O0OO ( oOOoO0 , oOOOOOo , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
 OOooO0OOoo . ok ( 'Full Backup Complete' , 'You can locate your backup at:[COLOR=dodgerblue]' , oOOOOOo + '[/COLOR]' )
 if 2 - 2: O00OOo00oo0o
 if 12 - 12: i11iIiiIii - iIii1I11I1II1 * i1IiiiI1iI * IIiIi1iI
def iiIII1i ( ) :
 oo0oo0O0 = xbmc . getInfoLabel ( "System.BuildVersion" )
 Ii1i1iI = float ( oo0oo0O0 [ : 4 ] )
 if 13 - 13: O0 * iiii - i1IIi - O00OOo00oo0o
 if Ii1i1iI < 14 :
  oooOO0 = os . path . join ( oOOoo0Oo , 'xbmc.log' )
  i1iiIII1IIiIIII ( 'XBMC Log' , oooOO0 )
  if 94 - 94: i1IiiiI1iI - iIii1I11I1II1 % II11iIiIIIiI
 else :
  oooOO0 = os . path . join ( oOOoo0Oo , 'kodi.log' )
  i1iiIII1IIiIIII ( 'Kodi Log' , oooOO0 )
  if 80 - 80: O00OOo00oo0o - oooOooOOo0OO . O00OOo00oo0o / i11iIiiIii + O0 . i1IiiiI1iI
  if 15 - 15: oOo + IIiIi1iI + OoOoOO00 * oOoO0o00OO0
def iII1111IIIIiI ( ) :
 OOooO0OOoo . ok ( "Restore local guisettings fix" , "You should [COLOR=lime]ONLY[/COLOR] use this option if the guisettings fix is failing to download via the addon. Installing via this method means you do not receive notifications of updates" )
 IiiiiIi11 ( )
 if 57 - 57: IIiIi1iI / iii1i1iiiiIi - II111iiii
 if 43 - 43: i1IiiiI1iI % O00OOo00oo0o . o0o / oOo
def oOo00Oo00oO ( mode ) :
 if not mode . endswith ( "premium" ) and not mode . endswith ( "public" ) and not mode . endswith ( "private" ) :
  II1IIiIiiI1iI = oo00o0OoO ( heading = "Search for content" )
  if 50 - 50: II111iiii + oooOooOOo0OO
  if ( not II1IIiIiiI1iI ) :
   return False , 0
   if 54 - 54: II11iIiIIIiI
  OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
  if 26 - 26: iiii % OoooooooOO . oo0O0oO * iiii + II111iiii - oooOooOOo0OO
  if mode == 'tutorials' :
   oO0oOooO00oo ( 'name=' + OOOOO0o0OOo )
   if 20 - 20: iii1i1iiiiIi
  if mode == 'hardware' :
   o00OIIIIII1iI1II ( 'name=' + OOOOO0o0OOo )
   if 99 - 99: oOo + OoooooooOO . IIiIi1iI + O0
  if mode == 'news' :
   IIii1 ( 'name=' + OOOOO0o0OOo )
   if 85 - 85: II111iiii - O00OOo00oo0o
 if mode . endswith ( "premium" ) or mode . endswith ( "public" ) or mode . endswith ( "private" ) :
  o0oOO000oO0oo ( 'folder' , 'Search By Name' , mode + '&name=' , 'search_builds' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , 'Search By Uploader' , mode + '&author=' , 'search_builds' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , 'Search By Audio Addons Installed' , mode + '&audio=' , 'search_builds' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , 'Search By Picture Addons Installed' , mode + '&pics=' , 'search_builds' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , 'Search By Program Addons Installed' , mode + '&progs=' , 'search_builds' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , 'Search By Video Addons Installed' , mode + '&vids=' , 'search_builds' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , 'Search By Skins Installed' , mode + '&skins=' , 'search_builds' , '' , '' , '' , '' )
  if 93 - 93: i1IiiiI1iI / i11iIiiIii - II11iIiIIIiI + iii1i1iiiiIi / i1IIi
  if 62 - 62: oooOooOOo0OO / OoooooooOO * OoOoOO00 - i1IIi
def OO0oOOo0o ( ) :
 o0oOO000oO0oo ( '' , 'Install a [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword' , 'http://urlshortbot.com/noobs' , 'keywords' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Create a [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword' , '' , 'create_keyword' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] Installing a keyword' , '' , 'instructions_3' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] Creating a keyword' , '' , 'instructions_4' , '' , '' , '' , '' )
 if 46 - 46: OoooooooOO
 if 23 - 23: i1IIi
def IIiii1I1I ( url ) :
 oo = 'http://noobsandnerds.com/TI/LatestNews/LatestNews.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 Oo0oOOOOo = re . compile ( 'author="(.+?)"' ) . findall ( I1111i )
 oo0O0OoO = re . compile ( 'date="(.+?)"' ) . findall ( I1111i )
 I1II1 = re . compile ( 'content="(.+?)###END###"' ) . findall ( I1111i )
 if 62 - 62: oOo - II11iIiIIIiI % oOo % i1IIi % iii1i1iiiiIi / i1IIi
 O0OOoOOO0oO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 i11o00Ooo = Oo0oOOOOo [ 0 ] if ( len ( Oo0oOOOOo ) > 0 ) else ''
 ii11 = oo0O0OoO [ 0 ] if ( len ( oo0O0OoO ) > 0 ) else ''
 iiiiI11ii = I1II1 [ 0 ] if ( len ( I1II1 ) > 0 ) else ''
 iIi1i1I1I = o00iIiiiII ( iiiiI11ii )
 Ooo0oo = str ( '[COLOR=orange]Source: [/COLOR]' + i11o00Ooo + '     [COLOR=orange]Date: [/COLOR]' + ii11 + '[CR][CR][COLOR=lime]Details: [/COLOR][CR]' + iIi1i1I1I )
 if 35 - 35: IIIIiiII111 + O0 * II111iiii
 i1iiIII1IIiIIII ( O0OOoOOO0oO , Ooo0oo )
 if 23 - 23: ooo0O * i1IiiiI1iI / II11iIiIIIiI
 if 60 - 60: iiii * O00OOo00oo0o + oo0O0oO . o0o . O0
def Ii1i1ii ( url ) :
 if I1ii11iIi11i == 'true' :
  o0oOO000oO0oo ( '' , '[COLOR=orange]Latest ' + I1IiiI + ' news[/COLOR]' , I1IiiI , 'notify_msg' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'news' , 'manual_search' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime][All News][/COLOR] From all sites' , str ( url ) + '' , 'grab_news' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Official Kodi.tv News' , str ( url ) + '&author=Official%20Kodi' , 'grab_news' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'OpenELEC News' , str ( url ) + '&author=OpenELEC' , 'grab_news' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Raspbmc News' , str ( url ) + '&author=Raspbmc' , 'grab_news' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] News' , str ( url ) + '&author=noobsandnerds' , 'grab_news' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'XBMC4Xbox News' , str ( url ) + '&author=XBMC4Xbox' , 'grab_news' , '' , '' , '' , '' )
 if 53 - 53: O0 . o0o
 if 79 - 79: OoooooooOO * oo0O0oO - i1IIi * OoooooooOO % O0 % iIii1I11I1II1
def oO0ooo00OoOooooo ( title , message , times , icon ) :
 icon = O00oO + icon
 xbmc . executebuiltin ( "XBMC.Notification(" + title + "," + message + "," + times + "," + icon + ")" )
 if 87 - 87: II111iiii - OoooooooOO / i1IIi . O00OOo00oo0o - oOo . i11iIiiIii
def IIIII11II1 ( url ) :
 o0OOo0Ooo0 = xbmc . translatePath ( os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'notification.txt' ) )
 if 75 - 75: iii1i1iiiiIi - ooo0O - i1IIi % oOo - II111iiii
 if not os . path . exists ( o0OOo0Ooo0 ) :
  IiI1Iii1 = open ( o0OOo0Ooo0 , mode = 'w' )
  IiI1Iii1 . write ( '20150101000000' )
  IiI1Iii1 . close ( )
  if 61 - 61: oOo + OoooooooOO / i11iIiiIii
 I11OoooO = open ( o0OOo0Ooo0 , 'r' ) . read ( )
 if 49 - 49: i1IiiiI1iI + iii1i1iiiiIi + O0
 oo = 'http://noobsandnerds.com/TI/Community_Builds/notify?reseller=%s' % ( I1IiiI )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OooOOOOOOOO00 = re . compile ( 'notify="(.+?)"' ) . findall ( I1111i )
 oo0O0OoO = re . compile ( 'date="(.+?)"' ) . findall ( I1111i )
 i1i1 = OooOOOOOOOO00 [ 0 ] if ( len ( OooOOOOOOOO00 ) > 0 ) else 'No news items available'
 IiiIi = oo0O0OoO [ 0 ] if ( len ( oo0O0OoO ) > 0 ) else ''
 IIiiIiI = IiiIi . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
 if 49 - 49: O00OOo00oo0o . oooOooOOo0OO % iiii . oOo * o0o
 if int ( I11OoooO ) < int ( IIiiIiI ) :
  IiI1Iii1 = open ( o0OOo0Ooo0 , mode = 'w' )
  IiI1Iii1 . write ( IIiiIiI )
  IiI1Iii1 . close ( )
  OOooO0OOoo . ok ( 'Latest ' + I1IiiI + ' News' , i1i1 )
  if 44 - 44: iIii1I11I1II1 / O0 * oOo + OoOoOO00 . iiii
 else :
  OOooO0OOoo . ok ( 'Latest ' + I1IiiI + ' News' , i1i1 )
  if 20 - 20: IIiIi1iI + oOoO0o00OO0 . oo0O0oO / i11iIiiIii
  if 7 - 7: ooo0O / ooo0O . oo0O0oO * O0 + i1IiiiI1iI + II11iIiIIIiI
def OoO00oOO00O00 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(filemanager,return)' )
 return
 if 78 - 78: iii1i1iiiiIi % II111iiii
 if 94 - 94: iiii * O0
def O0O0o ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(systeminfo)' )
 if 96 - 96: O0 . oOo - IIIIiiII111
 if 42 - 42: OoooooooOO . ooo0O
def iIIii ( url ) :
 o0O0o = urllib2 . Request ( url )
 o0O0o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 10.0; WOW64; Windows NT 5.1; en-GB; rv:1.9.0.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36 Gecko/2008092417 Firefox/3.0.3' )
 if 48 - 48: oo0O0oO
 iI1II1iIiiiI = urllib2 . urlopen ( o0O0o )
 I1111i = iI1II1iIiiiI . read ( )
 iI1II1iIiiiI . close ( )
 return I1111i . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
 if 9 - 9: O00OOo00oo0o
 if 1 - 1: O0 + IIiIi1iI * iiii - i11iIiiIii
def iI11IIi1iiI1I ( ) :
 import tarfile
 if 83 - 83: oOo / iiii
 if not os . path . exists ( o00OO00OoO ) :
  os . makedirs ( o00OO00OoO )
  if 11 - 11: oOoO0o00OO0 - II111iiii % II11iIiIIIiI . II111iiii
 iIii1 . create ( "Creating Backup" , "Adding files... " , '' , 'Please Wait' )
 OO0I11IIi1I1 = tarfile . open ( os . path . join ( o00OO00OoO , Iiiii ( ) + '.tar' ) , 'w' )
 if 8 - 8: iIii1I11I1II1 . iIii1I11I1II1 + O00OOo00oo0o . o0o
 for OoO0OO0 in iiI111I1iIiI :
  iIii1 . update ( 0 , "Backing Up" , '[COLOR blue]%s[/COLOR]' % OoO0OO0 , 'Please Wait' )
  OO0I11IIi1I1 . add ( OoO0OO0 )
  if 21 - 21: OoooooooOO . O0 / i11iIiiIii
 OO0I11IIi1I1 . close ( )
 iIii1 . close ( )
 if 86 - 86: ooo0O / o0o
 if 40 - 40: iIii1I11I1II1 / iiii / OoOoOO00 + oooOooOOo0OO * o0o
def IiiI1III1I1 ( ) :
 oo0oo0O0 = xbmc . getInfoLabel ( "System.BuildVersion" )
 Ii1i1iI = float ( oo0oo0O0 [ : 4 ] )
 if Ii1i1iI < 14 :
  III1i1iI111I1 = os . path . join ( oOOoo0Oo , 'xbmc.log' )
 else :
  III1i1iI111I1 = os . path . join ( oOOoo0Oo , 'kodi.log' )
  if 64 - 64: oOo % ooo0O . oOoO0o00OO0 % OoOoOO00 / o0o
 try :
  IiI1Iii1 = open ( III1i1iI111I1 , mode = 'r' )
  iiiiI11ii = IiI1Iii1 . read ( )
  IiI1Iii1 . close ( )
 except :
  try :
   IiI1Iii1 = open ( os . path . join ( oOOoO0 , 'temp' , 'kodi.log' ) , mode = 'r' )
   iiiiI11ii = IiI1Iii1 . read ( )
   IiI1Iii1 . close ( )
  except :
   try :
    IiI1Iii1 = open ( os . path . join ( oOOoO0 , 'temp' , 'xbmc.log' ) , mode = 'r' )
    iiiiI11ii = IiI1Iii1 . read ( )
    IiI1Iii1 . close ( )
   except :
    pass
    if 74 - 74: i1IiiiI1iI - II11iIiIIIiI * iii1i1iiiiIi - oo0O0oO
 if 'OpenELEC' in iiiiI11ii :
  return True
  if 81 - 81: oOoO0o00OO0 % O00OOo00oo0o - i11iIiiIii
  if 34 - 34: O00OOo00oo0o - i1IiiiI1iI + oo0O0oO
def OoOO ( ) :
 xbmc . executebuiltin ( 'RunAddon(service.openelec.settings)' )
 if 31 - 31: i1IIi . II111iiii * oOoO0o00OO0 / i11iIiiIii
 if 96 - 96: iii1i1iiiiIi + IIiIi1iI * II111iiii
def OO00OoO ( url ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]1. Install:[/COLOR]  Installation tutorials (e.g. flashing a new OS)' , str ( url ) + '&thirdparty=InstallTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Add-on Tools:[/COLOR]  Add-on maintenance and coding tutorials' , str ( url ) + '&thirdparty=AddonTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Audio Tools:[/COLOR]  Audio related tutorials' , str ( url ) + '&thirdparty=AudioTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Gaming Tools:[/COLOR]  Integrate a gaming section into your setup' , str ( url ) + '&thirdparty=GamingTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Image Tools:[/COLOR]  Tutorials to assist with your pictures/photos' , str ( url ) + '&thirdparty=ImageTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Library Tools:[/COLOR]  Music and Video Library Tutorials' , str ( url ) + '&thirdparty=LibraryTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Skinning Tools:[/COLOR]  All your skinning advice' , str ( url ) + '&thirdparty=SkinningTools' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Video Tools:[/COLOR]  All video related tools' , str ( url ) + '&thirdparty=VideoTools' , 'grab_tutorials' , '' , '' , '' , '' )
 if 6 - 6: o0o / iIii1I11I1II1 / iiii / OoOoOO00 - i1IIi - o0o
 if 8 - 8: i11iIiiIii * IIIIiiII111 . o0o / o0o
def oO0O ( xmlfile ) :
 if 42 - 42: OoooooooOO / oo0O0oO . oOoO0o00OO0 / O0 - i1IiiiI1iI * i1IiiiI1iI
 if 'http' in xmlfile :
  i111iIi11Ii = 'none'
  o0i111 = xmlfile [ - 10 : ]
  o0i111 = o0i111 [ : - 4 ]
  O0oOO0o00OO = os . path . join ( iiI1IiI , IiII1IiiIiI1 , 'latest' )
  if 39 - 39: oOoO0o00OO0 . i1IIi % II11iIiIIIiI / IIIIiiII111 % O0
  if os . path . exists ( O0oOO0o00OO ) :
   O000o0 = open ( O0oOO0o00OO , mode = 'r' )
   i111iIi11Ii = O000o0 . read ( )
   O000o0 . close ( )
   if 100 - 100: oo0O0oO - ooo0O
  if i111iIi11Ii == o0i111 :
   o0i111 = i111iIi11Ii
   if 78 - 78: OoooooooOO - ooo0O . i11iIiiIii
  else :
   downloader . download ( xmlfile , os . path . join ( OooO0 , IiII1IiiIiI1 , 'resources' , 'skins' , 'DefaultSkin' , 'media' , 'latest.jpg' ) )
   iIIiooO00O00oOO = open ( O0oOO0o00OO , mode = 'w+' )
   iIIiooO00O00oOO . write ( o0i111 )
   iIIiooO00O00oOO . close ( )
  xmlfile = 'latest.xml'
 III111i1IIiiI = OOoOoo ( xmlfile , I11i . getAddonInfo ( 'path' ) , 'DefaultSkin' , close_time = 34 )
 III111i1IIiiI . doModal ( )
 del III111i1IIiiI
 if 100 - 100: II11iIiIIIiI + IIiIi1iI . OoOoOO00 / II111iiii % i1IiiiI1iI
 if 6 - 6: iIii1I11I1II1 * II111iiii
def i1111IIiii1 ( recursive_location , remote_path ) :
 if not os . path . exists ( recursive_location ) :
  os . makedirs ( recursive_location )
  if 38 - 38: OoOoOO00
 I1111i = iIIii ( remote_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iiI1i1Iii111 = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( I1111i )
 if 42 - 42: oOoO0o00OO0
 for OO00oOooo0O in iiI1i1Iii111 :
  oOOOo = xbmc . translatePath ( os . path . join ( recursive_location , OO00oOooo0O ) )
  if 8 - 8: i11iIiiIii / iiii
  if '/' not in OO00oOooo0O :
   if 33 - 33: oo0O0oO * i1IiiiI1iI - O0 + OoOoOO00 / i1IiiiI1iI
   try :
    iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + OO00oOooo0O + '[/COLOR]' , '' , 'Please wait...' )
    downloader . download ( remote_path + OO00oOooo0O , oOOOo , iIii1 )
    if 19 - 19: i1IIi % II111iiii
   except :
    print "failed to install" + OO00oOooo0O
    if 85 - 85: i1IiiiI1iI - oOoO0o00OO0 % o0o - II111iiii
  if '/' in OO00oOooo0O and '..' not in OO00oOooo0O and 'http' not in OO00oOooo0O :
   o0o0OOooo0Oo = remote_path + OO00oOooo0O
   i1111IIiii1 ( oOOOo , o0o0OOooo0Oo )
   if 48 - 48: oOoO0o00OO0 + oooOooOOo0OO / oooOooOOo0OO
  else :
   pass
   if 80 - 80: OoooooooOO
   if 65 - 65: II11iIiIIIiI * i1IIi . OoooooooOO % iiii
def OoOo00oOoo0oO ( ) :
 OOooO0OOoo . ok ( "Register to unlock features" , "To get the most out of this addon please register at the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] forum for free." , 'www.noobsandnerds.com' )
 if 35 - 35: oo0O0oO - i1IIi / i1IiiiI1iI
 if 13 - 13: ooo0O - iii1i1iiiiIi * OoooooooOO
def iIi1 ( ) :
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Delete Addon_Data Folder?' , 'This will free up space by deleting your addon_data folder. This contains all addon related settings including username and password info.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 14 - 14: iiii
 if i1IiiI1iIi == 1 :
  o0O00O ( )
  OOooO0OOoo . ok ( "Addon_Data Removed" , '' , 'Your addon_data folder has now been removed.' , '' )
  if 75 - 75: iIii1I11I1II1 % iiii / o0o - IIiIi1iI % i11iIiiIii
def II1IIIiiI11 ( url ) :
 i11oO0OoO = str ( url ) . replace ( OooO0 , iiI1IiI )
 if 21 - 21: i1IiiiI1iI * ooo0O - oo0O0oO
 if OOooO0OOoo . yesno ( "Remove" , '' , "Do you want to Remove" ) :
  if 44 - 44: OoooooooOO + O00OOo00oo0o
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( url ) :
   if 84 - 84: i1IIi - II111iiii . OoooooooOO / ooo0O % O00OOo00oo0o
   for ooOo0O0o0 in Oo0o :
    os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    if 7 - 7: i1IIi / i1IiiiI1iI / IIiIi1iI
   for ii1iIIiii1 in i1iiIIIi :
    shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
  os . rmdir ( url )
  if 97 - 97: iii1i1iiiiIi + iIii1I11I1II1
  try :
   if 79 - 79: iiii + II11iIiIIIiI - II111iiii . oOo
   for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( i11oO0OoO ) :
    if 26 - 26: i1IiiiI1iI
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
     if 52 - 52: O0 + iiii
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 11 - 11: i1IIi / oo0O0oO * oooOooOOo0OO * oo0O0oO * iiii - i11iIiiIii
   os . rmdir ( i11oO0OoO )
   if 96 - 96: oooOooOOo0OO % oooOooOOo0OO
  except :
   pass
   if 1 - 1: OoOoOO00 . O00OOo00oo0o
  II11IIII1 = os . path . join ( O0OoO000O0OO , 'Database' , 'Addons16.db' )
  if 33 - 33: O00OOo00oo0o + ooo0O - oooOooOOo0OO + iIii1I11I1II1 % i1IIi * i1IiiiI1iI
  try :
   os . remove ( II11IIII1 )
   if 21 - 21: O0 * iiii % iii1i1iiiiIi
  except :
   pass
   if 14 - 14: O0 / oo0O0oO / iiii + i1IiiiI1iI - i1IiiiI1iI
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  IiiI11iIi ( )
  OOooO0OOoo . ok ( 'Add-on removed' , 'You may have to restart Kodi to repopulate' , 'your add-on database. Until you restart you\'ll' , 'find your add-on is still showing even though it\'s deleted' )
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 17 - 17: oo0O0oO % iiii + i1IiiiI1iI % oOoO0o00OO0 . i1IIi
  if 58 - 58: o0o
def Oo00O0o0 ( ) :
 O0OOo ( )
 i1iiii11I111I = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to DELETE' , 'files' , '.zip' , False , False , I1IIIii )
 if 69 - 69: oOo . i11iIiiIii / IIiIi1iI / O0 + O0 . iii1i1iiiiIi
 if i1iiii11I111I != I1IIIii :
  I11OO0OoO0OOoOo = ntpath . basename ( i1iiii11I111I )
  i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Delete Backup File' , 'This will completely remove ' + I11OO0OoO0OOoOo , 'Are you sure you want to delete?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Delete' )
  if 84 - 84: II11iIiIIIiI / O00OOo00oo0o * IIiIi1iI
  if i1IiiI1iIi == 1 :
   os . remove ( i1iiii11I111I )
   if 20 - 20: ooo0O % O0
   if 59 - 59: O0 . oOoO0o00OO0 % oooOooOOo0OO * II11iIiIIIiI + IIIIiiII111
def o00oIiIiIiiI ( ) :
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Remove All Crash Logs?' , 'There is absolutely no harm in doing this, these are log files generated when Kodi crashes and are only used for debugging purposes.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 83 - 83: ooo0O
 if i1IiiI1iIi == 1 :
  oooO0o ( )
  OOooO0OOoo . ok ( "Crash Logs Removed" , '' , 'Your crash log files have now been removed.' , '' )
  if 84 - 84: O00OOo00oo0o
  if 70 - 70: iIii1I11I1II1
def IiiI11iIi ( ) :
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Delete Packages Folder' , 'Do you want to clean the packages folder? This will free up space by deleting the old zip install files of your addons. Keeping these files can also sometimes cause problems when reinstalling addons' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 45 - 45: O0 - ooo0O % o0o
 if i1IiiI1iIi == 1 :
  ooO ( )
  OOooO0OOoo . ok ( "Packages Removed" , '' , 'Your zip install files have now been removed.' , '' )
  if 100 - 100: i11iIiiIii . o0o . i11iIiiIii
  if 81 - 81: OoOoOO00
def iii1II1iI1IIi ( ) :
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Clear Cached Images?' , 'This will clear your textures13.db file and remove your Thumbnails folder. These will automatically be repopulated after a restart.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 76 - 76: O0 - iiii / O00OOo00oo0o . oOo - O00OOo00oo0o
 if i1IiiI1iIi == 1 :
  ooo ( )
  IIIii11 ( ooOoOoo0O )
  if 75 - 75: iiii % o0o / oOoO0o00OO0 % II111iiii
  i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Quit Kodi Now?' , 'Cache has been successfully deleted.' , 'You must now restart Kodi, would you like to quit now?' , '' , nolabel = 'I\'ll restart later' , yeslabel = 'Yes, quit' )
  if 30 - 30: oOoO0o00OO0
  if i1IiiI1iIi == 1 :
   try :
    xbmc . executebuiltin ( "RestartApp" )
    if 15 - 15: II111iiii - O00OOo00oo0o - IIiIi1iI . II11iIiIIIiI / i11iIiiIii
   except :
    o0OoOo00O0o0O ( )
    if 38 - 38: iii1i1iiiiIi
    if 3 - 3: II111iiii . OoOoOO00 / oOo + oOoO0o00OO0
def ooo ( ) :
 ooooooOO = xbmc . translatePath ( 'special://home/userdata/Database/Textures13.db' )
 try :
  Oo0Ooo = database . connect ( ooooooOO )
  II1iII11 = Oo0Ooo . cursor ( )
  II1iII11 . execute ( "DROP TABLE IF EXISTS path" )
  II1iII11 . execute ( "VACUUM" )
  Oo0Ooo . commit ( )
  II1iII11 . execute ( "DROP TABLE IF EXISTS sizes" )
  II1iII11 . execute ( "VACUUM" )
  Oo0Ooo . commit ( )
  II1iII11 . execute ( "DROP TABLE IF EXISTS texture" )
  II1iII11 . execute ( "VACUUM" )
  Oo0Ooo . commit ( )
  II1iII11 . execute ( """CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""" )
  Oo0Ooo . commit ( )
  II1iII11 . execute ( """CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""" )
  Oo0Ooo . commit ( )
  II1iII11 . execute ( """CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""" )
  Oo0Ooo . commit ( )
 except :
  pass
  if 19 - 19: II111iiii
  if 5 - 5: oOo
def oOoOo0o0 ( url ) :
 oo = 'http://noobsandnerds.com/TI/Community_Builds/reseller_2?reseller=%s&token=%s&openelec=%s' % ( I1IiiI , IIi1IiiiI1Ii , url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i11IiiI1Ii1 = re . compile ( 'path="(.+?)"' ) . findall ( I1111i )
 II1Iiiii = re . compile ( 'reseller="(.+?)"' ) . findall ( I1111i )
 OoO00 = re . compile ( 'premium="(.+?)"' ) . findall ( I1111i )
 iI1I = re . compile ( 'openelec="(.+?)"' ) . findall ( I1111i )
 Oo0oO0OO0 = II1Iiiii [ 0 ] if ( len ( II1Iiiii ) > 0 ) else 'None'
 OOI1i11i = OoO00 [ 0 ] if ( len ( OoO00 ) > 0 ) else 'None'
 iiiI1I = iI1I [ 0 ] if ( len ( iI1I ) > 0 ) else 'None'
 exec iiiI1I
 exec Oo0oO0OO0
 exec OOI1i11i
 if 92 - 92: oOo % oOoO0o00OO0 - iiii / iiii / ooo0O
 if 84 - 84: o0o
def I1I1I1 ( name , url , description ) :
 if 'Backup' in name :
  O0OOo ( )
  iIiiiiII11 = open ( url ) . read ( )
  OOOo = os . path . join ( I1IIIii , description . split ( 'Your ' ) [ 1 ] )
  ooOo0O0o0 = open ( OOOo , mode = 'w' )
  ooOo0O0o0 . write ( iIiiiiII11 )
  ooOo0O0o0 . close ( )
  if 22 - 22: i1IIi / i1IiiiI1iI * IIIIiiII111
 else :
  if 'guisettings.xml' in description :
   O0O0oo = open ( os . path . join ( I1IIIii , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   OO0oOOOOO = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % oO0Oo
   iiI1i1Iii111 = re . compile ( OO0oOOOOO ) . findall ( O0O0oo )
   if 87 - 87: OoooooooOO . iiii % iIii1I11I1II1 . iIii1I11I1II1 % oooOooOOo0OO . oo0O0oO
   for type , i1ii1i1 , iiI1iiiii in iiI1i1Iii111 :
    iiI1iiiii = iiI1iiiii . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , i1ii1i1 , iiI1iiiii ) )
    if 53 - 53: oOoO0o00OO0 / oOo / IIiIi1iI + O00OOo00oo0o - iii1i1iiiiIi
  else :
   OOOo = os . path . join ( url )
   iIiiiiII11 = open ( os . path . join ( I1IIIii , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   ooOo0O0o0 = open ( OOOo , mode = 'w' )
   ooOo0O0o0 . write ( iIiiiiII11 )
   ooOo0O0o0 . close ( )
   if 18 - 18: II11iIiIIIiI * O0 - OoOoOO00 + O0 + oo0O0oO
 OOooO0OOoo . ok ( "Restore Complete" , "" , 'All Done !' , '' )
 if 70 - 70: oOoO0o00OO0 / IIIIiiII111 + II11iIiIIIiI % OoOoOO00 % oOo + iii1i1iiiiIi
 if 80 - 80: o0o
def iiii1IiI1i1 ( name , url , video , description , skins , guisettingslink , artpack ) :
 iIii1 . create ( "Backing Up Important Data" , 'Please wait...' , '' , '' )
 if 3 - 3: ooo0O
 if 33 - 33: OoooooooOO . i1IiiiI1iI / IIiIi1iI + OoooooooOO - oooOooOOo0OO
 II1I11i = open ( iiiiiIIii , mode = 'r' )
 oO000 = II1I11i . read ( )
 II1I11i . close ( )
 if 35 - 35: oo0O0oO * IIIIiiII111
 oOOo = re . compile ( 'gui="(.+?)"' ) . findall ( oO000 )
 ii1I1IiiI1 = oOOo [ 0 ] if ( len ( oOOo ) > 0 ) else '0'
 if 72 - 72: IIiIi1iI / oooOooOOo0OO + oooOooOOo0OO
 if 95 - 95: IIiIi1iI - o0o * IIiIi1iI
 if o0OOO == 'true' :
  try :
   O000oOo0OO = open ( iIi1ii1I1 , mode = 'r' )
   oo00O000 = O000oOo0OO . read ( )
   O000oOo0OO . close ( )
   if 90 - 90: IIiIi1iI
  except :
   print "### No favourites file to copy"
   if 81 - 81: O00OOo00oo0o % iii1i1iiiiIi
 if iIiiiI == 'true' :
  try :
   OOIII = open ( o0 , mode = 'r' )
   IiiI1iIiI = OOIII . read ( )
   OOIII . close ( )
   if 91 - 91: oOoO0o00OO0 * oooOooOOo0OO - IIiIi1iI . II111iiii
  except :
   print "### No sources file to copy"
   if 1 - 1: o0o + oo0O0oO * oooOooOOo0OO
   if 44 - 44: IIiIi1iI
   if 79 - 79: oOoO0o00OO0 % o0o . O0
   if 56 - 56: II11iIiIIIiI + i1IIi * IIiIi1iI - O0
   if 84 - 84: IIiIi1iI % OoOoOO00 / iIii1I11I1II1 * O00OOo00oo0o * iIii1I11I1II1 + oooOooOOo0OO
   if 78 - 78: i1IiiiI1iI / IIiIi1iI * O00OOo00oo0o . o0o . II11iIiIIIiI - oo0O0oO
   if 39 - 39: iiii . i1IIi + OoooooooOO . IIiIi1iI - i11iIiiIii % oo0O0oO
   if 38 - 38: II11iIiIIIiI
   if 9 - 9: IIIIiiII111 . iii1i1iiiiIi . II11iIiIIIiI / OoooooooOO
   if 59 - 59: iIii1I11I1II1 + i1IIi % II111iiii
 iii1IiI = 1
 O0OOo ( )
 if 87 - 87: OoOoOO00 - O0 - IIIIiiII111 * oo0O0oO % oo0O0oO
 if 99 - 99: O0 * i11iIiiIii % o0o * II111iiii
 if os . path . exists ( Ii1iIiII1ii1 ) :
  if 98 - 98: O0 + iIii1I11I1II1
  if os . path . exists ( O0o0Oo ) :
   os . remove ( Ii1iIiII1ii1 )
   if 94 - 94: i1IIi * iii1i1iiiiIi * ooo0O
  else :
   os . rename ( Ii1iIiII1ii1 , O0o0Oo )
   if 93 - 93: iiii / o0o * O0
 if os . path . exists ( Oo00OOOOO ) :
  os . remove ( Oo00OOOOO )
  if 17 - 17: iii1i1iiiiIi / iiii % OoOoOO00
  if 47 - 47: oOo * iii1i1iiiiIi / oOoO0o00OO0 * OoOoOO00
 if not os . path . exists ( OOO00 ) :
  IiI1Iii1 = open ( OOO00 , mode = 'w+' )
  IiI1Iii1 . close ( )
  if 60 - 60: oooOooOOo0OO / i1IiiiI1iI . i11iIiiIii / iii1i1iiiiIi % II111iiii
 iIii1 . close ( )
 iIii1 . create ( "Downloading Skin Fix" , "Downloading guisettings.xml" , '' , 'Please Wait' )
 o0OoOo0O00 = os . path . join ( I1IIIii , 'guifix.zip' )
 if 6 - 6: IIiIi1iI % oOoO0o00OO0 + oo0O0oO
 if 91 - 91: oOoO0o00OO0 + O0 * II11iIiIIIiI * i1IiiiI1iI * oooOooOOo0OO
 try :
  print "### attempting to download guisettings.xml"
  downloader . download ( guisettingslink , o0OoOo0O00 , iIii1 )
  iIii1 . close ( )
 except :
  OOooO0OOoo . ok ( 'Problem Detected' , 'Sorry there was a problem downloading the guisettings file. Please check your storage location, if you\'re certain that\'s ok please notify the build author on the relevant support thread.' )
  print "### FAILED to download " + guisettingslink
  if 83 - 83: OoooooooOO
 if zipfile . is_zipfile ( o0OoOo0O00 ) :
  IIi = str ( os . path . getsize ( o0OoOo0O00 ) )
  if 52 - 52: oOoO0o00OO0 / ooo0O % II11iIiIIIiI % iii1i1iiiiIi / i1IiiiI1iI % oOoO0o00OO0
 else :
  IIi = ii1I1IiiI1
  if 88 - 88: o0o / i11iIiiIii / O00OOo00oo0o / i11iIiiIii * oooOooOOo0OO % IIIIiiII111
  if 43 - 43: ooo0O * iii1i1iiiiIi % i1IIi * O00OOo00oo0o + iIii1I11I1II1
 IiI1Iii1 = open ( OOO00 , mode = 'r' )
 iiiiI11ii = IiI1Iii1 . read ( )
 IiI1Iii1 . close ( )
 if 80 - 80: oOoO0o00OO0 . IIiIi1iI . OoooooooOO
 iiII1 = re . compile ( 'id="(.+?)"' ) . findall ( iiiiI11ii )
 oo0OoO = re . compile ( 'name="(.+?)"' ) . findall ( iiiiI11ii )
 iIIi1iii1 = re . compile ( 'version="(.+?)"' ) . findall ( iiiiI11ii )
 if 63 - 63: iiii . o0o
 o00o0 = iiII1 [ 0 ] if ( len ( iiII1 ) > 0 ) else ''
 OOoOo0O0 = oo0OoO [ 0 ] if ( len ( oo0OoO ) > 0 ) else ''
 iiii1IIi1 = iIIi1iii1 [ 0 ] if ( len ( iIIi1iii1 ) > 0 ) else ''
 if 66 - 66: OoOoOO00
 if os . path . exists ( ooOooo000oOO ) :
  os . removedirs ( ooOooo000oOO )
  if 99 - 99: iii1i1iiiiIi % O0 . oo0O0oO - oooOooOOo0OO . oOo / ooo0O
  if 60 - 60: oooOooOOo0OO
 if ii1I1IiiI1 != IIi :
  try :
   os . rename ( O0o0Oo , Ii1iIiII1ii1 )
   if 78 - 78: II11iIiIIIiI + II111iiii
  except :
   OOooO0OOoo . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit Kodi and try again' , '' )
   return
   if 55 - 55: OoooooooOO
   if 90 - 90: OoOoOO00
 if video != 'fresh' :
  i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( name , 'We highly recommend backing up your existing build before installing any community builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
  if 4 - 4: o0o % iiii - o0o - oOoO0o00OO0
  if i1IiiI1iIi == 0 :
   iI1IIIiIII11 = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' ) )
   if 70 - 70: OoooooooOO + iii1i1iiiiIi * oOo
   if not os . path . exists ( iI1IIIiIII11 ) :
    os . makedirs ( iI1IIIiIII11 )
    if 20 - 20: i11iIiiIii - II111iiii - iiii % II11iIiIIIiI . iiii
   II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this backup" )
   if 50 - 50: iIii1I11I1II1 + oo0O0oO - IIIIiiII111 - OoooooooOO
   if ( not II1IIiIiiI1iI ) :
    return False , 0
    if 84 - 84: ooo0O - IIIIiiII111
   OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
   I11I11I11IiIi = xbmc . translatePath ( os . path . join ( iI1IIIiIII11 , OOOOO0o0OOo + '.zip' ) )
   OOii1ii1i11I1I = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
   iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
   OOOoo = "Creating full backup of existing build"
   III1II1iii1i = "Archiving..."
   O0OO0oOO = ""
   ooooO = "Please Wait"
   o0O0OO ( oOOoO0 , I11I11I11IiIi , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
   if 80 - 80: i11iIiiIii % o0o - oOo % o0o
   if 89 - 89: O00OOo00oo0o * IIIIiiII111 + ooo0O / i11iIiiIii
   if 68 - 68: OoooooooOO * IIIIiiII111
   if 86 - 86: oOoO0o00OO0 / ooo0O
   if 40 - 40: IIiIi1iI
 iIIiooO00O00oOO = open ( iiiiiIIii , mode = 'w+' )
 if 62 - 62: iiii / o0o
 if ii1I1IiiI1 != IIi :
  iIIiooO00O00oOO . write ( 'id="' + str ( o00o0 ) + '"\nname="' + OOoOo0O0 + ' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="' + iiii1IIi1 + '"\ngui="' + IIi + '"' )
  if 74 - 74: IIiIi1iI % oo0O0oO / oo0O0oO - iIii1I11I1II1 - II111iiii + o0o
 else :
  iIIiooO00O00oOO . write ( 'id="' + str ( o00o0 ) + '"\nname="' + OOoOo0O0 + '"\nversion="' + iiii1IIi1 + '"\ngui="' + IIi + '"' )
 iIIiooO00O00oOO . close ( )
 if 92 - 92: IIIIiiII111 % oo0O0oO
 if 18 - 18: iiii + oo0O0oO / o0o / II11iIiIIIiI + iIii1I11I1II1 % i1IiiiI1iI
 if video == 'libprofile' or video == 'library' or video == 'updatelibprofile' or video == 'updatelibrary' :
  try :
   shutil . copytree ( II , Oo0oOOo , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 94 - 94: IIIIiiII111
  except :
   iii1IiI = xbmcgui . Dialog ( ) . yesno ( name , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if 37 - 37: II11iIiIIIiI
   if iii1IiI == 0 :
    return
    if 52 - 52: oooOooOOo0OO * OoOoOO00 . o0o + i1IIi % II11iIiIIIiI / iIii1I11I1II1
  I11I11I11IiIi = xbmc . translatePath ( os . path . join ( I1IIIii , 'Database.zip' ) )
  iIIIiIi1I1i ( Oo0oOOo , I11I11I11IiIi )
  if 68 - 68: oo0O0oO - ooo0O . i11iIiiIii + oOoO0o00OO0
 if iii1IiI == 0 :
  return
  if 71 - 71: i11iIiiIii / i1IIi * OoOoOO00 / ooo0O
 time . sleep ( 1 )
 if 33 - 33: IIIIiiII111 . oOo
 if 89 - 89: IIiIi1iI + i1IIi - i1IiiiI1iI + iiii . II111iiii
 Oo00oOOO0 = xbmc . translatePath ( os . path . join ( oOOoO0 , '..' , 'koditemp.zip' ) )
 time . sleep ( 2 )
 iIii1 . create ( "Community Builds" , "Downloading " + description + " build." , '' , 'Please Wait' )
 i1iiii11I111I = description . replace ( ' ' , '_' )
 o0OoOo0O00 = os . path . join ( oOoOooOo0o0 , i1iiii11I111I + '.zip' )
 if 13 - 13: O0 + iIii1I11I1II1 % II111iiii + iIii1I11I1II1
 if not os . path . exists ( oOoOooOo0o0 ) :
  os . makedirs ( oOoOooOo0o0 )
  if 85 - 85: OoOoOO00 * iIii1I11I1II1 . IIiIi1iI / IIiIi1iI
 downloader . download ( url , o0OoOo0O00 , iIii1 )
 if 43 - 43: OoOoOO00
 if 78 - 78: iii1i1iiiiIi % II111iiii + ooo0O / OoOoOO00
 if 34 - 34: oOoO0o00OO0 % oooOooOOo0OO + O00OOo00oo0o * IIIIiiII111 / II11iIiIIIiI
 if 18 - 18: iiii
 if 92 - 92: iii1i1iiiiIi % iIii1I11I1II1 / i1IiiiI1iI * IIiIi1iI . i1IIi + II11iIiIIIiI
 if 24 - 24: i1IiiiI1iI . IIiIi1iI * i1IiiiI1iI % i11iIiiIii . i11iIiiIii + i1IIi
 if 64 - 64: iIii1I11I1II1 / i1IiiiI1iI / oOo - oooOooOOo0OO
 if 100 - 100: i1IiiiI1iI + i1IIi * iii1i1iiiiIi
 try :
  oOooOO0oOo0O0 = open ( IIIII , mode = 'r' )
  I1iiii1iiiI = oOooOO0oOo0O0 . read ( )
  oOooOO0oOo0O0 . close ( )
  if 1 - 1: i1IIi
 except :
  print "### No profiles detected, most likely a fresh wipe performed"
  if 27 - 27: IIIIiiII111
 iIii1 . close ( )
 iIii1 . create ( "Community Builds" , "Checking " , '' , 'Please Wait' )
 if 47 - 47: OoooooooOO
 if 48 - 48: ooo0O . i1IiiiI1iI % OoOoOO00 + IIIIiiII111
 if zipfile . is_zipfile ( o0OoOo0O00 ) :
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( o0OoOo0O00 , oOOoO0 , iIii1 )
  if 37 - 37: oOo + oo0O0oO * II11iIiIIIiI / oOoO0o00OO0
 else :
  OOooO0OOoo . ok ( 'Not a valid zip file' , 'This file is not a valid zip file, please let the build author know on their support thread so they can amend the download path. It\'s most likely just a simple typo on their behalf.' )
  return
  if 78 - 78: i1IiiiI1iI + IIIIiiII111 - oOoO0o00OO0 + iii1i1iiiiIi / iIii1I11I1II1
  if 47 - 47: o0o
  if 20 - 20: oo0O0oO % iiii - oo0O0oO * OoooooooOO / oooOooOOo0OO
 iIii1 . create ( "Restoring Dependencies" , "Checking " , '' , 'Please Wait' )
 iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
 if 57 - 57: i1IiiiI1iI % IIIIiiII111 * o0o % oooOooOOo0OO
 if o0OOO == 'true' :
  try :
   print "### Attempting to add back favourites ###"
   iIIiooO00O00oOO = open ( iIi1ii1I1 , mode = 'w+' )
   iIIiooO00O00oOO . write ( oo00O000 )
   iIIiooO00O00oOO . close ( )
   iIii1 . update ( 0 , "" , "Copying Favourites" )
   if 65 - 65: i1IIi - OoooooooOO
  except :
   print "### Failed to copy back favourites"
   if 66 - 66: oooOooOOo0OO / i1IIi * OoOoOO00 - ooo0O + II11iIiIIIiI
 if iIiiiI == 'true' :
  try :
   print "### Attempting to add back sources ###"
   iIIiooO00O00oOO = open ( o0 , mode = 'w+' )
   iIIiooO00O00oOO . write ( IiiI1iIiI )
   iIIiooO00O00oOO . close ( )
   iIii1 . update ( 0 , "" , "Copying Sources" )
   if 74 - 74: IIiIi1iI / oo0O0oO / II111iiii - IIiIi1iI / II11iIiIIIiI % IIIIiiII111
  except :
   print "### Failed to copy back sources"
   if 19 - 19: i1IiiiI1iI % OoooooooOO + OoooooooOO
 time . sleep ( 1 )
 if os . path . exists ( Oo0oOOo ) :
  shutil . rmtree ( Oo0oOOo )
  if 7 - 7: i1IIi
  if 91 - 91: ooo0O - ooo0O . i1IiiiI1iI
  if 33 - 33: oo0O0oO - iIii1I11I1II1 / O00OOo00oo0o % O0
  if 80 - 80: i1IiiiI1iI % OoooooooOO - i1IiiiI1iI
  if 27 - 27: oo0O0oO - oOoO0o00OO0 * oooOooOOo0OO - OoOoOO00
  if 22 - 22: oOo % OoooooooOO - oOo - IIiIi1iI . O00OOo00oo0o
  if 100 - 100: II111iiii / oo0O0oO / IIiIi1iI - oooOooOOo0OO * iIii1I11I1II1
  if 7 - 7: i1IIi . i1IiiiI1iI % i11iIiiIii * oooOooOOo0OO . IIIIiiII111 % oooOooOOo0OO
  if 35 - 35: OoOoOO00
  if 48 - 48: OoooooooOO % OoooooooOO - iii1i1iiiiIi . ooo0O
  if 22 - 22: iiii . i11iIiiIii . OoooooooOO . i1IIi
 Ii1I11I = 'http://noobsandnerds.com/TI/Community_Builds/downloadcount.php?id=%s' % ( o00o0 )
 if not 'update' in video :
  try :
   iIIii ( Ii1I11I )
  except :
   pass
   if 12 - 12: ooo0O % o0o + II11iIiIIIiI . O0 % iIii1I11I1II1
   if 41 - 41: OoooooooOO
 if os . path . exists ( OOOO ) :
  IiI1Iii1 = open ( OOOO , mode = 'r' )
  iiiiI11ii = IiI1Iii1 . read ( )
  IiI1Iii1 . close ( )
  I1IIii11 = re . compile ( 'version="[\s\S]*?"' ) . findall ( iiiiI11ii )
  i1i = I1IIii11 [ 0 ] if ( len ( I1IIii11 ) > 0 ) else ''
  i1I1 = iiiiI11ii . replace ( i1i , 'version="' + iiii1IIi1 + '"' )
  iIIiooO00O00oOO = open ( OOOO , mode = 'w' )
  iIIiooO00O00oOO . write ( str ( i1I1 ) )
  iIIiooO00O00oOO . close ( )
  if 13 - 13: IIIIiiII111 + oo0O0oO - oo0O0oO % II11iIiIIIiI / IIIIiiII111
 else :
  iIIiooO00O00oOO = open ( OOOO , mode = 'w+' )
  iIIiooO00O00oOO . write ( 'date="01011001"\nversion="' + iiii1IIi1 + '"' )
  iIIiooO00O00oOO . close ( )
  if 4 - 4: OoOoOO00 + o0o - i1IiiiI1iI + IIiIi1iI
  if 78 - 78: O00OOo00oo0o
 if O0O == 'false' :
  os . remove ( o0OoOo0O00 )
  if 29 - 29: II111iiii
  if 79 - 79: iIii1I11I1II1 - i11iIiiIii + iiii - II111iiii . iIii1I11I1II1
  if 84 - 84: oOo % IIIIiiII111 * O0 * IIIIiiII111
  if 66 - 66: o0o / iIii1I11I1II1 - ooo0O % O0 . iiii
  if 12 - 12: oOo + OoOoOO00
  if 37 - 37: i1IIi * i11iIiiIii
  if 95 - 95: i11iIiiIii % oo0O0oO * oOo + i1IIi . O0 + oooOooOOo0OO
 if 'prof' in video :
  try :
   II1iiiiI1Ii11 = open ( IIIII , mode = 'w+' )
   II1iiiiI1Ii11 . write ( I1iiii1iiiI )
   II1iiiiI1Ii11 . close ( )
  except :
   print "### Failed to write existing profile info back into profiles.xml"
   if 69 - 69: IIIIiiII111 / i1IIi / II11iIiIIIiI . oo0O0oO
   if 41 - 41: II11iIiIIIiI * i1IiiiI1iI + OoOoOO00
 if video == 'library' or video == 'libprofile' or video == 'updatelibprofile' or video == 'updatelibrary' :
  extract . all ( I11I11I11IiIi , II , iIii1 )
  if 7 - 7: iiii % iii1i1iiiiIi + OoooooooOO
  if 25 - 25: IIiIi1iI . iii1i1iiiiIi / iIii1I11I1II1
  if iii1IiI != 1 :
   shutil . rmtree ( Oo0oOOo )
 try :
  iIii1 . close ( )
 except :
  pass
  if 56 - 56: oOoO0o00OO0 % i11iIiiIii . O00OOo00oo0o * iIii1I11I1II1 - oOo
  if 77 - 77: OoooooooOO
 if os . path . exists ( OOoOO0oo0ooO ) :
  IIiI11I1I1i1i ( description )
  if 52 - 52: IIiIi1iI - iii1i1iiiiIi % i11iIiiIii . IIIIiiII111
  try :
   os . remove ( OOoOO0oo0ooO )
   if 98 - 98: OoooooooOO + ooo0O . ooo0O / O0 / i11iIiiIii
  except :
   print "##' Failed to remove: " + OOoOO0oo0ooO
   if 88 - 88: II111iiii - IIiIi1iI / OoooooooOO
  try :
   shutil . rmtree ( OOO00O )
   if 71 - 71: oooOooOOo0OO
  except :
   print "##' Failed to remove: " + OOO00O
   if 19 - 19: oOo - iii1i1iiiiIi + i11iIiiIii / iIii1I11I1II1
 else : print "### Community Builds - using an old build"
 if 1 - 1: i1IiiiI1iI % i1IIi
 if 41 - 41: iii1i1iiiiIi * iii1i1iiiiIi / IIiIi1iI + oooOooOOo0OO . oOoO0o00OO0
 if ii1I1IiiI1 != IIi :
  print "### GUI SIZE DIFFERENT ATTEMPTING MERGE ###"
  Oo0OOoo = os . path . join ( oOOoO0 , 'newbuild' )
  if 59 - 59: O0 % o0o - II111iiii . o0o . oooOooOOo0OO
  if not os . path . exists ( Oo0OOoo ) :
   os . makedirs ( Oo0OOoo )
   if 55 - 55: IIIIiiII111 . i1IiiiI1iI % II111iiii - i1IIi . O0 * O00OOo00oo0o
  os . makedirs ( ooOooo000oOO )
  time . sleep ( 1 )
  iiiI1IiI ( guisettingslink , video )
  time . sleep ( 1 )
  if 5 - 5: IIiIi1iI - IIiIi1iI / oo0O0oO % oOo
  if 61 - 61: II11iIiIIIiI - oooOooOOo0OO / IIiIi1iI % oooOooOOo0OO + iii1i1iiiiIi / oOo
  if 10 - 10: i11iIiiIii / ooo0O
  if 27 - 27: OoOoOO00 / OoooooooOO
  o0OoOo00O0o0O ( )
  OOooO0OOoo . ok ( "Force Close Required" , "If you\'re seeing this message it means the force close was unsuccessful. Please close XBMC/Kodi via your operating system or pull the power." )
  if 74 - 74: oooOooOOo0OO % oo0O0oO - iii1i1iiiiIi * IIIIiiII111 . OoooooooOO * iii1i1iiiiIi
 if ii1I1IiiI1 == IIi :
  OOooO0OOoo . ok ( 'Successfully Updated' , 'Congratulations the following build:[COLOR=dodgerblue]' , description , '[/COLOR]has been successfully updated!' )
  if 99 - 99: ooo0O . IIiIi1iI - OoooooooOO - O0
  if 6 - 6: o0o
def Ii1111i11 ( url ) :
 O0Ooo000OO00 = 0
 iii1IiI = 0
 print "Restore Location: " + url
 if 51 - 51: iiii * i1IiiiI1iI * iIii1I11I1II1 / ooo0O % i1IiiiI1iI
 oO0O ( 'noobsandnerds.xml' )
 if 36 - 36: oooOooOOo0OO * oOoO0o00OO0 + i11iIiiIii + OoooooooOO
 O0OOo ( )
 if 82 - 82: ooo0O . ooo0O
 if url == 'local' :
  i1iiii11I111I = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.zip' , False , False , I1IIIii )
  if i1iiii11I111I == '' :
   O0Ooo000OO00 = 1
   if 10 - 10: oOo * oooOooOOo0OO . II11iIiIIIiI . OoooooooOO . o0o * oooOooOOo0OO
 if O0Ooo000OO00 == 1 :
  print "### No file selected, quitting restore process ###"
  return
  if 80 - 80: oo0O0oO + IIIIiiII111 . oo0O0oO + o0o
 if url != 'local' :
  iIii1 . create ( "Community Builds" , "Downloading build." , '' , 'Please Wait' )
  i1iiii11I111I = os . path . join ( oOoOooOo0o0 , Iiiii ( ) + '.zip' )
  if 85 - 85: i11iIiiIii . IIIIiiII111 + O00OOo00oo0o / O00OOo00oo0o
  if not os . path . exists ( oOoOooOo0o0 ) :
   os . makedirs ( oOoOooOo0o0 )
   if 43 - 43: i1IiiiI1iI . OoooooooOO - II111iiii
  downloader . download ( url , i1iiii11I111I , iIii1 )
  if 90 - 90: OoOoOO00 - iIii1I11I1II1 + oooOooOOo0OO * o0o * II11iIiIIIiI
 if os . path . exists ( Ii1iIiII1ii1 ) :
  if os . path . exists ( O0o0Oo ) :
   os . remove ( Ii1iIiII1ii1 )
  else :
   os . rename ( Ii1iIiII1ii1 , O0o0Oo )
   if 19 - 19: oo0O0oO * II111iiii % oOo - i1IIi
 if os . path . exists ( Oo00OOOOO ) :
  os . remove ( Oo00OOOOO )
  if 27 - 27: ooo0O . O0 / oooOooOOo0OO . iIii1I11I1II1
  if 15 - 15: O00OOo00oo0o + iii1i1iiiiIi % iIii1I11I1II1 - oooOooOOo0OO - i1IIi % oOoO0o00OO0
 if not os . path . exists ( OOO00 ) :
  IiI1Iii1 = open ( OOO00 , mode = 'w+' )
  if 54 - 54: i1IiiiI1iI - II111iiii . iiii + O00OOo00oo0o
 if os . path . exists ( ooOooo000oOO ) :
  os . removedirs ( ooOooo000oOO )
  if 45 - 45: II11iIiIIIiI + II111iiii . IIiIi1iI / oooOooOOo0OO
  if 76 - 76: O00OOo00oo0o + IIiIi1iI - i1IiiiI1iI * iIii1I11I1II1 % i1IIi
 try :
  os . rename ( O0o0Oo , Ii1iIiII1ii1 )
  if 72 - 72: iiii + II111iiii . O0 - IIiIi1iI / OoooooooOO . oo0O0oO
 except :
  OOooO0OOoo . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit XBMC and try again' , '' )
  return
  if 28 - 28: iIii1I11I1II1 . O0
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( O0OOoOOO0oO , 'We highly recommend backing up your existing build before installing any builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
 if i1IiiI1iIi == 0 :
  iI1IIIiIII11 = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' ) )
  if 32 - 32: OoooooooOO
  if not os . path . exists ( iI1IIIiIII11 ) :
   os . makedirs ( iI1IIIiIII11 )
   if 29 - 29: oooOooOOo0OO
  II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this backup" )
  if ( not II1IIiIiiI1iI ) :
   return False , 0
   if 41 - 41: O00OOo00oo0o
  OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
  I11I11I11IiIi = xbmc . translatePath ( os . path . join ( iI1IIIiIII11 , OOOOO0o0OOo + '.zip' ) )
  OOii1ii1i11I1I = [ IiII1IiiIiI1 ]
  iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
  OOOoo = "Creating full backup of existing build"
  III1II1iii1i = "Archiving..."
  O0OO0oOO = ""
  ooooO = "Please Wait"
  if 49 - 49: O00OOo00oo0o % II111iiii . O00OOo00oo0o - oOoO0o00OO0 - IIIIiiII111 * i1IiiiI1iI
  o0O0OO ( oOOoO0 , I11I11I11IiIi , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
 IiiO0O0O0OOO0o = xbmcgui . Dialog ( ) . yesno ( O0OOoOOO0oO , 'Would you like to keep your existing database files or overwrite? Overwriting will wipe any existing music or video library you may have scanned in.' , nolabel = 'Overwrite' , yeslabel = 'Keep Existing' )
 if IiiO0O0O0OOO0o == 1 :
  if os . path . exists ( Oo0oOOo ) :
   shutil . rmtree ( Oo0oOOo )
   if 98 - 98: iii1i1iiiiIi - oOo * OoOoOO00
  try :
   shutil . copytree ( II , Oo0oOOo , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 90 - 90: OoOoOO00
  except :
   iii1IiI = xbmcgui . Dialog ( ) . yesno ( O0OOoOOO0oO , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if iii1IiI == 1 : pass
   if iii1IiI == 0 : O0Ooo000OO00 = 1 ; return
   if 27 - 27: iIii1I11I1II1 - II11iIiIIIiI
  I11I11I11IiIi = xbmc . translatePath ( os . path . join ( I1IIIii , 'Database.zip' ) )
  iIIIiIi1I1i ( Oo0oOOo , I11I11I11IiIi )
  if 73 - 73: o0o . oOo + oOo % oOo % O0
 if O0Ooo000OO00 == 1 :
  print "### Chose to exit restore function ###"
  return
  if 8 - 8: IIiIi1iI . O00OOo00oo0o - i1IIi % iii1i1iiiiIi / IIIIiiII111
 else :
  time . sleep ( 1 )
  O000o0 = open ( II11iiii1Ii , mode = 'r' )
  iIiiIiIIiI = O000o0 . read ( )
  O000o0 . close ( )
  if 13 - 13: oOo / ooo0O . oooOooOOo0OO . o0o
  if 31 - 31: oOoO0o00OO0
  print "### Checking zip file structure ###"
  oOO00 = zipfile . ZipFile ( i1iiii11I111I )
  if 'xbmc.log' in oOO00 . namelist ( ) or 'kodi.log' in oOO00 . namelist ( ) or '.git' in oOO00 . namelist ( ) or '.svn' in oOO00 . namelist ( ) :
   print "### Whoever created this build has used completely the wrong backup method, lets try and fix it! ###"
   OOooO0OOoo . ok ( 'Fixing Bad Zip' , 'Whoever created this build has used the wrong backup method, please wait while we fix it - this could take some time! Click OK to proceed' )
   OOo0oo0 = zipfile . ZipFile ( i1iiii11I111I , 'r' )
   i1I1I1 = os . path . join ( oOoOooOo0o0 , 'fixed.zip' )
   i11iI1111i = zipfile . ZipFile ( i1I1I1 , 'w' )
   if 42 - 42: oOo . II11iIiIIIiI + O0 / o0o % OoooooooOO
   iIii1 . create ( "Fixing Build" , "Checking " , '' , 'Please Wait' )
   if 19 - 19: iiii / O00OOo00oo0o
   for III1IIii1i in OOo0oo0 . infolist ( ) :
    buffer = OOo0oo0 . read ( III1IIii1i . filename )
    I1IIIi11 = str ( III1IIii1i . filename )
    if 2 - 2: oOo - iiii % iIii1I11I1II1
    if ( III1IIii1i . filename [ - 4 : ] != '.log' ) and not '.git' in I1IIIi11 and not '.svn' in I1IIIi11 :
     i11iI1111i . writestr ( III1IIii1i , buffer )
     iIii1 . update ( 0 , "Fixing..." , '[COLOR yellow]%s[/COLOR]' % III1IIii1i . filename , 'Please Wait' )
     if 88 - 88: oo0O0oO - iii1i1iiiiIi
   iIii1 . close ( )
   i11iI1111i . close ( )
   OOo0oo0 . close ( )
   i1iiii11I111I = i1I1I1
   if 79 - 79: IIiIi1iI
  iIii1 . create ( "Restoring Backup Build" , "Checking " , '' , 'Please Wait' )
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  if 45 - 45: II111iiii + IIiIi1iI . IIIIiiII111 . O0 * i1IIi - O00OOo00oo0o
  try :
   extract . all ( i1iiii11I111I , oOOoO0 , iIii1 )
  except :
   OOooO0OOoo . ok ( 'ERROR IN BUILD ZIP' , 'Please contact the build author, there are errors in this zip file that has caused the install process to fail. Most likely cause is it contains files with special characters in the name.' )
   return
   if 48 - 48: oooOooOOo0OO + oOo
  time . sleep ( 1 )
  if 76 - 76: oooOooOOo0OO
  if IiiO0O0O0OOO0o == 1 :
   extract . all ( I11I11I11IiIi , II , iIii1 )
   if 98 - 98: II111iiii + OoOoOO00 - oooOooOOo0OO . O00OOo00oo0o
   if iii1IiI != 1 :
    shutil . rmtree ( Oo0oOOo )
    if 51 - 51: O00OOo00oo0o + i11iIiiIii * iii1i1iiiiIi % oOo / OoOoOO00 - iIii1I11I1II1
  I1ioO000O0oO00 = open ( II11iiii1Ii , mode = 'w+' )
  I1ioO000O0oO00 . write ( iIiiIiIIiI )
  I1ioO000O0oO00 . close ( )
  try :
   os . rename ( O0o0Oo , Oo00OOOOO )
   if 25 - 25: IIIIiiII111 - ooo0O
  except :
   print "NO GUISETTINGS DOWNLOADED"
   if 4 - 4: oOo - O0 / IIIIiiII111 + O0 - II11iIiIIIiI * oOo
  time . sleep ( 1 )
  IiI1Iii1 = open ( Ii1iIiII1ii1 , mode = 'r' )
  iiiiI11ii = IiI1Iii1 . read ( )
  IiI1Iii1 . close ( )
  oooOo00 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( iiiiI11ii )
  I1i1ii1ii = oooOo00 [ 0 ] if ( len ( oooOo00 ) > 0 ) else ''
  iII1II = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( iiiiI11ii )
  i1ii = iII1II [ 0 ] if ( len ( iII1II ) > 0 ) else ''
  iiI111iIi1 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( iiiiI11ii )
  oOOOOO0 = iiI111iIi1 [ 0 ] if ( len ( iiI111iIi1 ) > 0 ) else ''
  if 25 - 25: OoOoOO00
  try :
   oo00ooOooO = open ( Oo00OOOOO , mode = 'r' )
   ooIi111iII = oo00ooOooO . read ( )
   oo00ooOooO . close ( )
   oOo0O0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooIi111iII )
   O0OO00OoO00 = oOo0O0 [ 0 ] if ( len ( oOo0O0 ) > 0 ) else ''
   iIi1iI = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooIi111iII )
   O00oIi11Iiii1iiii = iIi1iI [ 0 ] if ( len ( iIi1iI ) > 0 ) else ''
   iIIII1iII1i = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooIi111iII )
   i1IIII1111 = iIIII1iII1i [ 0 ] if ( len ( iIIII1iII1i ) > 0 ) else ''
   i1I1 = iiiiI11ii . replace ( I1i1ii1ii , O0OO00OoO00 ) . replace ( oOOOOO0 , i1IIII1111 ) . replace ( i1ii , O00oIi11Iiii1iiii )
   iIIiooO00O00oOO = open ( Ii1iIiII1ii1 , mode = 'w+' )
   iIIiooO00O00oOO . write ( str ( i1I1 ) )
   iIIiooO00O00oOO . close ( )
   if 64 - 64: II11iIiIIIiI
  except :
   print "NO GUISETTINGS DOWNLOADED"
   if 80 - 80: oOoO0o00OO0 % iIii1I11I1II1
  if os . path . exists ( O0o0Oo ) :
   os . remove ( O0o0Oo )
   if 63 - 63: i1IiiiI1iI * i11iIiiIii
  os . rename ( Ii1iIiII1ii1 , O0o0Oo )
  try :
   os . remove ( Oo00OOOOO )
   if 86 - 86: IIIIiiII111 % IIIIiiII111 - ooo0O + oo0O0oO / OoOoOO00 * OoooooooOO
  except :
   pass
   if 26 - 26: II111iiii * IIiIi1iI + oOoO0o00OO0 / O0 + i1IIi - IIIIiiII111
  os . makedirs ( ooOooo000oOO )
  time . sleep ( 1 )
  o0OoOo00O0o0O ( )
  if 56 - 56: o0o
  if 76 - 76: i1IIi % iIii1I11I1II1 - oOoO0o00OO0 + i1IiiiI1iI - IIIIiiII111
  if 81 - 81: oooOooOOo0OO + OoooooooOO - o0o * O0
  if 100 - 100: iIii1I11I1II1 - ooo0O
  if 28 - 28: oOo . O0 . IIIIiiII111
  if 60 - 60: II111iiii + oo0O0oO / II11iIiIIIiI % OoooooooOO - i1IIi
  if 57 - 57: iiii
  if 99 - 99: oOo + oo0O0oO % iiii - oOoO0o00OO0
  if 52 - 52: oooOooOOo0OO
  if 93 - 93: IIiIi1iI . i11iIiiIii
  if 24 - 24: o0o . iii1i1iiiiIi + oo0O0oO . II11iIiIIIiI - oooOooOOo0OO % IIiIi1iI
  if 49 - 49: O0 . oOo / O00OOo00oo0o
  if 29 - 29: oooOooOOo0OO / II11iIiIIIiI * O0 - i11iIiiIii - iii1i1iiiiIi + O00OOo00oo0o
  if 86 - 86: OoOoOO00 / oooOooOOo0OO * O00OOo00oo0o % i11iIiiIii
  if 20 - 20: IIiIi1iI . OoooooooOO + IIiIi1iI + iiii * oooOooOOo0OO
  if 44 - 44: i11iIiiIii
  if 69 - 69: o0o * O0 + i11iIiiIii
  if 65 - 65: O0 / IIiIi1iI . i1IIi * IIiIi1iI / iIii1I11I1II1 - II11iIiIIIiI
  if 93 - 93: ooo0O % i11iIiiIii - O00OOo00oo0o % iii1i1iiiiIi
def IiiiiIi11 ( ) :
 O0OOo ( )
 oOOo0OOOOOoO = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the guisettings zip file you want to restore' , 'files' , '.zip' , False , False , I1IIIii )
 if 69 - 69: O0 % IIiIi1iI . oOo + IIiIi1iI
 if oOOo0OOOOOoO == '' :
  return
  if 57 - 57: oooOooOOo0OO . oo0O0oO . i1IiiiI1iI . oOo % II11iIiIIIiI * oooOooOOo0OO
 else :
  ooooOo00O = 1
  IiIII ( oOOo0OOOOOoO , ooooOo00O )
  if 84 - 84: iiii . oooOooOOo0OO
  if 1 - 1: oOo * O0 . OoOoOO00 + iiii / ooo0O + IIIIiiII111
def oO0o0 ( name , url , video ) :
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option for first time install or if you\'re encountering any issues with your device. This will wipe all your Kodi settings, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if i1IiiI1iIi == 0 :
  return
  if 84 - 84: II11iIiIIIiI / oo0O0oO - OoooooooOO + iIii1I11I1II1
 elif i1IiiI1iIi == 1 :
  if 95 - 95: iii1i1iiiiIi - i1IiiiI1iI % oo0O0oO
  o0OoOo0O00 = '/storage/openelec_temp/'
  Ii1IiI1i1i = '/storage/.restore/'
  i1I1Iiii1 = os . path . join ( Ii1IiI1i1i , Iiiii ( ) + '.tar' )
  if not os . path . exists ( Ii1IiI1i1i ) :
   try :
    os . makedirs ( Ii1IiI1i1i )
   except :
    pass
  try :
   downloader . download ( url , i1I1Iiii1 )
   o0oo00oo0oO = True
  except :
   o0oo00oo0oO = False
  time . sleep ( 2 )
  if 85 - 85: IIIIiiII111 % IIIIiiII111 . O0
  if o0oo00oo0oO == True :
   if 40 - 40: iii1i1iiiiIi * ooo0O * iIii1I11I1II1 / ooo0O * OoooooooOO / oooOooOOo0OO
   try :
    IiI1Iii1 = open ( OOO00 , mode = 'r' )
    iiiiI11ii = IiI1Iii1 . read ( )
    IiI1Iii1 . close ( )
    if 33 - 33: i11iIiiIii % oOoO0o00OO0 . IIiIi1iI * o0o / IIIIiiII111
    iiII1 = re . compile ( 'id="(.+?)"' ) . findall ( iiiiI11ii )
    o00o0 = iiII1 [ 0 ] if ( len ( iiII1 ) > 0 ) else ''
    if 25 - 25: iii1i1iiiiIi
   except :
    pass
   if o00o0 != '' :
    Ii1I11I = 'http://noobsandnerds.com/TI/Community_Builds/downloadcount.php?id=%s' % ( o00o0 )
   try :
    iIIii ( Ii1I11I )
   except :
    pass
    if 39 - 39: O00OOo00oo0o * ooo0O + oOo . o0o - O0 * oooOooOOo0OO
    if 98 - 98: i1IiiiI1iI * IIiIi1iI . OoooooooOO . O0
   if not os . path . exists ( o0OoOo0O00 ) :
    try :
     os . makedirs ( o0OoOo0O00 )
    except :
     pass
     if 89 - 89: IIiIi1iI / O0 % OoooooooOO - O0 . iii1i1iiiiIi
   OOooO0OOoo . ok ( "Download Complete - Press OK To Reboot" , 'Once you press OK your device will attempt to reboot, if it hasn\'t rebooted within 30 seconds please pull the power to manually shutdown. When booting you may see lines of text, don\'t worry this is normal update behaviour!' )
   xbmc . executebuiltin ( 'Reboot' )
   if 32 - 32: iiii
   if 26 - 26: O0 * O00OOo00oo0o - OoOoOO00 - IIiIi1iI / iIii1I11I1II1
def oO0Ooo00O ( ) :
 O0Ooo000OO00 = 0
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option if you\'re encountering any issues with your device. This will wipe all your Kodi settings and restore with whatever is in the backup, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if i1IiiI1iIi == 0 :
  return
  if 74 - 74: oOoO0o00OO0 % ooo0O . IIiIi1iI % oo0O0oO . O0 % II111iiii
 elif i1IiiI1iIi == 1 :
  i1iiii11I111I = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.tar' , False , False , o00OO00OoO )
  if i1iiii11I111I == '' :
   O0Ooo000OO00 = 1
   if 5 - 5: II11iIiIIIiI - OoooooooOO / ooo0O
  if O0Ooo000OO00 == 1 :
   print "### No file selected, quitting restore process ###"
   return
  i1I1Iiii1 = os . path . join ( OOOO0OOoO0O0 , Iiiii ( ) + '.tar' )
  if not os . path . exists ( OOOO0OOoO0O0 ) :
   try :
    os . makedirs ( OOOO0OOoO0O0 )
   except :
    pass
  iIii1 . create ( 'Copying File To Restore Folder' , '' , 'Please wait...' )
  shutil . copyfile ( i1iiii11I111I , i1I1Iiii1 )
  xbmc . executebuiltin ( 'Reboot' )
  if 30 - 30: IIIIiiII111 % oOoO0o00OO0 + i1IIi * OoooooooOO * iii1i1iiiiIi - II111iiii
  if 55 - 55: iii1i1iiiiIi
def I111II1ii11I1 ( ) :
 o0i1I11iI1iiI ( )
 if IiiI1III1I1 ( ) :
  o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Restore a locally stored OpenELEC Backup[/COLOR]' , '' , 'restore_local_OE' , '' , '' , '' , 'Restore A Full OE System Backup' )
  if 41 - 41: i11iIiiIii
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Restore A Locally stored build[/COLOR]' , 'local' , 'restore_local_CB' , '' , '' , '' , 'Restore A Full System Backup' )
 o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Restore Local guisettings file[/COLOR]' , 'url' , 'LocalGUIDialog' , '' , '' , '' , 'Back Up Your Full System' )
 if 34 - 34: II111iiii + oOo . II11iIiIIIiI
 if os . path . exists ( os . path . join ( I1IIIii , 'addons.zip' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Your Addons' , 'addons' , 'restore_zip' , '' , '' , '' , 'Restore Your Addons' )
  if 36 - 36: i1IIi + IIiIi1iI / oooOooOOo0OO
 if os . path . exists ( os . path . join ( I1IIIii , 'addon_data.zip' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Your Addon UserData' , 'addon_data' , 'restore_zip' , '' , '' , '' , 'Restore Your Addon UserData' )
  if 55 - 55: iIii1I11I1II1 % ooo0O
 if os . path . exists ( os . path . join ( I1IIIii , 'guisettings.xml' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Guisettings.xml' , O0o0Oo , 'resore_backup' , '' , '' , '' , 'Restore Your guisettings.xml' )
  if 70 - 70: II11iIiIIIiI - O0 * iIii1I11I1II1 . oo0O0oO % O0
 if os . path . exists ( os . path . join ( I1IIIii , 'favourites.xml' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Favourites.xml' , iIi1ii1I1 , 'resore_backup' , '' , '' , '' , 'Restore Your favourites.xml' )
  if 99 - 99: OoOoOO00
 if os . path . exists ( os . path . join ( I1IIIii , 'sources.xml' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Source.xml' , o0 , 'resore_backup' , '' , '' , '' , 'Restore Your sources.xml' )
  if 30 - 30: O0 % OoooooooOO % IIIIiiII111 . i1IIi + oo0O0oO % o0o
 if os . path . exists ( os . path . join ( I1IIIii , 'advancedsettings.xml' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Advancedsettings.xml' , I11II1i , 'resore_backup' , '' , '' , '' , 'Restore Your advancedsettings.xml' )
  if 9 - 9: O0 . iIii1I11I1II1
 if os . path . exists ( os . path . join ( I1IIIii , 'keyboard.xml' ) ) :
  o0oOO000oO0oo ( '' , 'Restore Advancedsettings.xml' , IIiiiiiiIi1I1 , 'resore_backup' , '' , '' , '' , 'Restore Your keyboard.xml' )
  if 44 - 44: oooOooOOo0OO % i1IiiiI1iI
 if os . path . exists ( os . path . join ( I1IIIii , 'RssFeeds.xml' ) ) :
  o0oOO000oO0oo ( '' , 'Restore RssFeeds.xml' , ooooooO0oo , 'resore_backup' , '' , '' , '' , 'Restore Your RssFeeds.xml' )
  if 6 - 6: iii1i1iiiiIi
  if 82 - 82: iIii1I11I1II1 . IIIIiiII111 / i1IiiiI1iI / o0o * II111iiii % II11iIiIIIiI
def o0O00 ( url ) :
 O0OOo ( )
 if 'addons' in url :
  o00OOoo0 = xbmc . translatePath ( os . path . join ( I1IIIii , 'addons.zip' ) )
  i1I11i = OooO0
  if 70 - 70: OoOoOO00 . i1IiiiI1iI * oOoO0o00OO0 + o0o
 else :
  o00OOoo0 = xbmc . translatePath ( os . path . join ( I1IIIii , 'addon_data.zip' ) )
  i1I11i = iiI1IiI
  if 77 - 77: oOoO0o00OO0
 if 'Backup' in O0OOoOOO0oO :
  ooO ( )
  iIii1 . create ( "Creating Backup" , "Backing Up" , '' , 'Please Wait' )
  Ii1II11II1iii = zipfile . ZipFile ( o00OOoo0 , 'w' , zipfile . ZIP_DEFLATED )
  o0oOO0ooOoO = len ( i1I11i )
  ooO0000o00O = [ ]
  O0Ooo = [ ]
  for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( i1I11i ) :
   for file in Oo0o :
    O0Ooo . append ( file )
  Ooo0oO0 = len ( O0Ooo )
  for o0iIiiIiiIi , i1iiIIIi , Oo0o in os . walk ( i1I11i ) :
   for file in Oo0o :
    ooO0000o00O . append ( file )
    ii1I1I111 = len ( ooO0000o00O ) / float ( Ooo0oO0 ) * 100
    iIii1 . update ( int ( ii1I1I111 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
    Ii1Ii = os . path . join ( o0iIiiIiiIi , file )
    if not 'temp' in i1iiIIIi :
     if not IiII1IiiIiI1 in i1iiIIIi :
      import time
      iIiIii1I1II = '01/01/1980'
      O0Oooo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ii1Ii ) ) )
      if O0Oooo > iIiIii1I1II :
       Ii1II11II1iii . write ( Ii1Ii , Ii1Ii [ o0oOO0ooOoO : ] )
  Ii1II11II1iii . close ( )
  iIii1 . close ( )
  OOooO0OOoo . ok ( "Backup Complete" , "You Are Now Backed Up" , '' , '' )
  if 63 - 63: iiii * II11iIiIIIiI + iiii * O00OOo00oo0o + oOo / oooOooOOo0OO
 else :
  iIii1 . create ( "Extracting Zip" , "Checking " , '' , 'Please Wait' )
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( o00OOoo0 , i1I11i , iIii1 )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 15 - 15: O0 . oooOooOOo0OO * oooOooOOo0OO
  if 'Backup' in O0OOoOOO0oO :
   OOooO0OOoo . ok ( "Install Complete" , 'Kodi will now close. Just re-open Kodi and wait for all the updates to complete.' )
   o0OoOo00O0o0O ( )
   if 65 - 65: oo0O0oO + O0 % oOoO0o00OO0
  else :
   OOooO0OOoo . ok ( "SUCCESS!" , "You Are Now Restored" , '' , '' )
   if 72 - 72: o0o . ooo0O / II111iiii
   if 69 - 69: o0o * II111iiii - iiii - i1IIi + i11iIiiIii
def iiiiI1iiIi1i ( url ) :
 xbmc . executebuiltin ( 'RunAddon(' + url + ')' )
 if 11 - 11: O0 / oo0O0oO / iIii1I11I1II1 % O00OOo00oo0o
 if 31 - 31: IIIIiiII111 . i11iIiiIii . iii1i1iiiiIi * oOo % O00OOo00oo0o . oOoO0o00OO0
def iiIIii ( title ) :
 Oo0oi1i = ''
 iiIIi1II = xbmc . Keyboard ( Oo0oi1i , title )
 iiIIi1II . doModal ( )
 if iiIIi1II . isConfirmed ( ) :
  Oo0oi1i = iiIIi1II . getText ( ) . replace ( ' ' , '%20' )
  if Oo0oi1i == None :
   return False
 return Oo0oi1i
 if 68 - 68: ooo0O * iiii % iiii - i1IiiiI1iI + O0 * oooOooOOo0OO
 if 60 - 60: i11iIiiIii / i1IIi * o0o
def OoOOoOOoOoOo ( url ) :
 II1IIiIiiI1iI = oo00o0OoO ( heading = "Search for add-ons" )
 if 35 - 35: IIIIiiII111
 if ( not II1IIiIiiI1iI ) : return False , 0
 if 56 - 56: iiii + O0
 if 80 - 80: oOo / O00OOo00oo0o * oo0O0oO - o0o % oooOooOOo0OO
 OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
 url += OOOOO0o0OOo
 O0OoO0oooOO ( url )
 if 44 - 44: i1IIi - oooOooOOo0OO + oooOooOOo0OO . IIIIiiII111 / o0o
 if 48 - 48: oooOooOOo0OO . O0 . OoOoOO00 * oOoO0o00OO0 / IIiIi1iI
def oO0OO00o ( url ) :
 II1IIiIiiI1iI = oo00o0OoO ( heading = "Search for content" )
 if 97 - 97: O0 . oOoO0o00OO0
 if 17 - 17: O0 . II11iIiIIIiI - II11iIiIIIiI - i1IIi * o0o
 if ( not II1IIiIiiI1iI ) : return False , 0
 if 16 - 16: ooo0O / II111iiii
 if 22 - 22: IIIIiiII111
 OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
 url += OOOOO0o0OOo
 OoOiII11IiIi ( url )
 if 53 - 53: iii1i1iiiiIi
 if 96 - 96: OoooooooOO - iIii1I11I1II1 . II11iIiIIIiI
def ii11iI1i1i1i1i ( url ) :
 oo = 'http://noobsandnerds.com/TI/Community_Builds/community_builds.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 Oo0oOOOOo = re . compile ( 'author="(.+?)"' ) . findall ( I1111i )
 IIo0Oo0oO0oOO00 = re . compile ( 'version="(.+?)"' ) . findall ( I1111i )
 O0OOoOOO0oO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 i11o00Ooo = Oo0oOOOOo [ 0 ] if ( len ( Oo0oOOOOo ) > 0 ) else ''
 Ii1i1iI = IIo0Oo0oO0oOO00 [ 0 ] if ( len ( IIo0Oo0oO0oOO00 ) > 0 ) else ''
 OOooO0OOoo . ok ( O0OOoOOO0oO , 'Author: [COLOR=dodgerblue]' + i11o00Ooo + '[/COLOR]      Latest Version: [COLOR=dodgerblue]' + Ii1i1iI + '[/COLOR]' , '' , 'Click OK to view the build page.' )
 try :
  ii111I11Ii ( url + '&visibility=homepage' , url )
 except :
  return
  print "### Could not find build No. " + url
  OOooO0OOoo . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private. Please try manually searching via the Community Builds section' )
  if 10 - 10: II111iiii . o0o / IIiIi1iI
  if 35 - 35: IIiIi1iI / oOo + O0 * iIii1I11I1II1 - O0
def iI111III1 ( url ) :
 OOooO0OOoo . ok ( "This build is not complete" , 'The guisettings.xml file was not copied over during the last install process. Click OK to go to the build page and complete Install Step 2 (guisettings fix).' )
 if 16 - 16: iIii1I11I1II1 - II111iiii % IIIIiiII111 * O0 % oOo
 try :
  ii111I11Ii ( url + '&visibility=homepage' , url )
  if 17 - 17: i1IIi % ooo0O . oOo - oooOooOOo0OO
 except :
  return
  print "### Could not find build No. " + url
  OOooO0OOoo . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private. Please try manually searching via the Community Builds section' )
  if 37 - 37: oo0O0oO * O00OOo00oo0o + oOo * oo0O0oO % oOoO0o00OO0 . oOo
  if 37 - 37: O00OOo00oo0o / II111iiii
def o00OooO ( ) :
 oo = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( O0oo0OO0 , I1i1iiI1 )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIiii1 = re . compile ( 'posts="(.+?)"' ) . findall ( I1111i )
 iiIII1ii1 = re . compile ( 'messages="(.+?)"' ) . findall ( I1111i )
 OOO00O00ooo0o = re . compile ( 'unread="(.+?)"' ) . findall ( I1111i )
 OoOoo = re . compile ( 'email="(.+?)"' ) . findall ( I1111i )
 O0oOoOooo00oo = iiIII1ii1 [ 0 ] if ( len ( iiIII1ii1 ) > 0 ) else ''
 OOO0OO00 = OOO00O00ooo0o [ 0 ] if ( len ( OOO00O00ooo0o ) > 0 ) else ''
 oOO00II1IiII1I1II = OoOoo [ 0 ] if ( len ( OoOoo ) > 0 ) else ''
 oooOII111iiI1Ii1 = IIiii1 [ 0 ] if ( len ( IIiii1 ) > 0 ) else ''
 OOooO0OOoo . ok ( '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' , 'Username:  ' + O0oo0OO0 , 'Email: ' + oOO00II1IiII1I1II , 'Unread Messages: ' + OOO0OO00 + '/' + O0oOoOooo00oo + '[CR]Posts: ' + oooOII111iiI1Ii1 )
 if 58 - 58: OoooooooOO * i1IIi * ooo0O
 if 99 - 99: oOo
def oO0o000oOO ( url , type ) :
 if type == 'communitybuilds' :
  OO0o0 = 'grab_builds'
  if url . endswith ( "visibility=premium" ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=premium' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=reseller_private" ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=reseller_private' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=public" ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=public' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=private" ) :
   o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=private' , 'manual_search' , '' , '' , '' , '' )
 if type == 'tutorials' :
  OO0o0 = 'grab_tutorials'
 if type == 'hardware' :
  OO0o0 = 'grab_hardware'
 if type == 'addons' :
  OO0o0 = 'grab_addons'
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloads&orderx=DESC' , OO0o0 , '' , '' , '' , '' )
 if type == 'hardware' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=lime]Filter Results[/COLOR]' , url , 'hardware_filter_menu' , '' , '' , '' , '' )
 if type != 'addons' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloadcount&orderx=DESC' , OO0o0 , '' , '' , '' , '' )
 if type == 'tutorials' or type == 'hardware' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=Added&orderx=DESC' , OO0o0 , '' , '' , '' , '' )
 else :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=created&orderx=DESC' , OO0o0 , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Recently Updated[/COLOR]' , str ( url ) + '&sortx=updated&orderx=DESC' , OO0o0 , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by A-Z[/COLOR]' , str ( url ) + '&sortx=name&orderx=ASC' , OO0o0 , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Z-A[/COLOR]' , str ( url ) + '&sortx=name&orderx=DESC' , OO0o0 , '' , '' , '' , '' )
 if type == 'public_CB' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Genre[/COLOR]' , url , 'genres' , '' , '' , '' , '' )
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue]Sort by Country/Language[/COLOR]' , url , 'countries' , '' , '' , '' , '' )
  if 96 - 96: i1IIi - oo0O0oO * OoOoOO00 % OoOoOO00
  if 31 - 31: oooOooOOo0OO . O00OOo00oo0o / iiii / i11iIiiIii % oOoO0o00OO0
def o00ooOOo0ooO0 ( ) :
 i1iiIII1IIiIIII ( 'Speed Test Instructions' , '[COLOR=blue][B]What file should I use: [/B][/COLOR][CR]This function will download a file and will work out your speed based on how long it took to download. You will then be notified of '
 'what quality streams you can expect to stream without buffering. You can choose to download a 10MB, 16MB, 32MB, 64MB or 128MB file to use with the test. Using the larger files will give you a better '
 'indication of how reliable your speeds are but obviously if you have a limited amount of bandwidth allowance you may want to opt for a smaller file.'
 '[CR][CR][COLOR=blue][B]How accurate is this speed test:[/B][/COLOR][CR]Not very accurate at all! As this test is based on downloading a file from a server it\'s reliant on the server not having a go-slow day '
 'but the servers used should be pretty reliable. The 10MB file is hosted on a different server to the others so if you\'re not getting the results expected please try another file. If you have a fast fiber '
 'connection the chances are your speed will show as considerably slower than your real download speed due to the server not being able to send the file as fast as your download speed allows. Essentially the '
 'test results will be limited by the speed of the server but you will at least be able to see if it\'s your connection that\'s causing buffering or if it\'s the host you\'re trying to stream from'
 '[CR][CR][COLOR=blue][B]What is the differnce between Live Streams and Online Video:[/COLOR][/B][CR]When you run the test you\'ll see results based on your speeds and these let you know the quality you should expect to '
 'be able stream with your connection. Live Streams as the title suggests are like traditional TV channels, they are being streamed live so for example if you wanted to watch CNN this would fall into this category. '
 'Online Videos relates to movies, tv shows, youtube clips etc. Basically anything that isn\'t live - if you\'re new to the world of streaming then think of it as On Demand content, this is content that\'s been recorded and stored on the web.'
 '[CR][CR][COLOR=blue][B]Why am I still getting buffering:[/COLOR][/B][CR]The results you get from this test are strictly based on your download speed, there are many other factors that can cause buffering and contrary to popular belief '
 'having a massively fast internet connection will not make any difference to your buffering issues if the server you\'re trying to get the content from is unable to send it fast enough. This can often happen and is usually '
 'down to heavy traffic (too many users accessing the same server). A 10 Mb/s connection should be plenty fast enough for almost all content as it\'s very rare a server can send it any quicker than that.'
 '[CR][CR][COLOR=blue][B]What\'s the difference between MB/s and Mb/s:[/COLOR][/B][CR]A lot of people think the speed they see advertised by their ISP is Megabytes (MB/S) per second - this is not true. Speeds are usually shown as Mb/s '
 'which is Megabit per second - there are 8 of these to a megabyte so if you want to work out how many megabytes per second you\'re getting you need to divide the speed by 8. It may sound sneaky but really it\'s just the unit that has always been used.'
 '[CR][CR]A direct link to the buffering thread explaining what you can do to improve your viewing experience can be found at [COLOR=yellow]http://bit.ly/bufferingfix[/COLOR]'
 '[CR][CR]Thank you, [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Team.' )
 if 28 - 28: oo0O0oO + II111iiii % o0o * i11iIiiIii % II11iIiIIIiI + OoooooooOO
def OOOoOOOOooOo0 ( ) :
 o0oOO000oO0oo ( '' , '[COLOR=blue]Instructions - Read me first[/COLOR]' , 'none' , 'speed_instructions' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Download 16MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/16MB.txt' , 'runtest' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Download 32MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/32MB.txt' , 'runtest' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Download 64MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/64MB.txt' , 'runtest' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Download 128MB file - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/128MB.txt' , 'runtest' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Download 10MB file   - [COLOR=yellow]Server 2[/COLOR]' , 'http://www.wswd.net/testdownloadfiles/10MB.zip' , 'runtest' , '' , '' , '' , '' )
 if 65 - 65: O00OOo00oo0o
 if 71 - 71: oo0O0oO % oo0O0oO . II11iIiIIIiI + i11iIiiIii - i11iIiiIii
def i1iiIII1IIiIIII ( heading , anounce ) :
 class Iiii ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try :
    ooOo0O0o0 = open ( anounce ) ; OooO00 = ooOo0O0o0 . read ( )
   except :
    OooO00 = anounce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( OooO00 ) )
   return
 Iiii ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(10147)' ) :
  xbmc . sleep ( 500 )
  if 53 - 53: iiii . OoooooooOO * II11iIiIIIiI / oOo
  if 16 - 16: IIIIiiII111 / OoooooooOO - i1IiiiI1iI % OoOoOO00 % IIIIiiII111
def oOoooO0O0oOO ( url ) :
 try :
  i1111ii , OooO00 = url . split ( '|' )
  i1iiIII1IIiIIII ( i1111ii , OooO00 )
 except :
  i1iiIII1IIiIIII ( '' , url )
  if 43 - 43: ooo0O * i11iIiiIii . i11iIiiIii * OoooooooOO
  if 61 - 61: oOoO0o00OO0 . i1IiiiI1iI . O0 + OoooooooOO + O0
def Iiiii ( ) :
 Oo00Ooo0O0O0o = time . time ( )
 Oo0oo0o = time . localtime ( Oo00Ooo0O0O0o )
 return time . strftime ( '%Y%m%d%H%M%S' , Oo0oo0o )
 if 70 - 70: iiii
 if 92 - 92: O00OOo00oo0o - iiii / iiii + i1IiiiI1iI
def O00o0OO0O ( ) :
 o0oOO000oO0oo ( '' , '[COLOR=gold]CLEAN MY KODI FOLDERS (Save Space)[/COLOR]' , '' , 'full_clean' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword Install' , '' , 'nan_menu' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , '[COLOR=darkcyan][Noobs][/COLOR] Community Portal Folder Check' , 'url' , 'check_storage' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan][Noobs][/COLOR] Test My Download Speed' , 'none' , 'speedtest_menu' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=darkcyan][Noobs][/COLOR] Backup/Restore My Content' , 'none' , 'backup_restore' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Nerds][/COLOR] Advanced Options' , '' , 'advanced_tools' , '' , '' , '' , '' )
 if IiiI1III1I1 ( ) :
  o0oOO000oO0oo ( '' , '[COLOR=dodgerblue]Wi-Fi / OpenELEC Settings[/COLOR]' , '' , 'openelec_settings' , '' , '' , '' , '' )
  if 100 - 100: oo0O0oO - i1IIi
  if 90 - 90: O00OOo00oo0o + II11iIiIIIiI . II111iiii - ooo0O % iIii1I11I1II1
def i111I ( ) :
 o0oOO000oO0oo ( '' , 'Check For Special Characters In Filenames' , '' , 'ASCII_Check' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Check My IP Address' , 'none' , 'ipcheck' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Check XBMC/Kodi Version' , 'none' , 'xbmcversion' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Clear All Cache Folders' , 'url' , 'clear_cache' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Clear Cached Artwork (thumbnails & textures)' , 'none' , 'remove_textures' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Clear Packages Folder' , 'url' , 'remove_packages' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Completely remove an add-on (inc. passwords)' , 'plugin' , 'addon_removal_menu' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Convert Physical Paths To Special' , oOOoO0 , 'fix_special' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Delete Addon_Data' , 'url' , 'remove_addon_data' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Delete Old Builds/Zips From Device' , 'url' , 'remove_build' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Delete Old Crash Logs' , 'url' , 'remove_crash_logs' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Force Close Kodi' , 'url' , 'kill_xbmc' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Make Add-ons Gotham/Helix Compatible' , 'none' , 'gotham' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Make Skins Kodi (Helix) Compatible' , 'none' , 'helix' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Passwords - Hide when typing in' , 'none' , 'hide_passwords' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Passwords - Unhide when typing in' , 'none' , 'unhide_passwords' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Update My Add-ons (Force Refresh)' , 'none' , 'update' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Upload Log' , 'none' , 'uploadlog' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'View My Log' , 'none' , 'log' , '' , '' , '' , '' )
 o0oOO000oO0oo ( '' , 'Wipe My Install (Fresh Start)' , 'none' , 'wipe_xbmc' , '' , '' , '' , '' )
 if 33 - 33: o0o
 if 22 - 22: O0 + o0o % i1IIi
def oo00oo ( url ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]1. Add-on Maintenance[/COLOR]' , str ( url ) + '&type=Maintenance' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Audio Add-ons' , str ( url ) + '&type=Audio' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Picture Add-ons' , str ( url ) + '&type=Pictures' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Program Add-ons' , str ( url ) + '&type=Programs' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , 'Video Add-ons' , str ( url ) + '&type=Video' , 'grab_tutorials' , '' , '' , '' , '' )
 if 57 - 57: o0o * iii1i1iiiiIi + O0 % oo0O0oO - OoOoOO00
 if 43 - 43: oo0O0oO
def IiiIIiIii ( url ) :
 Ii1I11I = 'http://noobsandnerds.com/TI/TutorialPortal/downloadcount.php?id=%s' % ( url )
 try :
  iIIii ( Ii1I11I )
 except :
  pass
 oo = 'http://noobsandnerds.com/TI/TutorialPortal/tutorialdetails.php?id=%s' % ( url )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iI = re . compile ( 'name="(.+?)"' ) . findall ( I1111i )
 Oo0oOOOOo = re . compile ( 'author="(.+?)"' ) . findall ( I1111i )
 ii1IIii = re . compile ( 'video_guide1="(.+?)"' ) . findall ( I1111i )
 IiI11i1I11111 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( I1111i )
 Ii1IIIIIIiI1 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( I1111i )
 Ii11IiIiiii1 = re . compile ( 'video_guide4="(.+?)"' ) . findall ( I1111i )
 OooO0O0Ooo = re . compile ( 'video_guide5="(.+?)"' ) . findall ( I1111i )
 oO0OIIIiIi1iiI = re . compile ( 'video_label1="(.+?)"' ) . findall ( I1111i )
 iI1 = re . compile ( 'video_label2="(.+?)"' ) . findall ( I1111i )
 o0Iiii = re . compile ( 'video_label3="(.+?)"' ) . findall ( I1111i )
 I1i1I = re . compile ( 'video_label4="(.+?)"' ) . findall ( I1111i )
 i1111iI1 = re . compile ( 'video_label5="(.+?)"' ) . findall ( I1111i )
 iiIooo0O0O0OO = re . compile ( 'about="(.+?)"' ) . findall ( I1111i )
 oOooOOoO = re . compile ( 'step1="(.+?)"' ) . findall ( I1111i )
 o0o000OOO = re . compile ( 'step2="(.+?)"' ) . findall ( I1111i )
 I1111iii1ii11 = re . compile ( 'step3="(.+?)"' ) . findall ( I1111i )
 Oooo = re . compile ( 'step4="(.+?)"' ) . findall ( I1111i )
 III1II1I1iI = re . compile ( 'step5="(.+?)"' ) . findall ( I1111i )
 oOOOOOo0OO0o0oOO0 = re . compile ( 'step6="(.+?)"' ) . findall ( I1111i )
 i1II1IiIIi = re . compile ( 'step7="(.+?)"' ) . findall ( I1111i )
 o0O0 = re . compile ( 'step8="(.+?)"' ) . findall ( I1111i )
 iiIi1I1IIIII1IIi = re . compile ( 'step9="(.+?)"' ) . findall ( I1111i )
 i11iii1II1I1 = re . compile ( 'step10="(.+?)"' ) . findall ( I1111i )
 IiIi11iI1IIi = re . compile ( 'step11="(.+?)"' ) . findall ( I1111i )
 iII111I = re . compile ( 'step12="(.+?)"' ) . findall ( I1111i )
 Ooooo0Oo0oOo = re . compile ( 'step13="(.+?)"' ) . findall ( I1111i )
 IiI1III1 = re . compile ( 'step14="(.+?)"' ) . findall ( I1111i )
 iiiiII1i1Iii1I1 = re . compile ( 'step15="(.+?)"' ) . findall ( I1111i )
 IiI1I11ii = re . compile ( 'screenshot1="(.+?)"' ) . findall ( I1111i )
 oO0O00oO0o0 = re . compile ( 'screenshot2="(.+?)"' ) . findall ( I1111i )
 o0oOo = re . compile ( 'screenshot3="(.+?)"' ) . findall ( I1111i )
 O0OoOo0oO0o = re . compile ( 'screenshot4="(.+?)"' ) . findall ( I1111i )
 I11iIi1i1IIi = re . compile ( 'screenshot5="(.+?)"' ) . findall ( I1111i )
 II11I = re . compile ( 'screenshot6="(.+?)"' ) . findall ( I1111i )
 OOooo00oo = re . compile ( 'screenshot7="(.+?)"' ) . findall ( I1111i )
 i1iiIi1IiiiI = re . compile ( 'screenshot8="(.+?)"' ) . findall ( I1111i )
 OO0oooOO = re . compile ( 'screenshot9="(.+?)"' ) . findall ( I1111i )
 III = re . compile ( 'screenshot10="(.+?)"' ) . findall ( I1111i )
 i1iiIIiiiI = re . compile ( 'screenshot11="(.+?)"' ) . findall ( I1111i )
 I1IIiIi1iI = re . compile ( 'screenshot12="(.+?)"' ) . findall ( I1111i )
 oOo0Iiii11 = re . compile ( 'screenshot13="(.+?)"' ) . findall ( I1111i )
 o00000O = re . compile ( 'screenshot14="(.+?)"' ) . findall ( I1111i )
 OoOO00OO0 = re . compile ( 'screenshot15="(.+?)"' ) . findall ( I1111i )
 if 93 - 93: II111iiii * II111iiii + OoOoOO00 / oOo
 O0OOoOOO0oO = i1iI [ 0 ] if ( len ( i1iI ) > 0 ) else ''
 i11o00Ooo = Oo0oOOOOo [ 0 ] if ( len ( Oo0oOOOOo ) > 0 ) else ''
 I1I = ii1IIii [ 0 ] if ( len ( ii1IIii ) > 0 ) else 'None'
 ooooo = IiI11i1I11111 [ 0 ] if ( len ( IiI11i1I11111 ) > 0 ) else 'None'
 i11IIIiI1I = Ii1IIIIIIiI1 [ 0 ] if ( len ( Ii1IIIIIIiI1 ) > 0 ) else 'None'
 o0iiiI1I1iIIIi1 = Ii11IiIiiii1 [ 0 ] if ( len ( Ii11IiIiiii1 ) > 0 ) else 'None'
 Iii = OooO0O0Ooo [ 0 ] if ( len ( OooO0O0Ooo ) > 0 ) else 'None'
 O0Oo0o000oO = oO0OIIIiIi1iiI [ 0 ] if ( len ( oO0OIIIiIi1iiI ) > 0 ) else 'None'
 oO0o00oOOooO0 = iI1 [ 0 ] if ( len ( iI1 ) > 0 ) else 'None'
 OOOoO000 = o0Iiii [ 0 ] if ( len ( o0Iiii ) > 0 ) else 'None'
 oOOOO = I1i1I [ 0 ] if ( len ( I1i1I ) > 0 ) else 'None'
 IiIi1ii111i1 = i1111iI1 [ 0 ] if ( len ( i1111iI1 ) > 0 ) else 'None'
 oOoo00 = iiIooo0O0O0OO [ 0 ] if ( len ( iiIooo0O0O0OO ) > 0 ) else ''
 iI1ii1i1 = '[CR][CR][COLOR=dodgerblue]Step 1:[/COLOR][CR]' + oOooOOoO [ 0 ] if ( len ( oOooOOoO ) > 0 ) else ''
 IIiI = '[CR][CR][COLOR=dodgerblue]Step 2:[/COLOR][CR]' + o0o000OOO [ 0 ] if ( len ( o0o000OOO ) > 0 ) else ''
 oOOO = '[CR][CR][COLOR=dodgerblue]Step 3:[/COLOR][CR]' + I1111iii1ii11 [ 0 ] if ( len ( I1111iii1ii11 ) > 0 ) else ''
 O00o00 = '[CR][CR][COLOR=dodgerblue]Step 4:[/COLOR][CR]' + Oooo [ 0 ] if ( len ( Oooo ) > 0 ) else ''
 OOo00o0oOO0o = '[CR][CR][COLOR=dodgerblue]Step 5:[/COLOR][CR]' + III1II1I1iI [ 0 ] if ( len ( III1II1I1iI ) > 0 ) else ''
 I1ii1 = '[CR][CR][COLOR=dodgerblue]Step 6:[/COLOR][CR]' + oOOOOOo0OO0o0oOO0 [ 0 ] if ( len ( oOOOOOo0OO0o0oOO0 ) > 0 ) else ''
 O0Oi111 = '[CR][CR][COLOR=dodgerblue]Step 7:[/COLOR][CR]' + i1II1IiIIi [ 0 ] if ( len ( i1II1IiIIi ) > 0 ) else ''
 o0OiI1 = '[CR][CR][COLOR=dodgerblue]Step 8:[/COLOR][CR]' + o0O0 [ 0 ] if ( len ( o0O0 ) > 0 ) else ''
 IiiI = '[CR][CR][COLOR=dodgerblue]Step 9:[/COLOR][CR]' + iiIi1I1IIIII1IIi [ 0 ] if ( len ( iiIi1I1IIIII1IIi ) > 0 ) else ''
 III1i1iII1 = '[CR][CR][COLOR=dodgerblue]Step 10:[/COLOR][CR]' + i11iii1II1I1 [ 0 ] if ( len ( i11iii1II1I1 ) > 0 ) else ''
 IiiiiI11iii11iI = '[CR][CR][COLOR=dodgerblue]Step 11:[/COLOR][CR]' + IiIi11iI1IIi [ 0 ] if ( len ( IiIi11iI1IIi ) > 0 ) else ''
 I111iIii1i1 = '[CR][CR][COLOR=dodgerblue]Step 12:[/COLOR][CR]' + iII111I [ 0 ] if ( len ( iII111I ) > 0 ) else ''
 I1i1I1i1I1 = '[CR][CR][COLOR=dodgerblue]Step 13:[/COLOR][CR]' + Ooooo0Oo0oOo [ 0 ] if ( len ( Ooooo0Oo0oOo ) > 0 ) else ''
 i1IOO = '[CR][CR][COLOR=dodgerblue]Step 14:[/COLOR][CR]' + IiI1III1 [ 0 ] if ( len ( IiI1III1 ) > 0 ) else ''
 Oo0OO0ooO0O0O = '[CR][CR][COLOR=dodgerblue]Step 15:[/COLOR][CR]' + iiiiII1i1Iii1I1 [ 0 ] if ( len ( iiiiII1i1Iii1I1 ) > 0 ) else ''
 Ii11IIIii11 = IiI1I11ii [ 0 ] if ( len ( IiI1I11ii ) > 0 ) else ''
 O0oo = oO0O00oO0o0 [ 0 ] if ( len ( oO0O00oO0o0 ) > 0 ) else ''
 i1ii1i1i1 = o0oOo [ 0 ] if ( len ( o0oOo ) > 0 ) else ''
 oOOoo0II1 = O0OoOo0oO0o [ 0 ] if ( len ( O0OoOo0oO0o ) > 0 ) else ''
 OOO = I11iIi1i1IIi [ 0 ] if ( len ( I11iIi1i1IIi ) > 0 ) else ''
 iiIII1I11iii = II11I [ 0 ] if ( len ( II11I ) > 0 ) else ''
 ooIii = OOooo00oo [ 0 ] if ( len ( OOooo00oo ) > 0 ) else ''
 o0OO00oOOO0o0 = i1iiIi1IiiiI [ 0 ] if ( len ( i1iiIi1IiiiI ) > 0 ) else ''
 iiiioOOOO = OO0oooOO [ 0 ] if ( len ( OO0oooOO ) > 0 ) else ''
 OoOOoo0 = III [ 0 ] if ( len ( III ) > 0 ) else ''
 oo0OOO0OOoOO = i1iiIIiiiI [ 0 ] if ( len ( i1iiIIiiiI ) > 0 ) else ''
 oOoOII1i1 = I1IIiIi1iI [ 0 ] if ( len ( I1IIiIi1iI ) > 0 ) else ''
 o0o0oo0OOo0O0 = oOo0Iiii11 [ 0 ] if ( len ( oOo0Iiii11 ) > 0 ) else ''
 iIIiiII11i1I1 = o00000O [ 0 ] if ( len ( o00000O ) > 0 ) else ''
 oO00O = OoOO00OO0 [ 0 ] if ( len ( OoOO00OO0 ) > 0 ) else ''
 Ooo0oo = str ( '[COLOR=orange]Author: [/COLOR]' + i11o00Ooo + '[CR][CR][COLOR=lime]About: [/COLOR]' + oOoo00 + iI1ii1i1 + IIiI + oOOO + O00o00 + OOo00o0oOO0o + I1ii1 + O0Oi111 + o0OiI1 + IiiI + III1i1iII1 + IiiiiI11iii11iI + I111iIii1i1 + I1i1I1i1I1 + i1IOO + Oo0OO0ooO0O0O )
 if 63 - 63: O0 % iIii1I11I1II1 / O0
 if iI1ii1i1 != '' :
  o0oOO000oO0oo ( '' , '[COLOR=yellow][Text Guide][/COLOR]  ' + O0OOoOOO0oO , Ooo0oo , 'text_guide' , '' , OO0o , oOoo00 , '' )
 if I1I != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + O0Oo0o000oO , I1I , 'play_video' , '' , OO0o , '' , '' )
 if ooooo != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oO0o00oOOooO0 , ooooo , 'play_video' , '' , OO0o , '' , '' )
 if i11IIIiI1I != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + OOOoO000 , i11IIIiI1I , 'play_video' , '' , OO0o , '' , '' )
 if o0iiiI1I1iIIIi1 != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oOOOO , o0iiiI1I1iIIIi1 , 'play_video' , '' , OO0o , '' , '' )
 if Iii != 'None' :
  o0oOO000oO0oo ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + IiIi1ii111i1 , Iii , 'play_video' , '' , OO0o , '' , '' )
  if 5 - 5: i11iIiiIii * iiii % IIiIi1iI - IIIIiiII111
  if 5 - 5: O0 * i1IiiiI1iI * o0o + oo0O0oO % oOo - oooOooOOo0OO
def oO00oo ( ) :
 if I11i . getSetting ( 'tutorial_manual_search' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'tutorials' , 'manual_search' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_all' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=lime]All Guides[/COLOR] Everything in one place' , '' , 'grab_tutorials' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_kodi' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=lime]XBMC / Kodi[/COLOR] Specific' , '' , 'xbmc_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_xbmc4xbox' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=lime]XBMC4Xbox[/COLOR] Specific' , '&platform=XBMC4Xbox' , 'xbmc_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_android' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] Android' , '&platform=Android' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_atv' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] Apple TV' , '&platform=ATV' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_ios' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] ATV2 & iOS' , '&platform=iOS' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_linux' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] Linux' , '&platform=Linux' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_pure_linux' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] Pure Linux' , '&platform=Custom_Linux' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_openelec' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] OpenELEC' , '&platform=OpenELEC' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_osmc' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSMC' , '&platform=OSMC' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_osx' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSX' , '&platform=OSX' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_raspbmc' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] Raspbmc' , '&platform=Raspbmc' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_windows' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=orange][Platform][/COLOR] Windows' , '&platform=Windows' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_allwinner' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Allwinner Devices' , '&hardware=Allwinner' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_aftv' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Amazon Fire TV' , '&hardware=AFTV' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_amlogic' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] AMLogic Devices' , '&hardware=AMLogic' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_boxee' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Boxee' , '&hardware=Boxee' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_intel' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Intel Devices' , '&hardware=Intel' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_rpi' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Raspberry Pi' , '&hardware=RaspberryPi' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_rockchip' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Rockchip Devices' , '&hardware=Rockchip' , 'platform_menu' , '' , '' , '' , '' )
 if I11i . getSetting ( 'tutorial_xbox' ) == 'true' :
  o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Xbox' , '&hardware=Xbox' , 'platform_menu' , '' , '' , '' , '' )
  if 18 - 18: IIIIiiII111 * oooOooOOo0OO / i11iIiiIii / iIii1I11I1II1 * OoooooooOO . o0o
  if 69 - 69: oOo * iiii
def OOII1iI ( ) :
 OOooO0OOoo = xbmcgui . Dialog ( )
 if OOooO0OOoo . yesno ( "Make Add-on Passwords Visible?" , "This will make all your add-on passwords visible in the add-on settings. Are you sure you wish to continue?" ) :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( OooO0 ) :
   for ooOo0O0o0 in Oo0o :
    if ooOo0O0o0 == 'settings.xml' :
     I1iiIIiI11I = open ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) ) . read ( )
     iiI1i1Iii111 = re . compile ( '<setting id=(.+?)>' ) . findall ( I1iiIIiI11I )
     for I11II1I in iiI1i1Iii111 :
      if 'pass' in I11II1I :
       if 'option="hidden"' in I11II1I :
        try :
         oOoOo000 = I11II1I . replace ( ' option="hidden"' , '' )
         ooOo0O0o0 = open ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) , mode = 'w' )
         ooOo0O0o0 . write ( str ( I1iiIIiI11I ) . replace ( I11II1I , oOoOo000 ) )
         ooOo0O0o0 . close ( )
        except :
         pass
  OOooO0OOoo . ok ( "Passwords Are now visible" , "Your passwords will now be visible in your add-on settings. If you want to undo this please use the option to hide passwords." )
  if 52 - 52: OoOoOO00 - i11iIiiIii / i1IiiiI1iI . II11iIiIIIiI
  if 38 - 38: II11iIiIIIiI + OoooooooOO * ooo0O % II11iIiIIIiI
def oo0Oooo0O ( ) :
 if I11i . getSetting ( 'email' ) == '' :
  OOooO0OOoo = xbmcgui . Dialog ( )
  OOooO0OOoo . ok ( "No Email Address Set" , "A new window will Now open for you to enter your Email address. The logfile will be sent here" )
  I11i . openSettings ( )
 xbmc . executebuiltin ( 'XBMC.RunScript(special://home/addons/' + IiII1IiiIiI1 + '/uploadLog.py)' )
 if 80 - 80: oOo
 if 16 - 16: OoOoOO00 * IIiIi1iI . iIii1I11I1II1
def Oooo000ooo00O ( localbuildcheck , localversioncheck , localidcheck ) :
 if o0oO0 == 'true' :
  oo = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( O0oo0OO0 , I1i1iiI1 )
 else : oo = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( '' , '' )
 I1111i = iIIii ( oo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iiI11I1iII = re . compile ( 'login_msg="(.+?)"' ) . findall ( I1111i )
 IIiiiI1ii = iiI11I1iII [ 0 ] if ( len ( iiI11I1iII ) > 0 ) else ''
 if 54 - 54: OoooooooOO % O0 % O0 * O00OOo00oo0o % II111iiii + o0o
 if 89 - 89: i1IiiiI1iI - oOoO0o00OO0 - II111iiii * O00OOo00oo0o . iIii1I11I1II1
 if not 'REGISTER FOR FREE' in IIiiiI1ii :
  iIIiooO00O00oOO = open ( OOOOi11i1 , mode = 'w+' )
  iIIiooO00O00oOO . write ( 'd="' + Iiiii ( ) + '"\nlogin_msg="' + IIiiiI1ii + '"' )
  iIIiooO00O00oOO . close ( )
  if 33 - 33: OoOoOO00 . iIii1I11I1II1 / i11iIiiIii * O00OOo00oo0o
 iiiiii1 ( localbuildcheck , localversioncheck , localidcheck , IIiiiI1ii )
 if 18 - 18: ooo0O * ooo0O - oOoO0o00OO0 % iiii % II111iiii - i1IiiiI1iI
 if 75 - 75: iii1i1iiiiIi . II111iiii . II11iIiIIIiI / iii1i1iiiiIi % iIii1I11I1II1
def OO0O000 ( ) :
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( 'UpdateAddonRepos' )
 xbmcgui . Dialog ( ) . ok ( 'Force Refresh Started Successfully' , 'Depending on the speed of your device it could take a few minutes for the update to take effect.' )
 return
 if 8 - 8: O0 / II111iiii
 if 62 - 62: iIii1I11I1II1 % oo0O0oO % oooOooOOo0OO * i1IiiiI1iI
def oO0OO0o0oo0o ( ) :
 oOo0ooo00OoO = 1
 try :
  iIIii ( 'http://google.com' )
 except :
  try :
   iIIii ( 'http://google.com' )
  except :
   try :
    iIIii ( 'http://google.com' )
   except :
    try :
     iIIii ( 'http://google.cn' )
    except :
     try :
      iIIii ( 'http://google.cn' )
     except :
      OOooO0OOoo . ok ( "NO INTERNET CONNECTION" , 'It looks like this device isn\'t connected to the internet. Only some of the maintenance options will work until you fix the connectivity problem.' )
      iiiiii1 ( '' , '' , '' , '[COLOR=orange]NO INTERNET CONNECTION[/COLOR]' )
      oOo0ooo00OoO = 0
 if oOo0ooo00OoO == 1 :
  ooooOo00Oii11iIII111 ( )
  if 86 - 86: i1IiiiI1iI - i1IiiiI1iI
  if 51 - 51: i1IiiiI1iI % IIiIi1iI / IIIIiiII111 + II11iIiIIIiI - iiii * oo0O0oO
def ooooOo00Oii11iIII111 ( ) :
 oOo0I1Ii11i = 'None'
 iiIIIi1i = '0'
 if 76 - 76: ooo0O / oooOooOOo0OO / iIii1I11I1II1 * OoooooooOO * o0o
 if 80 - 80: II11iIiIIIiI / O0
 IiI1Iii1 = open ( OOOO , mode = 'r' )
 iiiiI11ii = IiI1Iii1 . read ( )
 IiI1Iii1 . close ( )
 if 55 - 55: OoOoOO00 * IIIIiiII111 / O0 % ooo0O
 Oo0OOOOOOOo0O = re . compile ( 'date="(.+?)"' ) . findall ( iiiiI11ii )
 I1III = Oo0OOOOOOOo0O [ 0 ] if ( len ( Oo0OOOOOOOo0O ) > 0 ) else ''
 I1IIii11 = re . compile ( 'version="(.+?)"' ) . findall ( iiiiI11ii )
 i1i = I1IIii11 [ 0 ] if ( len ( I1IIii11 ) > 0 ) else ''
 if 41 - 41: iIii1I11I1II1 - iii1i1iiiiIi * i1IiiiI1iI
 oo00ooOooO = open ( iiiiiIIii , mode = 'r' )
 ooIi111iII = oo00ooOooO . read ( )
 oo00ooOooO . close ( )
 if 65 - 65: o0o / o0o / IIiIi1iI * OoooooooOO
 o00o = re . compile ( 'id="(.+?)"' ) . findall ( ooIi111iII )
 OooOo = re . compile ( 'name="(.+?)"' ) . findall ( ooIi111iII )
 iiIIIi1i = o00o [ 0 ] if ( len ( o00o ) > 0 ) else 'None'
 oOo0I1Ii11i = OooOo [ 0 ] if ( len ( OooOo ) > 0 ) else ''
 if 40 - 40: oOo * OoooooooOO + i1IiiiI1iI
 if 58 - 58: OoOoOO00
 if i1111 == 'true' :
  try :
   I1111i = iIIii ( i11 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   I1iiI1IiI = re . compile ( 'date="(.+?)"' ) . findall ( I1111i )
   iiiI1II1iIII = re . compile ( 'video="https://www.youtube.com/watch\?v=(.+?)"' ) . findall ( I1111i )
   IiiIi = I1iiI1IiI [ 0 ] if ( len ( I1iiI1IiI ) > 0 ) else ''
   Oo0oOOOOoO0oOoO0OOO0 = iiiI1II1iIII [ 0 ] if ( len ( iiiI1II1iIII ) > 0 ) else ''
   if 11 - 11: oOoO0o00OO0 % OoOoOO00 / O00OOo00oo0o
   if 17 - 17: i1IiiiI1iI % OoooooooOO / iiii * OoooooooOO
   if int ( I1III ) < int ( IiiIi ) :
    i1I1 = iiiiI11ii . replace ( I1III , IiiIi )
    iIIiooO00O00oOO = open ( OOOO , mode = 'w' )
    iIIiooO00O00oOO . write ( str ( i1I1 ) )
    iIIiooO00O00oOO . close ( )
    if 14 - 14: II111iiii + O0 - IIiIi1iI
   yt . PlayVideo ( Oo0oOOOOoO0oOoO0OOO0 , forcePlayer = True )
   xbmc . sleep ( 500 )
   while xbmc . Player ( ) . isPlaying ( ) :
    xbmc . sleep ( 500 )
  except :
   pass
 if not os . path . exists ( OOOOi11i1 ) :
  print "### First login check ###"
  Oooo000ooo00O ( oOo0I1Ii11i , i1i , iiIIIi1i )
  if 18 - 18: oOoO0o00OO0 / i11iIiiIii % oooOooOOo0OO * OoooooooOO
  if 67 - 67: ooo0O
 else :
  OOO0 = open ( OOOOi11i1 , mode = 'r' )
  o0oo00 = OOO0 . read ( )
  OOO0 . close ( )
  if 92 - 92: i1IIi
  OOO0OOo0OoO = re . compile ( 'd="(.+?)"' ) . findall ( o0oo00 )
  oO00OOO = re . compile ( 'login_msg="(.+?)"' ) . findall ( o0oo00 )
  o0oO0Oo = OOO0OOo0OoO [ 0 ] if ( len ( OOO0OOo0OoO ) > 0 ) else '0'
  IIiiiI1ii = oO00OOO [ 0 ] if ( len ( oO00OOO ) > 0 ) else ''
  if 48 - 48: iIii1I11I1II1 . iii1i1iiiiIi + i11iIiiIii - O00OOo00oo0o . iii1i1iiiiIi
  if int ( o0oO0Oo ) + 2000000 > int ( Iiiii ( ) ) :
   print "### Login successful ###"
   iiiiii1 ( oOo0I1Ii11i , i1i , iiIIIi1i , IIiiiI1ii )
  else :
   print "### Checking login ###"
   Oooo000ooo00O ( oOo0I1Ii11i , i1i , iiIIIi1i )
   if 89 - 89: i1IIi
   if 92 - 92: iIii1I11I1II1 * oooOooOOo0OO
def Oooo00 ( ) :
 i1I11Iiii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 if os . path . exists ( i1I11Iiii ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( i1I11Iiii ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     try :
      os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
     except :
      pass
    for ii1iIIiii1 in i1iiIIIi :
     try :
      shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     except :
      pass
 oOOOoOo0oOoo = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
 if os . path . exists ( oOOOoOo0oOoo ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( oOOOoOo0oOoo ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     try :
      os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
     except :
      pass
    for ii1iIIiii1 in i1iiIIIi :
     try :
      shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     except :
      pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iIi = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( iIi ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
  O0OOoOOO0o0o = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( O0OOoOOO0o0o ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 64 - 64: i11iIiiIii + ooo0O + oOoO0o00OO0 + o0o
 iI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 if os . path . exists ( iI ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( iI ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 33 - 33: OoOoOO00 - IIiIi1iI . i1IIi / i11iIiiIii
 Ooo0ooo0oo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 if os . path . exists ( Ooo0ooo0oo ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( Ooo0ooo0oo ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 84 - 84: IIIIiiII111 / OoooooooOO / i1IiiiI1iI % IIIIiiII111 . o0o + oo0O0oO
 I11iIiI1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 if os . path . exists ( I11iIiI1 ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( I11iIiI1 ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 94 - 94: IIIIiiII111
 i1I1iiii1Ii11 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 if os . path . exists ( i1I1iiii1Ii11 ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( i1I1iiii1Ii11 ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 48 - 48: II11iIiIIIiI - OoooooooOO + oOoO0o00OO0 % i1IIi - OoOoOO00 + o0o
 IiIIIIi = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 if os . path . exists ( IiIIIIi ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( IiIIIIi ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 56 - 56: OoOoOO00 - o0o
 OoIIiIIIII1I = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 if os . path . exists ( OoIIiIIIII1I ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( OoIIiIIIII1I ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 35 - 35: iii1i1iiiiIi / OoOoOO00 * O0 + OoOoOO00 . O0
 ooiiI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 if os . path . exists ( ooiiI ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( ooiiI ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 86 - 86: OoOoOO00
 o00iIiI1iI1Ii1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 if os . path . exists ( o00iIiI1iI1Ii1 ) == True :
  for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( o00iIiI1iI1Ii1 ) :
   iI1I1 = 0
   iI1I1 += len ( Oo0o )
   if iI1I1 > 0 :
    for ooOo0O0o0 in Oo0o :
     os . unlink ( os . path . join ( OoO0oo0 , ooOo0O0o0 ) )
    for ii1iIIiii1 in i1iiIIIi :
     shutil . rmtree ( os . path . join ( OoO0oo0 , ii1iIIiii1 ) )
     if 10 - 10: ooo0O / II11iIiIIIiI % oOo
 try :
  iioO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
  Oo0Ooo = database . connect ( iioO )
  II1iII11 = Oo0Ooo . cursor ( )
  II1iII11 . execute ( "DROP TABLE IF EXISTS rel_list" )
  II1iII11 . execute ( "VACUUM" )
  Oo0Ooo . commit ( )
  II1iII11 . execute ( "DROP TABLE IF EXISTS rel_lib" )
  II1iII11 . execute ( "VACUUM" )
  Oo0Ooo . commit ( )
 except :
  pass
  if 15 - 15: IIIIiiII111 - iIii1I11I1II1 % O00OOo00oo0o
  if 47 - 47: IIiIi1iI / OoooooooOO - II111iiii
def oOOooo ( mode ) :
 if zip == '' :
  OOooO0OOoo . ok ( 'Please set your backup location before proceeding' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' )
  I11i . openSettings ( sys . argv [ 0 ] )
  IiI11IiIIi = I11i . getSetting ( 'zip' )
  if IiI11IiIIi == '' :
   oOOooo ( mode )
 iI1IIIiIII11 = xbmc . translatePath ( os . path . join ( I1IIIii , 'Community_Builds' , 'My_Builds' ) )
 if not os . path . exists ( iI1IIIiIII11 ) :
  os . makedirs ( iI1IIIiIII11 )
 i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( "ABSOLUTELY CERTAIN?!!!" , 'Are you absolutely certain you want to wipe?' , '' , 'All addons and settings will be completely wiped!' , yeslabel = 'Yes' , nolabel = 'No' )
 if 92 - 92: O00OOo00oo0o
 if i1IiiI1iIi == 1 :
  if oO0Oo != "skin.confluence" :
   OOooO0OOoo . ok ( 'Default Confluence Skin Required' , 'Please switch to the default Confluence skin before performing a wipe.' )
   xbmc . executebuiltin ( "ActivateWindow(appearancesettings,return)" )
   return
  else :
   if 48 - 48: IIiIi1iI . OoOoOO00 + O0
   i1IiiI1iIi = xbmcgui . Dialog ( ) . yesno ( "VERY IMPORTANT" , 'This will completely wipe your install.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'No' , nolabel = 'Yes' )
   if i1IiiI1iIi == 0 :
    if not os . path . exists ( iI1IIIiIII11 ) :
     os . makedirs ( iI1IIIiIII11 )
    II1IIiIiiI1iI = oo00o0OoO ( heading = "Enter a name for this backup" )
    if ( not II1IIiIiiI1iI ) : return False , 0
    OOOOO0o0OOo = urllib . quote_plus ( II1IIiIiiI1iI )
    I11I11I11IiIi = xbmc . translatePath ( os . path . join ( iI1IIIiIII11 , OOOOO0o0OOo + '.zip' ) )
    OOii1ii1i11I1I = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
    iiII1iiiiiii = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
    OOOoo = "Creating full backup of existing build"
    III1II1iii1i = "Archiving..."
    O0OO0oOO = ""
    ooooO = "Please Wait"
    o0O0OO ( oOOoO0 , I11I11I11IiIi , OOOoo , III1II1iii1i , O0OO0oOO , ooooO , OOii1ii1i11I1I , iiII1iiiiiii )
    if 19 - 19: OoOoOO00 / oo0O0oO - IIIIiiII111
    if 49 - 49: iIii1I11I1II1 - iIii1I11I1II1 - ooo0O + i1IiiiI1iI / ooo0O
   iIii1 . create ( "Wiping Existing Content" , '' , 'Please wait...' , '' )
   for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( oOOoO0 , topdown = True ) :
    i1iiIIIi [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in i1iiIIIi if ii1iIIiii1 not in O0o0O00Oo0o0 ]
    for O0OOoOOO0oO in Oo0o :
     try :
      iIii1 . update ( 0 , "Removing [COLOR=yellow]" + O0OOoOOO0oO + '[/COLOR]' , '' , 'Please wait...' )
      os . unlink ( os . path . join ( OoO0oo0 , O0OOoOOO0oO ) )
      os . remove ( os . path . join ( OoO0oo0 , O0OOoOOO0oO ) )
      os . rmdir ( os . path . join ( OoO0oo0 , O0OOoOOO0oO ) )
     except :
      print "Failed to remove file: " + O0OOoOOO0oO
      if 74 - 74: OoooooooOO + oooOooOOo0OO % O0
   iII1IIoO00oOOOO = [ O0OOoOOO0oO for O0OOoOOO0oO in os . listdir ( O0OoO000O0OO ) if os . path . isdir ( os . path . join ( O0OoO000O0OO , O0OOoOOO0oO ) ) ]
   try :
    for O0OOoOOO0oO in iII1IIoO00oOOOO :
     try :
      if O0OOoOOO0oO not in O0o0O00Oo0o0 :
       iIii1 . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + O0OOoOOO0oO + ' [/COLOR]' , '' , 'Please wait...' )
       shutil . rmtree ( os . path . join ( O0OoO000O0OO , O0OOoOOO0oO ) )
     except :
      print "Failed to remove: " + O0OOoOOO0oO
   except :
    pass
    if 54 - 54: IIIIiiII111 * OoooooooOO
   for OoO0oo0 , i1iiIIIi , Oo0o in os . walk ( O0OoO000O0OO , topdown = True ) :
    i1iiIIIi [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in i1iiIIIi if ii1iIIiii1 not in O0o0O00Oo0o0 ]
    for O0OOoOOO0oO in Oo0o :
     try :
      iIii1 . update ( 0 , "Removing [COLOR=yellow]" + O0OOoOOO0oO + '[/COLOR]' , '' , 'Please wait...' )
      os . unlink ( os . path . join ( OoO0oo0 , O0OOoOOO0oO ) )
      os . remove ( os . path . join ( OoO0oo0 , O0OOoOOO0oO ) )
     except :
      print "Failed to remove file: " + O0OOoOOO0oO
      if 71 - 71: oOoO0o00OO0 + OoooooooOO * II111iiii / oo0O0oO
   o000OOO000o = [ O0OOoOOO0oO for O0OOoOOO0oO in os . listdir ( OooO0 ) if os . path . isdir ( os . path . join ( OooO0 , O0OOoOOO0oO ) ) ]
   try :
    for O0OOoOOO0oO in o000OOO000o :
     try :
      if Iii1ii1II11i == 'true' :
       if O0OOoOOO0oO not in O0o0O00Oo0o0 and not 'repo' in O0OOoOOO0oO :
        iIii1 . update ( 0 , "Removing Add-on: [COLOR=yellow]" + O0OOoOOO0oO + ' [/COLOR]' , '' , 'Please wait...' )
        shutil . rmtree ( os . path . join ( OooO0 , O0OOoOOO0oO ) )
      else :
       if O0OOoOOO0oO not in O0o0O00Oo0o0 :
        iIii1 . update ( 0 , "Removing Add-on: [COLOR=yellow]" + O0OOoOOO0oO + ' [/COLOR]' , '' , 'Please wait...' )
        shutil . rmtree ( os . path . join ( OooO0 , O0OOoOOO0oO ) )
     except :
      print "Failed to remove: " + O0OOoOOO0oO
   except :
    pass
    if 71 - 71: oo0O0oO - IIiIi1iI % O0
   i1I1111iI = [ O0OOoOOO0oO for O0OOoOOO0oO in os . listdir ( iiI1IiI ) if os . path . isdir ( os . path . join ( iiI1IiI , O0OOoOOO0oO ) ) ]
   try :
    for O0OOoOOO0oO in i1I1111iI :
     try :
      if O0OOoOOO0oO not in O0o0O00Oo0o0 :
       iIii1 . update ( 0 , "Removing Add-on Data: [COLOR=yellow]" + O0OOoOOO0oO + ' [/COLOR]' , '' , 'Please wait...' )
       shutil . rmtree ( os . path . join ( iiI1IiI , O0OOoOOO0oO ) )
     except :
      print "Failed to remove: " + O0OOoOOO0oO
   except :
    pass
    if 64 - 64: O0 + OoOoOO00 . II111iiii - oo0O0oO * O00OOo00oo0o % O00OOo00oo0o
   iIIIi1IiI11i = [ O0OOoOOO0oO for O0OOoOOO0oO in os . listdir ( oOOoO0 ) if os . path . isdir ( os . path . join ( oOOoO0 , O0OOoOOO0oO ) ) ]
   try :
    for O0OOoOOO0oO in iIIIi1IiI11i :
     try :
      if O0OOoOOO0oO not in O0o0O00Oo0o0 :
       iIii1 . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + O0OOoOOO0oO + ' [/COLOR]' , '' , 'Please wait...' )
       shutil . rmtree ( os . path . join ( oOOoO0 , O0OOoOOO0oO ) )
     except :
      print "Failed to remove: " + O0OOoOOO0oO
   except :
    pass
  if mode != 'CB' :
   OOooO0OOoo . ok ( 'Wipe Complete' , 'Kodi will now close.' , 'When you next load up Kodi it should boot into the default Confluence skin and you should have a fresh install.' )
   xbmc . executebuiltin ( 'quit' )
  try :
   os . remove ( OOOO )
  except :
   print "### Failed to remove startup.xml"
  try :
   os . remove ( iiiiiIIii )
  except :
   print "### Failed to remove id.xml"
 else : return
 if 9 - 9: ooo0O * oOoO0o00OO0
 if 28 - 28: i1IiiiI1iI - O00OOo00oo0o . i1IiiiI1iI - oooOooOOo0OO * IIiIi1iI * iii1i1iiiiIi
def o00oo0oO00O000 ( url ) :
 o0oOO000oO0oo ( 'folder' , '[COLOR=yellow]1. Install[/COLOR]' , str ( url ) + '&tags=Install&XBMC=1' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=lime]2. Settings[/COLOR]' , str ( url ) + '&tags=Settings' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=orange]3. Add-ons[/COLOR]' , str ( url ) , 'tutorial_addon_menu' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Audio' , str ( url ) + '&tags=Audio' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Errors' , str ( url ) + '&tags=Errors' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Gaming' , str ( url ) + '&tags=Gaming' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  LiveTV' , str ( url ) + '&tags=LiveTV' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Maintenance' , str ( url ) + '&tags=Maintenance' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Pictures' , str ( url ) + '&tags=Pictures' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Profiles' , str ( url ) + '&tags=Profiles' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Skins' , str ( url ) + '&tags=Skins' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Video' , str ( url ) + '&tags=Video' , 'grab_tutorials' , '' , '' , '' , '' )
 o0oOO000oO0oo ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Weather' , str ( url ) + '&tags=Weather' , 'grab_tutorials' , '' , '' , '' , '' )
 if 20 - 20: IIIIiiII111 . i1IIi . i11iIiiIii - oOoO0o00OO0 * i1IiiiI1iI
 if 99 - 99: OoOoOO00 - iIii1I11I1II1
def oOO0oo0o0ooO00 ( url ) :
 oo0oo0O0 = xbmc . getInfoLabel ( "System.BuildVersion" )
 Ii1i1iI = float ( oo0oo0O0 [ : 4 ] )
 if Ii1i1iI < 14 :
  i1i1IIoO0O = 'You are running XBMC'
 else :
  i1i1IIoO0O = 'You are running Kodi'
 OOooO0OOoo = xbmcgui . Dialog ( )
 OOooO0OOoo . ok ( i1i1IIoO0O , "Your version is: %s" % Ii1i1iI )
 if 55 - 55: IIiIi1iI * oOo + ooo0O * o0o / IIiIi1iI * i1IIi
 if 49 - 49: i1IiiiI1iI + iIii1I11I1II1
 if 30 - 30: i11iIiiIii % oOoO0o00OO0 . i1IIi
 if 49 - 49: oOoO0o00OO0 * O00OOo00oo0o + oOo
 if 1 - 1: oOoO0o00OO0 / II111iiii + IIIIiiII111 . i11iIiiIii + iiii . ooo0O
 if 95 - 95: oOoO0o00OO0 / oo0O0oO % II111iiii + iiii
 if 97 - 97: o0o
 if 55 - 55: iiii
 if 1 - 1: iii1i1iiiiIi
 if 43 - 43: iIii1I11I1II1 - o0o - oOoO0o00OO0 + oooOooOOo0OO - oo0O0oO % oooOooOOo0OO
 if 58 - 58: ooo0O
 if 27 - 27: i1IiiiI1iI * o0o - OoooooooOO . O00OOo00oo0o - II111iiii
 if 62 - 62: OoOoOO00 / iIii1I11I1II1 * IIIIiiII111
 if 84 - 84: i1IiiiI1iI - ooo0O . i1IiiiI1iI + iiii . IIiIi1iI
 if 96 - 96: O00OOo00oo0o % IIiIi1iI * O00OOo00oo0o % OoOoOO00 . oOoO0o00OO0 / oOoO0o00OO0
 if 7 - 7: iii1i1iiiiIi - iiii % i1IIi
 if 24 - 24: iii1i1iiiiIi % O0 % IIIIiiII111
 if 61 - 61: iiii . IIiIi1iI / iiii * OoooooooOO
 if 13 - 13: II111iiii
 if 17 - 17: II111iiii
 if 66 - 66: i1IiiiI1iI * II11iIiIIIiI
 if 73 - 73: i11iIiiIii + O0 % O0
OOOo0Oo0O = Ii11ii1 ( )
oOoOoOoo0 = None
O0OOO00OOO00o = None
Oo0oOO0O00 = None
i11o00Ooo = None
OoOoO00OoOOo = None
i11oO0OoO = None
Ooo0oo = None
oOO00II1IiII1I1II = None
oo0o0oOo = None
IiIIIIIi = None
i1i1IIIIIIIi = None
I1111i = None
ooooOo00O = None
O0oOoOooo00oo = None
oOOO0O000Oo = None
O0OOoOOO0oO = None
oooOII111iiI1Ii1 = None
o00OOo0o0O = None
III1ii1I = None
O0OoO0ooOO0o = None
iiiii1I = None
oOoO00O = None
i11i = None
OOOOO0o0OOo = None
ii1I1IiiI1ii1i = None
OOO0OO00 = None
i1ii1iIiI1 = None
Ii1i1iI = None
I1Ii = None
I11I1I1i1i = None
IIiiiI1ii = None
IiI = None
oOoOo0OoOOoo = 'maintenance'
if 25 - 25: iiii % ooo0O . II11iIiIIIiI
try :
 oOoOoOoo0 = urllib . unquote_plus ( OOOo0Oo0O [ "addon_id" ] )
except :
 pass
try :
 O0o0O00o0o = urllib . unquote_plus ( OOOo0Oo0O [ "adult" ] )
except :
 pass
try :
 O0OOO00OOO00o = urllib . unquote_plus ( OOOo0Oo0O [ "artpack" ] )
except :
 pass
try :
 Oo0oOO0O00 = urllib . unquote_plus ( OOOo0Oo0O [ "audioaddons" ] )
except :
 pass
try :
 i11o00Ooo = urllib . unquote_plus ( OOOo0Oo0O [ "author" ] )
except :
 pass
try :
 OoOoO00OoOOo = urllib . unquote_plus ( OOOo0Oo0O [ "buildname" ] )
except :
 pass
try :
 i11oO0OoO = urllib . unquote_plus ( OOOo0Oo0O [ "data_path" ] )
except :
 pass
try :
 Ooo0oo = urllib . unquote_plus ( OOOo0Oo0O [ "description" ] )
except :
 pass
try :
 oOO00II1IiII1I1II = urllib . unquote_plus ( OOOo0Oo0O [ "email" ] )
except :
 pass
try :
 oo0o0oOo = urllib . unquote_plus ( OOOo0Oo0O [ "fanart" ] )
except :
 pass
try :
 IiIIIIIi = urllib . unquote_plus ( OOOo0Oo0O [ "forum" ] )
except :
 pass
try :
 II1IIiiI1 = urllib . unquote_plus ( OOOo0Oo0O [ "guisettingslink" ] )
except :
 pass
try :
 i1i1IIIIIIIi = urllib . unquote_plus ( OOOo0Oo0O [ "iconimage" ] )
except :
 pass
try :
 I1111i = urllib . unquote_plus ( OOOo0Oo0O [ "link" ] )
except :
 pass
try :
 ooooOo00O = urllib . unquote_plus ( OOOo0Oo0O [ "local" ] )
except :
 pass
try :
 O0oOoOooo00oo = urllib . unquote_plus ( OOOo0Oo0O [ "messages" ] )
except :
 pass
try :
 oOOO0O000Oo = str ( OOOo0Oo0O [ "mode" ] )
except :
 pass
try :
 O0OOoOOO0oO = urllib . unquote_plus ( OOOo0Oo0O [ "name" ] )
except :
 pass
try :
 I111Iii1 = urllib . unquote_plus ( OOOo0Oo0O [ "pictureaddons" ] )
except :
 pass
try :
 oooOII111iiI1Ii1 = urllib . unquote_plus ( OOOo0Oo0O [ "posts" ] )
except :
 pass
try :
 o00OOo0o0O = urllib . unquote_plus ( OOOo0Oo0O [ "programaddons" ] )
except :
 pass
try :
 III1ii1I = urllib . unquote_plus ( OOOo0Oo0O [ "provider_name" ] )
except :
 pass
try :
 iiiii1I = urllib . unquote_plus ( OOOo0Oo0O [ "repo_link" ] )
except :
 pass
try :
 O0OoO0ooOO0o = urllib . unquote_plus ( OOOo0Oo0O [ "repo_id" ] )
except :
 pass
try :
 oOoO00O = urllib . unquote_plus ( OOOo0Oo0O [ "skins" ] )
except :
 pass
try :
 i11i = urllib . unquote_plus ( OOOo0Oo0O [ "sources" ] )
except :
 pass
try :
 OOOOO0o0OOo = urllib . unquote_plus ( OOOo0Oo0O [ "title" ] )
except :
 pass
try :
 ii1I1IiiI1ii1i = urllib . unquote_plus ( OOOo0Oo0O [ "updated" ] )
except :
 pass
try :
 OOO0OO00 = urllib . unquote_plus ( OOOo0Oo0O [ "unread" ] )
except :
 pass
try :
 i1ii1iIiI1 = urllib . unquote_plus ( OOOo0Oo0O [ "url" ] )
except :
 pass
try :
 Ii1i1iI = urllib . unquote_plus ( OOOo0Oo0O [ "version" ] )
except :
 pass
try :
 I1Ii = urllib . unquote_plus ( OOOo0Oo0O [ "video" ] )
except :
 pass
try :
 I11I1I1i1i = urllib . unquote_plus ( OOOo0Oo0O [ "videoaddons" ] )
except :
 pass
try :
 IIiiiI1ii = urllib . unquote_plus ( OOOo0Oo0O [ "welcometext" ] )
except :
 pass
try :
 IiI = urllib . unquote_plus ( OOOo0Oo0O [ "zip_link" ] )
except :
 pass
 if 9 - 9: ooo0O . iIii1I11I1II1 . oOo - oOoO0o00OO0 . i1IiiiI1iI
if not os . path . exists ( oO0 ) :
 os . makedirs ( oO0 )
 if 66 - 66: i11iIiiIii / OoOoOO00 % oo0O0oO
if not os . path . exists ( OOOO ) :
 IiI1Iii1 = open ( OOOO , mode = 'w+' )
 IiI1Iii1 . write ( 'date="01011001"\nversion="0.0"' )
 IiI1Iii1 . close ( )
 if 78 - 78: iiii % OoooooooOO . iiii % i11iIiiIii + II111iiii
if not os . path . exists ( iiiiiIIii ) :
 IiI1Iii1 = open ( iiiiiIIii , mode = 'w+' )
 IiI1Iii1 . write ( 'id="None"\nname="None"' )
 IiI1Iii1 . close ( )
 if 25 - 25: iiii
if os . path . exists ( O000OO0 ) :
 try :
  shutil . rmtree ( O000OO0 )
 except :
  pass
  if 83 - 83: O00OOo00oo0o / OoooooooOO * II11iIiIIIiI . OoOoOO00 . i1IIi
if os . path . exists ( I11iii1Ii ) :
 try :
  shutil . rmtree ( I11iii1Ii )
 except :
  pass
  if 59 - 59: IIIIiiII111 . IIIIiiII111 * OoOoOO00 - O00OOo00oo0o % ooo0O
if os . path . exists ( I1IIiiIiii ) :
 try :
  shutil . rmtree ( I1IIiiIiii )
 except :
  pass
  if 19 - 19: OoooooooOO / oOo - oo0O0oO . ooo0O
  if 8 - 8: IIIIiiII111 % iiii . iIii1I11I1II1
  if 95 - 95: oOoO0o00OO0 + i11iIiiIii . oooOooOOo0OO . iiii . oOoO0o00OO0
  if 93 - 93: IIiIi1iI
  if 55 - 55: II111iiii % oOoO0o00OO0 - iii1i1iiiiIi
  if 48 - 48: iiii * iIii1I11I1II1 % ooo0O
  if 100 - 100: II111iiii - i11iIiiIii + iii1i1iiiiIi % iiii - iIii1I11I1II1 * i11iIiiIii
  if 30 - 30: iii1i1iiiiIi . iii1i1iiiiIi . O00OOo00oo0o % O00OOo00oo0o * i1IIi * II11iIiIIIiI
  if 74 - 74: OoooooooOO
  if 33 - 33: oOoO0o00OO0 - II111iiii
  if 95 - 95: OoooooooOO
  if 23 - 23: II111iiii + IIIIiiII111 / O0 . IIIIiiII111 . oo0O0oO + iIii1I11I1II1
if oOOO0O000Oo == None : oO0OO0o0oo0o ( )
elif oOOO0O000Oo == 'ASCII_Check' : OOoO00ooO ( )
elif oOOO0O000Oo == 'addon_final_menu' : OOOO0OoOO0o0o ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'addon_categories' : OoOOoOooooOOo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'addon_countries' : oO00oOOoooO ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'addon_genres' : I11I ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'addon_install' : oOO00oO00O0OO ( O0OOoOOO0oO , IiI , iiiii1I , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIIIIIi , i11oO0OoO )
elif oOOO0O000Oo == 'addon_install_badzip' : oOoi1i ( O0OOoOOO0oO , IiI , iiiii1I , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIIIIIi , i11oO0OoO )
elif oOOO0O000Oo == 'addon_install_na' : ooOo ( O0OOoOOO0oO , IiI , iiiii1I , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIIIIIi , i11oO0OoO )
elif oOOO0O000Oo == 'addon_install_zero' : oOooO00o0O ( O0OOoOOO0oO , IiI , iiiii1I , O0OoO0ooOO0o , oOoOoOoo0 , III1ii1I , IiIIIIIi , i11oO0OoO )
elif oOOO0O000Oo == 'addon_loop' : i11Ii1iIiII ( )
elif oOOO0O000Oo == 'addon_removal_menu' : iIiII ( )
elif oOOO0O000Oo == 'addonmenu' : Oo0 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'addon_settings' : i1i1IiIiIi1Ii ( )
elif oOOO0O000Oo == 'advanced_tools' : i111I ( )
elif oOOO0O000Oo == 'backup' : BACKUP ( )
elif oOOO0O000Oo == 'backup_option' : Oo0oO00 ( )
elif oOOO0O000Oo == 'backup_restore' : oo0 ( )
elif oOOO0O000Oo == 'browse_repos' : oOo0o0O000 ( )
elif oOOO0O000Oo == 'cb_test_loop' : i11Ii1iIiII ( )
elif oOOO0O000Oo == 'CB_Menu' : i11oooOo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'check_storage' : checkPath . check ( oOoOo0OoOOoo )
elif oOOO0O000Oo == 'check_updates' : i1OOoO ( )
elif oOOO0O000Oo == 'clear_cache' : ii1IIiI1IIi ( )
elif oOOO0O000Oo == 'create_keyword' : OoOoO00o00 ( )
elif oOOO0O000Oo == 'community' : ii1I ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'community_backup' : IioOo0O ( )
elif oOOO0O000Oo == 'community_backup_2' : I111I1I ( )
elif oOOO0O000Oo == 'community_menu' : ii111I11Ii ( i1ii1iIiI1 , I1Ii )
elif oOOO0O000Oo == 'countries' : OOoooO00o0o ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'description' : iIIiOOOo00o ( O0OOoOOO0oO , i1ii1iIiI1 , OoOoO00OoOOo , i11o00Ooo , Ii1i1iI , Ooo0oo , ii1I1IiiI1ii1i , oOoO00O , I11I1I1i1i , Oo0oOO0O00 , o00OOo0o0O , I111Iii1 , i11i , O0o0O00o0o )
elif oOOO0O000Oo == 'fix_special' : oO0o0Oo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'full_backup' : ooo00o0OO ( )
elif oOOO0O000Oo == 'full_clean' : i1Iii ( )
elif oOOO0O000Oo == 'genres' : II11i1I ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'gotham' : i1iIii ( )
elif oOOO0O000Oo == 'grab_addons' : O0OoO0oooOO ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'grab_builds' : OoOiII11IiIi ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'grab_builds_premium' : Grab_Builds_Premium ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'grab_hardware' : o00OIIIIII1iI1II ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'grab_news' : IIii1 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'grab_tutorials' : oO0oOooO00oo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'guisettingsfix' : IiIII ( i1ii1iIiI1 , ooooOo00O )
elif oOOO0O000Oo == 'hardware_filter_menu' : o00o00 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'hardware_final_menu' : IIi11 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'hardware_root_menu' : ooooOOo ( )
elif oOOO0O000Oo == 'helix' : i1I11IiI ( )
elif oOOO0O000Oo == 'hide_passwords' : O0ooOo0Oooo ( )
elif oOOO0O000Oo == 'ipcheck' : I1oooO00oOOooO ( )
elif oOOO0O000Oo == 'install_content' : i1Oo000O000 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'install_from_zip' : I1Io0Oo00 ( )
elif oOOO0O000Oo == 'instructions' : I111I ( )
elif oOOO0O000Oo == 'instructions_1' : i11iI11ii ( )
elif oOOO0O000Oo == 'instructions_2' : iII1I1Ii11i1i ( )
elif oOOO0O000Oo == 'instructions_3' : iIii1i1IIi ( )
elif oOOO0O000Oo == 'instructions_4' : O00OIIIIIi1 ( )
elif oOOO0O000Oo == 'instructions_5' : iii1 ( )
elif oOOO0O000Oo == 'instructions_6' : Instructions_6 ( )
elif oOOO0O000Oo == 'keywords' : iii1iII11IiI ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'kill_xbmc' : o0OoOo00O0o0O ( )
elif oOOO0O000Oo == 'kodi_settings' : I1ii ( )
elif oOOO0O000Oo == 'local_backup' : o0OoOOOO00o0 ( )
elif oOOO0O000Oo == 'LocalGUIDialog' : iII1111IIIIiI ( )
elif oOOO0O000Oo == 'log' : iiIII1i ( )
elif oOOO0O000Oo == 'manual_search' : oOo00Oo00oO ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'manual_search_builds' : Manual_Search_Builds ( )
elif oOOO0O000Oo == 'nan_menu' : OO0oOOo0o ( )
elif oOOO0O000Oo == 'news_root_menu' : Ii1i1ii ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'news_menu' : IIiii1I1I ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'notify_msg' : IIIII11II1 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'open_system_info' : O0O0o ( )
elif oOOO0O000Oo == 'open_filemanager' : OoO00oOO00O00 ( )
elif oOOO0O000Oo == 'openelec_backup' : iI11IIi1iiI1I ( )
elif oOOO0O000Oo == 'openelec_settings' : OoOO ( )
elif oOOO0O000Oo == 'play_video' : yt . PlayVideo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'platform_menu' : OO00OoO ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'pop' : oO0O ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'register' : OoOo00oOoo0oO ( )
elif oOOO0O000Oo == 'remove_addon_data' : iIi1 ( )
elif oOOO0O000Oo == 'remove_addons' : II1IIIiiI11 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'remove_build' : Oo00O0o0 ( )
elif oOOO0O000Oo == 'remove_crash_logs' : o00oIiIiIiiI ( )
elif oOOO0O000Oo == 'remove_packages' : IiiI11iIi ( )
elif oOOO0O000Oo == 'remove_textures' : iii1II1iI1IIi ( )
elif oOOO0O000Oo == 'restore' : RESTORE ( )
elif oOOO0O000Oo == 'restore_backup' : I1I1I1 ( O0OOoOOO0oO , i1ii1iIiI1 , Ooo0oo )
elif oOOO0O000Oo == 'restore_community' : iiii1IiI1i1 ( O0OOoOOO0oO , i1ii1iIiI1 , I1Ii , Ooo0oo , oOoO00O , II1IIiiI1 , O0OOO00OOO00o )
elif oOOO0O000Oo == 'restore_local_CB' : Ii1111i11 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'restore_local_gui' : IiiiiIi11 ( )
elif oOOO0O000Oo == 'restore_local_OE' : oO0Ooo00O ( )
elif oOOO0O000Oo == 'restore_openelec' : oO0o0 ( O0OOoOOO0oO , i1ii1iIiI1 , I1Ii )
elif oOOO0O000Oo == 'restore_option' : I111II1ii11I1 ( )
elif oOOO0O000Oo == 'restore_zip' : o0O00 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'run_addon' : iiiiI1iiIi1i ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'runtest' : speedtest . runtest ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'search_addons' : OoOOoOOoOoOo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'search_builds' : oO0OO00o ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'Search_Private' : Private_Search ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'showinfo' : ii11iI1i1i1i1i ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'showinfo2' : iI111III1 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'SortBy' : oO0o000oOO ( BuildURL , type )
elif oOOO0O000Oo == 'speed_instructions' : o00ooOOo0ooO0 ( )
elif oOOO0O000Oo == 'speedtest_menu' : OOOoOOOOooOo0 ( )
elif oOOO0O000Oo == 'text_guide' : oOoooO0O0oOO ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'tools' : O00o0OO0O ( )
elif oOOO0O000Oo == 'tutorial_final_menu' : IiiIIiIii ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'tutorial_addon_menu' : oo00oo ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'tutorial_root_menu' : oO00oo ( )
elif oOOO0O000Oo == 'unhide_passwords' : OOII1iI ( )
elif oOOO0O000Oo == 'update' : OO0O000 ( )
elif oOOO0O000Oo == 'uploadlog' : oo0Oooo0O ( )
elif oOOO0O000Oo == 'user_info' : o00OooO ( )
elif oOOO0O000Oo == 'xbmc_menu' : o00oo0oO00O000 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'xbmcversion' : oOO0oo0o0ooO00 ( i1ii1iIiI1 )
elif oOOO0O000Oo == 'wipe_xbmc' : oOOooo ( oOOO0O000Oo )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
