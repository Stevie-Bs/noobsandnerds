
RIVY XBMC Repository addon for XBMC

This software is released under the GNU General Public License,
version 3 (aka, GPL-3.0), WITHOUT ANY WARRANTY, as further
described in the file "LICENSE.txt" (and also published at
<http://opensource.org/licenses/GPL-3.0>). Some code and/or resources
used within this software are also covered by the Creative Commons
Attribution-ShareAlike license [CC BY-SA], as noted in credits below.

Usage:

	Place in xbmc addons directory

Further Information:

Repository @ https://github.com/rivy/xbmc-repository.rivy.xbmc
Issues @ https://github.com/rivy/xbmc-repository.rivy.xbmc/issues

Credits: (as of 2014-01-20)

 - rivy
	Author / repository maintenance

 - Moka Project @ http://mokaproject.com
	License: Creative Commons Attribution-ShareAlike 4.0 International
	- [CC BY-SA 4.0] @ http://creativecommons.org/licenses/by-sa/4.0/legalcode
	icon.png
